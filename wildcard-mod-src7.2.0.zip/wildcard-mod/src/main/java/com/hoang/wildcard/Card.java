package com.hoang.wildcard;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class Card {
    public final String id;
    public final Rarity rarity;
    public final Item buffIcon;
    public final Item debuffIcon;
    /** Cards sharing a tag never appear together with an owned card that has the same tag. */
    public final Set<String> tags;
    /** Active skill cooldowns in seconds (v3: at most one per card; v6: only Rare and rarer cards have one). */
    public final List<Integer> skills = new ArrayList<>();
    /** Original skill number of each entry in {@link #skills}: used for texts, icons and the skill code. */
    public final List<Integer> skillOrig = new ArrayList<>();
    /** Troll debuff ids (TrollDebuffs) found among this card's debuffs. v6: trolls are ordinary debuffs. Filled by Cards. */
    public final List<String> trolls = new ArrayList<>();
    /** v6: extra data-driven buffs / debuffs (GenSpec syntax) so rarer cards have more of each (GenExtra). */
    public final List<String> xBuff = new ArrayList<>();
    public final List<String> xDebuff = new ArrayList<>();
    /** Generated cards (c41+, u61+): data-driven buff and debuff. Null for hand-made cards. */
    public GenSpec gen;
    /** Generated skill (null when the skill is hand-made in Skills/Mythic/MemeCards). */
    public GenSkill genSkill;
    /** Meme card: special roll sound. */
    public boolean meme;

    public Card(String id, Rarity rarity, Item buffIcon, Item debuffIcon, Set<String> tags) {
        this.id = id;
        this.rarity = rarity;
        this.buffIcon = buffIcon;
        this.debuffIcon = debuffIcon;
        this.tags = tags;
    }

    public Component buffName() { return Component.translatable("card.wildcard." + id + ".buff"); }
    public Component buffDesc() { return Component.translatable("card.wildcard." + id + ".buff.desc"); }
    public Component debuffName() { return Component.translatable("card.wildcard." + id + ".debuff"); }
    public Component debuffDesc() { return Component.translatable("card.wildcard." + id + ".debuff.desc"); }

    public int orig(int i) { return i >= 0 && i < skillOrig.size() ? skillOrig.get(i) : i; }
    public Component skillName(int i) { return Component.translatable("skill.wildcard." + id + "." + orig(i)); }
    public Component skillDesc(int i) { return Component.translatable("skill.wildcard." + id + "." + orig(i) + ".desc"); }
    public int skillCooldown(int i) { return i >= 0 && i < skills.size() ? skills.get(i) : 0; }

    /** Max duplicate stars. Each star: -10% cooldown, buffs +8%, debuffs -6%. */
    public static final int MAX_STARS = 5;

    public static int clampStars(int stars) { return Math.max(0, Math.min(MAX_STARS, stars)); }

    /** Cooldown in ticks after the duplicate-star reduction (at least 1 second). */
    public int cooldownTicks(int i, int stars) {
        return Math.max(20, (int) Math.round(skillCooldown(i) * 20 * (1 - 0.10 * clampStars(stars))));
    }

    /** Same in whole seconds, for tooltips. */
    public int cooldownSeconds(int i, int stars) { return Math.max(1, Math.round(cooldownTicks(i, stars) / 20f)); }

    public static double buffFactor(int stars) { return 1 + 0.08 * clampStars(stars); }

    public static double debuffFactor(int stars) { return 1 - 0.06 * clampStars(stars); }

    /** v6.1: cards without an active skill get +20% buffs per star instead, and their debuffs stay the same. */
    public double buffMul(int stars) { return skills.isEmpty() ? 1 + 0.20 * clampStars(stars) : buffFactor(stars); }

    public double debuffMul(int stars) { return skills.isEmpty() ? 1 : debuffFactor(stars); }

    /** v6.1: star colour per level: 1 white, 2 green, 3 blue, 4 purple, 5 gold. */
    public static int starColor(int stars) {
        return switch (clampStars(stars)) {
            case 1 -> 0xF0F0F0;
            case 2 -> 0x55FF55;
            case 3 -> 0x55C8FF;
            case 4 -> 0xC266FF;
            case 5 -> 0xFFC21A;
            default -> 0x9A9AA8;
        };
    }

    /** "★★★☆☆" coloured by level (filled stars only when {@code empty} is false). */
    public static Component starText(int stars, boolean empty) {
        int n = clampStars(stars);
        Component filled = Component.literal("★".repeat(n)).withStyle(s -> s.withColor(starColor(n)).withBold(n >= 5));
        if (!empty) return filled;
        return Component.empty().append(filled).append(Component.literal("☆".repeat(MAX_STARS - n)).withStyle(s -> s.withColor(0x5A5A66)));
    }

    public ItemStack buffStack() { return new ItemStack(buffIcon); }
    public ItemStack debuffStack() { return new ItemStack(debuffIcon); }

    public boolean conflictsWith(Card other) {
        if (other == this) return true;
        for (String t : tags) if (other.tags.contains(t)) return true;
        return false;
    }
}
