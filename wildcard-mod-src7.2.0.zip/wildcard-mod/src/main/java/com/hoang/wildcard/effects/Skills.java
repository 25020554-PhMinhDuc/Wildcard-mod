package com.hoang.wildcard.effects;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.*;
import java.util.function.Consumer;

import static com.hoang.wildcard.effects.Effects.*;

/**
 * Active skills of Epic+ cards. The player chooses which skills sit on G H J K L (WData.loadout).
 * Each skill has its own cooldown (seconds, from {@link Card#skills}); a skill that finds no target
 * does not go on cooldown.
 */
public final class Skills {

    public static void use(ServerPlayer p, int slot) {
        WData d = WData.get(p);
        if (slot < 0 || slot >= d.loadout.length || !d.validEntry(d.loadout[slot])) {
            actionBar(p, Component.translatable("msg.wildcard.noskill").withStyle(ChatFormatting.GRAY));
            return;
        }
        String[] e = WData.parse(d.loadout[slot]);
        String id = e[0];
        int idx = Integer.parseInt(e[1]);
        Card card = Cards.get(id);
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        String key = "sk_" + id + "_" + idx;
        long left = st.remaining(key, now);
        if (left > 0) {
            WorldEffects.actionCooldown(p, left);
            return;
        }
        if (TrollDebuffs.silenced(p)) { // Mất Sóng
            actionBar(p, Component.translatable("troll.wildcard.t25").withStyle(ChatFormatting.LIGHT_PURPLE));
            return;
        }
        int orig = card.orig(idx);
        com.hoang.wildcard.fx.Element el = com.hoang.wildcard.fx.SkillFx.of(id, orig);
        com.hoang.wildcard.fx.Fx.cur = el;
        boolean ok;
        try {
            if (card.genSkill != null) ok = GenSkills.run(p, card);
            else if (id.equals("u61") || id.equals("u62") || id.equals("u63") || id.equals("u64")) ok = MemeCards.skill(p, id);
            else ok = run(p, id, orig);
        } finally {
            com.hoang.wildcard.fx.Fx.cur = null;
        }
        if (!ok) return;
        com.hoang.wildcard.fx.Fx.cast(p, el);
        net.minecraft.sounds.SoundEvent cs = com.hoang.wildcard.ModSounds.card(id);
        if (cs != null) p.level().playSound(null, p.blockPosition(), cs, SoundSource.PLAYERS, 1f, 1f);
        Mythic.afterSkill(p, id);
        // trùng thẻ: mỗi sao giảm 10% hồi chiêu (tối đa 5 sao)
        int ticks = card.cooldownTicks(idx, d.stars.getOrDefault(id, 0));
        st.setCooldown(key, now + ticks);
        Net.toPlayer(p, new Net.Fx("cd:" + id + ":" + idx, ticks));
        actionBar(p, card.skillName(idx).copy().withStyle(s -> s.withColor(card.rarity.rgb()).withBold(true)));
    }

    /** Puts a skill that was just moved in the loadout on at least {@code ticks} of cooldown. */
    public static void swapCooldown(ServerPlayer p, String entry, int ticks) {
        String[] e = WData.parse(entry);
        if (e == null) return;
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        String key = "sk_" + e[0] + "_" + e[1];
        if (st.remaining(key, now) >= ticks) return;
        st.setCooldown(key, now + ticks);
        Net.toPlayer(p, new Net.Fx("cd:" + e[0] + ":" + e[1], ticks));
    }

    // ================================================================== helpers

    /** Mobs a damaging skill may hit: hostile mobs, or anything currently attacking the caster. */
    /** v6.1: damage type of every skill: true damage, ignores armour, protection enchantments and shields. */
    public static final net.minecraft.resources.ResourceKey<net.minecraft.world.damagesource.DamageType> TRUE_DAMAGE =
            net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.DAMAGE_TYPE,
                    new net.minecraft.resources.ResourceLocation(com.hoang.wildcard.WildcardMod.MODID, "true_damage"));

    /** Skill damage from {@code p} to {@code t}: true damage (xuyên giáp). */
    public static boolean trueHurt(ServerPlayer p, LivingEntity t, float amount) {
        var holder = p.level().registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(TRUE_DAMAGE);
        return t.hurt(new net.minecraft.world.damagesource.DamageSource(holder, p), amount);
    }

    static boolean foe(ServerPlayer p, LivingEntity le) {
        if (le == p || !le.isAlive() || le instanceof ArmorStand) return false;
        if (le instanceof Player other) { // kỹ năng trúng cả người chơi khác (khi server bật PvP)
            return !other.isSpectator() && !other.isCreative() && p.server.isPvpAllowed() && !p.isAlliedTo(other);
        }
        if (isOwnedBy(le, p)) return false;
        if (le instanceof TamableAnimal ta && ta.isOwnedBy(p)) return false;
        return true; // v6.1: kỹ năng trúng mọi mob (cả mob thụ động) và người chơi khác
    }

    static List<LivingEntity> foes(ServerPlayer p, double r) {
        return p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                x -> foe(p, x) && x.distanceToSqr(p) <= r * r);
    }

    static void forFoes(ServerPlayer p, double r, Consumer<LivingEntity> c) {
        for (LivingEntity le : foes(p, r)) c.accept(le);
    }

    /** Single target under the crosshair: a mob or another player (v6.1), never your own pet. */
    @Nullable
    static LivingEntity aim(ServerPlayer p, double range) {
        LivingEntity t = Abilities.lookTarget(p, range);
        if (t == null || !foe(p, t)) return null;
        return t;
    }

    static boolean noTarget(ServerPlayer p) {
        actionBar(p, Component.translatable("msg.wildcard.notarget").withStyle(ChatFormatting.GRAY));
        return false;
    }

    static void self(ServerPlayer p, MobEffect e, int ticks, int amp) {
        p.addEffect(new MobEffectInstance(e, ticks, amp));
    }

    static void sound(ServerPlayer p, SoundEvent s, float pitch) {
        p.level().playSound(null, p.blockPosition(), s, SoundSource.PLAYERS, 1f, pitch);
    }

    static void puff(ServerPlayer p, ParticleOptions o, int n, double spread) {
        com.hoang.wildcard.fx.Element el = com.hoang.wildcard.fx.Fx.cur;
        if (el != null) { // v4: khối 3D thay cho hạt vanilla
            com.hoang.wildcard.fx.Vfx.burst(p.serverLevel(), p.position().add(0, 1, 0), el, Math.max(0.6, Math.min(3, n / 25.0 + spread * 0.4)));
            if (spread >= 2) com.hoang.wildcard.fx.Vfx.ring(p.serverLevel(), p.position().add(0, 0.1, 0), el, spread * 1.5, 14);
            return;
        }
        p.serverLevel().sendParticles(o, p.getX(), p.getY() + 1, p.getZ(), n, spread, 0.5, spread, 0.05);
    }

    static void push(Entity e, Vec3 v) {
        e.setDeltaMovement(v);
        e.hurtMarked = true;
    }

    static Vec3 flatLook(ServerPlayer p) {
        Vec3 l = p.getLookAngle().multiply(1, 0, 1);
        return l.lengthSqr() < 1e-4 ? Vec3.directionFromRotation(0, p.getYRot()) : l.normalize();
    }

    /** No fall damage for the next {@code ticks}. */
    static void noFall(ServerPlayer p, int ticks) {
        PlayerState.get(p).time("nofall", p.level().getGameTime() + ticks);
        p.fallDistance = 0;
    }

    static void shockwave(ServerPlayer p, double r, float dmg) {
        ServerLevel level = p.serverLevel();
        forFoes(p, r, le -> {
            trueHurt(p, le, dmg);
            Vec3 away = le.position().subtract(p.position()).multiply(1, 0, 1);
            away = away.lengthSqr() < 1e-4 ? Vec3.ZERO : away.normalize();
            push(le, le.getDeltaMovement().add(away.x * 0.9, 0.5, away.z * 0.9));
        });
        level.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8f, 1.3f);
        com.hoang.wildcard.fx.Element el = com.hoang.wildcard.fx.Fx.cur != null ? com.hoang.wildcard.fx.Fx.cur : com.hoang.wildcard.fx.Element.EARTH;
        com.hoang.wildcard.fx.Fx.circle(level, p.position().add(0, 0.1, 0), el, r, 36, false);
        com.hoang.wildcard.fx.Fx.ring(level, p.position().add(0, 0.15, 0), el, r, 12);
        if (el == com.hoang.wildcard.fx.Element.EARTH || el == com.hoang.wildcard.fx.Element.FROST)
            com.hoang.wildcard.fx.Vfx.spikesAround(level, p.position(), el, r * 0.6, (int) Math.max(6, r * 3), 30);
        else com.hoang.wildcard.fx.Vfx.starburst(level, p.position().add(0, 0.8, 0), el, Math.max(1, r * 0.3));
        com.hoang.wildcard.fx.Fx.ring(level, p.position().add(0, 0.25, 0), el, r * 0.6, 9);
        com.hoang.wildcard.fx.Fx.burst(level, p.position().add(0, 0.3, 0), el, 30, 0.35);
    }

    static void whenLanded(ServerPlayer p, int maxTicks, Runnable r) {
        Scheduler.later(1, () -> {
            if (!p.isAlive()) return;
            if (p.onGround() || p.isInWater() || maxTicks <= 0) r.run();
            else whenLanded(p, maxTicks - 1, r);
        });
    }

    @Nullable
    static BlockHitResult blockLook(ServerPlayer p, double range) {
        BlockHitResult hit = p.level().clip(new ClipContext(p.getEyePosition(), p.getEyePosition().add(p.getLookAngle().scale(range)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() == HitResult.Type.MISS ? null : hit;
    }

    static Vec3 lookPoint(ServerPlayer p, double range) {
        BlockHitResult hit = blockLook(p, range);
        return hit != null ? hit.getLocation() : p.getEyePosition().add(p.getLookAngle().scale(range));
    }

    static void beam(ServerPlayer p, Vec3 to, ParticleOptions o) {
        Vec3 from = p.getEyePosition();
        Vec3 d = to.subtract(from);
        if (com.hoang.wildcard.fx.Fx.cur == null) {
            int n = (int) Math.max(2, d.length() * 2);
            for (int i = 1; i <= n; i++) {
                Vec3 at = from.add(d.scale(i / (double) n));
                p.serverLevel().sendParticles(o, at.x, at.y, at.z, 1, 0, 0, 0, 0);
            }
        } else {
            com.hoang.wildcard.fx.Fx.beam(p.serverLevel(), from.subtract(0, 0.2, 0), to, com.hoang.wildcard.fx.Fx.cur);
            com.hoang.wildcard.fx.Fx.burst(p.serverLevel(), to, com.hoang.wildcard.fx.Fx.cur, 16, 0.25);
        }
    }

    static void glowAll(ServerPlayer p, double r, int ticks, boolean onlyFoes) {
        for (LivingEntity le : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                x -> x != p && (!onlyFoes || foe(p, x)))) {
            le.addEffect(new MobEffectInstance(MobEffects.GLOWING, ticks, 0, false, false));
        }
    }

    static void clearAggro(ServerPlayer p, double r) {
        for (Mob m : p.level().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(r), x -> x.getTarget() == p)) m.setTarget(null);
    }

    /** v6.1: our own fire orb instead of the vanilla small fireball. */
    static void fireball(ServerPlayer p, float yawOffset) {
        Vec3 look = Vec3.directionFromRotation(p.getXRot(), p.getYRot() + yawOffset);
        Spells.fireOrb(p, p.getEyePosition().add(look.scale(0.8)).subtract(0, 0.2, 0), look, 6f, 0.55, null);
    }

    // ================================================================== the skills

    private static boolean run(ServerPlayer p, String id, int slot) {
        ServerLevel level = p.serverLevel();
        PlayerState st = PlayerState.get(p);
        long now = level.getGameTime();
        switch (id + ":" + slot) {
            // ---------------------------------------------------------- Hiếm
            case "r01:0" -> shockwave(p, 4, 4f);
            case "r02:0" -> {
                forFoes(p, 6, le -> le.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0)));
                clearAggro(p, 6);
                puff(p, ParticleTypes.LARGE_SMOKE, 80, 2.5);
                sound(p, SoundEvents.FIRE_EXTINGUISH, 0.7f);
            }
            case "r03:0" -> {
                if (!wall(p)) return false;
            }
            case "r04:0" -> {
                p.heal(6f);
                puff(p, ParticleTypes.HEART, 8, 0.6);
                sound(p, SoundEvents.TOTEM_USE, 1.6f);
            }
            case "r05:0" -> {
                glowAll(p, 32, 200, false);
                sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 0.6f);
            }
            case "r06:0" -> {
                for (Entity e : level.getEntities(p, p.getBoundingBox().inflate(10),
                        x -> x instanceof ItemEntity || x instanceof ExperienceOrb || (x instanceof LivingEntity le && foe(p, le)))) {
                    Vec3 pull = p.position().subtract(e.position());
                    push(e, pull.normalize().scale(Math.min(1.6, pull.length() * 0.25)).add(0, 0.25, 0));
                }
                puff(p, ParticleTypes.PORTAL, 60, 3);
                sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.5f);
            }
            case "r07:0" -> {
                LivingEntity t = aim(p, 24);
                if (t == null) return noTarget(p);
                smite(p, t, 6f);
            }
            case "r08:0" -> {
                push(p, p.getDeltaMovement().add(0, 1.0, 0));
                self(p, MobEffects.SLOW_FALLING, 120, 0);
                noFall(p, 160);
                puff(p, ParticleTypes.CLOUD, 20, 0.5);
                sound(p, SoundEvents.PHANTOM_FLAP, 1.2f);
            }
            case "r09:0" -> {
                p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 120, 0, false, false, true));
                forFoes(p, 5, le -> le.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0)));
                clearAggro(p, 24);
                puff(p, ParticleTypes.LARGE_SMOKE, 60, 1.2);
                sound(p, SoundEvents.FIRE_EXTINGUISH, 1.2f);
            }
            case "r10:0" -> {
                forFoes(p, 6, le -> {
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
                    le.setTicksFrozen(Math.max(le.getTicksFrozen(), le.getTicksRequiredToFreeze() + 100));
                });
                puff(p, ParticleTypes.SNOWFLAKE, 120, 3);
                sound(p, SoundEvents.GLASS_BREAK, 0.6f);
            }
            case "r11:0" -> {
                for (int i = 0; i < 2; i++) {
                    Wolf w = EntityType.WOLF.create(level);
                    if (w == null) continue;
                    w.moveTo(p.getX() + p.getRandom().nextGaussian(), p.getY(), p.getZ() + p.getRandom().nextGaussian(), p.getYRot(), 0);
                    w.tame(p);
                    w.getPersistentData().putUUID(OWNER_TAG, p.getUUID());
                    level.addFreshEntity(w);
                    AllyTracker.track(w, 600);
                }
                sound(p, SoundEvents.WOLF_HOWL, 1f);
            }
            case "r12:0" -> {
                ItemStack s = p.getMainHandItem();
                if (!s.isDamageableItem() || s.getDamageValue() == 0) return nothing(p);
                s.setDamageValue(Math.max(0, s.getDamageValue() - s.getMaxDamage() / 4));
                sound(p, SoundEvents.ANVIL_USE, 1.4f);
            }
            case "r13:0" -> {
                Vec3 l = flatLook(p);
                push(p, new Vec3(l.x * 2.0, 0.2, l.z * 2.0));
                puff(p, ParticleTypes.SPLASH, 40, 0.6);
                sound(p, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.2f);
            }
            case "r14:0" -> {
                if (!tongue(p)) return noTarget(p);
            }
            case "r15:0" -> {
                Vec3 l = flatLook(p);
                push(p, new Vec3(l.x * 1.7, 0.1, l.z * 1.7));
                sound(p, SoundEvents.RAVAGER_ROAR, 1.5f);
                ram(p, 10);
            }
            case "r16:0" -> {
                st.selfExplosionImmuneUntil = now + 5;
                level.explode(p, p.getX(), p.getY(), p.getZ(), 1.5f, Level.ExplosionInteraction.NONE);
                push(p, p.getDeltaMovement().add(0, 1.3, 0));
                noFall(p, 120);
            }
            case "r17:0" -> {
                LivingEntity t = aim(p, 8);
                if (!(t instanceof Mob m)) return noTarget(p);
                CombatEffects.stealDrop(p, m, p.damageSources().playerAttack(p));
            }
            case "r18:0" -> {
                p.heal(4f);
                p.getFoodData().eat(4, 0.3f);
                puff(p, ParticleTypes.HAPPY_VILLAGER, 20, 0.6);
                sound(p, SoundEvents.SWEET_BERRY_BUSH_PICK_BERRIES, 1f);
            }
            case "r19:0" -> {
                ThrownPotion tp = new ThrownPotion(level, p);
                tp.setItem(PotionUtils.setPotion(new ItemStack(Items.SPLASH_POTION), Potions.POISON));
                tp.shootFromRotation(p, p.getXRot(), p.getYRot(), -20f, 0.7f, 1f);
                level.addFreshEntity(tp);
                sound(p, SoundEvents.SPLASH_POTION_THROW, 1f);
            }
            case "r20:0" -> {
                Vec3 l = flatLook(p);
                push(p, new Vec3(-l.x * 1.8, 0.35, -l.z * 1.8));
                self(p, MobEffects.MOVEMENT_SPEED, 60, 1);
                puff(p, ParticleTypes.CLOUD, 15, 0.4);
            }
            case "r21:0" -> {
                List<LivingEntity> undead = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(8),
                        x -> x != p && x.getMobType() == MobType.UNDEAD && foe(p, x));
                for (LivingEntity le : undead) {
                    trueHurt(p, le, 6f);
                    le.setSecondsOnFire(5);
                }
                puff(p, ParticleTypes.END_ROD, 80, 4);
                sound(p, SoundEvents.BEACON_POWER_SELECT, 1.4f);
            }
            case "r22:0" -> {
                p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 160, 0, false, false, true));
                clearAggro(p, 32);
                puff(p, ParticleTypes.SQUID_INK, 40, 0.6);
                sound(p, SoundEvents.SCULK_CLICKING, 0.6f);
            }
            case "r23:0" -> {
                LivingEntity t = aim(p, 20);
                if (t == null) return noTarget(p);
                beam(p, t.getEyePosition(), ParticleTypes.SNOWFLAKE);
                trueHurt(p, t, 4f);
                t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 3));
                t.setTicksFrozen(Math.max(t.getTicksFrozen(), t.getTicksRequiredToFreeze() + 60));
                sound(p, SoundEvents.GLASS_BREAK, 1.6f);
            }
            case "r24:0" -> {
                if (p.getInventory().countItem(Items.EMERALD) < 5) {
                    actionBar(p, Component.translatable("msg.wildcard.noemerald").withStyle(ChatFormatting.RED));
                    return false;
                }
                p.getInventory().clearOrCountMatchingItems(s -> s.is(Items.EMERALD), 5, p.inventoryMenu.getCraftSlots());
                give(p, blackMarket(p));
                sound(p, SoundEvents.VILLAGER_YES, 0.8f);
            }
            case "r25:0" -> {
                forFoes(p, 8, le -> le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 0)));
                self(p, MobEffects.DAMAGE_BOOST, 120, 0);
                sound(p, SoundEvents.RAVAGER_ROAR, 1f);
            }
            // ---------------------------------------------------------- Sử thi
            case "e01:0" -> {
                fireball(p, 0);
                sound(p, SoundEvents.BLAZE_SHOOT, 1f);
            }
            case "e01:1" -> {
                forFoes(p, 5, le -> {
                    trueHurt(p, le, 4f);
                    le.setSecondsOnFire(5);
                });
                ring(p, 5, ParticleTypes.FLAME);
                sound(p, SoundEvents.BLAZE_SHOOT, 0.6f);
            }
            case "e02:0" -> {
                push(p, p.getDeltaMovement().add(0, 1.25, 0));
                noFall(p, 140);
                puff(p, ParticleTypes.CLOUD, 20, 0.4);
                sound(p, SoundEvents.SLIME_JUMP, 0.8f);
            }
            case "e02:1" -> {
                if (!p.onGround()) {
                    push(p, new Vec3(0, -2.0, 0));
                    noFall(p, 80);
                    whenLanded(p, 60, () -> shockwave(p, 4, 5f));
                } else {
                    shockwave(p, 4, 5f);
                }
            }
            case "e03:0" -> {
                IronGolem g = null;
                for (IronGolem x : level.getEntitiesOfClass(IronGolem.class, p.getBoundingBox().inflate(96), gg -> isOwnedBy(gg, p))) g = x;
                if (g == null) return noTarget(p);
                g.teleportTo(p.getX() + 1, p.getY(), p.getZ() + 1);
                g.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 0));
                sound(p, SoundEvents.IRON_GOLEM_REPAIR, 1f);
            }
            case "e03:1" -> {
                self(p, MobEffects.DAMAGE_RESISTANCE, 120, 1);
                sound(p, SoundEvents.ANVIL_PLACE, 1.4f);
            }
            case "e04:0" -> {
                if (!home(p)) return nothing(p);
            }
            case "e04:1" -> Abilities.ender(p);
            case "e05:0" -> {
                Vec3 to = lookPoint(p, 12);
                BlockHitResult hit = blockLook(p, 12);
                if (hit != null) to = Vec3.atBottomCenterOf(hit.getBlockPos().relative(hit.getDirection()));
                p.teleportTo(to.x, to.y, to.z);
                p.fallDistance = 0;
                sound(p, SoundEvents.ENDERMAN_TELEPORT, 1f);
            }
            case "e05:1" -> {
                LivingEntity t = aim(p, 24);
                if (t == null || CombatEffects.isBoss(t)) return noTarget(p);
                Vec3 a = p.position(), b = t.position();
                p.teleportTo(b.x, b.y, b.z);
                t.teleportTo(a.x, a.y, a.z);
                sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.7f);
            }
            case "e06:0" -> {
                Vec3 look = p.getLookAngle();
                Set<LivingEntity> hit = new HashSet<>();
                for (int i = 1; i <= 8; i++) {
                    Vec3 at = p.getEyePosition().add(look.scale(i));
                    level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y - 0.3, at.z, 1, 0, 0, 0, 0);
                    for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(at, at).inflate(1.0),
                            x -> x != p && !(x instanceof Player) && !isOwnedBy(x, p) && !(x instanceof TamableAnimal ta && ta.isTame()))) {
                        if (hit.add(le)) trueHurt(p, le, 6f);
                    }
                }
                sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7f);
            }
            case "e06:1" -> {
                forFoes(p, 3, le -> trueHurt(p, le, 5f));
                ring(p, 3, ParticleTypes.SWEEP_ATTACK);
                sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 1f);
            }
            case "e07:0" -> {
                Vec3 at = lookPoint(p, 32);
                Spells.fireRain(p, at, 3, 7f, 2.5); // v6.1: thiên thạch lửa riêng, không còn cầu lửa ghast
                sound(p, SoundEvents.BLAZE_SHOOT, 0.6f);
            }
            case "e07:1" -> {
                self(p, MobEffects.ABSORPTION, 200, 1);
                sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1f);
            }
            case "e08:0" -> {
                LivingEntity t = aim(p, 16);
                if (t == null || CombatEffects.isBoss(t) || t instanceof net.minecraft.world.entity.animal.Chicken) return noTarget(p);
                CombatEffects.turnIntoChicken(t);
            }
            case "e08:1" -> {
                forFoes(p, 5, le -> {
                    Vec3 away = le.position().subtract(p.position()).normalize();
                    push(le, new Vec3(away.x * 1.8, 0.6, away.z * 1.8));
                });
                ring(p, 5, ParticleTypes.CLOUD);
                sound(p, SoundEvents.CHICKEN_HURT, 0.5f);
            }
            case "e10:0" -> {
                Net.toPlayer(p, new Net.Fx("xray", 200));
                sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1.4f);
            }
            case "e10:1" -> {
                glowAll(p, 24, 200, false);
                sound(p, SoundEvents.SCULK_CLICKING, 1f);
            }
            case "e11:0" -> Abilities.fan(p);
            case "e11:1" -> {
                Vec3 l = p.getLookAngle();
                push(p, new Vec3(l.x * 2.0, Math.max(0.5, l.y * 1.5 + 0.3), l.z * 2.0));
                noFall(p, 100);
                puff(p, ParticleTypes.CLOUD, 30, 0.5);
                sound(p, SoundEvents.PHANTOM_FLAP, 1.4f);
            }
            case "e12:0" -> {
                forFoes(p, 4, le -> {
                    trueHurt(p, le, 6f);
                    le.setSecondsOnFire(4);
                });
                ring(p, 4, ParticleTypes.LAVA);
                level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.getX(), p.getY() + 0.5, p.getZ(), 1, 0, 0, 0, 0);
                sound(p, SoundEvents.GENERIC_EXPLODE, 1.2f);
            }
            case "e12:1" -> {
                self(p, MobEffects.FIRE_RESISTANCE, 200, 0);
                self(p, MobEffects.DAMAGE_BOOST, 200, 0);
                puff(p, ParticleTypes.FLAME, 30, 0.5);
            }
            case "e13:0" -> {
                if (!web(p)) return noTarget(p);
            }
            case "e13:1" -> {
                BlockHitResult hit = blockLook(p, 20);
                if (hit == null) return noTarget(p);
                Vec3 to = hit.getLocation().subtract(p.position());
                push(p, to.normalize().scale(Math.min(2.6, 0.6 + to.length() * 0.18)).add(0, 0.35, 0));
                beam(p, hit.getLocation(), ParticleTypes.WHITE_ASH);
                noFall(p, 80);
                sound(p, SoundEvents.SPIDER_STEP, 1.4f);
            }
            case "e16:0" -> {
                self(p, MobEffects.MOVEMENT_SPEED, 160, 1);
                self(p, MobEffects.DAMAGE_BOOST, 160, 0);
                sound(p, SoundEvents.WARDEN_HEARTBEAT, 1.4f);
            }
            case "e16:1" -> {
                p.heal(8f);
                puff(p, ParticleTypes.HEART, 10, 0.6);
                sound(p, SoundEvents.TOTEM_USE, 1.8f);
            }
            case "e18:0" -> {
                self(p, MobEffects.DAMAGE_RESISTANCE, 80, 2);
                sound(p, SoundEvents.SHIELD_BLOCK, 0.8f);
            }
            case "e18:1" -> {
                st.time("e18_reflect", now + 100);
                puff(p, ParticleTypes.ENCHANTED_HIT, 30, 0.6);
                sound(p, SoundEvents.ANVIL_PLACE, 1.8f);
            }
            case "e20:0" -> {
                if (!smeltInventory(p)) return nothing(p);
                sound(p, SoundEvents.BLASTFURNACE_FIRE_CRACKLE, 1f);
            }
            case "e20:1" -> {
                LivingEntity t = aim(p, 16);
                if (t == null) return noTarget(p);
                beam(p, t.getEyePosition(), ParticleTypes.FLAME);
                t.setSecondsOnFire(6);
                trueHurt(p, t, 3f);
                sound(p, SoundEvents.FIRECHARGE_USE, 1f);
            }
            // ---------------------------------------------------------- Huyền thoại
            case "l01:0" -> {
                LivingEntity t = aim(p, 32);
                if (t == null) return noTarget(p);
                smite(p, t, 8f);
            }
            case "l01:1" -> {
                List<LivingEntity> list = new ArrayList<>(foes(p, 8));
                list.sort(Comparator.comparingDouble(x -> x.distanceToSqr(p)));
                if (list.isEmpty()) return noTarget(p);
                for (int i = 0; i < Math.min(5, list.size()); i++) smite(p, list.get(i), 6f);
            }
            case "l01:2" -> {
                st.time("l01_shock", now + 160);
                puff(p, ParticleTypes.ELECTRIC_SPARK, 40, 0.6);
                sound(p, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.6f);
            }
            case "l02:0" -> {
                if (p.isCreative()) return nothing(p);
                st.flightEnd = now + 300;
                p.getAbilities().mayfly = true;
                p.getAbilities().flying = true;
                p.onUpdateAbilities();
                level.sendParticles(ParticleTypes.DRAGON_BREATH, p.getX(), p.getY() + 0.5, p.getZ(), 40, 0.5, 0.3, 0.5, 0.02);
                sound(p, SoundEvents.ENDER_DRAGON_FLAP, 1.2f);
            }
            case "l02:1" -> {
                for (float yaw : new float[]{-15f, 0f, 15f}) fireball(p, yaw);
                sound(p, SoundEvents.ENDER_DRAGON_SHOOT, 1f);
            }
            case "l02:2" -> shockwave(p, 4, 6f);
            case "l04:0" -> {
                self(p, MobEffects.REGENERATION, 100, 2);
                puff(p, ParticleTypes.HEART, 8, 0.6);
            }
            case "l04:1" -> {
                if (p.getHealth() <= 4.5f) return nothing(p);
                p.setHealth(p.getHealth() - 4f);
                self(p, MobEffects.DAMAGE_BOOST, 200, 1);
                puff(p, ParticleTypes.DAMAGE_INDICATOR, 10, 0.4);
                sound(p, SoundEvents.WITHER_HURT, 1.4f);
            }
            case "l04:2" -> {
                self(p, MobEffects.DAMAGE_RESISTANCE, 60, 3);
                puff(p, ParticleTypes.TOTEM_OF_UNDYING, 40, 0.6);
                sound(p, SoundEvents.TOTEM_USE, 1.2f);
            }
            case "l05:0" -> tunnel(p);
            case "l05:1" -> shockwave(p, 5, 6f);
            case "l05:2" -> {
                BlockHitResult hit = blockLook(p, 24);
                if (hit == null) return noTarget(p);
                Vec3 at = hit.getLocation();
                st.selfExplosionImmuneUntil = now + 5;
                level.explode(p, at.x, at.y, at.z, 3f, Level.ExplosionInteraction.TNT);
            }
            case "l20:0" -> Abilities.timeStop(p);
            case "l20:1" -> {
                for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16), x -> foe(p, x))) {
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 3));
                }
                puff(p, ParticleTypes.REVERSE_PORTAL, 80, 4);
                sound(p, SoundEvents.BEACON_DEACTIVATE, 1.4f);
            }
            case "l20:2" -> {
                Vec3 back = st.history.peekFirst();
                if (back == null) return nothing(p);
                puff(p, ParticleTypes.REVERSE_PORTAL, 40, 0.5);
                p.teleportTo(back.x, back.y, back.z);
                p.fallDistance = 0;
                p.heal(4f);
                st.history.clear();
                sound(p, SoundEvents.CHORUS_FRUIT_TELEPORT, 0.8f);
            }
            default -> {
                return Mythic.skill(p, id, slot);
            }
        }
        return true;
    }

    static boolean nothing(ServerPlayer p) {
        actionBar(p, Component.translatable("msg.wildcard.nothing").withStyle(ChatFormatting.GRAY));
        return false;
    }

    static void ring(ServerPlayer p, double r, ParticleOptions o) {
        com.hoang.wildcard.fx.Element el = com.hoang.wildcard.fx.Fx.cur;
        if (el != null) { // v4: vòng sóng phát sáng thay cho hạt vanilla
            com.hoang.wildcard.fx.Vfx.ring(p.serverLevel(), p.position().add(0, 0.15, 0), el, r, 14);
            com.hoang.wildcard.fx.Vfx.ring(p.serverLevel(), p.position().add(0, 0.6, 0), el, r * 0.7, 10);
            return;
        }
        for (int i = 0; i < 32; i++) {
            double a = i * Math.PI * 2 / 32;
            p.serverLevel().sendParticles(o, p.getX() + Math.cos(a) * r, p.getY() + 0.6, p.getZ() + Math.sin(a) * r, 1, 0, 0.1, 0, 0.01);
        }
    }

    /** Húc Đầu: the first foe touched during the dash takes 5 damage and is knocked back. */
    private static void ram(ServerPlayer p, int ticksLeft) {
        if (ticksLeft <= 0 || !p.isAlive()) return;
        for (LivingEntity le : foes(p, 1.8)) {
            trueHurt(p, le, 5f);
            Vec3 l = flatLook(p);
            push(le, new Vec3(l.x * 1.4, 0.5, l.z * 1.4));
            p.level().playSound(null, p.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.6f, 1.6f);
            return;
        }
        Scheduler.later(1, () -> ram(p, ticksLeft - 1));
    }

    private static boolean wall(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Direction f = p.getDirection();
        BlockPos base = p.blockPosition().relative(f, 2);
        Direction side = f.getClockWise();
        boolean any = false;
        for (int a = -1; a <= 1; a++) {
            for (int y = 0; y < 3; y++) {
                BlockPos q = base.relative(side, a).above(y);
                if (level.getBlockState(q).canBeReplaced()) {
                    level.setBlockAndUpdate(q, Blocks.DIRT.defaultBlockState());
                    any = true;
                }
            }
        }
        if (any) level.playSound(null, base, SoundEvents.ROOTED_DIRT_PLACE, SoundSource.PLAYERS, 1f, 0.8f);
        return any;
    }

    static boolean tongue(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Entity target = Abilities.lookTarget(p, 8);
        if (target == null || target.getBbWidth() > 1.0f) {
            ItemEntity best = null;
            double bd = 64;
            for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(8))) {
                double d = ie.distanceToSqr(p);
                if (d < bd) {
                    bd = d;
                    best = ie;
                }
            }
            target = best;
        }
        if (target == null) return false;
        Vec3 pull = p.position().subtract(target.position()).normalize().scale(1.2).add(0, 0.3, 0);
        push(target, pull);
        level.playSound(null, p.blockPosition(), SoundEvents.FROG_TONGUE, SoundSource.PLAYERS, 1f, 1f);
        return true;
    }

    private static boolean web(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        BlockHitResult hit = blockLook(p, 16);
        LivingEntity target = Abilities.lookTarget(p, 16);
        BlockPos at = target != null ? target.blockPosition() : hit == null ? null : hit.getBlockPos().relative(hit.getDirection());
        if (at == null || !level.getBlockState(at).canBeReplaced()) return false;
        level.setBlockAndUpdate(at, Blocks.COBWEB.defaultBlockState());
        BlockPos webPos = at.immutable();
        Scheduler.later(200, () -> {
            if (level.getBlockState(webPos).is(Blocks.COBWEB)) level.removeBlock(webPos, false);
        });
        level.playSound(null, p.blockPosition(), SoundEvents.SPIDER_AMBIENT, SoundSource.PLAYERS, 1f, 1.4f);
        return true;
    }

    /** Hồi Hương: back to your bed / respawn anchor (anchor charge is not used), else world spawn. */
    static boolean home(ServerPlayer p) {
        ResourceKey<Level> dim = p.getRespawnDimension();
        BlockPos pos = p.getRespawnPosition();
        ServerLevel target = p.server.getLevel(dim);
        Vec3 to = null;
        if (target != null && pos != null) {
            to = Player.findRespawnPositionAndUseSpawnBlock(target, pos, p.getRespawnAngle(), p.isRespawnForced(), true).orElse(null);
        }
        if (to == null) {
            target = p.server.overworld();
            BlockPos sp = target.getSharedSpawnPos();
            to = Vec3.atBottomCenterOf(sp);
        }
        p.teleportTo(target, to.x, to.y, to.z, p.getYRot(), p.getXRot());
        p.fallDistance = 0;
        target.playSound(null, BlockPos.containing(to), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 0.8f);
        return true;
    }

    private static final Map<Item, Item> SMELT = Map.of(
            Items.RAW_IRON, Items.IRON_INGOT,
            Items.RAW_GOLD, Items.GOLD_INGOT,
            Items.RAW_COPPER, Items.COPPER_INGOT,
            Items.ANCIENT_DEBRIS, Items.NETHERITE_SCRAP);

    private static boolean smeltInventory(ServerPlayer p) {
        boolean any = false;
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            Item out = SMELT.get(s.getItem());
            if (out != null) {
                inv.setItem(i, new ItemStack(out, s.getCount()));
                any = true;
            }
        }
        return any;
    }

    private static ItemStack blackMarket(ServerPlayer p) {
        ItemStack[] pool = {
                new ItemStack(Items.GOLDEN_APPLE, 1), new ItemStack(Items.ENDER_PEARL, 4), new ItemStack(Items.DIAMOND, 2),
                new ItemStack(Items.EXPERIENCE_BOTTLE, 8), new ItemStack(Items.IRON_INGOT, 8), new ItemStack(Items.NAME_TAG, 1),
                new ItemStack(Items.ARROW, 32), new ItemStack(Items.COOKED_BEEF, 16), new ItemStack(Items.SADDLE, 1),
                new ItemStack(Items.OBSIDIAN, 8)};
        return pool[p.getRandom().nextInt(pool.length)].copy();
    }

    /** Đào Hầm: 3x3 tunnel, 5 blocks deep, in the horizontal facing direction. */
    private static void tunnel(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Direction f = p.getDirection();
        Direction side = f.getClockWise();
        BlockPos start = p.blockPosition();
        for (int d = 1; d <= 5; d++) {
            for (int a = -1; a <= 1; a++) {
                for (int y = 0; y <= 2; y++) {
                    BlockPos q = start.relative(f, d).relative(side, a).above(y);
                    BlockState s = level.getBlockState(q);
                    float hard = s.getDestroySpeed(level, q);
                    if (s.isAir() || hard < 0 || hard > 50 || s.hasBlockEntity() || !s.getFluidState().isEmpty()) continue;
                    level.destroyBlock(q, true, p);
                }
            }
        }
        level.playSound(null, p.blockPosition(), SoundEvents.STONE_BREAK, SoundSource.PLAYERS, 1f, 0.6f);
    }

    private Skills() {}
}
