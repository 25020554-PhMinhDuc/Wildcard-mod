package com.hoang.wildcard.effects;

import com.hoang.wildcard.GenSkill;
import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.Fx;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.EvokerFangs;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.function.Consumer;

/**
 * Spell-book style skills (projectiles that fly, chain lightning, rays, breath, fangs...). Own code and visuals,
 * drawn with our element particles; every cast still shows the rune circle from Fx.cast.
 */
public final class Spells {
    /** Flying orb. Moves {@code speed} blocks per tick, can home in on {@code target}. */
    static void missile(ServerPlayer p, Element el, Vec3 from, Vec3 dir, double speed, int life, LivingEntity target,
                        Consumer<LivingEntity> onHit, Consumer<Vec3> onImpact) {
        missile(p, el, from, dir, speed, life, target, onHit, onImpact, 0.45);
    }

    /** Same, with the size of the voxel ball drawn for it. */
    static void missile(ServerPlayer p, Element el, Vec3 from, Vec3 dir, double speed, int life, LivingEntity target,
                        Consumer<LivingEntity> onHit, Consumer<Vec3> onImpact, double size) {
        ServerLevel level = p.serverLevel();
        step(p, level, el, from, dir.normalize(), speed, life, target, onHit, onImpact, com.hoang.wildcard.fx.Vfx.newId(), size);
    }

    private static void step(ServerPlayer p, ServerLevel level, Element el, Vec3 pos, Vec3 dir, double speed, int life,
                             LivingEntity target, Consumer<LivingEntity> onHit, Consumer<Vec3> onImpact, int id, double size) {
        if (life <= 0 || !p.isAlive() || p.level() != level) {
            if (onImpact != null) onImpact.accept(pos);
            return;
        }
        if (target != null && target.isAlive()) { // bám đuổi nhẹ
            Vec3 want = target.getBoundingBox().getCenter().subtract(pos).normalize();
            dir = dir.scale(0.6).add(want.scale(0.4)).normalize();
        }
        int sub = Math.max(1, (int) Math.ceil(speed / 0.5));
        for (int i = 0; i < sub; i++) {
            pos = pos.add(dir.scale(speed / sub));
            BlockPos bp = BlockPos.containing(pos);
            if (!level.getBlockState(bp).getCollisionShape(level, bp).isEmpty()) {
                Fx.burst(level, pos, el, 14, 0.2);
                if (onImpact != null) onImpact.accept(pos);
                return;
            }
            final Vec3 at = pos;
            List<LivingEntity> hit = level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(0.6), x -> Skills.foe(p, x));
            if (!hit.isEmpty()) {
                Fx.burst(level, at, el, 18, 0.25);
                onHit.accept(hit.get(0));
                if (onImpact != null) onImpact.accept(at);
                return;
            }
        }
        com.hoang.wildcard.fx.Vfx.ball(level, id, pos, dir.scale(speed), el, size, 3);
        final Vec3 np = pos, nd = dir;
        Scheduler.later(1, () -> step(p, level, el, np, nd, speed, life - 1, target, onHit, onImpact, id, size));
    }

    /** v6.1: our own fire orb (no vanilla/ghast fireball): true damage + burn on hit, small blast where it lands. */
    public static void fireOrb(ServerPlayer p, Vec3 from, Vec3 dir, float dmg, double size, LivingEntity target) {
        ServerLevel level = p.serverLevel();
        missile(p, Element.FIRE, from, dir, 1.1, 40, target, t -> {
            dmg(p, t, dmg);
            t.setSecondsOnFire(4);
        }, at -> {
            Fx.explode(level, at, Element.FIRE, 1.2 + size);
            for (LivingEntity le : around(p, at, 1.2 + size)) dmg(p, le, dmg * 0.4f);
            Fx.impact(level, at, Element.FIRE, 0.8f);
        }, size);
    }

    /** v6.1: fire meteors falling around a point (replaces the old ghast fireballs). */
    public static void fireRain(ServerPlayer p, Vec3 center, int n, float dmg, double spread) {
        ServerLevel level = p.serverLevel();
        Fx.circle(level, center.add(0, 0.1, 0), Element.FIRE, spread + 1, 32, true);
        com.hoang.wildcard.fx.Vfx.area(level, center.add(0, 0.02, 0), Element.FIRE, spread + 1, 20 + n * 6);
        for (int k = 0; k < n; k++) {
            Scheduler.later(4 + k * 6, () -> {
                if (!p.isAlive()) return;
                Vec3 hit = center.add(level.random.nextGaussian() * spread * 0.5, 0, level.random.nextGaussian() * spread * 0.5);
                Vec3 from = hit.add(-4 + level.random.nextDouble() * 8, 18, -4 + level.random.nextDouble() * 8);
                missile(p, Element.FIRE, from, hit.subtract(from), 1.2, 30, null, t -> {}, at -> {
                    Fx.explode(level, at, Element.FIRE, 2.5);
                    com.hoang.wildcard.fx.Vfx.spikesAround(level, at, Element.FIRE, 1.2, 6, 20);
                    for (LivingEntity le : around(p, at, 2.8)) {
                        dmg(p, le, dmg);
                        le.setSecondsOnFire(5);
                    }
                    Fx.impact(level, at, Element.FIRE, 1f);
                }, 0.9);
            });
        }
    }

    private static Vec3 eye(ServerPlayer p) {
        return p.getEyePosition().add(p.getLookAngle().scale(0.6)).subtract(0, 0.2, 0);
    }

    private static void dmg(ServerPlayer p, LivingEntity t, float a) {
        Skills.trueHurt(p, t, a);
    }

    /** Foes of {@code p} within {@code r} blocks of a point. */
    static List<LivingEntity> around(ServerPlayer p, Vec3 at, double r) {
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(r),
                x -> Skills.foe(p, x) && x.distanceToSqr(at) <= r * r * 1.5);
    }

    /** Foes inside a cone in front of the player. */
    static List<LivingEntity> cone(ServerPlayer p, double range, double cosHalf) {
        Vec3 look = p.getLookAngle();
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity le : Skills.foes(p, range)) {
            Vec3 to = le.getBoundingBox().getCenter().subtract(p.getEyePosition());
            if (to.lengthSqr() < 1e-4 || to.normalize().dot(look) >= cosHalf) out.add(le);
        }
        return out;
    }

    static boolean run(ServerPlayer p, GenSkill s, Element el) {
        ServerLevel level = p.serverLevel();
        float a = (float) s.a();
        switch (s.kind()) {
            case "firebolt" -> {
                missile(p, el, eye(p), p.getLookAngle(), 1.4, 30, null, t -> {
                    dmg(p, t, a);
                    t.setSecondsOnFire(5);
                }, null);
                Skills.sound(p, SoundEvents.BLAZE_SHOOT, 1.3f);
            }
            case "icicle" -> {
                missile(p, el, eye(p), p.getLookAngle(), 1.8, 25, null, t -> {
                    dmg(p, t, a);
                    t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                    t.setTicksFrozen(Math.max(t.getTicksFrozen(), t.getTicksRequiredToFreeze() + 60));
                    com.hoang.wildcard.fx.Vfx.spikesAround(level, t.position(), el, 0.9, 5, 30);
                }, null);
                Skills.sound(p, SoundEvents.GLASS_BREAK, 1.8f);
            }
            case "magic_missile" -> {
                List<LivingEntity> targets = Skills.foes(p, 20);
                targets.sort(Comparator.comparingDouble(x -> x.distanceToSqr(p)));
                for (int i = 0; i < 3; i++) {
                    LivingEntity t = targets.isEmpty() ? null : targets.get(i % targets.size());
                    Vec3 d = p.getLookAngle().add((i - 1) * 0.35, 0.25, 0);
                    final int delay = i * 3;
                    Scheduler.later(delay + 1, () -> missile(p, el, eye(p), d, 0.9, 40, t, x -> dmg(p, x, a), null));
                }
                Skills.sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f);
            }
            case "lightning_lance" -> {
                LivingEntity t = Skills.aim(p, s.b());
                if (t == null) return Skills.noTarget(p);
                Fx.zap(level, p.getEyePosition(), t.getEyePosition(), el);
                Fx.ring(level, t.position().add(0, 0.1, 0), el, 3, 10);
                Effects.lightning(level, t.position(), p, true);
                dmg(p, t, a);
            }
            case "chain_lightning" -> {
                LivingEntity t = Skills.aim(p, 20);
                if (t == null) return Skills.noTarget(p);
                Set<LivingEntity> done = new HashSet<>();
                Vec3 from = p.getEyePosition();
                float d = a;
                for (int i = 0; i < 4 && t != null; i++) {
                    Fx.zap(level, from, t.getBoundingBox().getCenter(), el);
                    dmg(p, t, d);
                    done.add(t);
                    from = t.getBoundingBox().getCenter();
                    d *= 0.8f;
                    final LivingEntity cur = t;
                    t = level.getEntitiesOfClass(LivingEntity.class, cur.getBoundingBox().inflate(6), x -> Skills.foe(p, x) && !done.contains(x))
                            .stream().min(Comparator.comparingDouble(x -> x.distanceToSqr(cur))).orElse(null);
                }
                Skills.sound(p, SoundEvents.FIREWORK_ROCKET_TWINKLE, 1.6f);
            }
            case "blood_slash" -> {
                float healed = 0;
                for (LivingEntity le : cone(p, 4.5, 0.4)) {
                    dmg(p, le, a);
                    healed += a * 0.25f;
                }
                if (healed > 0) p.heal(Math.min(6f, healed));
                Fx.slash(level, p, el, 4.5);
                for (LivingEntity le : cone(p, 4.5, 0.4)) Fx.burst(level, le.getBoundingBox().getCenter(), el, 12, 0.2);
                Skills.sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7f);
            }
            case "ray_of_frost" -> {
                Vec3 from = p.getEyePosition(), dir = p.getLookAngle();
                double len = s.b();
                Vec3 to = from.add(dir.scale(len));
                for (LivingEntity le : Skills.foes(p, len)) {
                    Vec3 c = le.getBoundingBox().getCenter();
                    double t = c.subtract(from).dot(dir);
                    if (t < 0 || t > len) continue;
                    if (from.add(dir.scale(t)).distanceTo(c) > 1.2) continue;
                    dmg(p, le, a);
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
                    le.setTicksFrozen(Math.max(le.getTicksFrozen(), le.getTicksRequiredToFreeze() + 80));
                }
                Fx.beam(level, from.subtract(0, 0.2, 0), to, el);
                com.hoang.wildcard.fx.Vfx.iceSpikes(level, p.position(), dir, el, (int) Math.min(10, len / 1.6), 40);
                Skills.sound(p, SoundEvents.POWDER_SNOW_STEP, 0.6f);
            }
            case "fang_strike" -> {
                Vec3 l = Skills.flatLook(p);
                float yaw = (float) Math.atan2(l.z, l.x);
                for (int i = 1; i <= (int) s.b(); i++) {
                    Vec3 at = p.position().add(l.scale(i * 1.25));
                    level.addFreshEntity(new EvokerFangs(level, at.x, Math.floor(p.getY()), at.z, yaw, i, p));
                    final Vec3 fa = at;
                    Scheduler.later(i, () -> Fx.motes(level, fa.add(0, 0.3, 0), el, 4, 0.2, 0.1));
                    if (i == 1) com.hoang.wildcard.fx.Vfx.iceSpikes(level, p.position(), l, el, (int) s.b(), 30);
                }
                Skills.sound(p, SoundEvents.EVOKER_PREPARE_ATTACK, 1.2f);
            }
            case "wisp" -> {
                LivingEntity t = Skills.aim(p, 24);
                if (t == null) {
                    List<LivingEntity> near = Skills.foes(p, 16);
                    t = near.isEmpty() ? null : near.get(0);
                }
                missile(p, el, eye(p), p.getLookAngle().add(0, 0.4, 0), 0.6, 80, t, x -> {
                    dmg(p, x, a);
                    p.heal(a * 0.5f);
                }, null);
                Skills.sound(p, SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM, 1.3f);
            }
            case "acid_orb" -> {
                missile(p, el, eye(p), p.getLookAngle().add(0, 0.1, 0), 1.0, 30, null, t -> dmg(p, t, a), at -> {
                    AreaEffectCloud cloud = new AreaEffectCloud(level, at.x, at.y - 0.5, at.z);
                    cloud.setOwner(p);
                    cloud.setRadius((float) s.b());
                    cloud.setDuration(100);
                    cloud.setRadiusPerTick(-0.01f);
                    cloud.setFixedColor(0x7CFC00);
                    cloud.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 1));
                    level.addFreshEntity(cloud);
                    com.hoang.wildcard.fx.Vfx.area(level, at.subtract(0, 0.5, 0), el, s.b(), 100);
                });
                Skills.sound(p, SoundEvents.SLIME_SQUISH, 0.6f);
            }
            case "breath" -> {
                for (int k = 0; k < 10; k++) {
                    Scheduler.later(k * 4, () -> {
                        if (!p.isAlive()) return;
                        Vec3 look = p.getLookAngle();
                        com.hoang.wildcard.fx.Vfx.breath(level, eye(p), look, el, 4);
                        for (LivingEntity le : cone(p, 6, 0.75)) {
                            dmg(p, le, a / 5f);
                            if (el == Element.FIRE) le.setSecondsOnFire(3);
                            else le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
                        }
                    });
                }
                Skills.sound(p, el == Element.FIRE ? SoundEvents.ENDER_DRAGON_SHOOT : SoundEvents.POWDER_SNOW_BREAK, 1f);
            }
            case "counterspell" -> {
                Skills.forFoes(p, 10, LivingEntity::removeAllEffects);
                for (MobEffectInstance e : new ArrayList<>(p.getActiveEffects())) {
                    if (e.getEffect().getCategory() == MobEffectCategory.HARMFUL) p.removeEffect(e.getEffect());
                }
                Fx.circle(level, p.position().add(0, 0.1, 0), el, 10, 48, true);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, 10, 16);
                com.hoang.wildcard.fx.Vfx.dome(level, p.position(), el, 2.5, 20);
                com.hoang.wildcard.fx.Vfx.starburst(level, p.position().add(0, 1, 0), el, 1.2);
                Skills.sound(p, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1f);
            }
            case "root" -> {
                int ticks = (int) (s.b() * 20);
                Skills.forFoes(p, 6, le -> {
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 9));
                    le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 0));
                    Fx.circle(level, le.position().add(0, 0.1, 0), el, 0.7, 8, false);
                    com.hoang.wildcard.fx.Vfx.spikesAround(level, le.position(), Element.EARTH, 0.8, 6, ticks);
                });
                Skills.sound(p, SoundEvents.ROOTED_DIRT_BREAK, 0.6f);
            }
            case "blight" -> {
                int ticks = (int) (s.b() * 20);
                Skills.forFoes(p, 8, le -> le.addEffect(new MobEffectInstance(MobEffects.WITHER, ticks, 1)));
                Fx.circle(level, p.position().add(0, 0.1, 0), el, 8, 40, true);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, 8, 16);
                com.hoang.wildcard.fx.Vfx.area(level, p.position().add(0, 0.02, 0), el, 8, ticks);
                Skills.sound(p, SoundEvents.WITHER_AMBIENT, 1.5f);
            }
            // ===== v3.3: phép mới (code riêng, cảm hứng từ sách phép) =====
            case "fireball" -> { // quả cầu lửa lớn bay chậm, nổ lan
                double r = s.b();
                missile(p, el, eye(p), p.getLookAngle(), 0.8, 40, null, t -> {}, at -> {
                    Fx.explode(level, at, el, r);
                    for (LivingEntity le : around(p, at, r)) {
                        dmg(p, le, a);
                        le.setSecondsOnFire(4);
                        Vec3 away = le.position().subtract(at).normalize();
                        Skills.push(le, le.getDeltaMovement().add(away.x * 0.6, 0.4, away.z * 0.6));
                    }
                }, 1.1);
                Skills.sound(p, SoundEvents.BLAZE_SHOOT, 0.7f);
            }
            case "starfall" -> { // mưa sao băng quanh điểm nhìn
                Vec3 center = Skills.lookPoint(p, 24);
                double r = s.b();
                for (int k = 0; k < 12; k++) {
                    Scheduler.later(k * 4, () -> {
                        if (!p.isAlive()) return;
                        Vec3 hit = center.add(level.random.nextGaussian() * r * 0.5, 0, level.random.nextGaussian() * r * 0.5);
                        Vec3 from = hit.add(-3 + level.random.nextDouble() * 6, 14, -3 + level.random.nextDouble() * 6);
                        missile(p, el, from, hit.subtract(from), 1.3, 20, null, t -> {}, at -> {
                            Fx.explode(level, at, el, 1.5);
                            for (LivingEntity le : around(p, at, 2.2)) dmg(p, le, a);
                        }, 0.7);
                    });
                }
                Fx.circle(level, center.add(0, 0.1, 0), el, r, 32, true);
                Skills.sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 0.6f);
            }
            case "black_hole" -> { // hố đen hút kẻ địch rồi sụp đổ
                Vec3 c = Skills.lookPoint(p, 16).add(0, 1.2, 0);
                double r = s.b();
                for (int k = 0; k < 30; k++) {
                    final int tick = k;
                    Scheduler.later(k * 2, () -> {
                        if (!p.isAlive()) return;
                        if (tick == 0) com.hoang.wildcard.fx.Vfx.blackHole(level, c, el, 1.3, 62);
                        for (LivingEntity le : around(p, c, r)) {
                            Vec3 pull = c.subtract(le.position()).normalize().scale(0.25);
                            Skills.push(le, le.getDeltaMovement().scale(0.5).add(pull));
                            if (tick % 5 == 0) dmg(p, le, a * 0.1f);
                        }
                        if (tick == 29) {
                            Fx.explode(level, c, el, 3);
                            for (LivingEntity le : around(p, c, 3)) dmg(p, le, a);
                        }
                    });
                }
                Skills.sound(p, SoundEvents.PORTAL_TRIGGER, 1.6f);
            }
            case "ice_shield" -> { // khiên băng: giáp + làm chậm kẻ lại gần
                int ticks = (int) (s.b() * 20);
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, ticks, 1));
                p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, ticks, Math.max(0, (int) a / 4)));
                for (int k = 0; k < ticks / 5; k++) {
                    final int tick = k;
                    Scheduler.later(k * 5, () -> {
                        if (!p.isAlive()) return;
                        Vec3 c = p.position().add(0, 1, 0);
                        for (int i = 0; i < 6; i++) { // khối băng xoay quanh người
                            double ang = tick * 0.5 + i * Math.PI / 3;
                            Vec3 at = c.add(Math.cos(ang) * 1.3, Math.sin(tick * 0.3 + i) * 0.6, Math.sin(ang) * 1.3);
                            com.hoang.wildcard.fx.Vfx.ball(level, 0, at, Vec3.ZERO, el, 0.3, 6);
                        }
                        for (LivingEntity le : around(p, c, 2.5)) {
                            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2));
                            le.setTicksFrozen(Math.max(le.getTicksFrozen(), le.getTicksRequiredToFreeze() + 20));
                        }
                    });
                }
                com.hoang.wildcard.fx.Vfx.dome(level, p.position(), el, 1.9, ticks);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, 2.5, 16);
                Skills.sound(p, SoundEvents.GLASS_PLACE, 0.6f);
            }
            case "sunbeam" -> { // cột sáng từ trời giáng xuống
                LivingEntity t = Skills.aim(p, 24);
                Vec3 hit = t != null ? t.position() : Skills.lookPoint(p, 24);
                for (int k = 0; k < 6; k++) { // báo trước
                    final int tick = k;
                    Scheduler.later(k * 2, () -> Fx.ring(level, hit.add(0, 0.1, 0), el, 2.5 - tick * 0.3, 6));
                }
                Scheduler.later(14, () -> {
                    if (!p.isAlive()) return;
                    com.hoang.wildcard.fx.Vfx.beam(level, hit.add(0, 20, 0), hit, el, 1.1, 18);
                    com.hoang.wildcard.fx.Vfx.starburst(level, hit.add(0, 0.5, 0), el, 1.6);
                    Fx.explode(level, hit.add(0, 0.3, 0), el, 2.5);
                    for (LivingEntity le : around(p, hit, 2.5)) dmg(p, le, le.isInvertedHealAndHarm() ? a * 2 : a);
                    p.heal(a * 0.25f);
                });
                Skills.sound(p, SoundEvents.BEACON_POWER_SELECT, 1.4f);
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    private Spells() {}
}
