package com.hoang.wildcard.event;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.Config;
import com.hoang.wildcard.Rarity;
import com.hoang.wildcard.RoundManager;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.advancements.FrameType;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.AdvancementEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.Set;

/**
 * Bonus cards: advancements (v6: every 3 green ones = Rare+, every purple one = Epic+), and the first kill of each boss
 * (Ender Dragon: Legendary; Wither, Warden, Elder Guardian: Epic+), once per player.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class Rewards {

    /**
     * v6: green advancements (task and goal frames) count towards a Rare+ card every 3 (config greenEvery),
     * purple ones (challenge frame) give an Epic+ card (config purpleEvery, default every 1).
     */
    @SubscribeEvent
    public static void onAdvancement(AdvancementEvent.AdvancementEarnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Advancement adv = e.getAdvancement();
        DisplayInfo display = adv.getDisplay();
        if (display == null) return; // công thức chế tạo
        if (adv.getId().getPath().startsWith("recipes/")) return;
        boolean purple = display.getFrame() == FrameType.CHALLENGE;
        String cat = purple ? "purple" : "green";
        int every = purple ? Config.ADV_PURPLE_EVERY.get() : Config.ADV_GREEN_EVERY.get();
        if (every <= 0) return;
        Rarity min = purple ? Rarity.EPIC : Rarity.RARE;
        WData d = WData.get(p);
        String key = "adv_" + cat;
        int n = d.extra.getInt(key) + 1;
        d.extra.putInt(key, n);
        d.save(p);
        Component why = Component.translatable("reward.wildcard.adv." + cat, every);
        if (n % every == 0) {
            RoundManager.giveReward(p, RoundManager.rewardCard(d, min), why);
        } else {
            p.displayClientMessage(Component.translatable("msg.wildcard.adv.progress." + cat, n % every, every), true);
        }
    }

    @SubscribeEvent
    public static void onBossDeath(LivingDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead.level().isClientSide) return;
        EntityType<?> type = dead.getType();
        String boss;
        Rarity rarity;
        boolean exact;
        double radius;
        if (type == EntityType.ENDER_DRAGON) { boss = "dragon"; rarity = Rarity.LEGENDARY; exact = true; radius = 256; }
        else if (type == EntityType.WITHER) { boss = "wither"; rarity = Rarity.EPIC; exact = false; radius = 64; }
        else if (type == EntityType.WARDEN) { boss = "warden"; rarity = Rarity.EPIC; exact = false; radius = 48; }
        else if (type == EntityType.ELDER_GUARDIAN) { boss = "elder_guardian"; rarity = Rarity.EPIC; exact = false; radius = 48; }
        else return;
        // người hạ + mọi người chơi đánh cùng ở gần
        Set<ServerPlayer> who = new HashSet<>();
        Entity src = e.getSource().getEntity();
        if (src instanceof Projectile pr) src = pr.getOwner();
        if (src instanceof TamableAnimal ta && ta.getOwner() instanceof ServerPlayer owner) src = owner;
        if (src instanceof ServerPlayer sp) who.add(sp);
        for (ServerPlayer sp : dead.getServer().getPlayerList().getPlayers()) {
            if (sp.level() == dead.level() && !sp.isSpectator() && sp.distanceToSqr(dead) <= radius * radius) who.add(sp);
        }
        for (ServerPlayer p : who) {
            WData d = WData.get(p);
            String flag = "boss_" + boss;
            if (d.extra.getBoolean(flag)) continue; // mỗi người chỉ 1 lần
            d.extra.putBoolean(flag, true);
            Card c = exact ? RoundManager.exactCard(d, rarity) : RoundManager.rewardCard(d, rarity);
            RoundManager.giveReward(p, c, Component.translatable("reward.wildcard.boss." + boss));
        }
    }

    /** v7: a monster killed by a player has a small chance (config dropChance, 0.1%) to drop a card. */
    @SubscribeEvent
    public static void onMonsterDeath(LivingDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead.level().isClientSide || !(dead instanceof net.minecraft.world.entity.monster.Enemy)) return;
        if (dead.getType() == EntityType.ENDER_DRAGON || dead.getType() == EntityType.WITHER) return; // boss có thưởng riêng
        Entity src = e.getSource().getEntity();
        if (src instanceof Projectile pr) src = pr.getOwner();
        if (src instanceof TamableAnimal ta && ta.getOwner() instanceof ServerPlayer owner) src = owner;
        if (!(src instanceof ServerPlayer p)) return;
        if (p.getRandom().nextDouble() >= Config.MOB_DROP_CHANCE.get()) return;
        Card c = RoundManager.rewardCard(WData.get(p), Rarity.COMMON);
        if (c == null) return;
        net.minecraft.world.item.ItemStack stack = com.hoang.wildcard.CardItem.of(c);
        stack.getOrCreateTag().putBoolean("drop", true);
        net.minecraft.world.entity.item.ItemEntity item = new net.minecraft.world.entity.item.ItemEntity(dead.level(), dead.getX(), dead.getY() + 0.5, dead.getZ(), stack);
        item.setGlowingTag(true);
        item.setCustomName(stack.getHoverName());
        item.setCustomNameVisible(true);
        item.setDefaultPickUpDelay();
        dead.level().addFreshEntity(item);
        dead.level().playSound(null, dead.blockPosition(), net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_RESONATE, net.minecraft.sounds.SoundSource.PLAYERS, 1.2f, 1.4f);
        p.displayClientMessage(Component.translatable("msg.wildcard.mobdrop", dead.getDisplayName()).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE), true);
    }

    /** Picking up a dropped card gives it right away (it never goes into the inventory). */
    @SubscribeEvent
    public static void onPickup(net.minecraftforge.event.entity.player.EntityItemPickupEvent e) {
        net.minecraft.world.item.ItemStack stack = e.getItem().getItem();
        if (!(stack.getItem() instanceof com.hoang.wildcard.CardItem) || !stack.hasTag() || !stack.getTag().getBoolean("drop")) return;
        e.setCanceled(true);
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Card c = com.hoang.wildcard.CardItem.card(stack);
        e.getItem().discard();
        WData d = WData.get(p);
        if (c == null || d.stars.getOrDefault(c.id, 0) >= Card.MAX_STARS) c = RoundManager.rewardCard(d, Rarity.COMMON);
        RoundManager.giveReward(p, c, Component.translatable("reward.wildcard.mobdrop"));
    }

    private Rewards() {}
}
