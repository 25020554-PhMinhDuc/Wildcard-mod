package com.hoang.wildcard.client;

import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.effects.V71Cards;
import com.hoang.wildcard.net.Net;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

/** Client half of the v7.1 cards (see effects/V71Cards). */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID, value = Dist.CLIENT)
public final class V71Client {
    private static final ResourceLocation ALT = new ResourceLocation("minecraft", "alt");
    private static final Map<Integer, Float> SIZES = new HashMap<>();
    private static final ArrayDeque<float[]> LAG = new ArrayDeque<>();
    private static float lastScale = 1f;
    private static boolean jumpWasDown, airJumpUsed, gliding;
    private static int glideSent;

    private static boolean has(String id) {
        return ClientState.has(id);
    }

    // ================================================================== body size

    public static void size(Net.Size msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (msg.scale() == 1f) SIZES.remove(msg.entity());
        else SIZES.put(msg.entity(), msg.scale());
        Entity e = mc.level.getEntity(msg.entity());
        if (e != null && e != mc.player) e.refreshDimensions();
    }

    private static float scale(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        if (e == mc.player) return V71Cards.scaleOf(mc.player);
        return SIZES.getOrDefault(e.getId(), 1f);
    }

    @SubscribeEvent
    public static void onSize(EntityEvent.Size e) {
        if (!(e.getEntity() instanceof Player p) || !p.level().isClientSide || p.tickCount < 1) return;
        float s = scale(p);
        if (s == 1f) return;
        e.setNewSize(e.getNewSize().scale(s));
        e.setNewEyeHeight(e.getNewEyeHeight() * s);
    }

    @SubscribeEvent
    public static void onRenderPre(RenderPlayerEvent.Pre e) {
        float s = scale(e.getEntity());
        if (s == 1f) return;
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.scale(s, s, s);
    }

    @SubscribeEvent
    public static void onRenderPost(RenderPlayerEvent.Post e) {
        if (scale(e.getEntity()) != 1f) e.getPoseStack().popPose();
    }

    // ================================================================== ticks

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        float s = V71Cards.scaleOf(p);
        if (s != lastScale) {
            lastScale = s;
            p.refreshDimensions();
        }
        if (has("e38")) mc.options.renderDebug = false;                                   // No F3 For You
        if (has("u209") && !mc.options.autoJump().get()) mc.options.autoJump().set(true);  // Auto Jump
        if (has("e33")) mc.level.setDayTime(18000);                                         // Màn Đêm Bất Tận
        while (ClientSetup.KEY_SAND.consumeClick()) if (has("l27")) Net.toServer(new Net.Act("sand"));
        while (ClientSetup.KEY_ADV.consumeClick()) if (mc.screen == null) mc.setScreen(new AdvProgressScreen()); // v7.2
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.START || !(e.player instanceof LocalPlayer p) || !p.level().isClientSide) return;
        Minecraft mc = Minecraft.getInstance();
        boolean jumpDown = mc.options.keyJump.isDown();
        boolean pressed = jumpDown && !jumpWasDown;
        jumpWasDown = jumpDown;
        if (p.onGround() || p.isInWater() || p.getAbilities().flying || p.isPassenger() || p.onClimbable()) {
            airJumpUsed = false;
            gliding = false;
        }
        // Nhảy 2 Lần
        if (pressed && !p.onGround() && !airJumpUsed && has("r57") && !p.isInWater() && !p.getAbilities().flying && !gliding) {
            airJumpUsed = true;
            Vec3 v = p.getDeltaMovement();
            p.setDeltaMovement(v.x, 0.42 * V71Cards.jumpMul(p), v.z);
            p.fallDistance = 0;
            for (int i = 0; i < 8; i++) p.level().addParticle(ParticleTypes.CLOUD, p.getX(), p.getY(), p.getZ(), (Math.random() - 0.5) * 0.2, 0, (Math.random() - 0.5) * 0.2);
            Net.toServer(new Net.Act("djump"));
            pressed = false;
        }
        // Kẻ Bay Lượn: nhấn nhảy khi đang rơi để lượn như Elytra
        if (pressed && has("e39") && !gliding && !p.onGround() && p.getDeltaMovement().y < 0 && !p.isInWater()) gliding = true;
        if (gliding && !has("e39")) gliding = false;
        if (gliding) {
            glide(p);
            if (glideSent++ % 10 == 0) Net.toServer(new Net.Act("glide"));
        }
    }

    /** Elytra-like flight (simplified): pitch trades height for speed. */
    private static void glide(LocalPlayer p) {
        Vec3 v = p.getDeltaMovement();
        // bỏ phần trọng lực / ma sát vanilla sẽ áp ở tick này
        v = new Vec3(v.x / 0.91, v.y / 0.98 + 0.08, v.z / 0.91);
        Vec3 look = p.getLookAngle();
        float pitch = p.getXRot() * Mth.DEG_TO_RAD;
        double hl = Math.sqrt(look.x * look.x + look.z * look.z);
        double hv = v.horizontalDistance();
        double c = Math.cos(pitch);
        c = c * c * Math.min(1.0, look.length() / 0.4);
        v = v.add(0, 0.08 * (-1 + c * 0.75), 0);
        if (v.y < 0 && hl > 0) {
            double d = v.y * -0.1 * c;
            v = v.add(look.x * d / hl, d, look.z * d / hl);
        }
        if (pitch < 0 && hl > 0) {
            double d = hv * -Mth.sin(pitch) * 0.04;
            v = v.add(-look.x * d / hl, d * 3.2, -look.z * d / hl);
        }
        if (hl > 0) v = v.add((look.x / hl * hv - v.x) * 0.1, 0, (look.z / hl * hv - v.z) * 0.1);
        v = v.multiply(0.99, 0.98, 0.99);
        // vanilla sẽ trừ trọng lực và nhân ma sát sau khi di chuyển, nên đặt trước đúng vận tốc mong muốn
        p.setDeltaMovement(v);
        p.fallDistance = 0;
    }

    // ================================================================== input

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onInput(MovementInputUpdateEvent e) {
        Player p = e.getEntity();
        Input in = e.getInput();
        // Input Lag: phím di chuyển chậm 200ms (4 tick)
        if (has("e31")) {
            LAG.addLast(new float[]{in.forwardImpulse, in.leftImpulse, in.jumping ? 1 : 0, in.up ? 1 : 0, in.down ? 1 : 0, in.left ? 1 : 0, in.right ? 1 : 0});
            if (LAG.size() > 4) {
                float[] old = LAG.removeFirst();
                in.forwardImpulse = old[0];
                in.leftImpulse = old[1];
                in.jumping = old[2] > 0;
                in.up = old[3] > 0;
                in.down = old[4] > 0;
                in.left = old[5] > 0;
                in.right = old[6] > 0;
            } else {
                in.forwardImpulse = 0;
                in.leftImpulse = 0;
                in.jumping = false;
            }
        } else LAG.clear();
        // Phòng Thủ Linh Hoạt: giơ khiên không bị chậm (vanilla nhân 0.2 ngay sau sự kiện này)
        if (has("r62") && p.isUsingItem() && p.getUseItem().canPerformAction(ToolActions.SHIELD_BLOCK)) {
            in.forwardImpulse *= 5f;
            in.leftImpulse *= 5f;
        }
    }

    // ================================================================== screen

    /** Có Thấy Tao Đang Share Màn Hình Không?: the lower the health, the blockier the screen. */
    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !has("r62")) return;
        float missing = 1f - mc.player.getHealth() / Math.max(1f, mc.player.getMaxHealth());
        if (missing < 0.15f) return;
        GuiGraphics g = e.getGuiGraphics();
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        int cell = 4 + (int) (missing * 14);
        int alpha = (int) (missing * 110);
        Random r = new Random(mc.player.tickCount / 3);
        for (int y = 0; y < h; y += cell) {
            for (int x = 0; x < w; x += cell) {
                if (r.nextFloat() > missing) continue;
                int grey = 40 + r.nextInt(120);
                int tint = r.nextInt(3);
                int col = tint == 0 ? (grey << 16) | ((grey / 2) << 8) | grey : tint == 1 ? (grey / 2 << 16) | (grey << 8) | grey : (grey << 16) | (grey << 8) | (grey / 2);
                g.fill(x, y, x + cell, y + cell, (alpha << 24) | col);
            }
        }
    }

    /** Tĩnh Lặng: mobs barely animate. */
    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre<?, ?> e) {
        if (!has("e32") || !(e.getEntity() instanceof Mob m)) return;
        m.walkAnimation.setSpeed(0f);
        m.attackAnim = 0f;
        m.oAttackAnim = 0f;
        m.yHeadRot = m.yBodyRot;
    }

    // ================================================================== enchanting table alphabet

    /** Ngữ Pháp Của Bàn Phù Phép: normal text only 30 s out of every 2.5 min. */
    private static boolean galactic() {
        Minecraft mc = Minecraft.getInstance();
        if (!has("e37") || mc.level == null) return false;
        long sec = mc.level.getGameTime() / 20;
        return sec % 150 < 120;
    }

    private static Component alt(Component c) {
        return c.copy().withStyle(Style.EMPTY.withFont(ALT));
    }

    @SubscribeEvent
    public static void onChat(ClientChatReceivedEvent e) {
        if (galactic() && e.getMessage() != null) e.setMessage(alt(e.getMessage()));
    }

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        if (!galactic()) return;
        List<Component> tip = e.getToolTip();
        for (int i = 0; i < tip.size(); i++) tip.set(i, alt(tip.get(i)));
    }

    private V71Client() {}
}
