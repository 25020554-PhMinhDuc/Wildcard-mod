package com.hoang.wildcard.fe.event.entity.player;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class AnvilRepairEvent extends PlayerEvent {
    private final ItemStack output;
    public AnvilRepairEvent(Player p, ItemStack output) { super(p); this.output = output; }
    public ItemStack getOutput() { return output; }
}
