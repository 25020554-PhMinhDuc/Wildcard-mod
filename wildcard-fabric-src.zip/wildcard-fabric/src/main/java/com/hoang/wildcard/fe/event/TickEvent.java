package com.hoang.wildcard.fe.event;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class TickEvent extends Event {
    public enum Phase { START, END }
    public enum Type { LEVEL, PLAYER, CLIENT, SERVER, RENDER }
    public final Phase phase;
    public final com.hoang.wildcard.fe.LogicalSide side;
    protected TickEvent(Phase phase, com.hoang.wildcard.fe.LogicalSide side) { this.phase = phase; this.side = side; }
    public static class PlayerTickEvent extends TickEvent {
        public final Player player;
        public PlayerTickEvent(Phase phase, Player player) { super(phase, player.level().isClientSide() ? com.hoang.wildcard.fe.LogicalSide.CLIENT : com.hoang.wildcard.fe.LogicalSide.SERVER); this.player = player; }
    }
    public static class ServerTickEvent extends TickEvent {
        private final MinecraftServer server;
        public ServerTickEvent(Phase phase, MinecraftServer server) { super(phase, com.hoang.wildcard.fe.LogicalSide.SERVER); this.server = server; }
        public MinecraftServer getServer() { return server; }
    }
    public static class ClientTickEvent extends TickEvent {
        public ClientTickEvent(Phase phase) { super(phase, com.hoang.wildcard.fe.LogicalSide.CLIENT); }
    }
    public static class LevelTickEvent extends TickEvent {
        public final Level level;
        public LevelTickEvent(Phase phase, Level level) { super(phase, level.isClientSide() ? com.hoang.wildcard.fe.LogicalSide.CLIENT : com.hoang.wildcard.fe.LogicalSide.SERVER); this.level = level; }
    }
    public static class RenderTickEvent extends TickEvent {
        public final float renderTickTime;
        public RenderTickEvent(Phase phase, float t) { super(phase, com.hoang.wildcard.fe.LogicalSide.CLIENT); renderTickTime = t; }
    }
}
