package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.living.*;
import com.hoang.wildcard.fe.eventbus.api.Event;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Shadow protected ItemStack useItem;
    @Shadow protected int useItemRemaining;
    @Shadow protected int lastHurtByPlayerMemoryTime;
    @Shadow public abstract boolean isUsingItem();
    @Shadow public abstract void stopUsingItem();

    private LivingEntity self() { return (LivingEntity) (Object) this; }

    // ---------------------------------------------------------------- damage
    @WrapOperation(method = "hurtServer", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/entity/LivingEntity;actuallyHurt(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)V"))
    private void wildcard$hurt(LivingEntity e, ServerLevel level, DamageSource src, float amount, Operation<Void> orig) {
        LivingHurtEvent ev = new LivingHurtEvent(e, src, amount);
        if (Hooks.post(ev) || ev.getAmount() <= 0) return;
        orig.call(e, level, src, ev.getAmount());
    }

    @WrapMethod(method = "causeFallDamage")
    private boolean wildcard$fall(double dist, float mult, DamageSource src, Operation<Boolean> orig) {
        if (self().level().isClientSide()) return orig.call(dist, mult, src);
        LivingFallEvent ev = new LivingFallEvent(self(), (float) dist, mult);
        if (Hooks.post(ev)) return false;
        return orig.call((double) ev.getDistance(), ev.getDamageMultiplier(), src);
    }

    @WrapMethod(method = "knockback(DDDLnet/minecraft/world/damagesource/DamageSource;FZ)V")
    private void wildcard$knockback(double strength, double x, double z, DamageSource src, float f, boolean b, Operation<Void> orig) {
        LivingKnockBackEvent ev = new LivingKnockBackEvent(self(), (float) strength);
        if (Hooks.post(ev)) return;
        orig.call((double) ev.getStrength(), x, z, src, f, b);
    }

    @Inject(method = "jumpFromGround", at = @At("TAIL"))
    private void wildcard$jump(CallbackInfo ci) {
        Hooks.post(new LivingEvent.LivingJumpEvent(self()));
    }

    @ModifyReturnValue(method = "getVisibilityPercent", at = @At("RETURN"))
    private double wildcard$visibility(double v, ServerLevel level, Entity looking) {
        LivingEvent.LivingVisibilityEvent ev = new LivingEvent.LivingVisibilityEvent(self(), looking, 1.0);
        Hooks.post(ev);
        return v * ev.getVisibilityModifier();
    }

    // ---------------------------------------------------------------- using items
    @WrapMethod(method = "startUsingItem")
    private void wildcard$startUse(InteractionHand hand, Operation<Void> orig) {
        boolean was = isUsingItem();
        orig.call(hand);
        if (was || !isUsingItem() || useItem.isEmpty()) return;
        LivingEntityUseItemEvent.Start ev = new LivingEntityUseItemEvent.Start(self(), useItem, useItemRemaining);
        if (Hooks.post(ev) || ev.getDuration() <= 0) stopUsingItem();
        else useItemRemaining = ev.getDuration();
    }

    @Inject(method = "updateUsingItem", at = @At("HEAD"), cancellable = true)
    private void wildcard$tickUse(ItemStack stack, CallbackInfo ci) {
        if (stack.isEmpty()) return;
        LivingEntityUseItemEvent.Tick ev = new LivingEntityUseItemEvent.Tick(self(), stack, useItemRemaining);
        if (Hooks.post(ev) || ev.getDuration() <= 0) { stopUsingItem(); ci.cancel(); return; }
        useItemRemaining = ev.getDuration();
    }

    @WrapOperation(method = "completeUsingItem", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/item/ItemStack;finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;"))
    private ItemStack wildcard$finishUse(ItemStack stack, Level level, LivingEntity e, Operation<ItemStack> orig) {
        ItemStack before = stack.copy();
        ItemStack result = orig.call(stack, level, e);
        LivingEntityUseItemEvent.Finish ev = new LivingEntityUseItemEvent.Finish(e, before, useItemRemaining, result);
        Hooks.post(ev);
        return ev.getResultStack();
    }

    // ---------------------------------------------------------------- drops & xp
    @Inject(method = "dropAllDeathLoot", at = @At("HEAD"))
    private void wildcard$startCapture(ServerLevel level, DamageSource src, CallbackInfo ci) {
        Hooks.CAPTURE.put(self(), new ArrayList<>());
    }

    @Inject(method = "dropAllDeathLoot", at = @At("TAIL"))
    private void wildcard$endCapture(ServerLevel level, DamageSource src, CallbackInfo ci) {
        List<ItemEntity> drops = Hooks.CAPTURE.remove(self());
        if (drops == null) return;
        LivingDropsEvent ev = new LivingDropsEvent(self(), src, drops, lastHurtByPlayerMemoryTime > 0);
        if (Hooks.post(ev)) return;
        for (ItemEntity ie : drops) level.addFreshEntity(ie);
    }

    @WrapOperation(method = "dropExperience", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/entity/ExperienceOrb;award(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/phys/Vec3;I)V"))
    private void wildcard$xp(ServerLevel level, Vec3 pos, int xp, Operation<Void> orig, ServerLevel l2, Entity killer) {
        LivingExperienceDropEvent ev = new LivingExperienceDropEvent(self(), killer instanceof Player p ? p : null, xp);
        if (Hooks.post(ev) || ev.getDroppedExperience() <= 0) return;
        orig.call(level, pos, ev.getDroppedExperience());
    }

    @WrapOperation(method = "drop", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/level/Level;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"))
    private boolean wildcard$toss(Level level, Entity item, Operation<Boolean> orig) {
        if (!level.isClientSide() && self() instanceof Player p && p.isAlive() && item instanceof ItemEntity ie
                && Hooks.post(new com.hoang.wildcard.fe.event.entity.item.ItemTossEvent(ie, p))) return false;
        return orig.call(level, item);
    }

    // ---------------------------------------------------------------- effects
    @ModifyReturnValue(method = "canBeAffected", at = @At("RETURN"))
    private boolean wildcard$applicable(boolean v, MobEffectInstance inst) {
        if (self().level().isClientSide()) return v;
        MobEffectEvent.Applicable ev = new MobEffectEvent.Applicable(self(), inst);
        Hooks.post(ev);
        return ev.getResult() == Event.Result.DEFAULT ? v : ev.getResult() == Event.Result.ALLOW;
    }

    @Inject(method = "onEffectAdded", at = @At("HEAD"))
    private void wildcard$added(MobEffectInstance inst, Entity src, CallbackInfo ci) {
        if (!self().level().isClientSide()) Hooks.post(new MobEffectEvent.Added(self(), inst));
    }
}
