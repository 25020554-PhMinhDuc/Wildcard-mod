package com.hoang.wildcard;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

import java.util.*;

/** Saved per-player wildcard data. Stored in the player's persisted NBT so it survives death and relogs. */
public final class WData {
    private static final Map<UUID, WData> CACHE = new HashMap<>();

    /** Every card the player owns (collection). */
    public final LinkedHashSet<String> cards = new LinkedHashSet<>();
    /** Owned cards that are equipped; only these give their buff, debuff and skills. At most Config.MAX_EQUIPPED. */
    public final LinkedHashSet<String> equipped = new LinkedHashSet<>();
    /** Number of cards picked so far. */
    public int round;
    /** Offers in a row without an Epic or Legendary card (old rule, off by default). */
    public int pity;
    /** Offers in a row without a Legendary (or better) / without a Mythic card. */
    public int pityLegendary, pityMythic;
    /** Duplicate copies per card (stars). */
    public final Map<String, Integer> stars = new HashMap<>();
    /** Skill loadout for G H J K L: "cardId:skillIndex" or "" per slot. */
    public final String[] loadout = {"", "", "", "", ""};
    /** Ticks until the next offer. */
    public int timer;
    public boolean choosing;
    public int choiceTicks;
    public final List<String> offer = new ArrayList<>();
    /** Free-form per-card storage (counters, cooldowns, flags). */
    public CompoundTag extra = new CompoundTag();
    /** v9: thẻ Forge 1.20.1 đã được nhập. */
    public boolean legacyDone;

    public static WData get(Player p) {
        return CACHE.computeIfAbsent(p.getUUID(), u -> load(p));
    }

    public static void unload(Player p) {
        WData d = CACHE.remove(p.getUUID());
        if (d != null) d.save(p);
    }

    public static void clearAll() {
        CACHE.clear();
    }

    /**
     * v9: thẻ từ bản Forge 1.20.1. Forge lưu trong "ForgeData", Fabric không đọc khóa đó. Lấy từ:
     * 1) save người chơi chưa bị 26.3 ghi đè (ServerPlayerMixin), hoặc
     * 2) file cũ copy vào thư mục world/wildcard-import/ (playerdata/&lt;uuid&gt;.dat của thế giới Forge cũ).
     */
    private static CompoundTag legacy(Player p) {
        CompoundTag forge = com.hoang.wildcard.fe.bridge.Hooks.LEGACY.remove(p.getUUID());
        String from = "save";
        if (!(p instanceof net.minecraft.server.level.ServerPlayer sp)) return new CompoundTag();
        if (forge == null || forge.getCompoundOrEmpty("PlayerPersisted").getCompoundOrEmpty("wildcard").isEmpty()) {
            forge = null;
            java.nio.file.Path dir = sp.level().getServer().getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("wildcard-import");
            for (String name : new String[]{p.getUUID() + ".dat", p.getUUID() + ".dat_old"}) {
                java.nio.file.Path f = dir.resolve(name);
                if (!java.nio.file.Files.isRegularFile(f)) continue;
                try {
                    CompoundTag old = net.minecraft.nbt.NbtIo.readCompressed(f, net.minecraft.nbt.NbtAccounter.unlimitedHeap());
                    forge = old.getCompoundOrEmpty("ForgeData");
                    from = f.toString();
                    java.nio.file.Files.move(f, f.resolveSibling(name + ".imported"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    break;
                } catch (Exception ex) {
                    WildcardMod.LOG.error("Wildcard: không đọc được {}", f, ex);
                }
            }
        }
        if (forge == null) return new CompoundTag();
        CompoundTag t = forge.getCompoundOrEmpty("PlayerPersisted").getCompoundOrEmpty("wildcard");
        if (!t.isEmpty()) {
            WildcardMod.LOG.info("Wildcard: đã nhập {} thẻ cũ (Forge 1.20.1) cho {} từ {}", t.getListOrEmpty("cards").size(), p.getName().getString(), from);
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal("Wildcard: đã khôi phục " + t.getListOrEmpty("cards").size() + " thẻ từ bản Forge 1.20.1")
                    .withStyle(net.minecraft.ChatFormatting.GREEN));
        }
        return t;
    }

    private static CompoundTag merge(CompoundTag cur, CompoundTag old) {
        CompoundTag r = old.copy();
        if (!cur.isEmpty()) {
            ListTag cards = r.getListOrEmpty("cards");
            java.util.Set<String> have = new java.util.HashSet<>();
            for (int i = 0; i < cards.size(); i++) have.add(cards.getStringOr(i, ""));
            ListTag cc = cur.getListOrEmpty("cards");
            for (int i = 0; i < cc.size(); i++) if (have.add(cc.getStringOr(i, ""))) cards.add(StringTag.valueOf(cc.getStringOr(i, "")));
            r.put("cards", cards);
            ListTag eq = r.getListOrEmpty("equipped");
            r.put("equipped", eq);
            CompoundTag st = r.getCompoundOrEmpty("stars");
            CompoundTag cs = cur.getCompoundOrEmpty("stars");
            for (String k : cs.keySet()) st.putInt(k, Math.max(st.getIntOr(k, 0), cs.getIntOr(k, 0)));
            r.put("stars", st);
            for (String k : new String[]{"round", "pity", "pityLegendary", "pityMythic"}) r.putInt(k, Math.max(r.getIntOr(k, 0), cur.getIntOr(k, 0)));
            r.putInt("timer", cur.getIntOr("timer", r.getIntOr("timer", 0)));
            r.putBoolean("choosing", false);
            r.remove("offer");
        }
        r.putBoolean("legacyDone", true);
        return r;
    }

    private static WData load(Player p) {
        CompoundTag root = com.hoang.wildcard.compat.MC.pdata(p).getCompoundOrEmpty("PlayerPersisted");
        CompoundTag t = root.getCompoundOrEmpty("wildcard");
        WData d = new WData();
        if (!t.getBooleanOr("legacyDone", false)) { // v9: nhập thẻ Forge 1.20.1 (gộp với thẻ đã có trên 26.3)
            CompoundTag old = legacy(p);
            if (!old.isEmpty()) t = merge(t, old);
        }
        if (t.isEmpty()) {
            d.timer = Config.ROUND_SECONDS.get() * 20;
            return d;
        }
        ListTag list = t.getListOrEmpty("cards");
        for (int i = 0; i < list.size(); i++) {
            String id = list.getStringOr(i, "");
            if (Cards.get(id) != null) d.cards.add(id);
        }
        d.round = t.getIntOr("round", 0);
        d.pity = t.getIntOr("pity", 0);
        d.pityLegendary = t.getIntOr("pityLegendary", 0);
        d.pityMythic = t.getIntOr("pityMythic", 0);
        CompoundTag st = t.getCompoundOrEmpty("stars");
        for (String k : st.keySet()) if (Cards.get(k) != null) d.stars.put(k, st.getIntOr(k, 0));
        if (t.contains("equipped")) {
            ListTag eq = t.getListOrEmpty("equipped");
            for (int i = 0; i < eq.size(); i++) if (d.cards.contains(eq.getStringOr(i, ""))) d.equipped.add(eq.getStringOr(i, ""));
        } else { // older saves: equip the first cards up to the limit
            for (String id : d.cards) if (d.equipped.size() < Config.MAX_EQUIPPED.get()) d.equipped.add(id);
        }
        ListTag lo = t.getListOrEmpty("loadout");
        for (int i = 0; i < Math.min(5, lo.size()); i++) d.loadout[i] = lo.getStringOr(i, "");
        d.cleanLoadout();
        if (java.util.Arrays.stream(d.loadout).allMatch(String::isEmpty)) { // older saves: fill with the newest skill cards
            List<String> owned = new ArrayList<>(d.cards);
            Collections.reverse(owned);
            for (String id : owned) {
                Card c = Cards.get(id);
                if (c != null && d.equipped.contains(id)) d.autoFill(c);
            }
        }
        d.timer = t.getIntOr("timer", 0);
        d.choosing = t.getBooleanOr("choosing", false);
        d.choiceTicks = t.getIntOr("choiceTicks", 0);
        ListTag off = t.getListOrEmpty("offer");
        for (int i = 0; i < off.size(); i++) d.offer.add(off.getStringOr(i, ""));
        d.extra = t.getCompoundOrEmpty("extra");
        d.legacyDone = t.getBooleanOr("legacyDone", false);
        return d;
    }

    public CompoundTag write() {
        CompoundTag t = new CompoundTag();
        ListTag list = new ListTag();
        for (String c : cards) list.add(StringTag.valueOf(c));
        t.put("cards", list);
        t.putInt("round", round);
        t.putInt("pity", pity);
        t.putInt("pityLegendary", pityLegendary);
        t.putInt("pityMythic", pityMythic);
        CompoundTag st = new CompoundTag();
        for (Map.Entry<String, Integer> e : stars.entrySet()) st.putInt(e.getKey(), e.getValue());
        t.put("stars", st);
        ListTag eq = new ListTag();
        for (String c : equipped) eq.add(StringTag.valueOf(c));
        t.put("equipped", eq);
        ListTag lo = new ListTag();
        for (String s : loadout) lo.add(StringTag.valueOf(s));
        t.put("loadout", lo);
        t.putInt("timer", timer);
        t.putBoolean("choosing", choosing);
        t.putInt("choiceTicks", choiceTicks);
        ListTag off = new ListTag();
        for (String c : offer) off.add(StringTag.valueOf(c));
        t.put("offer", off);
        t.put("extra", extra);
        if (legacyDone) t.putBoolean("legacyDone", true);
        return t;
    }

    /** Card and skill index in a loadout entry, or null when the slot is empty or no longer valid. */
    public static String[] parse(String entry) {
        if (entry == null || entry.isEmpty()) return null;
        int i = entry.lastIndexOf(':');
        if (i <= 0) return null;
        return new String[]{entry.substring(0, i), entry.substring(i + 1)};
    }

    public boolean validEntry(String entry) {
        String[] e = parse(entry);
        if (e == null || !equipped.contains(e[0])) return false;
        Card c = Cards.get(e[0]);
        try {
            int idx = Integer.parseInt(e[1]);
            return c != null && idx >= 0 && idx < c.skills.size();
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    /** Empties slots that point to cards the player no longer has. */
    public void cleanLoadout() {
        equipped.retainAll(cards);
        for (int i = 0; i < loadout.length; i++) if (!validEntry(loadout[i])) loadout[i] = "";
    }

    /** Puts a new card's skills into the empty slots, in order. */
    public void autoFill(Card c) {
        cleanLoadout();
        for (int k = 0; k < c.skills.size(); k++) {
            String entry = c.id + ":" + k;
            if (java.util.Arrays.asList(loadout).contains(entry)) continue;
            for (int i = 0; i < loadout.length; i++) {
                if (loadout[i].isEmpty()) {
                    loadout[i] = entry;
                    break;
                }
            }
        }
    }

    public boolean isFull() {
        return equipped.size() >= Config.MAX_EQUIPPED.get();
    }

    public void save(Player p) {
        CompoundTag data = com.hoang.wildcard.compat.MC.pdata(p);
        CompoundTag root = data.getCompoundOrEmpty("PlayerPersisted");
        root.put("wildcard", write());
        data.put("PlayerPersisted", root);
    }

    public void reset() {
        cards.clear();
        equipped.clear();
        round = 0;
        pity = 0;
        pityLegendary = 0;
        pityMythic = 0;
        stars.clear();
        java.util.Arrays.fill(loadout, "");
        timer = Config.ROUND_SECONDS.get() * 20;
        choosing = false;
        choiceTicks = 0;
        offer.clear();
        extra = new CompoundTag();
    }
}
