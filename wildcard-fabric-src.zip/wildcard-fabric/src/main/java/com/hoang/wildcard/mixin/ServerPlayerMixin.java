package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.PlayerContainerEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.OptionalInt;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.storage.ValueInput;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin {
    @Inject(method = "openMenu", at = @At("RETURN"))
    private void wildcard$open(MenuProvider provider, CallbackInfoReturnable<OptionalInt> cir) {
        ServerPlayer p = (ServerPlayer) (Object) this;
        if (cir.getReturnValue().isPresent() && p.containerMenu != p.inventoryMenu) Hooks.post(new PlayerContainerEvent.Open(p, p.containerMenu));
    }

    /** v9: keep the Forge 1.20.1 "ForgeData" tag (old Wildcard cards) of players whose save was not rewritten on 26.3 yet. */
    @Inject(method = "readAdditionalSaveData", at = @At("HEAD"))
    private void wildcard$legacy(ValueInput in, CallbackInfo ci) {
        ServerPlayer p = (ServerPlayer) (Object) this;
        in.read("ForgeData", CompoundTag.CODEC).ifPresent(t -> Hooks.LEGACY.put(p.getUUID(), t));
    }
}
