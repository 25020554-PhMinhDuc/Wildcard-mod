package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.PlayerContainerEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.OptionalInt;

@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin {
    @Inject(method = "openMenu", at = @At("RETURN"))
    private void wildcard$open(MenuProvider provider, CallbackInfoReturnable<OptionalInt> cir) {
        ServerPlayer p = (ServerPlayer) (Object) this;
        if (cir.getReturnValue().isPresent() && p.containerMenu != p.inventoryMenu) Hooks.post(new PlayerContainerEvent.Open(p, p.containerMenu));
    }
}
