package com.hoang.wildcard.fe.common;

import com.hoang.wildcard.fe.eventbus.api.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.Consumer;

/** Shim event bus: dispatches events (fired from Fabric callbacks and mixins) to @SubscribeEvent methods. */
public final class MinecraftForge {
    public static final Bus EVENT_BUS = new Bus();

    public static final class Bus implements IEventBus {
        private record L(Class<?> type, EventPriority prio, boolean recvCanceled, Consumer<Event> call) {}
        private final Map<Class<?>, List<L>> byType = new HashMap<>();
        private final Map<Class<?>, List<L>> cache = new HashMap<>();
        private final List<L> all = new ArrayList<>();

        private void add(L l) { all.add(l); all.sort(Comparator.comparingInt(x -> x.prio().ordinal())); cache.clear(); }

        @Override public void register(Object target) {
            boolean isStatic = target instanceof Class<?>;
            Class<?> c = isStatic ? (Class<?>) target : target.getClass();
            for (Method m : c.getDeclaredMethods()) {
                SubscribeEvent a = m.getAnnotation(SubscribeEvent.class);
                if (a == null || m.getParameterCount() != 1) continue;
                if (Modifier.isStatic(m.getModifiers()) != isStatic) continue;
                Class<?> t = m.getParameterTypes()[0];
                if (!Event.class.isAssignableFrom(t)) continue;
                m.setAccessible(true);
                Object inst = isStatic ? null : target;
                add(new L(t, a.priority(), a.receiveCanceled(), e -> {
                    try { m.invoke(inst, e); }
                    catch (InvocationTargetException ex) { throw new RuntimeException("Wildcard event " + m, ex.getCause()); }
                    catch (IllegalAccessException ex) { throw new RuntimeException(ex); }
                }));
            }
        }

        @SuppressWarnings("unchecked")
        @Override public <T extends Event> void addListener(Consumer<T> listener) {
            throw new UnsupportedOperationException("addListener without type; use addListener(Class, Consumer)");
        }

        @SuppressWarnings("unchecked")
        public <T extends Event> void addListener(Class<T> type, Consumer<T> listener) {
            add(new L(type, EventPriority.NORMAL, false, e -> listener.accept((T) e)));
        }

        private List<L> listeners(Class<?> t) {
            return cache.computeIfAbsent(t, k -> { List<L> out = new ArrayList<>(); for (L l : all) if (l.type().isAssignableFrom(k)) out.add(l); return out; });
        }

        /** Returns true when the event was canceled. */
        @Override public boolean post(Event e) {
            for (L l : listeners(e.getClass())) {
                if (e.isCanceled() && !l.recvCanceled()) continue;
                try { l.call().accept(e); }
                catch (RuntimeException ex) { com.hoang.wildcard.WildcardMod.LOG.error("Wildcard: lỗi khi xử lý sự kiện {}", e.getClass().getSimpleName(), ex); }
            }
            return e.isCanceled();
        }
    }

    private MinecraftForge() {}
}
