package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ArrowLooseEvent extends PlayerEvent {
    private final ItemStack bow; private int charge; private final boolean hasAmmo;
    public ArrowLooseEvent(Player p, ItemStack bow, Level level, int charge, boolean hasAmmo) { super(p); this.bow = bow; this.charge = charge; this.hasAmmo = hasAmmo; }
    public ItemStack getBow() { return bow; }
    public int getCharge() { return charge; }
    public void setCharge(int c) { charge = c; }
    public boolean hasAmmo() { return hasAmmo; }
    public Level getLevel() { return getEntity().level(); }
}
