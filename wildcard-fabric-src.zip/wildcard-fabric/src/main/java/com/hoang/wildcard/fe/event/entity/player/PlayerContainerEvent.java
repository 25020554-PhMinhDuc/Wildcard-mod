package com.hoang.wildcard.fe.event.entity.player;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;

public class PlayerContainerEvent extends PlayerEvent {
    private final AbstractContainerMenu menu;
    public PlayerContainerEvent(Player p, AbstractContainerMenu m) { super(p); menu = m; }
    public AbstractContainerMenu getContainer() { return menu; }
    public static class Open extends PlayerContainerEvent { public Open(Player p, AbstractContainerMenu m) { super(p, m); } }
}
