package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;

/** Collects death drops while LivingEntity.dropAllDeathLoot runs (for LivingDropsEvent). */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @WrapOperation(method = "spawnAtLocation(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity;",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"))
    private boolean wildcard$capture(ServerLevel level, Entity e, Operation<Boolean> orig) {
        List<ItemEntity> list = Hooks.CAPTURE.get((Object) this);
        if (list != null && e instanceof ItemEntity ie) { list.add(ie); return true; }
        return orig.call(level, e);
    }
}
