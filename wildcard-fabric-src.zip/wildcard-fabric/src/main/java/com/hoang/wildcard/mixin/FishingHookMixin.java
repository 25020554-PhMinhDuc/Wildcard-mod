package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.ItemFishedEvent;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(FishingHook.class)
public abstract class FishingHookMixin {
    @WrapOperation(method = "retrieve", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/level/storage/loot/LootTable;getRandomItems(Lnet/minecraft/world/level/storage/loot/LootParams;)Lit/unimi/dsi/fastutil/objects/ObjectArrayList;"))
    private ObjectArrayList<ItemStack> wildcard$fished(LootTable table, LootParams params, Operation<ObjectArrayList<ItemStack>> orig) {
        ObjectArrayList<ItemStack> items = orig.call(table, params);
        FishingHook self = (FishingHook) (Object) this;
        if (self.getPlayerOwner() == null) return items;
        ItemFishedEvent ev = new ItemFishedEvent(items, 1, self);
        boolean cancel = Hooks.post(ev);
        Hooks.rodDamage = ev.getRodDamage();
        return cancel ? new ObjectArrayList<>() : items;
    }

    @ModifyReturnValue(method = "retrieve", at = @At("RETURN"))
    private int wildcard$rodDamage(int v) {
        int d = Hooks.rodDamage;
        Hooks.rodDamage = -1;
        return d >= 0 && v > 0 ? d : v;
    }
}
