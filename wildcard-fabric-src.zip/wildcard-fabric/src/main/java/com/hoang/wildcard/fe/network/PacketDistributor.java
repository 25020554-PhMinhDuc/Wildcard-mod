package com.hoang.wildcard.fe.network;

import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import com.hoang.wildcard.fe.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/** Who a message goes to. */
public final class PacketDistributor<T> {
    public static final PacketDistributor<ServerPlayer> PLAYER = new PacketDistributor<>(p -> List.of(p));
    public static final PacketDistributor<Entity> TRACKING_ENTITY = new PacketDistributor<>(e -> new ArrayList<>(PlayerLookup.tracking(e)));
    public static final PacketDistributor<Entity> TRACKING_ENTITY_AND_SELF = new PacketDistributor<>(e -> {
        List<ServerPlayer> l = new ArrayList<>(PlayerLookup.tracking(e));
        if (e instanceof ServerPlayer sp && !l.contains(sp)) l.add(sp);
        return l;
    });
    public static final PacketDistributor<TargetPoint> NEAR = new PacketDistributor<>(t -> {
        var server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return List.of();
        ServerLevel l = server.getLevel(t.dim);
        if (l == null) return List.of();
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : l.players()) if (p.distanceToSqr(t.x, t.y, t.z) <= t.r * t.r) out.add(p);
        return out;
    });
    public static final PacketDistributor<Void> ALL = new PacketDistributor<>(v -> {
        var server = ServerLifecycleHooks.getCurrentServer();
        return server == null ? List.of() : new ArrayList<>(server.getPlayerList().getPlayers());
    });

    private final Function<T, Collection<ServerPlayer>> fn;
    private PacketDistributor(Function<T, Collection<ServerPlayer>> fn) { this.fn = fn; }

    public PacketTarget with(Supplier<T> s) { T v = s.get(); return () -> fn.apply(v); }
    public PacketTarget noArg() { return () -> fn.apply(null); }

    public interface PacketTarget { Collection<ServerPlayer> players(); }

    public static final class TargetPoint {
        final double x, y, z, r;
        final ResourceKey<Level> dim;
        public TargetPoint(double x, double y, double z, double r, ResourceKey<Level> dim) { this.x = x; this.y = y; this.z = z; this.r = r; this.dim = dim; }
    }
}
