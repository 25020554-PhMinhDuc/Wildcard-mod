package com.hoang.wildcard.fe.event.level;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ExplosionEvent extends Event {
    private final Level level; private final net.minecraft.world.level.Explosion explosion;
    public ExplosionEvent(Level level, net.minecraft.world.level.Explosion e) { this.level = level; this.explosion = e; }
    public Level getLevel() { return level; }
    public net.minecraft.world.level.Explosion getExplosion() { return explosion; }
    public static class Start extends ExplosionEvent { public Start(Level l, net.minecraft.world.level.Explosion e) { super(l, e); } }
    public static class Detonate extends ExplosionEvent {
        private final List<Entity> entities; private final List<BlockPos> blocks;
        public Detonate(Level l, net.minecraft.world.level.Explosion e, List<Entity> entities, List<BlockPos> blocks) { super(l, e); this.entities = entities; this.blocks = blocks; }
        public List<Entity> getAffectedEntities() { return entities; }
        public List<BlockPos> getAffectedBlocks() { return blocks; }
    }
}
