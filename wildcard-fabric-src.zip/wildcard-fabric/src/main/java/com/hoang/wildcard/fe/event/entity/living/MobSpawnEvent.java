package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import net.minecraft.world.level.ServerLevelAccessor;

public class MobSpawnEvent extends LivingEvent {
    private final ServerLevelAccessor level; private final double x, y, z;
    public MobSpawnEvent(Mob mob, ServerLevelAccessor level, double x, double y, double z) { super(mob); this.level = level; this.x = x; this.y = y; this.z = z; }
    @Override public Mob getEntity() { return (Mob) super.getEntity(); }
    public ServerLevelAccessor getLevel() { return level; }
    public double getX() { return x; } public double getY() { return y; } public double getZ() { return z; }
    public static class FinalizeSpawn extends MobSpawnEvent {
        private final EntitySpawnReason reason; private boolean spawnCancelled;
        public FinalizeSpawn(Mob mob, ServerLevelAccessor level, double x, double y, double z, EntitySpawnReason reason) { super(mob, level, x, y, z); this.reason = reason; }
        public EntitySpawnReason getSpawnType() { return reason; }
        public EntitySpawnReason getSpawnReason() { return reason; }
        public void setSpawnCancelled(boolean c) { spawnCancelled = c; }
        public boolean isSpawnCancelled() { return spawnCancelled; }
    }
}
