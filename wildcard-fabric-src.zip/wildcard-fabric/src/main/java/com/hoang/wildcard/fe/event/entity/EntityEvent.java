package com.hoang.wildcard.fe.event.entity;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class EntityEvent extends Event {
    private final Entity entity;
    public EntityEvent(Entity entity) { this.entity = entity; }
    public Entity getEntity() { return entity; }
    /** Size: fired from Entity.getDimensions. */
    public static class Size extends EntityEvent {
        private final Pose pose; private final EntityDimensions oldSize; private EntityDimensions newSize;
        public Size(Entity e, Pose pose, EntityDimensions size) { super(e); this.pose = pose; this.oldSize = size; this.newSize = size; }
        public Pose getPose() { return pose; }
        public EntityDimensions getOldSize() { return oldSize; }
        public EntityDimensions getNewSize() { return newSize; }
        public void setNewSize(EntityDimensions s) { newSize = s; }
        public void setNewSize(EntityDimensions s, boolean updateEyeHeight) { newSize = s; }
    }
}
