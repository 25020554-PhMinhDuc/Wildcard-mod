package com.hoang.wildcard;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import com.hoang.wildcard.fe.eventbus.api.IEventBus;
import com.hoang.wildcard.fe.registries.DeferredRegister;
import com.hoang.wildcard.fe.registries.ForgeRegistries;
import com.hoang.wildcard.fe.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> REG = DeferredRegister.create(ForgeRegistries.ITEMS, WildcardMod.MODID);
    /** Card that falls during the Card Rain event (NBT "card" = card id). */
    public static final RegistryObject<Item> CARD = REG.register("card", () -> new CardItem(new Item.Properties().setId(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ITEM, net.minecraft.resources.Identifier.fromNamespaceAndPath(WildcardMod.MODID, "card"))).stacksTo(1).rarity(Rarity.RARE)));

    public static void register(IEventBus bus) {
        REG.register(bus);
    }

    private ModItems() {}
}
