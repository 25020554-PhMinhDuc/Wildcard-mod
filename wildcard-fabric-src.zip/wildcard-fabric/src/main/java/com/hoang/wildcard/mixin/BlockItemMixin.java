package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.level.BlockEvent;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(BlockItem.class)
public abstract class BlockItemMixin {
    @ModifyReturnValue(method = "placeBlock", at = @At("RETURN"))
    private boolean wildcard$placed(boolean ok, BlockPlaceContext ctx, BlockState state) {
        if (ok && !ctx.getLevel().isClientSide() && ctx.getPlayer() != null)
            Hooks.post(new BlockEvent.EntityPlaceEvent(ctx.getLevel(), ctx.getClickedPos(), ctx.getLevel().getBlockState(ctx.getClickedPos()), ctx.getPlayer()));
        return ok;
    }
}
