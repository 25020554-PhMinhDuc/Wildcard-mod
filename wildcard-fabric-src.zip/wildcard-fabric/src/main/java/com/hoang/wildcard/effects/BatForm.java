package com.hoang.wildcard.effects;

import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.player.PlayerEvent;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;
import com.hoang.wildcard.net.Net;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * v9: M1 "Huyết Tộc" bat form. The player really becomes a bat: other clients (and the player in third person) see a vanilla
 * bat model instead of the player (armor, held item and name hidden, see client.BatClient), the hitbox shrinks, the player can
 * only fly and cannot attack, break or place blocks, or use items and entities. Skills still work (they go through key packets).
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class BatForm {
    /** Client side: entity ids of players currently in bat form (filled by {@link Net.Bat}). */
    public static final Set<Integer> CLIENT = ConcurrentHashMap.newKeySet();
    private static final String KEY = "bat_form";

    public static boolean active(Player p) {
        if (p == null) return false;
        if (p.level().isClientSide()) return CLIENT.contains(p.getId());
        return PlayerState.get(p).time(KEY) > p.level().getGameTime();
    }

    /** Fabric callbacks (both sides). Registered before the Forge-style bridge so nothing else reacts first. */
    public static void init() {
        AttackBlockCallback.EVENT.register((p, l, h, pos, dir) -> active(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        AttackEntityCallback.EVENT.register((p, l, h, e, hit) -> active(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        UseBlockCallback.EVENT.register((p, l, h, hit) -> active(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        UseItemCallback.EVENT.register((p, l, h) -> active(p) ? InteractionResult.FAIL : InteractionResult.PASS);
        UseEntityCallback.EVENT.register((p, l, h, e, hit) -> active(p) ? InteractionResult.FAIL : InteractionResult.PASS);
    }

    public static void start(ServerPlayer p, int ticks) {
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        st.time(KEY, now + ticks);
        st.flightEnd = now + ticks;
        p.stopUsingItem();
        p.getAbilities().mayfly = true;
        p.getAbilities().flying = true;
        p.onUpdateAbilities();
        AttributeInstance sc = p.getAttribute(Attributes.SCALE);
        if (sc != null) {
            sc.removeModifier(Effects.modId(KEY));
            sc.addTransientModifier(new AttributeModifier(Effects.modId(KEY), -0.6, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        broadcast(p, ticks);
    }

    public static void end(ServerPlayer p) {
        PlayerState st = PlayerState.get(p);
        st.time(KEY, 0);
        AttributeInstance sc = p.getAttribute(Attributes.SCALE);
        if (sc != null) sc.removeModifier(Effects.modId(KEY));
        broadcast(p, 0);
        p.level().sendParticles(ParticleTypes.SQUID_INK, p.getX(), p.getY() + 0.5, p.getZ(), 30, 0.4, 0.5, 0.4, 0.02);
    }

    private static void broadcast(ServerPlayer p, int ticks) {
        Net.Bat msg = new Net.Bat(p.getId(), ticks);
        for (ServerPlayer o : p.level().players()) Net.toPlayer(o, msg);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        PlayerState st = PlayerState.get(p);
        long until = st.time(KEY);
        if (until == 0) return;
        long now = p.level().getGameTime();
        if (now >= until || !p.isAlive() || p.isSpectator()) {
            end(p);
            return;
        }
        // chỉ có thể bay
        if (!p.getAbilities().flying || !p.getAbilities().mayfly) {
            p.getAbilities().mayfly = true;
            p.getAbilities().flying = true;
            p.onUpdateAbilities();
        }
        if (p.isUsingItem()) p.stopUsingItem();
        p.fallDistance = 0;
    }

    @SubscribeEvent
    public static void onTrack(PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof ServerPlayer other && e.getEntity() instanceof ServerPlayer viewer) {
            long left = PlayerState.get(other).time(KEY) - other.level().getGameTime();
            if (left > 0) Net.toPlayer(viewer, new Net.Bat(other.getId(), (int) left));
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && PlayerState.get(p).time(KEY) != 0) end(p);
    }

    @SubscribeEvent
    public static void onDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        long left = PlayerState.get(p).time(KEY) - p.level().getGameTime();
        if (left > 0) broadcast(p, (int) left);
    }

    private BatForm() {}
}
