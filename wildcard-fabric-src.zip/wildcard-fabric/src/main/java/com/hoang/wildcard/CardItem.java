package com.hoang.wildcard;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import org.jspecify.annotations.Nullable;
import java.util.List;

/** A Wildcard card as an item (Card Rain). Shows the card's name in its rarity colour. */
public class CardItem extends Item {
    public CardItem(Properties props) {
        super(props);
    }

    @Nullable
    public static Card card(ItemStack stack) {
        return com.hoang.wildcard.compat.MC.hasTag(stack) ? Cards.get(com.hoang.wildcard.compat.MC.tag(stack).getStringOr("card", "")) : null;
    }

    public static ItemStack of(Card c) {
        ItemStack s = new ItemStack(ModItems.CARD.get());
        com.hoang.wildcard.compat.MC.editTag(s, t -> t.putString("card", c.id));
        return s;
    }

    /** v6: Card Rain cards never show their rarity or content. */
    public static boolean hidden(ItemStack stack) {
        return com.hoang.wildcard.compat.MC.hasTag(stack) && com.hoang.wildcard.compat.MC.tag(stack).contains("rain");
    }

    @Override
    public Component getName(ItemStack stack) {
        Card c = card(stack);
        if (c == null) return super.getName(stack);
        if (hidden(stack)) return Component.translatable("item.wildcard.card.mystery");
        return Component.empty().append(c.rarity.displayName()).append(": ").append(c.buffName())
                .withStyle(s -> s.withColor(c.rarity.rgb()).withBold(c.rarity.ordinal() >= Rarity.EPIC.ordinal()));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        Card c = card(stack);
        return c != null && !hidden(stack) && c.rarity.ordinal() >= Rarity.EPIC.ordinal();
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, net.minecraft.world.item.component.TooltipDisplay disp, java.util.function.Consumer<Component> tipAdd, TooltipFlag flag) {
        List<Component> tip = new java.util.ArrayList<>();
        try { addTip(stack, tip); } finally { tip.forEach(tipAdd); }
    }

    private void addTip(ItemStack stack, List<Component> tip) {
        Card c = card(stack);
        if (c == null) return;
        if (hidden(stack)) {
            tip.add(Component.translatable("gui.wildcard.rain.hidden").withStyle(ChatFormatting.GRAY));
            return;
        }
        tip.add(Component.literal("+ ").append(c.buffDesc()).withStyle(ChatFormatting.GREEN));
        tip.add(Component.literal("- ").append(c.debuffDesc()).withStyle(ChatFormatting.RED));
    }
}
