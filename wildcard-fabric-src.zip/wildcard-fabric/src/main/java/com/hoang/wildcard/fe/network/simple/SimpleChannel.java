package com.hoang.wildcard.fe.network.simple;

import com.hoang.wildcard.fe.network.NetworkDirection;
import com.hoang.wildcard.fe.network.NetworkEvent;
import com.hoang.wildcard.fe.network.PacketDistributor;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Forge SimpleChannel on top of Fabric payloads: every message travels as raw bytes inside one payload type per
 * direction, prefixed by its message id.
 */
public final class SimpleChannel {
    public record Raw(CustomPacketPayload.Type<Raw> t, byte[] data) implements CustomPacketPayload {
        public Type<? extends CustomPacketPayload> type() { return t; }
    }

    public final CustomPacketPayload.Type<Raw> s2c, c2s;
    private final Map<Class<?>, Def<?>> byClass = new HashMap<>();
    private final Map<Integer, Def<?>> byId = new HashMap<>();

    record Def<T>(int id, Class<T> cls, BiConsumer<T, FriendlyByteBuf> enc, Function<FriendlyByteBuf, T> dec,
                  BiConsumer<T, Supplier<NetworkEvent.Context>> handler, NetworkDirection dir) {}

    public SimpleChannel(Identifier id) {
        s2c = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(id.getNamespace(), id.getPath() + "_s2c"));
        c2s = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(id.getNamespace(), id.getPath() + "_c2s"));
        PayloadTypeRegistry.clientboundPlay().register(s2c, codec(s2c));
        PayloadTypeRegistry.serverboundPlay().register(c2s, codec(c2s));
        ServerPlayNetworking.registerGlobalReceiver(c2s, (raw, ctx) -> receive(raw.data(), ctx.player()));
    }

    private static StreamCodec<RegistryFriendlyByteBuf, Raw> codec(CustomPacketPayload.Type<Raw> t) {
        return StreamCodec.of((buf, r) -> { buf.writeVarInt(r.data().length); buf.writeBytes(r.data()); },
                buf -> { byte[] b = new byte[buf.readVarInt()]; buf.readBytes(b); return new Raw(t, b); });
    }

    /** Decodes and runs one message (sender is null on the client). */
    @SuppressWarnings("unchecked")
    public void receive(byte[] data, ServerPlayer sender) {
        FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.wrappedBuffer(data));
        Def<Object> d = (Def<Object>) byId.get(buf.readVarInt());
        if (d == null) return;
        Object msg = d.dec().apply(buf);
        NetworkEvent.Context c = new NetworkEvent.Context(sender, d.dir());
        d.handler().accept(msg, () -> c);
    }

    @SuppressWarnings("unchecked")
    private byte[] encode(Object msg) {
        Def<Object> d = (Def<Object>) byClass.get(msg.getClass());
        if (d == null) throw new IllegalArgumentException("Unregistered message " + msg.getClass());
        FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
        buf.writeVarInt(d.id());
        d.enc().accept(msg, buf);
        byte[] out = new byte[buf.readableBytes()];
        buf.readBytes(out);
        return out;
    }

    public void send(PacketDistributor.PacketTarget target, Object msg) {
        Raw r = new Raw(s2c, encode(msg));
        for (ServerPlayer p : target.players())
            if (ServerPlayNetworking.canSend(p, s2c)) ServerPlayNetworking.send(p, r);
    }

    /** Set by the client entrypoint. */
    public static java.util.function.Consumer<CustomPacketPayload> clientSender;

    public void sendToServer(Object msg) {
        if (clientSender != null) clientSender.accept(new Raw(c2s, encode(msg)));
    }

    public <T> Builder<T> messageBuilder(Class<T> cls, int id, NetworkDirection dir) { return new Builder<>(cls, id, dir); }

    public final class Builder<T> {
        private final Class<T> cls; private final int id; private final NetworkDirection dir;
        private BiConsumer<T, FriendlyByteBuf> enc; private Function<FriendlyByteBuf, T> dec;
        private BiConsumer<T, Supplier<NetworkEvent.Context>> handler;
        Builder(Class<T> cls, int id, NetworkDirection dir) { this.cls = cls; this.id = id; this.dir = dir; }
        public Builder<T> encoder(BiConsumer<T, FriendlyByteBuf> e) { enc = e; return this; }
        public Builder<T> decoder(Function<FriendlyByteBuf, T> d) { dec = d; return this; }
        public Builder<T> consumerMainThread(BiConsumer<T, Supplier<NetworkEvent.Context>> h) { handler = h; return this; }
        public Builder<T> consumer(BiConsumer<T, Supplier<NetworkEvent.Context>> h) { handler = h; return this; }
        public void add() {
            Def<T> d = new Def<>(id, cls, enc, dec, handler, dir);
            byClass.put(cls, d); byId.put(id, d);
        }
    }
}
