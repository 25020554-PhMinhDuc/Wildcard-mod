package com.hoang.wildcard.client;


import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.net.Net;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import com.hoang.wildcard.fe.api.distmarker.Dist;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;
import org.joml.Matrix4f;

import java.util.*;

/**
 * v4 spell visuals, drawn directly in the world (no particles): chunky voxel balls (fireball style),
 * glowing lightning ribbons, beams, black holes with radiating light rays, shockwave rings and voxel shards.
 * Two passes: voxels with normal blending, glow with additive blending.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID, value = Dist.CLIENT)
public final class VfxClient {
    public static final int BALL = 0, LIGHTNING = 1, BEAM = 2, RING = 3, BLACK_HOLE = 4, BURST = 5, SLASH = 6, BREATH = 7, ICE_SPIKES = 8, PORTAL = 9, STARBURST = 10,
            PILLAR = 11, DOME = 12, VORTEX = 13, AREA = 14;

    /** Palette per element (index = Element.ordinal()): hot core .. dark edge. */
    private static final int[][] PAL = {
            {0xF6EEFF, 0xC9A0FF, 0x9A5AE0, 0x5A24A0}, // ARCANE
            {0xFFF06A, 0xFFB02E, 0xFF6A1A, 0xC8321A}, // FIRE
            {0xFFFFFF, 0xBDEEFF, 0x7FD0FF, 0x3F8FE4}, // FROST
            {0xFFFFFF, 0xD8F6FF, 0x6FE7FF, 0x2AA8FF}, // STORM
            {0xFF8080, 0xE5303C, 0xA01020, 0x5A0610}, // BLOOD
            {0xFF3CC8, 0x6A1A8A, 0x2A0C3A, 0x12061A}, // VOID
            {0xFFFBE6, 0xFFE88A, 0xFFD040, 0xE4A020}, // HOLY
            {0xC09A66, 0x8B6A3E, 0x6B4A2A, 0x3A2814}, // EARTH
            {0xFFFFFF, 0xC8FFF0, 0x8AE0CC, 0x5AA898}, // WIND
    };

    private static final Random R = new Random();
    private static final List<Fx> ACTIVE = new ArrayList<>();
    private static final Map<Integer, Fx> BALLS = new HashMap<>();
    private static final List<Shard> SHARDS = new ArrayList<>();

    private static int[] pal(int el) {
        return PAL[Math.max(0, Math.min(PAL.length - 1, el))];
    }

    // ===== nhận gói tin =====
    public static void handle(Net.Vfx m) {
        Vec3 pos = new Vec3(m.x(), m.y(), m.z());
        Vec3 v = new Vec3(m.a(), m.b(), m.c());
        if (m.kind() == BALL && m.id() != 0) { // quả cầu bay: cập nhật vị trí mỗi tick
            Fx f = BALLS.get(m.id());
            if (f == null) {
                f = new Fx(m.kind(), m.el(), pos, v, m.d(), m.life());
                BALLS.put(m.id(), f);
                ACTIVE.add(f);
            } else {
                f.trail.addFirst(f.pos);
                if (f.trail.size() > 7) f.trail.removeLast();
                f.pos = pos;
                f.vec = v;
                f.age = 0;
                f.life = m.life();
            }
            return;
        }
        Fx f = new Fx(m.kind(), m.el(), pos, v, m.d(), m.life());
        ACTIVE.add(f);
        if (m.kind() == STARBURST) {
            for (int i = 0; i < 40; i++) {
                Vec3 dir = new Vec3(R.nextGaussian(), R.nextGaussian() * 0.6, R.nextGaussian()).normalize();
                Shard s = new Shard(pos, dir.scale(0.15 + R.nextDouble() * 0.25), m.el(), 0.06f + R.nextFloat() * 0.08f, 10 + R.nextInt(10));
                s.noGravity = true;
                SHARDS.add(s);
            }
        }
        if (m.kind() == BURST) {
            int n = (int) Math.min(60, 10 + m.a() * 10);
            for (int i = 0; i < n; i++) {
                Vec3 dir = new Vec3(R.nextGaussian(), Math.abs(R.nextGaussian()) * 0.8 + 0.2, R.nextGaussian()).normalize();
                SHARDS.add(new Shard(pos, dir.scale(0.12 + R.nextDouble() * 0.12 * Math.max(1, m.a())), m.el(),
                        0.08f + R.nextFloat() * 0.12f * (float) Math.min(2.5, Math.max(0.6, m.a())), 14 + R.nextInt(12)));
            }
        }
    }

    // ===== cập nhật mỗi tick =====
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            ACTIVE.clear();
            BALLS.clear();
            SHARDS.clear();
            return;
        }
        if (mc.isPaused()) return;
        for (Iterator<Fx> it = ACTIVE.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            f.age++;
            if (f.kind == LIGHTNING && f.age % 2 == 0) f.seed = R.nextLong(); // sét chớp đổi hình
            if (f.kind == BALL && f.el == 1) { // v6.1 cầu lửa: tàn lửa bong ra, bay ngược và bốc lên
                int n = 2 + (int) (f.size * 3);
                for (int i = 0; i < n; i++) {
                    Vec3 back = f.vec.scale(-0.15).add(R.nextGaussian() * 0.04, 0.03 + R.nextDouble() * 0.06, R.nextGaussian() * 0.04);
                    Vec3 at = f.pos.add(R.nextGaussian() * f.size * 0.3, R.nextGaussian() * f.size * 0.3, R.nextGaussian() * f.size * 0.3);
                    Shard s = new Shard(at, back, f.el, 0.05f + R.nextFloat() * 0.08f * (float) Math.max(0.6, f.size), 8 + R.nextInt(8));
                    s.noGravity = true;
                    SHARDS.add(s);
                }
            }
            if (f.kind == BREATH) { // phun khối nhỏ theo hướng nhìn
                for (int i = 0; i < 6; i++) {
                    Vec3 d = f.vec.add(R.nextGaussian() * 0.15, R.nextGaussian() * 0.1, R.nextGaussian() * 0.15).normalize().scale(0.45 + R.nextDouble() * 0.2);
                    SHARDS.add(new Shard(f.pos, d, f.el, 0.12f + R.nextFloat() * 0.12f, 12 + R.nextInt(6)));
                }
            }
            if (f.kind == BLACK_HOLE && f.age % 2 == 0) { // mảnh vụn bị hút vào
                double ang = R.nextDouble() * Math.PI * 2, rr = f.size * 1.6;
                Vec3 at = f.pos.add(Math.cos(ang) * rr, R.nextGaussian() * 0.8, Math.sin(ang) * rr);
                Shard s = new Shard(at, f.pos.subtract(at).scale(0.07), f.el, 0.1f + R.nextFloat() * 0.1f, 14);
                s.noGravity = true;
                SHARDS.add(s);
            }
            if (f.kind == PILLAR) { // khối sáng bay lên trong cột
                for (int i = 0; i < 3; i++) {
                    double ang = R.nextDouble() * Math.PI * 2, rr = R.nextDouble() * f.size;
                    Shard s = new Shard(f.pos.add(Math.cos(ang) * rr, R.nextDouble() * 0.5, Math.sin(ang) * rr),
                            new Vec3(0, 0.08 + R.nextDouble() * 0.1, 0), f.el, 0.07f + R.nextFloat() * 0.08f, 16 + R.nextInt(10));
                    s.noGravity = true;
                    SHARDS.add(s);
                }
            }
            if (f.kind == VORTEX) { // khối xoáy ốc đi lên
                for (int i = 0; i < 4; i++) {
                    Shard s = new Shard(f.pos, Vec3.ZERO, f.el, 0.1f + R.nextFloat() * 0.12f, 18 + R.nextInt(8));
                    s.orbit = f.pos;
                    s.angle = R.nextDouble() * Math.PI * 2;
                    s.radius = f.size * (0.3 + R.nextDouble() * 0.7);
                    s.rise = f.vec.x / 22.0 * (0.7 + R.nextDouble() * 0.6);
                    s.noGravity = true;
                    SHARDS.add(s);
                }
            }
            if (f.kind == AREA && f.age % 2 == 0) { // bọt khối sủi lên trong vùng
                for (int i = 0; i < 3; i++) {
                    double ang = R.nextDouble() * Math.PI * 2, rr = Math.sqrt(R.nextDouble()) * f.size;
                    Shard s = new Shard(f.pos.add(Math.cos(ang) * rr, 0.05, Math.sin(ang) * rr),
                            new Vec3(R.nextGaussian() * 0.005, 0.03 + R.nextDouble() * 0.04, R.nextGaussian() * 0.005), f.el,
                            0.1f + R.nextFloat() * 0.14f, 20 + R.nextInt(14));
                    s.noGravity = true;
                    SHARDS.add(s);
                }
            }
            if (f.age >= f.life) {
                it.remove();
                if (f.kind == BALL) BALLS.values().remove(f);
            }
        }
        for (Iterator<Shard> it = SHARDS.iterator(); it.hasNext(); ) {
            Shard s = it.next();
            s.prev = s.pos;
            if (s.orbit != null) { // quỹ đạo xoáy
                s.angle += 0.35;
                s.radius *= 0.985;
                s.orbit = s.orbit.add(0, s.rise, 0);
                s.pos = s.orbit.add(Math.cos(s.angle) * s.radius, 0, Math.sin(s.angle) * s.radius);
                if (s.age == 0) s.prev = s.pos;
            } else s.pos = s.pos.add(s.vel);
            s.vel = s.noGravity ? s.vel : s.vel.scale(0.9).add(0, -0.03, 0);
            if (++s.age >= s.life) it.remove();
        }
        if (SHARDS.size() > 2000) SHARDS.subList(0, SHARDS.size() - 2000).clear();
    }

    // ===== vẽ ===== (v9: 26.3 submits custom geometry through the level render context)
    public static void render(net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext ctx) {
        if (ACTIVE.isEmpty() && SHARDS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        Vec3 cam = mc.gameRenderer.mainCamera().position();
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        long now = mc.level != null ? mc.level.getGameTime() : 0;
        var snapActive = new ArrayList<>(ACTIVE);
        var snapShards = new ArrayList<>(SHARDS);

        // lượt 1: khối voxel (cầu lửa, hố đen, mảnh vỡ)
        ctx.submitNodeCollector().submitCustomGeometry(ctx.poseStack(), net.minecraft.client.renderer.rendertype.RenderTypes.debugQuads(), (pose, bb) -> {
            Matrix4f m = pose.pose();
            for (Fx f : snapActive) {
                if (f.kind == BALL) voxelBall(bb, m, f, cam, pt, now);
                else if (f.kind == BLACK_HOLE) blackHoleCore(bb, m, f, cam, pt, now);
                else if (f.kind == ICE_SPIKES) iceSpikes(bb, m, f, cam, pt);
                else if (f.kind == PORTAL) portal(bb, m, f, cam, pt, now);
            }
            for (Shard sh : snapShards) {
                Vec3 p = lerp(sh.prev, sh.pos, pt).subtract(cam);
                float k = 1 - (sh.age + pt) / sh.life;
                int[] pl = pal(sh.el);
                cube(bb, m, (float) p.x, (float) p.y, (float) p.z, sh.size * (0.4f + 0.6f * k), pl[sh.shade], 1f);
            }
        });

        // lượt 2: ánh sáng cộng màu (sét, tia, vòng, tia sáng hố đen, quầng)
        ctx.submitNodeCollector().submitCustomGeometry(ctx.poseStack(), net.minecraft.client.renderer.rendertype.RenderTypes.lightning(), (pose, bb) -> {
            Matrix4f m = pose.pose();
            for (Fx f : snapActive) {
                float k = 1 - Math.min(1, (f.age + pt) / f.life);
                switch (f.kind) {
                    case BALL -> glowBall(bb, m, f, cam, pt);
                    case LIGHTNING -> lightning(bb, m, f, cam, k);
                    case BEAM -> beam(bb, m, f, cam, k, now, pt);
                    case RING -> ring(bb, m, f, cam, pt);
                    case BLACK_HOLE -> blackHoleRays(bb, m, f, cam, pt, now);
                    case BURST -> flash(bb, m, f, cam, pt);
                    case SLASH -> slash(bb, m, f, cam, pt);
                    case STARBURST -> starburst(bb, m, f, cam, pt, now);
                    case PILLAR -> pillar(bb, m, f, cam, pt, now);
                    case DOME -> dome(bb, m, f, cam, pt, now);
                    case VORTEX -> {
                        Vec3 c = f.pos.subtract(cam);
                        flatBand(bb, m, c.add(0, 0.05, 0), (float) f.size * 0.2f, (float) f.size * 1.1f, pal(f.el)[1], 0.35f * k, 0f);
                    }
                    case AREA -> {
                        Vec3 c = f.pos.subtract(cam);
                        float al = Math.min(1, (f.age + pt) / 6f) * Math.min(1, k * 4);
                        flatBand(bb, m, c.add(0, 0.06, 0), 0f, (float) f.size, pal(f.el)[2], 0.22f * al, 0.35f * al);
                        flatBand(bb, m, c.add(0, 0.07, 0), (float) f.size - 0.15f, (float) f.size, pal(f.el)[0], 0.6f * al, 0.6f * al);
                    }
                    case PORTAL -> billboard(bb, m, f.pos.subtract(cam), (float) f.size * 2.4f, pal(f.el)[0], 0.35f * k);
                    default -> {
                    }
                }
            }
        });
    }

    // ----- voxel -----
    private static void voxelBall(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt, long now) {
        Vec3 c = f.pos.add(f.vec.scale(pt)).subtract(cam);
        int[] pl = pal(f.el);
        float s = (float) f.size;
        float cell = Math.max(0.12f, s / 3.2f);
        Random r = new Random(f.seed + now / 2); // lửa lập lòe
        for (float[] o : f.voxels) {
            float flick = 0.85f + r.nextFloat() * 0.3f;
            int shade = Math.max(0, Math.min(3, (int) ((o[3] - 0.6f) / 0.4f * 2.2f + r.nextFloat() * 1.4f)));
            cube(bb, m, (float) c.x + o[0] * s, (float) c.y + o[1] * s, (float) c.z + o[2] * s, cell * flick, pl[shade], 1f);
        }
        if (f.el == 1) { // v6.1 cầu lửa: lõi trắng vàng nóng rực + lưỡi lửa kéo dài phía sau
            float core = s * 0.55f;
            for (int k = 0; k < 6; k++) {
                float ox = (r.nextFloat() - 0.5f) * core * 0.5f, oy = (r.nextFloat() - 0.5f) * core * 0.5f, oz = (r.nextFloat() - 0.5f) * core * 0.5f;
                cube(bb, m, (float) c.x + ox, (float) c.y + oy, (float) c.z + oz, core * (0.7f + r.nextFloat() * 0.3f), k < 2 ? 0xFFFFF4 : pl[0], 1f);
            }
            Vec3 back = f.vec.lengthSqr() < 1e-6 ? new Vec3(0, -1, 0) : f.vec.normalize().scale(-1);
            for (int k = 1; k <= 7; k++) {
                float t = k / 7f;
                Vec3 at = c.add(back.scale(s * (0.4 + t * 2.2))).add(0, t * s * 0.25, 0);
                float w = s * (0.75f - t * 0.6f) * (0.8f + r.nextFloat() * 0.4f);
                cube(bb, m, (float) at.x + (r.nextFloat() - 0.5f) * w * 0.4f, (float) at.y + (r.nextFloat() - 0.5f) * w * 0.4f,
                        (float) at.z + (r.nextFloat() - 0.5f) * w * 0.4f, w, pl[Math.min(3, (int) (t * 3.5f))], 1f - t * 0.5f);
            }
        }
        // đuôi: khối nhỏ dần phía sau
        int i = 0;
        for (Vec3 tp : f.trail) {
            i++;
            Vec3 p = tp.subtract(cam);
            float k = 1 - i / 8f;
            for (int j = 0; j < 3; j++) {
                float ox = (r.nextFloat() - 0.5f) * s * k, oy = (r.nextFloat() - 0.5f) * s * k, oz = (r.nextFloat() - 0.5f) * s * k;
                cube(bb, m, (float) p.x + ox, (float) p.y + oy, (float) p.z + oz, cell * k, pl[Math.min(3, 1 + i / 3)], 0.9f * k);
            }
        }
    }

    private static void blackHoleCore(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt, long now) {
        Vec3 c = f.pos.subtract(cam);
        float grow = Math.min(1, (f.age + pt) / 8f) * (f.age > f.life - 6 ? Math.max(0, (f.life - f.age - pt) / 6f) : 1);
        float s = (float) f.size * grow;
        if (s <= 0.01f) return;
        float cell = Math.max(0.15f, s / 4f);
        double spin = (now + pt) * 0.05;
        float cs = (float) Math.cos(spin), sn = (float) Math.sin(spin);
        for (float[] o : f.voxels) {
            float x = o[0] * cs - o[2] * sn, z = o[0] * sn + o[2] * cs;
            int col = o[3] > 0.92f ? 0x6A1A8A : 0x0A0410; // lõi đen, viền tím
            cube(bb, m, (float) c.x + x * s, (float) c.y + o[1] * s, (float) c.z + z * s, cell, col, 1f);
        }
    }

    private static void iceSpikes(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt) {
        Vec3 dir = new Vec3(f.vec.x, 0, f.vec.z);
        dir = dir.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : dir.normalize();
        Vec3 side = new Vec3(-dir.z, 0, dir.x);
        int[] pl = pal(f.el);
        float age = f.age + pt;
        for (float[] sp : f.voxels) { // {khoảng cách, lệch ngang, cao, trễ, nghiêng}
            float t = age - sp[3];
            if (t <= 0) continue;
            float rise = Math.min(1, t / 3f);
            float fade = f.age > f.life - 8 ? Math.max(0, (f.life - age) / 8f) : 1;
            float h = sp[2] * rise * fade;
            if (h <= 0.05f) continue;
            Vec3 base = f.pos.add(dir.scale(sp[0])).add(side.scale(sp[1])).subtract(cam);
            float cell = 0.32f;
            int layers = Math.max(1, (int) (h / cell * 1.0f));
            for (int i = 0; i < layers; i++) {
                float u = i / (float) layers;
                float w = 0.55f * (1 - u * 0.75f);
                Vec3 at = base.add(side.scale(sp[4] * u * h)).add(0, i * cell + cell / 2, 0);
                for (int cx = -1; cx <= 1; cx++) for (int cz = -1; cz <= 1; cz++) {
                    if (w < 0.3f && (cx != 0 || cz != 0)) continue;
                    if (Math.abs(cx) + Math.abs(cz) == 2 && w < 0.45f) continue;
                    int col = (cx == 0 && cz == 0) ? pl[2] : (i + cx + cz) % 3 == 0 ? pl[0] : pl[1];
                    cube(bb, m, (float) at.x + cx * cell * w, (float) at.y, (float) at.z + cz * cell * w, cell * Math.max(0.5f, w) * 1.05f, col, 0.88f);
                }
            }
        }
    }

    private static void portal(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt, long now) {
        Vec3 c = f.pos.subtract(cam);
        double yaw = f.vec.x;
        float age = f.age + pt;
        float open = Math.min(1, age / 6f) * (f.age > f.life - 6 ? Math.max(0, (f.life - age) / 6f) : 1);
        double rx = f.size * 0.6 * open, ry = f.size * open;
        if (ry <= 0.02) return;
        double ax = Math.cos(yaw), az = Math.sin(yaw);
        int[] pl = pal(f.el);
        Random r = new Random(f.seed);
        for (int i = 0; i < 160; i++) { // điểm ảnh xoáy ốc
            double u = r.nextDouble();
            double ang = u * 9 + age * 0.25 + r.nextDouble() * 0.3;
            double rr = 0.15 + 0.85 * u;
            double lx = Math.cos(ang) * rr * rx, ly = Math.sin(ang) * rr * ry;
            Vec3 p = c.add(ax * lx, ly, az * lx);
            int col = u > 0.85 ? pl[0] : u > 0.5 ? 0xC83CE0 : u > 0.25 ? 0x8A2AB0 : 0x2A0C3A;
            cube(bb, m, (float) p.x, (float) p.y, (float) p.z, 0.12f + (float) u * 0.06f, col, 0.95f);
        }
        { // mảnh rơi ra ở rìa
            double ang = R.nextDouble() * Math.PI * 2;
            Vec3 p = f.pos.add(ax * Math.cos(ang) * rx, Math.sin(ang) * ry, az * Math.cos(ang) * rx);
            if (R.nextInt(3) == 0) {
                Shard s = new Shard(p, new Vec3(R.nextGaussian() * 0.02, 0.03, R.nextGaussian() * 0.02), f.el, 0.07f, 12);
                s.noGravity = true;
                SHARDS.add(s);
            }
        }
    }

    // ----- glow -----
    private static void starburst(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt, long now) {
        float t = Math.min(1, (f.age + pt) / f.life);
        Vec3 c = f.pos.subtract(cam);
        int[] pl = pal(f.el);
        Random r = new Random(f.seed);
        float al = t < 0.3f ? 1 : (1 - t) / 0.7f;
        for (int i = 0; i < 14; i++) { // chùm tia sáng bắn tỏa
            double yaw = r.nextDouble() * Math.PI * 2, pitch = (r.nextDouble() - 0.3) * 0.9;
            Vec3 dir = new Vec3(Math.cos(pitch) * Math.cos(yaw), Math.sin(pitch), Math.cos(pitch) * Math.sin(yaw));
            float len = (float) f.size * (1.5f + r.nextFloat() * 2f) * Math.min(1, t * 4);
            ray(bb, m, c, c.add(dir.scale(len)), (float) f.size * 0.35f, pl[1], 0.6f * al);
            ray(bb, m, c, c.add(dir.scale(len * 0.9)), (float) f.size * 0.12f, pl[0], 0.9f * al);
        }
        billboard(bb, m, c, (float) f.size * 2.5f, pl[1], 0.6f * al);
    }

    private static void pillar(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt, long now) {
        float t = Math.min(1, (f.age + pt) / f.life);
        float al = t < 0.15f ? t / 0.15f : (1 - t) / 0.85f;
        Vec3 c = f.pos.subtract(cam);
        int[] pl = pal(f.el);
        float h = (float) f.vec.x * Math.min(1, t * 5);
        float w = (float) f.size * (1 + 0.1f * (float) Math.sin((now + pt) * 0.8));
        // cột mờ dần lên trên: vẽ từng đoạn với alpha giảm
        int n = 6;
        for (int i = 0; i < n; i++) {
            Vec3 a = c.add(0, h * i / n, 0), b = c.add(0, h * (i + 1) / n, 0);
            float a0 = al * (1 - i / (float) n), a1 = al * (1 - (i + 1) / (float) n);
            ribbonFade(bb, m, a, b, w * 2.2f, pl[2], 0.3f * a0, 0.3f * a1);
            ribbonFade(bb, m, a, b, w * 1.0f, pl[1], 0.55f * a0, 0.55f * a1);
            ribbonFade(bb, m, a, b, w * 0.35f, pl[0], 0.9f * a0, 0.9f * a1);
        }
        flatBand(bb, m, c.add(0, 0.05, 0), 0f, w * 1.6f, pl[1], 0.5f * al, 0f);
    }

    private static void dome(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt, long now) {
        float t = Math.min(1, (f.age + pt) / f.life);
        float al = (t < 0.1f ? t / 0.1f : t > 0.75f ? (1 - t) / 0.25f : 1f) * (0.75f + 0.25f * (float) Math.sin((now + pt) * 0.5));
        Vec3 c = f.pos.subtract(cam);
        int[] pl = pal(f.el);
        float r = (float) f.size;
        int bands = 7;
        for (int i = 0; i < bands; i++) { // các vành ngang ghép thành mái vòm
            double th0 = i * (Math.PI / 2) / bands, th1 = (i + 1) * (Math.PI / 2) / bands;
            float y0 = r * (float) Math.sin(th0), y1 = r * (float) Math.sin(th1);
            float r0 = r * (float) Math.cos(th0), r1 = r * (float) Math.cos(th1);
            shell(bb, m, c, y0, r0, y1, r1, pl[1], 0.12f * al);
            flatBand(bb, m, c.add(0, y0, 0), r0 - 0.04f, r0 + 0.04f, pl[0], 0.7f * al, 0.7f * al); // đường lưới sáng
        }
        flatBand(bb, m, c.add(0, 0.05, 0), r * 0.9f, r * 1.1f, pl[0], 0.8f * al, 0f);
    }

    /** One horizontal slice of a dome surface between two heights. */
    private static void shell(VertexConsumer bb, Matrix4f m, Vec3 c, float y0, float r0, float y1, float r1, int rgb, float alpha) {
        int n = 32;
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            vtx(bb, m, arc(c, a0, r0).add(0, y0, 0), rgb, alpha);
            vtx(bb, m, arc(c, a1, r0).add(0, y0, 0), rgb, alpha);
            vtx(bb, m, arc(c, a1, r1).add(0, y1, 0), rgb, alpha);
            vtx(bb, m, arc(c, a0, r1).add(0, y1, 0), rgb, alpha);
        }
    }

    private static void ribbonFade(VertexConsumer bb, Matrix4f m, Vec3 a, Vec3 b, float w, int rgb, float alphaA, float alphaB) {
        Vec3 side = b.subtract(a).cross(a.add(b).scale(0.5));
        if (side.lengthSqr() < 1e-8) return;
        side = side.normalize().scale(w / 2);
        quad(bb, m, a.subtract(side), a.add(side), b.add(side), b.subtract(side), rgb, alphaA, alphaB);
    }

    // (glow ball)
    private static void glowBall(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt) {
        Vec3 c = f.pos.add(f.vec.scale(pt)).subtract(cam);
        int[] pl = pal(f.el);
        if (f.el == 1) { // cầu lửa: quầng cam lớn + nhân sáng
            billboard(bb, m, c, (float) f.size * 3.4f, pl[3], 0.22f);
            billboard(bb, m, c, (float) f.size * 2.4f, pl[2], 0.35f);
            billboard(bb, m, c, (float) f.size * 1.3f, pl[0], 0.6f);
            return;
        }
        billboard(bb, m, c, (float) f.size * 2.2f, pl[1], 0.35f);
        billboard(bb, m, c, (float) f.size * 1.4f, pl[0], 0.45f);
    }

    private static void lightning(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float k) {
        Random r = new Random(f.seed);
        Vec3 a = f.pos.subtract(cam), b = f.vec.subtract(cam);
        List<Vec3> pts = jag(a, b, r, 0.45);
        int[] pl = pal(f.el);
        float w = (float) f.size;
        float alpha = k > 0.3f ? 1f : k / 0.3f;
        ribbon(bb, m, pts, w * 4f, pl[3], 0.25f * alpha);
        ribbon(bb, m, pts, w * 2f, pl[2], 0.55f * alpha);
        ribbon(bb, m, pts, w * 0.8f, pl[0], 1f * alpha);
        for (int i = 2; i < pts.size() - 1; i += 2) { // nhánh phụ
            if (r.nextFloat() < 0.5f) continue;
            Vec3 from = pts.get(i);
            Vec3 dir = b.subtract(a).normalize().add(r.nextGaussian() * 0.8, r.nextGaussian() * 0.8, r.nextGaussian() * 0.8).normalize();
            List<Vec3> br = jag(from, from.add(dir.scale(0.8 + r.nextDouble() * 1.5)), r, 0.25);
            ribbon(bb, m, br, w * 1.6f, pl[2], 0.4f * alpha);
            ribbon(bb, m, br, w * 0.5f, pl[0], 0.9f * alpha);
        }
    }

    private static void beam(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float k, long now, float pt) {
        Vec3 a = f.pos.subtract(cam), b = f.vec.subtract(cam);
        int[] pl = pal(f.el);
        float pulse = 1 + 0.15f * (float) Math.sin((now + pt) * 1.3);
        float w = (float) f.size * pulse * (k > 0.3f ? 1 : k / 0.3f);
        List<Vec3> pts = List.of(a, b);
        ribbon(bb, m, pts, w * 3.5f, pl[3], 0.25f);
        ribbon(bb, m, pts, w * 1.8f, pl[1], 0.5f);
        ribbon(bb, m, pts, w * 0.7f, pl[0], 1f);
        billboard(bb, m, b, w * 4, pl[1], 0.5f * k);
    }

    private static void ring(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt) {
        float t = Math.min(1, (f.age + pt) / f.life);
        float ease = 1 - (1 - t) * (1 - t);
        float r = (float) (0.3 + (f.vec.x - 0.3) * ease);
        float w = (float) Math.max(0.15, f.vec.x * 0.12) * (1 - t * 0.5f);
        Vec3 c = f.pos.subtract(cam);
        int[] pl = pal(f.el);
        float al = 1 - t * t;
        flatBand(bb, m, c, r - w, r + w, pl[1], 0.7f * al, 0f);
        flatBand(bb, m, c, r - w * 2.5f, r - w, pl[2], 0.0f, 0.35f * al);
        flatBand(bb, m, c.add(0, w * 0.6, 0), r - w * 0.4f, r + w * 0.4f, pl[0], 0.9f * al, 0.9f * al);
    }

    private static void blackHoleRays(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt, long now) {
        Vec3 c = f.pos.subtract(cam);
        float grow = Math.min(1, (f.age + pt) / 8f) * (f.age > f.life - 6 ? Math.max(0, (f.life - f.age - pt) / 6f) : 1);
        float s = (float) f.size * grow;
        if (s <= 0.01f) return;
        Random r = new Random(f.seed);
        double spin = (now + pt) * 0.02;
        for (int i = 0; i < 28; i++) { // tia sáng hồng tỏa ra
            double yaw = r.nextDouble() * Math.PI * 2 + spin * (i % 2 == 0 ? 1 : -1), pitch = (r.nextDouble() - 0.5) * Math.PI;
            Vec3 dir = new Vec3(Math.cos(pitch) * Math.cos(yaw), Math.sin(pitch), Math.cos(pitch) * Math.sin(yaw));
            float len = s * (3f + r.nextFloat() * 4f) * (0.8f + 0.2f * (float) Math.sin((now + pt) * 0.2 + i));
            ray(bb, m, c, c.add(dir.scale(len)), s * (0.35f + r.nextFloat() * 0.35f), 0xFF3CC8, 0.55f);
        }
        billboard(bb, m, c, s * 2.6f, 0xFF3CC8, 0.5f);   // quầng
        billboard(bb, m, c, s * 1.7f, 0xFFB0F0, 0.35f);
        flatBand(bb, m, c, s * 1.3f, s * 2.0f, 0xFF3CC8, 0.6f, 0f); // đĩa bồi tụ
    }

    private static void flash(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt) {
        float t = Math.min(1, (f.age + pt) / f.life);
        if (t > 0.6f) return;
        Vec3 c = f.pos.subtract(cam);
        int[] pl = pal(f.el);
        float sz = (float) Math.max(0.6, f.vec.x) * (0.8f + t * 1.5f);
        billboard(bb, m, c, sz * 1.6f, pl[1], 0.6f * (1 - t / 0.6f));
        billboard(bb, m, c, sz, pl[0], 0.8f * (1 - t / 0.6f));
    }

    private static void slash(VertexConsumer bb, Matrix4f m, Fx f, Vec3 cam, float pt) {
        float t = Math.min(1, (f.age + pt) / f.life);
        double yaw = f.vec.x, size = f.vec.y;
        Vec3 c = f.pos.subtract(cam);
        int[] pl = pal(f.el);
        double sweep = Math.min(1, t * 2.5) * 1.4;
        int n = 18;
        float al = t < 0.5f ? 1 : (1 - t) / 0.5f;
        for (int i = 0; i < n; i++) {
            double a0 = -1.4 + (sweep * 2) * i / n, a1 = -1.4 + (sweep * 2) * (i + 1) / n;
            float k0 = 1 - Math.abs((float) (a0 / 1.4)), k1 = 1 - Math.abs((float) (a1 / 1.4));
            for (int layer = 0; layer < 2; layer++) {
                double rIn = size * (layer == 0 ? 0.75 : 0.88), rOut = size * (layer == 0 ? 1.05 : 0.98);
                int col = layer == 0 ? pl[2] : pl[0];
                float aa = (layer == 0 ? 0.5f : 1f) * al;
                Vec3 p0 = arc(c, yaw + a0, rIn), p1 = arc(c, yaw + a0, rIn + (rOut - rIn) * k0);
                Vec3 p2 = arc(c, yaw + a1, rIn + (rOut - rIn) * k1), p3 = arc(c, yaw + a1, rIn);
                quad(bb, m, p0, p1, p2, p3, col, aa * k0, aa * k1);
            }
        }
    }

    // ----- hình học -----
    private static Vec3 arc(Vec3 c, double ang, double r) {
        return c.add(Math.cos(ang) * r, 0, Math.sin(ang) * r);
    }

    private static List<Vec3> jag(Vec3 a, Vec3 b, Random r, double amp) {
        List<Vec3> out = new ArrayList<>();
        Vec3 d = b.subtract(a);
        int n = Math.max(3, (int) (d.length() / 0.8));
        out.add(a);
        for (int i = 1; i < n; i++) {
            out.add(a.add(d.scale(i / (double) n)).add(r.nextGaussian() * amp, r.nextGaussian() * amp, r.nextGaussian() * amp));
        }
        out.add(b);
        return out;
    }

    /** Camera-facing strip through the points (camera at origin). */
    private static void ribbon(VertexConsumer bb, Matrix4f m, List<Vec3> pts, float w, int rgb, float alpha) {
        for (int i = 0; i < pts.size() - 1; i++) {
            Vec3 a = pts.get(i), b = pts.get(i + 1);
            Vec3 side = b.subtract(a).cross(a.add(b).scale(0.5));
            if (side.lengthSqr() < 1e-8) continue;
            side = side.normalize().scale(w / 2);
            quad(bb, m, a.subtract(side), a.add(side), b.add(side), b.subtract(side), rgb, alpha, alpha);
        }
    }

    /** Tapered ray from c (wide) to tip (thin), fading out. */
    private static void ray(VertexConsumer bb, Matrix4f m, Vec3 c, Vec3 tip, float w, int rgb, float alpha) {
        Vec3 side = tip.subtract(c).cross(c.add(tip).scale(0.5));
        if (side.lengthSqr() < 1e-8) return;
        side = side.normalize();
        Vec3 sw = side.scale(w / 2), st = side.scale(w * 0.05);
        quad(bb, m, c.subtract(sw), c.add(sw), tip.add(st), tip.subtract(st), rgb, alpha, 0f);
    }

    /** Quad that always faces the camera. */
    private static void billboard(VertexConsumer bb, Matrix4f m, Vec3 c, float size, int rgb, float alpha) {
        Vec3 view = c.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : c.normalize();
        Vec3 up0 = Math.abs(view.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 right = view.cross(up0).normalize().scale(size / 2);
        Vec3 up = right.cross(view).normalize().scale(size / 2);
        // tâm sáng, viền mờ: 4 tam giác quạt dùng quad suy biến
        Vec3[] corners = {c.add(right).add(up), c.subtract(right).add(up), c.subtract(right).subtract(up), c.add(right).subtract(up)};
        Vec3[] mids = {c.add(up), c.subtract(right), c.subtract(up), c.add(right)};
        for (int i = 0; i < 4; i++) {
            Vec3 m0 = mids[(i + 3) % 4], m1 = mids[i];
            vtx(bb, m, c, rgb, alpha);
            vtx(bb, m, c.add(m0.subtract(c)), rgb, 0f);
            vtx(bb, m, c.add(corners[i].subtract(c).scale(0.7)), rgb, 0f);
            vtx(bb, m, c.add(m1.subtract(c)), rgb, 0f);
        }
    }

    private static void flatBand(VertexConsumer bb, Matrix4f m, Vec3 c, float rIn, float rOut, int rgb, float aIn, float aOut) {
        int n = 40;
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            Vec3 i0 = arc(c, a0, rIn), o0 = arc(c, a0, rOut), o1 = arc(c, a1, rOut), i1 = arc(c, a1, rIn);
            vtx(bb, m, i0, rgb, aIn);
            vtx(bb, m, o0, rgb, aOut);
            vtx(bb, m, o1, rgb, aOut);
            vtx(bb, m, i1, rgb, aIn);
        }
    }

    private static void quad(VertexConsumer bb, Matrix4f m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, int rgb, float alphaStart, float alphaEnd) {
        vtx(bb, m, a, rgb, alphaStart);
        vtx(bb, m, b, rgb, alphaStart);
        vtx(bb, m, c, rgb, alphaEnd);
        vtx(bb, m, d, rgb, alphaEnd);
    }

    private static void vtx(VertexConsumer bb, Matrix4f m, Vec3 p, int rgb, float alpha) {
        bb.addVertex(m, (float) p.x, (float) p.y, (float) p.z).setColor(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, Math.max(0f, Math.min(1f, alpha)))
                ;
    }

    /** Axis-aligned cube centred on (x,y,z), faces lightly shaded so it reads as 3D. */
    private static void cube(VertexConsumer bb, Matrix4f m, float x, float y, float z, float size, int rgb, float alpha) {
        float h = size / 2;
        float x0 = x - h, x1 = x + h, y0 = y - h, y1 = y + h, z0 = z - h, z1 = z + h;
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        face(bb, m, r, g, b, alpha, 1f, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0);      // trên
        face(bb, m, r, g, b, alpha, 0.55f, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);   // dưới
        face(bb, m, r, g, b, alpha, 0.8f, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0);    // bắc
        face(bb, m, r, g, b, alpha, 0.8f, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);    // nam
        face(bb, m, r, g, b, alpha, 0.68f, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);   // tây
        face(bb, m, r, g, b, alpha, 0.68f, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1);   // đông
    }

    private static void face(VertexConsumer bb, Matrix4f m, float r, float g, float b, float a, float sh, float... v) {
        for (int i = 0; i < 12; i += 3) bb.addVertex(m, v[i], v[i + 1], v[i + 2]).setColor(r * sh, g * sh, b * sh, a);
    }

    private static Vec3 lerp(Vec3 a, Vec3 b, float t) {
        return a.add(b.subtract(a).scale(t));
    }

    // ----- dữ liệu -----
    private static final class Fx {
        final int kind, el;
        Vec3 pos, vec;
        final double size;
        int life, age;
        long seed = R.nextLong();
        final Deque<Vec3> trail = new ArrayDeque<>();
        final List<float[]> voxels = new ArrayList<>();

        Fx(int kind, int el, Vec3 pos, Vec3 vec, double size, int life) {
            this.kind = kind;
            this.el = el;
            this.pos = pos;
            this.vec = vec;
            this.size = size;
            this.life = Math.max(1, life);
            if (kind == ICE_SPIKES && vec.x * vec.x + vec.z * vec.z < 1e-6) { // gai mọc thành vòng tròn
                int n = (int) Math.max(3, size);
                double rr = Math.max(0.6, vec.y);
                for (int i = 0; i < n; i++) {
                    double ang = i * Math.PI * 2 / n + R.nextDouble() * 0.3;
                    voxels.add(new float[]{(float) (Math.cos(ang) * rr), (float) (Math.sin(ang) * rr),
                            0.9f + R.nextFloat() * 1.2f, R.nextFloat() * 3f, (R.nextFloat() - 0.5f) * 0.3f});
                }
            } else if (kind == ICE_SPIKES) { // hàng cột băng
                int n = (int) Math.max(3, size);
                for (int i = 0; i < n; i++) {
                    for (int k = 0; k < (i % 2 == 0 ? 2 : 1); k++) {
                        voxels.add(new float[]{1.2f + i * 1.1f + R.nextFloat() * 0.3f, (R.nextFloat() - 0.5f) * 1.4f,
                                1.2f + R.nextFloat() * 1.8f + (k == 0 ? 0.6f : 0), i * 1.5f, (R.nextFloat() - 0.5f) * 0.25f});
                    }
                }
            }
            if (kind == BALL || kind == BLACK_HOLE) { // khối xếp thành quả cầu, ô ngoài cùng tối hơn
                int g = 4;
                for (int x = -g; x <= g; x++) for (int y = -g; y <= g; y++) for (int z = -g; z <= g; z++) {
                    double d = Math.sqrt(x * x + y * y + z * z) / g;
                    if (d > 1.0 || (d < 0.6 && kind == BALL)) continue; // rỗng ruột cho nhẹ
                    if (kind == BALL && R.nextFloat() < 0.25f) continue; // mép lởm chởm
                    voxels.add(new float[]{x / (float) g * 0.5f, y / (float) g * 0.5f, z / (float) g * 0.5f, (float) d});
                }
            }
        }
    }

    private static final class Shard {
        Vec3 pos, prev, vel;
        final int el, shade, life;
        final float size;
        int age;
        boolean noGravity;
        Vec3 orbit;
        double angle, radius, rise;

        Shard(Vec3 pos, Vec3 vel, int el, float size, int life) {
            this.pos = this.prev = pos;
            this.vel = vel;
            this.el = el;
            this.size = size;
            this.life = life;
            this.shade = R.nextInt(3);
        }
    }

    private VfxClient() {}
}
