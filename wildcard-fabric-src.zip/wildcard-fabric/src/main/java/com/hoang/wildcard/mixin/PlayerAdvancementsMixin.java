package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.AdvancementEvent;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.server.PlayerAdvancements;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(PlayerAdvancements.class)
public abstract class PlayerAdvancementsMixin {
    @Shadow private ServerPlayer player;
    @Shadow public abstract AdvancementProgress getOrStartProgress(AdvancementHolder h);

    @WrapMethod(method = "award")
    private boolean wildcard$award(AdvancementHolder h, String criterion, Operation<Boolean> orig) {
        boolean was = getOrStartProgress(h).isDone();
        boolean r = orig.call(h, criterion);
        if (!was && getOrStartProgress(h).isDone()) Hooks.post(new AdvancementEvent.AdvancementEarnEvent(player, h));
        return r;
    }
}
