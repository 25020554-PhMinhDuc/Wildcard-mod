package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ItemFishedEvent extends PlayerEvent {
    private final List<ItemStack> drops; private final net.minecraft.world.entity.projectile.FishingHook hook; private int rodDamage;
    public ItemFishedEvent(List<ItemStack> drops, int rodDamage, net.minecraft.world.entity.projectile.FishingHook hook) { super(hook.getPlayerOwner()); this.drops = drops; this.rodDamage = rodDamage; this.hook = hook; }
    public int getRodDamage() { return rodDamage; }
    public void damageRodBy(int d) { rodDamage = d; }
    public List<ItemStack> getDrops() { return drops; }
    public net.minecraft.world.entity.projectile.FishingHook getHookEntity() { return hook; }
}
