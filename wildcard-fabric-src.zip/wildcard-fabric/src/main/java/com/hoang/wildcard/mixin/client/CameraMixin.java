package com.hoang.wildcard.mixin.client;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.client.event.ViewportEvent;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/** ViewportEvent.ComputeCameraAngles: yaw/pitch shake and screen roll. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow @Final private Quaternionf rotation;
    @Unique private float wildcard$roll;


    @ModifyArgs(method = "alignWithEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setRotation(FF)V"))
    private void wildcard$modify(Args args) {
        float pt = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
        ViewportEvent.ComputeCameraAngles ev = new ViewportEvent.ComputeCameraAngles(args.get(0), args.get(1), 0f, pt);
        Hooks.post(ev);
        args.set(0, ev.getYaw());
        args.set(1, ev.getPitch());
        wildcard$roll = ev.getRoll();
    }

    @Inject(method = "alignWithEntity", at = @At("TAIL"))
    private void wildcard$roll(float pt, CallbackInfo ci) {
        if (wildcard$roll != 0f) rotation.rotateZ((float) Math.toRadians(-wildcard$roll));
        wildcard$roll = 0f;
    }
}
