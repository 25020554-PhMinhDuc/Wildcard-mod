package com.hoang.wildcard.fe.network;

import net.minecraft.server.level.ServerPlayer;

public class NetworkEvent {
    public static class Context {
        private final ServerPlayer sender;
        private final NetworkDirection dir;
        public Context(ServerPlayer sender, NetworkDirection dir) { this.sender = sender; this.dir = dir; }
        public ServerPlayer getSender() { return sender; }
        public NetworkDirection getDirection() { return dir; }
        /** Fabric already runs payload handlers on the main thread. */
        public void enqueueWork(Runnable r) { r.run(); }
        public void setPacketHandled(boolean b) {}
    }
}
