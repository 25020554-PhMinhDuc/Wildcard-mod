package com.hoang.wildcard.fe.fml;

import com.hoang.wildcard.fe.api.distmarker.Dist;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;

import java.util.function.Supplier;

public final class DistExecutor {
    public static boolean is(Dist d) {
        boolean client = FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
        return client == (d == Dist.CLIENT);
    }
    public static void unsafeRunWhenOn(Dist d, Supplier<Runnable> r) { if (is(d)) r.get().run(); }
    public static void safeRunWhenOn(Dist d, Supplier<Runnable> r) { if (is(d)) r.get().run(); }
    private DistExecutor() {}
}
