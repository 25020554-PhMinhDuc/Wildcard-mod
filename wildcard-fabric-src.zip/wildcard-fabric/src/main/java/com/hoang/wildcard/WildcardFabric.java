package com.hoang.wildcard;

import com.hoang.wildcard.compat.MC;
import com.hoang.wildcard.fe.bridge.CommonBridge;
import com.hoang.wildcard.fe.common.MinecraftForge;
import com.hoang.wildcard.net.Net;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

/** v9 (Fabric 26.3) entrypoint: registers content, loads the config and wires every listener to Fabric events. */
public final class WildcardFabric implements ModInitializer {
    public static final String MODID = WildcardMod.MODID;
    public static final Logger LOG = WildcardMod.LOG;

    /** Classes that used to be @Mod.EventBusSubscriber on the Forge bus (common side). */
    static final Class<?>[] COMMON = {
            RoundManager.class, WildcardCommand.class,
            com.hoang.wildcard.effects.Effects.class, com.hoang.wildcard.effects.CombatEffects.class,
            com.hoang.wildcard.effects.WorldEffects.class, com.hoang.wildcard.effects.GenEffects.class,
            com.hoang.wildcard.effects.NewCards.class, com.hoang.wildcard.effects.AllyTracker.class,
            com.hoang.wildcard.effects.MythicV8.class, com.hoang.wildcard.effects.Scheduler.class,
            com.hoang.wildcard.effects.MaxStars.class, com.hoang.wildcard.effects.MemeCards.class,
            com.hoang.wildcard.effects.TrollDebuffs.class, com.hoang.wildcard.effects.V71Cards.class,
            com.hoang.wildcard.effects.V72Cards.class,
            com.hoang.wildcard.event.Rewards.class, com.hoang.wildcard.event.Invasion.class,
            com.hoang.wildcard.event.Curse.class, com.hoang.wildcard.event.CardRain.class,
    };

    @Override
    public void onInitialize() {
        Config.SPEC.load(FabricLoader.getInstance().getConfigDir().resolve("wildcard-common.json"));
        com.hoang.wildcard.fx.ModParticles.register(null);
        ModSounds.register(null);
        ModItems.register(null);
        MC.init();
        Net.register();
        for (Class<?> c : COMMON) MinecraftForge.EVENT_BUS.register(c);
        CommonBridge.init();
        LOG.info("Wildcard Hỗn Loạn: {} thẻ đã đăng ký", Cards.ALL.size());
    }
}
