package com.hoang.wildcard;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** v9 (Fabric 26.3) – bước 1: khung mod để kiểm tra build và phiên bản. */
public final class WildcardFabric implements ModInitializer {
    public static final String MODID = "wildcard";
    public static final Logger LOG = LoggerFactory.getLogger(MODID);

    @Override
    public void onInitialize() {
        LOG.info("Wildcard Hỗn Loạn (Fabric) đang khởi động");
        ServerLifecycleEvents.SERVER_STARTED.register(server ->
                LOG.info("Wildcard: server {} đã chạy", server.getServerVersion()));
    }
}
