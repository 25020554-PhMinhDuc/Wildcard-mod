package com.hoang.wildcard.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * v9: the 1.20.1 GuiGraphics calls the screens were written against, mapped onto 26.3's GuiGraphicsExtractor.
 * Colors without alpha get full alpha (26.x skips text whose alpha is 0).
 */
public final class GuiGraphics {
    public final GuiGraphicsExtractor g;
    private final Pose pose;

    public GuiGraphics(GuiGraphicsExtractor g) { this.g = g; this.pose = new Pose(g); }

    public static final class Pose {
        private final GuiGraphicsExtractor g;
        Pose(GuiGraphicsExtractor g) { this.g = g; }
        public void pushPose() { g.pose().pushMatrix(); }
        public void popPose() { g.pose().popMatrix(); }
        public void translate(double x, double y, double z) { g.pose().translate((float) x, (float) y); }
        public void scale(float x, float y, float z) { g.pose().scale(x, y); }
    }

    public Pose pose() { return pose; }

    static int argb(int c) { return (c >>> 24) == 0 ? c | 0xFF000000 : c; }

    public int guiWidth() { return g.guiWidth(); }
    public int guiHeight() { return g.guiHeight(); }

    public int drawString(Font f, String s, int x, int y, int c) { return drawString(f, s, x, y, c, true); }
    public int drawString(Font f, String s, int x, int y, int c, boolean shadow) { g.text(f, s, x, y, argb(c), shadow); return x + f.width(s); }
    public int drawString(Font f, Component s, int x, int y, int c) { return drawString(f, s, x, y, c, true); }
    public int drawString(Font f, Component s, int x, int y, int c, boolean shadow) { g.text(f, s, x, y, argb(c), shadow); return x + f.width(s); }
    public int drawString(Font f, FormattedCharSequence s, int x, int y, int c) { return drawString(f, s, x, y, c, true); }
    public int drawString(Font f, FormattedCharSequence s, int x, int y, int c, boolean shadow) { g.text(f, s, x, y, argb(c), shadow); return x + f.width(s); }
    public int drawString(Font f, String s, float x, float y, int c, boolean shadow) { return drawString(f, s, (int) x, (int) y, c, shadow); }
    public int drawString(Font f, FormattedCharSequence s, float x, float y, int c, boolean shadow) { return drawString(f, s, (int) x, (int) y, c, shadow); }
    public int drawString(Font f, Component s, float x, float y, int c, boolean shadow) { return drawString(f, s, (int) x, (int) y, c, shadow); }

    public void drawCenteredString(Font f, String s, int x, int y, int c) { g.centeredText(f, s, x, y, argb(c)); }
    public void drawCenteredString(Font f, Component s, int x, int y, int c) { g.centeredText(f, s, x, y, argb(c)); }
    public void drawCenteredString(Font f, FormattedCharSequence s, int x, int y, int c) { g.centeredText(f, s, x, y, argb(c)); }

    public void fill(int x1, int y1, int x2, int y2, int c) { g.fill(x1, y1, x2, y2, c); }
    public void fillGradient(int x1, int y1, int x2, int y2, int a, int b) { g.fillGradient(x1, y1, x2, y2, a, b); }
    public void renderOutline(int x, int y, int w, int h, int c) { g.outline(x, y, w, h, c); }
    public void enableScissor(int x1, int y1, int x2, int y2) { g.enableScissor(x1, y1, x2, y2); }
    public void disableScissor() { g.disableScissor(); }

    private int tint = -1;

    /** Replacement for RenderSystem.setShaderColor: tints the following blits. */
    public void setColor(float r, float gr, float b, float a) {
        tint = ((int) (a * 255) << 24) | ((int) (r * 255) << 16) | ((int) (gr * 255) << 8) | (int) (b * 255);
    }

    /** Old blit(tex, x, y, u, v, w, h, texW, texH). */
    public void blit(Identifier t, int x, int y, float u, float v, int w, int h, int tw, int th) {
        g.blit(RenderPipelines.GUI_TEXTURED, t, x, y, u, v, w, h, tw, th, tint);
    }

    /** Old blit(tex, x, y, w, h, u, v, uw, vh, texW, texH). */
    public void blit(Identifier t, int x, int y, int w, int h, float u, float v, int uw, int vh, int tw, int th) {
        g.blit(RenderPipelines.GUI_TEXTURED, t, x, y, u, v, w, h, uw, vh, tw, th, tint);
    }

    public void renderItem(ItemStack s, int x, int y) { g.item(s, x, y); }
    public void renderFakeItem(ItemStack s, int x, int y) { g.fakeItem(s, x, y); }

    public void renderComponentTooltip(Font f, List<Component> tip, int x, int y) { g.setComponentTooltipForNextFrame(f, tip, x, y); }
    public void renderTooltip(Font f, Component c, int x, int y) { g.setTooltipForNextFrame(f, c, x, y); }
}
