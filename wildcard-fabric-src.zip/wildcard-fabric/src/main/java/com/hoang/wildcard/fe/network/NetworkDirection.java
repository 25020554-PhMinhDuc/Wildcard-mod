package com.hoang.wildcard.fe.network;

public enum NetworkDirection { PLAY_TO_CLIENT, PLAY_TO_SERVER }
