package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.Rarity;
import com.hoang.wildcard.net.Net;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Card collection (default key B). Shows every owned card and the 5-slot skill loadout (G H J K L).
 * Pick a slot, then click a skill of the selected card on the right to put it there. Right click a slot to empty it.
 */
public class CardsScreen extends WScreen {
    private static final int TILE_W = 118, TILE_H = 36, GAP = 4;
    private static final int BAR_Y = 34, BAR_H = 22, TOP = BAR_Y + BAR_H + 8, BTN_H = 16;

    private final List<Card> owned = new ArrayList<>();
    private Card selected;
    private int selSlot;
    private double scroll;
    private int cols, gridX0, gridX1, gridY1, previewW, previewH;
    private boolean showPreview;

    public CardsScreen() {
        super(Component.translatable("gui.wildcard.collection"));
    }

    @Override
    protected void init() {
        owned.clear();
        List<String> order = new ArrayList<>(ClientState.CARDS);
        for (String id : order) {
            Card c = Cards.get(id);
            if (c != null) owned.add(c);
        }
        // highest rarity first, newest first inside a rarity
        owned.sort(Comparator.<Card>comparingInt(c -> -c.rarity.ordinal()).thenComparingInt(c -> -order.indexOf(c.id)));
        if (selected == null || !owned.contains(selected)) {
            selected = owned.stream().filter(c -> !c.skills.isEmpty()).findFirst().orElse(owned.isEmpty() ? null : owned.get(0));
        }
        selSlot = firstEmptySlot();

        showPreview = width >= 360;
        previewW = showPreview ? Mth.clamp(width / 3, 120, 160) : 0;
        gridX0 = 10;
        gridX1 = width - (showPreview ? previewW + 22 : 10);
        gridY1 = height - 18;
        cols = Math.max(1, (gridX1 - gridX0 + GAP) / (TILE_W + GAP));
        clampScroll();
    }

    private int firstEmptySlot() {
        for (int i = 0; i < ClientState.LOADOUT.length; i++) if (SkillHud.card(ClientState.LOADOUT[i]) == null) return i;
        return 0;
    }

    private int rows() {
        return (owned.size() + cols - 1) / cols;
    }

    private void clampScroll() {
        int content = rows() * (TILE_H + GAP);
        int view = gridY1 - TOP;
        scroll = Mth.clamp(scroll, 0, Math.max(0, content - view));
    }

    private int gridLeft() {
        int used = cols * (TILE_W + GAP) - GAP;
        return gridX0 + Math.max(0, (gridX1 - gridX0 - used) / 2);
    }

    private int tileAt(double mx, double my) {
        if (mx < gridX0 || mx >= gridX1 || my < TOP || my >= gridY1) return -1;
        int lx = (int) mx - gridLeft();
        int ly = (int) (my - TOP + scroll);
        if (lx < 0) return -1;
        int col = lx / (TILE_W + GAP), row = ly / (TILE_H + GAP);
        if (col >= cols || lx % (TILE_W + GAP) >= TILE_W || ly % (TILE_H + GAP) >= TILE_H) return -1;
        int i = row * cols + col;
        return i < owned.size() ? i : -1;
    }

    // ------------------------------------------------------------------ loadout bar geometry

    private int slotW() {
        return (gridX1 - gridX0 - 4 * 4) / 5;
    }

    private int slotX(int i) {
        return gridX0 + i * (slotW() + 4);
    }

    private int slotAt(double mx, double my) {
        if (my < BAR_Y || my >= BAR_Y + BAR_H) return -1;
        for (int i = 0; i < 5; i++) if (mx >= slotX(i) && mx < slotX(i) + slotW()) return i;
        return -1;
    }

    // ------------------------------------------------------------------ preview + skill buttons geometry

    private int previewX() {
        return width - previewW - 12;
    }

    private int buttonsH() {
        return selected == null ? 0 : selected.skills.size() * (BTN_H + 2);
    }

    private int previewHeight() {
        return Mth.clamp(height - BAR_Y - 24 - buttonsH(), 110, 250);
    }

    private int buttonY(int k) {
        return BAR_Y + previewHeight() + 6 + k * (BTN_H + 2);
    }

    private int buttonAt(double mx, double my) {
        if (!showPreview || selected == null) return -1;
        int px = previewX();
        if (mx < px || mx >= px + previewW) return -1;
        for (int k = 0; k < selected.skills.size(); k++) {
            int y = buttonY(k);
            if (my >= y && my < y + BTN_H) return k;
        }
        return -1;
    }

    private int slotOf(String entry) {
        return Arrays.asList(ClientState.LOADOUT).indexOf(entry);
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        // ---- header
        g.drawString(font, title.copy().withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), 10, 8, 0xFFFFFF, true);
        Component count = Component.translatable("gui.wildcard.collection.count", owned.size(), Cards.ALL.size()).withStyle(ChatFormatting.GRAY);
        int cx = 10 + font.width(title) + 10;
        g.drawString(font, count, cx, 8, 0xFFFFFF, false);
        int eq = ClientState.EQUIPPED.size(), max = com.hoang.wildcard.Config.MAX_EQUIPPED.get();
        g.drawString(font, Component.translatable("gui.wildcard.equipped", eq, max).withStyle(eq >= max ? ChatFormatting.RED : ChatFormatting.GREEN),
                cx + font.width(count) + 10, 8, 0xFFFFFF, false);
        MutableComponent counts = Component.empty();
        for (Rarity r : Rarity.values()) {
            long n = owned.stream().filter(c -> c.rarity == r).count();
            if (!counts.getSiblings().isEmpty()) counts.append(Component.literal("  ").withStyle(ChatFormatting.DARK_GRAY));
            counts.append(r.displayName().copy().append(" " + n).withStyle(s -> s.withColor(r.rgb())));
        }
        g.pose().pushPose();
        g.pose().translate(10, 21, 0);
        g.pose().scale(0.75f, 0.75f, 1);
        g.drawString(font, counts, 0, 0, 0xFFFFFF, false);
        g.pose().popPose();

        // ---- loadout bar
        int hoverSlot = slotAt(mouseX, mouseY);
        for (int i = 0; i < 5; i++) drawSlot(g, i, i == hoverSlot);

        int hover = tileAt(mouseX, mouseY);
        if (owned.isEmpty()) {
            g.drawCenteredString(font, Component.translatable("gui.wildcard.collection.empty").withStyle(ChatFormatting.GRAY),
                    (gridX0 + gridX1) / 2, height / 2, 0xFFFFFF);
        }

        // ---- grid
        g.enableScissor(gridX0 - 4, TOP - 4, gridX1 + 4, gridY1);
        int left = gridLeft();
        for (int i = 0; i < owned.size(); i++) {
            int x = left + (i % cols) * (TILE_W + GAP);
            int y = TOP + (i / cols) * (TILE_H + GAP) - (int) scroll;
            if (y + TILE_H < TOP - 4 || y > gridY1) continue;
            drawTile(g, owned.get(i), x, y, i == hover);
        }
        g.disableScissor();

        int content = rows() * (TILE_H + GAP);
        int view = gridY1 - TOP;
        if (content > view) {
            int barH = Math.max(12, view * view / content);
            int barY = TOP + (int) ((view - barH) * (scroll / (content - view)));
            g.fill(gridX1 + 2, TOP, gridX1 + 4, gridY1, 0x40FFFFFF);
            g.fill(gridX1 + 2, barY, gridX1 + 4, barY + barH, 0xC0FFFFFF);
        }

        // ---- preview of the hovered (or selected) card, and the selected card's skill buttons
        Card shown = hover >= 0 ? owned.get(hover) : selected;
        int hoverBtn = buttonAt(mouseX, mouseY);
        if (showPreview && shown != null) {
            int px = previewX();
            CardArt.drawCard(g, font, shown, px, BAR_Y, previewW, previewHeight(), false);
            if (selected != null) {
                for (int k = 0; k < selected.skills.size(); k++) drawSkillButton(g, selected, k, px, buttonY(k), k == hoverBtn);
            }
        }
        g.pose().pushPose();
        g.pose().translate(10, height - 12, 0);
        g.pose().scale(0.75f, 0.75f, 1);
        g.drawString(font, Component.translatable("gui.wildcard.loadout.hint").withStyle(ChatFormatting.DARK_GRAY), 0, 0, 0xFFFFFF, false);
        g.pose().popPose();

        super.render(g, mouseX, mouseY, partialTick);

        // ---- tooltips
        if (hoverSlot >= 0) {
            String entry = ClientState.LOADOUT[hoverSlot];
            Card c = SkillHud.card(entry);
            int k = SkillHud.index(entry);
            List<Component> tip = new ArrayList<>();
            if (c != null && k >= 0 && k < c.skills.size()) {
                tip.add(c.skillName(k).copy().withStyle(s -> s.withBold(true).withColor(c.rarity.rgb())));
                tip.add(c.skillDesc(k).copy().withStyle(ChatFormatting.GRAY));
                tip.add(Component.translatable("gui.wildcard.cooldown", c.cooldownSeconds(k, ClientState.STARS.getOrDefault(c.id, 0))).withStyle(ChatFormatting.DARK_GRAY));
                tip.add(Component.translatable("gui.wildcard.loadout.clear").withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC));
            } else {
                tip.add(Component.translatable("gui.wildcard.loadout.empty").withStyle(ChatFormatting.GRAY));
            }
            g.renderComponentTooltip(font, tip, mouseX, mouseY);
        } else if (hoverBtn >= 0) {
            List<Component> tip = new ArrayList<>();
            tip.add(selected.skillDesc(hoverBtn).copy().withStyle(ChatFormatting.GRAY));
            tip.add(Component.translatable("gui.wildcard.cooldown", selected.cooldownSeconds(hoverBtn, ClientState.STARS.getOrDefault(selected.id, 0))).withStyle(ChatFormatting.DARK_GRAY));
            tip.add(ClientState.EQUIPPED.contains(selected.id)
                    ? Component.translatable("gui.wildcard.loadout.assign", ClientSetup.skillKeyLabel(selSlot)).withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC)
                    : Component.translatable("gui.wildcard.loadout.needequip").withStyle(ChatFormatting.RED, ChatFormatting.ITALIC));
            g.renderComponentTooltip(font, tip, mouseX, mouseY);
        } else if (hover >= 0) {
            Card c = owned.get(hover);
            List<Component> tip = new ArrayList<>();
            if (!showPreview) {
                tip.add(c.buffName().copy().withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
                tip.add(c.buffDesc().copy().withStyle(ChatFormatting.GRAY));
                tip.add(c.debuffName().copy().withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
                tip.add(c.debuffDesc().copy().withStyle(ChatFormatting.GRAY));
            }
            tip.addAll(CardArt.skillTooltip(c));
            if (!c.skills.isEmpty()) tip.add(Component.translatable("gui.wildcard.loadout.pick").withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC));
            boolean on = ClientState.EQUIPPED.contains(c.id);
            tip.add(Component.translatable(on ? "gui.wildcard.unequip" : "gui.wildcard.equip").withStyle(on ? ChatFormatting.RED : ChatFormatting.GREEN));
            if (!tip.isEmpty()) g.renderComponentTooltip(font, tip, mouseX, mouseY);
        }
    }

    private void drawSlot(GuiGraphics g, int i, boolean hover) {
        int x = slotX(i), w = slotW(), y = BAR_Y;
        String entry = ClientState.LOADOUT[i];
        Card c = SkillHud.card(entry);
        int k = SkillHud.index(entry);
        boolean valid = c != null && k >= 0 && k < c.skills.size();
        g.fill(x, y, x + w, y + BAR_H, hover ? 0xE0202028 : 0xC0101014);
        int border = i == selSlot ? 0xFFFFFFFF : valid ? 0xFF000000 | c.rarity.rgb() : 0x60FFFFFF;
        g.renderOutline(x, y, w, BAR_H, border);
        if (i == selSlot) g.renderOutline(x - 1, y - 1, w + 2, BAR_H + 2, 0x80FFFFFF);
        g.drawString(font, ClientSetup.skillKeyLabel(i), x + 4, y + 7, 0xFFFFE070, true);
        float s = 0.75f;
        int tx = x + 4 + font.width(ClientSetup.skillKeyLabel(i)) + 4;
        if (valid) {
            CardArt.drawSkillIcon(g, c, k, tx, y + 3, 16);
            tx += 19;
        }
        int maxW = (int) ((x + w - 3 - tx) / s);
        g.pose().pushPose();
        g.pose().translate(tx, y + 4, 0);
        g.pose().scale(s, s, 1);
        if (valid) {
            g.drawString(font, font.plainSubstrByWidth(c.skillName(k).getString(), maxW), 0, 0, 0xFFFFFFFF, false);
            g.drawString(font, font.plainSubstrByWidth(c.buffName().getString(), maxW), 0, 11, 0xFF000000 | c.rarity.rgb(), false);
        } else {
            g.drawString(font, Component.translatable("gui.wildcard.loadout.empty").getString(), 0, 5, 0xFF707078, false);
        }
        g.pose().popPose();
    }

    private void drawSkillButton(GuiGraphics g, Card c, int k, int x, int y, boolean hover) {
        int w = previewW;
        int inSlot = slotOf(c.id + ":" + k);
        boolean on = ClientState.EQUIPPED.contains(c.id);
        g.fill(x, y, x + w, y + BTN_H, !on ? 0x80101010 : hover ? 0xE0303040 : 0xC0181820);
        g.renderOutline(x, y, w, BTN_H, hover ? 0xFFFFFFFF : 0xFF000000 | c.rarity.rgb());
        String tag = inSlot >= 0 ? "[" + ClientSetup.skillKeyLabel(inSlot) + "]" : "+";
        int tagW = font.width(tag);
        if (on) g.drawString(font, tag, x + w - tagW - 4, y + 4, inSlot >= 0 ? 0xFFFFE070 : 0xFF7EE07E, false);
        CardArt.drawSkillIcon(g, c, k, x + 2, y + 2, 12);
        g.drawString(font, font.plainSubstrByWidth(c.skillName(k).getString(), w - tagW - 26), x + 17, y + 4, on ? 0xFFFFFFFF : 0xFF707078, false);
    }

    private void drawTile(GuiGraphics g, Card c, int x, int y, boolean hover) {
        if (hover) CardArt.nineSlice(g, CardArt.glow(c.rarity), x - 2, y - 2, TILE_W + 4, TILE_H + 4);
        CardArt.nineSlice(g, CardArt.frame(c.rarity), x, y, TILE_W, TILE_H);
        if (c == selected) g.renderOutline(x - 1, y - 1, TILE_W + 2, TILE_H + 2, 0xFFFFFFFF);
        boolean on = ClientState.EQUIPPED.contains(c.id);
        g.renderItem(c.buffStack(), x + 6, y + 10);
        g.blit(CardArt.gem(c.rarity), x + 3, y + 3, 0, 0, 9, 9, 9, 9);

        float s = 0.8f;
        int tx = x + 26;
        int maxW = (int) ((TILE_W - 26 - 6) / s);
        g.pose().pushPose();
        g.pose().translate(tx, y + 7, 0);
        g.pose().scale(s, s, 1);
        g.drawString(font, font.plainSubstrByWidth(c.buffName().getString(), maxW), 0, 0, CardArt.BUFF_NAME, true);
        g.drawString(font, font.plainSubstrByWidth(c.debuffName().getString(), maxW), 0, 11, CardArt.DEBUFF_NAME, true);
        if (!c.skills.isEmpty()) {
            StringBuilder keys = new StringBuilder();
            for (int k = 0; k < c.skills.size(); k++) {
                int slot = slotOf(c.id + ":" + k);
                if (slot >= 0) keys.append(ClientSetup.skillKeyLabel(slot)).append(' ');
            }
            String sk = Component.translatable("gui.wildcard.skills").getString() + " x" + c.skills.size()
                    + (keys.length() > 0 ? "  [" + keys.toString().trim() + "]" : "");
            g.drawString(font, font.plainSubstrByWidth(sk, maxW), 0, 22, keys.length() > 0 ? 0xFFFFD700 : 0xFF9A9AA8, false);
        }
        if (!on && c.skills.isEmpty()) {
            g.drawString(font, Component.translatable("gui.wildcard.notequipped").getString(), 0, 22, 0xFF9A9AA8, false);
        }
        g.pose().popPose();
        int stars = ClientState.STARS.getOrDefault(c.id, 0);
        if (stars > 0) { // trùng thẻ
            String st = "★" + Math.min(com.hoang.wildcard.Card.MAX_STARS, stars);
            g.pose().pushPose();
            g.pose().translate(x + TILE_W - 8 - font.width(st) * 0.75f, y + TILE_H - 11, 0);
            g.pose().scale(0.75f, 0.75f, 1);
            g.drawString(font, st, 0, 0, 0xFF000000 | com.hoang.wildcard.Card.starColor(stars), true);
            g.pose().popPose();
        }
        if (!on) {
            g.fill(x + 2, y + 2, x + TILE_W - 2, y + TILE_H - 2, 0x90000000); // dimmed: in collection only
        } else {
            g.fill(x + TILE_W - 7, y + 3, x + TILE_W - 3, y + 7, 0xFF55FF55); // green dot: equipped
        }
    }

    // ------------------------------------------------------------------ input

    private void click() {
        if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.2f));
    }

    /** Same rule as the server: if the skill already sits in another slot, the two slots swap. */
    private void assign(int slot, String entry) {
        String old = ClientState.LOADOUT[slot];
        for (int i = 0; i < ClientState.LOADOUT.length; i++) {
            if (i != slot && !entry.isEmpty() && ClientState.LOADOUT[i].equals(entry)) ClientState.LOADOUT[i] = old;
        }
        ClientState.LOADOUT[slot] = entry;
        Net.toServer(new Net.SetSlot(slot, entry));
        click();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int slot = slotAt(mx, my);
        if (slot >= 0) {
            if (button == 1) {
                if (!ClientState.LOADOUT[slot].isEmpty()) assign(slot, "");
            } else {
                selSlot = slot;
                click();
            }
            return true;
        }
        int b = buttonAt(mx, my);
        if (b >= 0 && button == 0 && ClientState.EQUIPPED.contains(selected.id)) {
            assign(selSlot, selected.id + ":" + b);
            selSlot = firstEmptySlot();
            return true;
        }
        int i = tileAt(mx, my);
        if (button == 1 && i >= 0) { // equip / unequip
            Net.toServer(new Net.ToggleEquip(owned.get(i).id));
            click();
            return true;
        }
        if (button == 0 && i >= 0) {
            selected = owned.get(i);
            click();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll -= delta * (TILE_H + GAP);
        clampScroll();
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (keyMatches(ClientSetup.KEY_CARDS, key, scan)) {
            onClose();
            return true;
        }
        for (int i = 0; i < ClientSetup.KEY_SKILLS.length; i++) {
            if (keyMatches(ClientSetup.KEY_SKILLS[i], key, scan)) { // G H J K L chọn ô
                selSlot = i;
                click();
                return true;
            }
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
