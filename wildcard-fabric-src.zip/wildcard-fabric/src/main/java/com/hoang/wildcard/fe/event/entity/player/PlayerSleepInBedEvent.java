package com.hoang.wildcard.fe.event.entity.player;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;

public class PlayerSleepInBedEvent extends PlayerEvent {
    private final BlockPos pos;
    private Player.BedSleepingProblem problem;
    public PlayerSleepInBedEvent(Player p, BlockPos pos) { super(p); this.pos = pos; }
    public BlockPos getPos() { return pos; }
    public Player.BedSleepingProblem getResultStatus() { return problem; }
    public void setResult(Player.BedSleepingProblem r) { problem = r; }
}
