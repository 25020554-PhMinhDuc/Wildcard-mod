package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.CriticalHitEvent;
import com.hoang.wildcard.fe.event.entity.player.PlayerEvent;
import com.hoang.wildcard.fe.event.entity.player.PlayerXpEvent;
import com.hoang.wildcard.fe.eventbus.api.Event;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(Player.class)
public abstract class PlayerMixin {
    private Player self() { return (Player) (Object) this; }

    @ModifyReturnValue(method = "getDestroySpeed", at = @At("RETURN"))
    private float wildcard$breakSpeed(float v, BlockState state) {
        PlayerEvent.BreakSpeed ev = new PlayerEvent.BreakSpeed(self(), state, v, null);
        if (Hooks.post(ev)) return 0f;
        return ev.getNewSpeed();
    }

    @WrapMethod(method = "giveExperiencePoints")
    private void wildcard$xp(int amount, Operation<Void> orig) {
        PlayerXpEvent.XpChange ev = new PlayerXpEvent.XpChange(self(), amount);
        if (Hooks.post(ev)) return;
        orig.call(ev.getAmount());
    }

    @WrapMethod(method = "giveExperienceLevels")
    private void wildcard$levels(int levels, Operation<Void> orig) {
        PlayerXpEvent.LevelChange ev = new PlayerXpEvent.LevelChange(self(), levels);
        if (Hooks.post(ev)) return;
        orig.call(ev.getLevels());
    }

    @WrapOperation(method = "attack", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;canCriticalAttack(Lnet/minecraft/world/entity/Entity;)Z"))
    private boolean wildcard$crit(Player p, Entity target, Operation<Boolean> orig) {
        boolean vanilla = orig.call(p, target);
        CriticalHitEvent ev = new CriticalHitEvent(p, target, 1.5f, vanilla);
        Hooks.post(ev);
        Hooks.critMod = ev.getDamageModifier();
        return ev.getResult() == Event.Result.ALLOW || (ev.getResult() == Event.Result.DEFAULT && vanilla);
    }

    @ModifyConstant(method = "attack", constant = @Constant(floatValue = 1.5f))
    private float wildcard$critMod(float v) {
        float m = Hooks.critMod;
        Hooks.critMod = 1.5f;
        return m;
    }
}
