package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class CriticalHitEvent extends PlayerEvent {
    private final Entity target; private final boolean vanilla; private float damageModifier; private final float oldModifier;
    public CriticalHitEvent(Player p, Entity target, float mod, boolean vanilla) { super(p); this.target = target; this.damageModifier = mod; this.oldModifier = mod; this.vanilla = vanilla; }
    public Entity getTarget() { return target; }
    public boolean isVanillaCritical() { return vanilla; }
    public float getDamageModifier() { return damageModifier; }
    public void setDamageModifier(float m) { damageModifier = m; }
    public float getOldDamageModifier() { return oldModifier; }
}
