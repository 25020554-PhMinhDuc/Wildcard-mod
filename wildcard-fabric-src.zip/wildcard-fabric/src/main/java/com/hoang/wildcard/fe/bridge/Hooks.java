package com.hoang.wildcard.fe.bridge;

import com.hoang.wildcard.fe.common.MinecraftForge;
import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** Shared state for the mixins. */
public final class Hooks {
    /** True while chunk entities are being loaded from disk (EntityJoinLevelEvent#loadedFromDisk). */
    public static boolean loadingFromDisk;
    /** Death drops being collected for LivingDropsEvent, by the dying entity. */
    public static final Map<Entity, List<ItemEntity>> CAPTURE = new IdentityHashMap<>();
    /** Crit damage multiplier chosen by the last CriticalHitEvent. */
    public static float critMod = 1.5f;
    /** Rod damage chosen by the last ItemFishedEvent (-1 = none). */
    public static int rodDamage = -1;

    public static boolean post(Event e) { return MinecraftForge.EVENT_BUS.post(e); }

    private Hooks() {}
}
