package com.hoang.wildcard.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** v9: lets the 1.20.1-style screens (render / mouseClicked(x, y, button) / keyPressed(key, scan, mods)) run on 26.3. */
public abstract class WScreen extends Screen {
    private MouseButtonEvent lastMouse;
    private boolean lastDouble;
    private KeyEvent lastKey;
    private GuiGraphicsExtractor frame;

    protected WScreen(Component title) { super(title); }

    @Override
    public final void extractRenderState(GuiGraphicsExtractor e, int mx, int my, float pt) {
        frame = e;
        render(new GuiGraphics(e), mx, my, pt);
    }

    /** Draw the screen; call super.render to draw the widgets. */
    public void render(GuiGraphics g, int mx, int my, float pt) { super.extractRenderState(g.g, mx, my, pt); }

    /** 26.3 draws the background before extractRenderState by itself. */
    protected void renderBackground(GuiGraphics g) {}

    @Override
    public final boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        lastMouse = e; lastDouble = dbl;
        return mouseClicked(e.x(), e.y(), e.button());
    }

    public boolean mouseClicked(double mx, double my, int button) {
        return lastMouse != null && super.mouseClicked(lastMouse, lastDouble);
    }

    @Override
    public final boolean mouseScrolled(double mx, double my, double dx, double dy) { return mouseScrolled(mx, my, dy); }

    public boolean mouseScrolled(double mx, double my, double delta) { return super.mouseScrolled(mx, my, 0, delta); }

    @Override
    public final boolean keyPressed(KeyEvent e) {
        lastKey = e;
        return keyPressed(e.key(), e.keycode(), e.modifiers());
    }

    public boolean keyPressed(int key, int scan, int mods) { return lastKey != null && super.keyPressed(lastKey); }

    /** Replacement for KeyMapping#matches(key, scan) inside keyPressed. */
    protected boolean keyMatches(KeyMapping k, int key, int scan) { return lastKey != null && k.matches(lastKey); }
}
