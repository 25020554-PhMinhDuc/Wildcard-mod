package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LivingEntityUseItemEvent extends LivingEvent {
    private final ItemStack item; private int duration;
    protected LivingEntityUseItemEvent(LivingEntity e, ItemStack item, int duration) { super(e); this.item = item; this.duration = duration; }
    public ItemStack getItem() { return item; }
    public int getDuration() { return duration; }
    public void setDuration(int d) { duration = d; }
    public static class Start extends LivingEntityUseItemEvent { public Start(LivingEntity e, ItemStack i, int d) { super(e, i, d); } }
    public static class Tick extends LivingEntityUseItemEvent { public Tick(LivingEntity e, ItemStack i, int d) { super(e, i, d); } }
    public static class Stop extends LivingEntityUseItemEvent { public Stop(LivingEntity e, ItemStack i, int d) { super(e, i, d); } }
    public static class Finish extends LivingEntityUseItemEvent {
        private ItemStack result;
        public Finish(LivingEntity e, ItemStack i, int d, ItemStack result) { super(e, i, d); this.result = result; }
        public ItemStack getResultStack() { return result; }
        public void setResultStack(ItemStack r) { result = r; }
    }
}
