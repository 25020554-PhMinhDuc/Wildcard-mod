package com.hoang.wildcard.fe.common;

import net.minecraft.core.Holder;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import java.util.function.Supplier;

/** Shim: Forge's extra attributes are vanilla attributes in 26.x. */
public final class ForgeMod {
    public static final Supplier<Holder<Attribute>> BLOCK_REACH = () -> Attributes.BLOCK_INTERACTION_RANGE;
    public static final Supplier<Holder<Attribute>> ENTITY_REACH = () -> Attributes.ENTITY_INTERACTION_RANGE;
    public static final Supplier<Holder<Attribute>> SWIM_SPEED = () -> Attributes.WATER_MOVEMENT_EFFICIENCY;
    public static final Supplier<Holder<Attribute>> ENTITY_GRAVITY = () -> Attributes.GRAVITY;
    public static final Supplier<Holder<Attribute>> STEP_HEIGHT_ADDITION = () -> Attributes.STEP_HEIGHT;
    private ForgeMod() {}
}
