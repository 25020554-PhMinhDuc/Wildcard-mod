package com.hoang.wildcard.event;

import com.hoang.wildcard.Config;
import com.hoang.wildcard.WildcardMod;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.EntityJoinLevelEvent;
import com.hoang.wildcard.fe.event.entity.living.LivingDropsEvent;
import com.hoang.wildcard.fe.event.entity.living.LivingExperienceDropEvent;
import com.hoang.wildcard.fe.event.entity.living.MobSpawnEvent;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;

import java.util.UUID;

/**
 * v7.1 "Lời Nguyền Wildcard": every 3rd night (config) and the night after it, monsters get +25% max health and
 * +15% damage. Ends when the second night is over. Nights are counted from the start of the world (night 1 is the
 * first night), so nights 3-4, 6-7, 9-10... are cursed with the default settings.
 * v7.3: the Nether and the End are cursed all the time; cursed monsters drop a card 0.5% of the time.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class Curse {
    private static final String TAG = "wildcard_cursed";
    private static final net.minecraft.resources.Identifier HP_ID = com.hoang.wildcard.effects.Effects.modId("curse_hp_id");
    private static final net.minecraft.resources.Identifier DMG_ID = com.hoang.wildcard.effects.Effects.modId("curse_dmg_id");
    private static long announced = -1;
    private static boolean wasActive;
    private static long forcedNight = -1;

    /** Night number (1 = first night) of the overworld right now, or -1 during the day. */
    static long nightNumber(ServerLevel ow) {
        long dt = com.hoang.wildcard.compat.MC.dayTime(ow) % 24000;
        if (dt < 13000 || dt >= 23000) return -1;
        return com.hoang.wildcard.compat.MC.dayTime(ow) / 24000 + 1;
    }

    /** Which night of the curse this is (1 or 2 with defaults), or 0 when the night is not cursed. */
    static int cursedIndex(long night) {
        if (night < 0) return 0;
        if (night == forcedNight) return 1;
        int every = Config.CURSE_EVERY.get(), len = Config.CURSE_NIGHTS.get();
        if (every <= 0 || night < every) return 0;
        long k = night % every;
        return k < len ? (int) k + 1 : 0;
    }

    public static boolean active(ServerLevel ow) {
        return cursedIndex(nightNumber(ow)) > 0;
    }

    /** v7.3: the Nether and the End are always cursed (config); the overworld only on cursed nights. */
    static boolean alwaysCursed(ServerLevel l) {
        return Config.CURSE_NETHER_END.get() && l.dimension() != net.minecraft.world.level.Level.OVERWORLD;
    }

    public static boolean activeIn(ServerLevel l) {
        return alwaysCursed(l) || active(l.getServer().overworld());
    }

    /** /wildcard curse: curse the current (or coming) night right away. */
    public static void force(MinecraftServer server) {
        ServerLevel ow = server.overworld();
        long n = nightNumber(ow);
        forcedNight = n > 0 ? n : com.hoang.wildcard.compat.MC.dayTime(ow) / 24000 + 1;
        announced = -1;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer() == null) return;
        ServerLevel ow = e.getServer().overworld();
        if (ow.getGameTime() % 20 != 0) return;
        long night = nightNumber(ow);
        int idx = cursedIndex(night);
        if (idx > 0 && announced != night) {
            announced = night;
            wasActive = true;
            int len = night == forcedNight ? 1 : Math.max(1, Config.CURSE_NIGHTS.get());
            Component title = Component.translatable("event.wildcard.curse.title").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD);
            Component sub = Component.translatable("event.wildcard.curse.sub", hpPct(), dmgPct(), (int) Math.round(Config.CURSE_SPAWN.get() * 100), (int) Math.round(Config.CURSE_LOOT.get() * 100)).withStyle(ChatFormatting.RED);
            for (ServerPlayer p : e.getServer().getPlayerList().getPlayers()) {
                p.connection.send(new ClientboundSetTitleTextPacket(title));
                p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
                p.sendSystemMessage(Component.translatable("event.wildcard.curse.chat", hpPct(), dmgPct(), idx, len, (int) Math.round(Config.CURSE_SPAWN.get() * 100), (int) Math.round(Config.CURSE_LOOT.get() * 100)).withStyle(ChatFormatting.RED));
                com.hoang.wildcard.compat.MC.notify(p, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 0.5f, 0.6f);
            }
            for (Entity en : ow.getAllEntities()) if (en instanceof Mob m && m instanceof Enemy) curse(m);
        } else if (idx == 0 && wasActive) {
            wasActive = false;
            if (night < 0 || night != forcedNight) forcedNight = -1;
            for (ServerPlayer p : e.getServer().getPlayerList().getPlayers())
                p.sendSystemMessage(Component.translatable("event.wildcard.curse.end").withStyle(ChatFormatting.GREEN));
            for (Entity en : ow.getAllEntities()) if (en instanceof Mob m && m.entityTags().contains(TAG)) lift(m);
        }
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof Mob m)) return;
        ServerLevel l = (ServerLevel) e.getLevel();
        boolean on = activeIn(l);
        if (m instanceof Enemy && on) curse(m);
        else if (m.entityTags().contains(TAG) && !on) lift(m); // loaded back after the curse ended / came back through a portal
    }

    /** v7.3: reminder when entering a dimension that is always cursed. */
    @SubscribeEvent
    public static void onDim(com.hoang.wildcard.fe.event.entity.player.PlayerEvent.PlayerChangedDimensionEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !alwaysCursed(p.level())) return;
        p.sendSystemMessage(Component.translatable("event.wildcard.curse.dim", hpPct(), dmgPct(), (int) Math.round(Config.CURSE_SPAWN.get() * 100),
                (int) Math.round(Config.CURSE_LOOT.get() * 100), Math.round(Config.CURSE_CARD_DROP.get() * 1000) / 10.0).withStyle(ChatFormatting.DARK_RED));
    }

    /** v7.2: cursed nights spawn 30% more monsters (one extra copy of a natural spawn). */
    @SubscribeEvent
    public static void onSpawn(MobSpawnEvent.FinalizeSpawn e) {
        if (e.getSpawnType() != EntitySpawnReason.NATURAL || !(e.getEntity() instanceof Enemy)) return;
        if (!(e.getLevel() instanceof ServerLevel level) || !activeIn(level)) return;
        if (level.getRandom().nextDouble() >= Config.CURSE_SPAWN.get()) return;
        Mob src = e.getEntity();
        EntityType<?> type = src.getType();
        double x = src.getX(), y = src.getY(), z = src.getZ();
        com.hoang.wildcard.effects.Scheduler.later(1, () -> {
            Entity en = type.create(level, net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED);
            if (!(en instanceof Mob m)) return;
            m.snapTo(x + level.getRandom().nextDouble() - 0.5, y, z + level.getRandom().nextDouble() - 0.5, level.getRandom().nextFloat() * 360, 0);
            m.finalizeSpawn(level, level.getCurrentDifficultyAt(m.blockPosition()), EntitySpawnReason.EVENT, null);
            level.addFreshEntity(m);
        });
    }

    /** v7.2: cursed monsters drop 20% more items. */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        if (!e.getEntity().entityTags().contains(TAG)) return;
        double bonus = Config.CURSE_LOOT.get();
        var rng = e.getEntity().getRandom();
        for (ItemEntity ie : e.getDrops()) {
            ItemStack s = ie.getItem();
            double extra = s.getCount() * bonus;
            int add = (int) extra + (rng.nextDouble() < extra - (int) extra ? 1 : 0);
            if (add > 0) s.setCount(Math.min(s.getMaxStackSize(), s.getCount() + add));
        }
    }

    /** v7.2: cursed monsters drop 20% more experience. */
    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent e) {
        if (!e.getEntity().entityTags().contains(TAG)) return;
        e.setDroppedExperience((int) Math.round(e.getDroppedExperience() * (1 + Config.CURSE_LOOT.get())));
    }

    private static int hpPct() { return (int) Math.round(Config.CURSE_HP.get() * 100); }
    private static int dmgPct() { return (int) Math.round(Config.CURSE_DAMAGE.get() * 100); }

    private static void curse(Mob m) {
        if (m.entityTags().contains(TAG)) return;
        m.addTag(TAG);
        boolean full = m.getHealth() >= m.getMaxHealth();
        mod(m, Attributes.MAX_HEALTH, HP_ID, "wildcard curse hp", Config.CURSE_HP.get());
        mod(m, Attributes.ATTACK_DAMAGE, DMG_ID, "wildcard curse dmg", Config.CURSE_DAMAGE.get());
        if (full) m.setHealth(m.getMaxHealth());
    }

    private static void lift(Mob m) {
        m.removeTag(TAG);
        for (net.minecraft.core.Holder<Attribute> a : new net.minecraft.core.Holder[]{Attributes.MAX_HEALTH, Attributes.ATTACK_DAMAGE}) {
            AttributeInstance ai = m.getAttribute(a);
            if (ai == null) continue;
            ai.removeModifier(a == Attributes.MAX_HEALTH ? HP_ID : DMG_ID);
        }
        if (m.getHealth() > m.getMaxHealth()) m.setHealth(m.getMaxHealth());
    }

    private static void mod(Mob m, net.minecraft.core.Holder<Attribute> a, net.minecraft.resources.Identifier id, String name, double v) {
        AttributeInstance ai = m.getAttribute(a);
        if (ai == null || v == 0 || ai.getModifier(id) != null) return;
        ai.addPermanentModifier(new AttributeModifier(id, v, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    private Curse() {}
}
