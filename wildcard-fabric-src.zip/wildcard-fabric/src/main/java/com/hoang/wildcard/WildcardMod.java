package com.hoang.wildcard;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** v9: on Fabric the start-up lives in {@link WildcardFabric}; this class only keeps the shared constants. */
public final class WildcardMod {
    public static final String MODID = "wildcard";
    public static final Logger LOG = LoggerFactory.getLogger(MODID);

    private WildcardMod() {}
}
