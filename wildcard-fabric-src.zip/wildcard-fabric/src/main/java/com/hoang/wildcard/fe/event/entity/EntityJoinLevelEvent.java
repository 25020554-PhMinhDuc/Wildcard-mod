package com.hoang.wildcard.fe.event.entity;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class EntityJoinLevelEvent extends com.hoang.wildcard.fe.event.entity.EntityEvent {
    private final Level level; private final boolean loadedFromDisk;
    public EntityJoinLevelEvent(Entity e, Level level, boolean fromDisk) { super(e); this.level = level; this.loadedFromDisk = fromDisk; }
    public Level getLevel() { return level; }
    public boolean loadedFromDisk() { return loadedFromDisk; }
}
