package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class MobEffectEvent extends LivingEvent {
    protected final net.minecraft.world.effect.MobEffectInstance instance;
    public MobEffectEvent(LivingEntity e, net.minecraft.world.effect.MobEffectInstance i) { super(e); instance = i; }
    public net.minecraft.world.effect.MobEffectInstance getEffectInstance() { return instance; }
    public static class Applicable extends MobEffectEvent { public Applicable(LivingEntity e, net.minecraft.world.effect.MobEffectInstance i) { super(e, i); } }
    public static class Added extends MobEffectEvent { public Added(LivingEntity e, net.minecraft.world.effect.MobEffectInstance i) { super(e, i); } }
}
