package com.hoang.wildcard.effects;

import com.hoang.wildcard.WildcardMod;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.level.Level;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.server.ServerStoppedEvent;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;

import java.util.*;

/**
 * Tracks temporary entities: undead allies (Pháp Sư Xác Sống), frozen mobs/projectiles (Ngưng Đọng Thời Gian)
 * and thrown TNT (Bom Tự Chế).
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class AllyTracker {
    private static final Map<Mob, Integer> ALLIES = new HashMap<>();
    private static final Set<PrimedTnt> THROWN_TNT = new HashSet<>();

    public static void track(Mob ally, int ticks) {
        ALLIES.put(ally, ticks);
    }

    public static void trackTnt(PrimedTnt tnt) {
        THROWN_TNT.add(tnt);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Iterator<Map.Entry<Mob, Integer>> it = ALLIES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Mob, Integer> en = it.next();
            Mob ally = en.getKey();
            int left = en.getValue() - 1;
            if (!ally.isAlive() || left <= 0) {
                if (ally.isAlive() && ally.level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.SOUL, ally.getX(), ally.getY() + 1, ally.getZ(), 15, 0.3, 0.5, 0.3, 0.02);
                    ally.discard();
                }
                it.remove();
                continue;
            }
            en.setValue(left);
            if (left % 20 == 0 && (ally.getTarget() == null || !ally.getTarget().isAlive())) {
                Mob best = null;
                double bestD = 16 * 16;
                for (Mob m : ally.level().getEntitiesOfClass(Mob.class, ally.getBoundingBox().inflate(16),
                        x -> x instanceof Enemy && x != ally && !com.hoang.wildcard.compat.MC.hasUUID(com.hoang.wildcard.compat.MC.pdata(x), Effects.OWNER_TAG))) {
                    double d = m.distanceToSqr(ally);
                    if (d < bestD) {
                        bestD = d;
                        best = m;
                    }
                }
                if (best != null) ally.setTarget(best);
            }
        }

        Iterator<PrimedTnt> ti = THROWN_TNT.iterator();
        while (ti.hasNext()) {
            PrimedTnt t = ti.next();
            if (!t.isAlive()) {
                ti.remove();
                continue;
            }
            if (t.onGround() || t.horizontalCollision) {
                Level level = t.level();
                t.discard();
                level.explode(t, t.getX(), t.getY(), t.getZ(), 8f, Level.ExplosionInteraction.TNT);
                ti.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onStop(ServerStoppedEvent e) {
        ALLIES.clear();
        THROWN_TNT.clear();
    }

    private AllyTracker() {}
}
