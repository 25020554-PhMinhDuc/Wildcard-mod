package com.hoang.wildcard.fe.client.event;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.world.entity.player.Player;

/** Fired after the keyboard input is read each tick; handlers edit {@link #getInput()}. */
public class MovementInputUpdateEvent extends Event {
    /** Mutable copy of 1.20.1's Input fields; written back by the mixin. */
    public static final class Input {
        public float forwardImpulse, leftImpulse;
        public boolean up, down, left, right, jumping, shiftKeyDown, sprinting;
    }
    private final Player player; private final Input input;
    public MovementInputUpdateEvent(Player p, Input in) { player = p; input = in; }
    public Player getEntity() { return player; }
    public Input getInput() { return input; }
}
