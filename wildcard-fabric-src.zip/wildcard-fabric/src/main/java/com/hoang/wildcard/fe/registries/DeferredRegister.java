package com.hoang.wildcard.fe.registries;

import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import java.util.*;
import java.util.function.Supplier;

/** Shim: collects entries, then registers them into the vanilla registry when {@link #register(Object)} is called (mod init). */
public final class DeferredRegister<T> {
    private final Registry<T> registry; private final String modid;
    private final List<RegistryObject<T>> entries = new ArrayList<>();
    private DeferredRegister(Registry<T> r, String modid) { registry = r; this.modid = modid; }
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <T> DeferredRegister<T> create(ForgeRegistries.Reg<? super T> reg, String modid) { return new DeferredRegister<>((Registry) reg.registry(), modid); }
    public <I extends T> RegistryObject<I> register(String name, Supplier<? extends I> sup) {
        RegistryObject<I> o = new RegistryObject<>(Identifier.fromNamespaceAndPath(modid, name), sup);
        @SuppressWarnings("unchecked") RegistryObject<T> t = (RegistryObject<T>) o;
        entries.add(t);
        return o;
    }
    public void register(Object bus) {
        for (RegistryObject<T> o : entries) if (o.value == null) o.value = Registry.register(registry, o.id, o.factory.get());
    }
    public Collection<RegistryObject<T>> getEntries() { return entries; }
}
