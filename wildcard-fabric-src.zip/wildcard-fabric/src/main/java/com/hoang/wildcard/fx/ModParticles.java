package com.hoang.wildcard.fx;

import com.hoang.wildcard.WildcardMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import com.hoang.wildcard.fe.eventbus.api.IEventBus;
import com.hoang.wildcard.fe.registries.DeferredRegister;
import com.hoang.wildcard.fe.registries.ForgeRegistries;
import com.hoang.wildcard.fe.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

/** Our own particle type: the floating rune of the cast circle, one per {@link Element}. v4 visuals are in client.VfxClient. */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> REG = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, WildcardMod.MODID);
    public static final Map<Element, RegistryObject<SimpleParticleType>> RUNE = new EnumMap<>(Element.class);

    static {
        for (Element e : Element.values()) {
            RUNE.put(e, REG.register(e.key() + "_rune", () -> net.fabricmc.fabric.api.particle.v1.FabricParticleTypes.simple(true)));
        }
    }

    public static void register(IEventBus modBus) {
        REG.register(modBus);
    }

    private ModParticles() {}
}
