package com.hoang.wildcard.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.resources.Identifier;

import java.util.Set;

/** v9 helpers for client features whose 1.20.1 hooks no longer exist. */
public final class ClientCompat {
    /** Mù Đường (u14): F3 lines hidden while the card is active (checked by DebugEntryListMixin). */
    public static final Set<Identifier> COORD_ENTRIES = Set.of(DebugScreenEntries.PLAYER_POSITION, DebugScreenEntries.PLAYER_SECTION_POSITION,
            DebugScreenEntries.BIOME, DebugScreenEntries.LIGHT_LEVELS, DebugScreenEntries.HEIGHTMAP);

    public static boolean hideCoords() { return ClientState.has("u14"); }

    /** No F3 For You (e38). */
    public static void hideDebug(Minecraft mc) {
        if (mc.debugEntries.isOverlayVisible()) mc.debugEntries.setOverlayVisible(false);
    }

    private ClientCompat() {}
}
