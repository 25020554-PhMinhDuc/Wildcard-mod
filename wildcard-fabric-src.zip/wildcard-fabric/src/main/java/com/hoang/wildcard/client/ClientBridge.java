package com.hoang.wildcard.client;

import com.hoang.wildcard.fe.common.MinecraftForge;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.player.ItemTooltipEvent;
import com.hoang.wildcard.fe.network.simple.SimpleChannel;
import com.hoang.wildcard.net.Net;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;

/** Maps Fabric client callbacks onto the old Forge-style client handlers. */
public final class ClientBridge {
    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(Net.CH.s2c, (raw, ctx) -> Net.CH.receive(raw.data(), null));
        SimpleChannel.clientSender = ClientPlayNetworking::send;

        ClientSetup.keys();
        ParticleSetup.providers();

        MinecraftForge.EVENT_BUS.register(ClientEvents.class);
        MinecraftForge.EVENT_BUS.register(V71Client.class);
        MinecraftForge.EVENT_BUS.register(VfxClient.class);

        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            MinecraftForge.EVENT_BUS.post(new TickEvent.ClientTickEvent(TickEvent.Phase.START));
            if (mc.player != null) MinecraftForge.EVENT_BUS.post(new TickEvent.PlayerTickEvent(TickEvent.Phase.START, mc.player));
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            MinecraftForge.EVENT_BUS.post(new TickEvent.ClientTickEvent(TickEvent.Phase.END));
            BatClient.tick(mc);
            if (mc.player != null) MinecraftForge.EVENT_BUS.post(new TickEvent.PlayerTickEvent(TickEvent.Phase.END, mc.player));
        });

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("wildcard", "overlay"),
                (g, dt) -> ClientEvents.onOverlay(new GuiGraphics(g)));
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("wildcard", "v71"),
                (g, dt) -> V71Client.onGui(new GuiGraphics(g)));
        HudElementRegistry.replaceElement(VanillaHudElements.HOTBAR, old -> (g, dt) -> {
            GuiGraphics gg = new GuiGraphics(g);
            boolean pushed = ClientEvents.onHotbarPre(gg, dt.getGameTimeDeltaPartialTick(false));
            old.extractRenderState(g, dt);
            if (pushed) gg.pose().popPose();
        });

        LevelRenderEvents.AFTER_TRANSLUCENT_FEATURES.register(ctx -> {
            VfxClient.render(ctx);
            ClientEvents.onRenderLevel(ctx);
        });

        UseItemCallback.EVENT.register((player, level, hand) ->
                level.isClientSide() && V71Client.onUse(hand) ? InteractionResult.FAIL : InteractionResult.PASS);

        ClientReceiveMessageEvents.MODIFY_GAME.register((msg, overlay) -> overlay ? msg : V71Client.onChat(msg));

        ItemTooltipCallback.EVENT.register((stack, ctx, flag, lines) ->
                MinecraftForge.EVENT_BUS.post(new ItemTooltipEvent(stack, Minecraft.getInstance().player, lines, flag)));
    }

    private ClientBridge() {}
}
