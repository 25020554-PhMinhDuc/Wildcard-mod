package com.hoang.wildcard.fe.network;

import com.hoang.wildcard.fe.network.simple.SimpleChannel;
import net.minecraft.resources.Identifier;

import java.util.function.Predicate;
import java.util.function.Supplier;

public final class NetworkRegistry {
    public static SimpleChannel newSimpleChannel(Identifier id, Supplier<String> version, Predicate<String> client, Predicate<String> server) {
        return new SimpleChannel(id);
    }
    private NetworkRegistry() {}
}
