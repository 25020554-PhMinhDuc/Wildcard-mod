package com.hoang.wildcard.fe.event.entity.player;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class BonemealEvent extends PlayerEvent {
    private final Level level; private final BlockPos pos;
    public BonemealEvent(Player p, Level level, BlockPos pos) { super(p); this.level = level; this.pos = pos; }
    public Level getLevel() { return level; }
    public BlockPos getPos() { return pos; }
}
