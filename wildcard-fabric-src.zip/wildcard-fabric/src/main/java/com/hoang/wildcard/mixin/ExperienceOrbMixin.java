package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.PlayerXpEvent;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ExperienceOrb.class)
public abstract class ExperienceOrbMixin {
    @Inject(method = "playerTouch", cancellable = true, at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;take(Lnet/minecraft/world/entity/Entity;I)V"))
    private void wildcard$pickup(Player p, CallbackInfo ci) {
        if (Hooks.post(new PlayerXpEvent.PickupXp(p, (ExperienceOrb) (Object) this))) ci.cancel();
    }
}
