package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LivingExperienceDropEvent extends LivingEvent {
    private final Player attackingPlayer; private final int original; private int dropped;
    public LivingExperienceDropEvent(LivingEntity e, Player p, int xp) { super(e); attackingPlayer = p; original = xp; dropped = xp; }
    public int getDroppedExperience() { return dropped; }
    public void setDroppedExperience(int x) { dropped = x; }
    public int getOriginalExperience() { return original; }
    public Player getAttackingPlayer() { return attackingPlayer; }
}
