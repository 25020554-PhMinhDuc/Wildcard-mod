package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class PlayerInteractEvent extends PlayerEvent {
    private final InteractionHand hand; private final BlockPos pos;
    private InteractionResult cancellationResult = InteractionResult.PASS;
    protected PlayerInteractEvent(Player p, InteractionHand hand, BlockPos pos) { super(p); this.hand = hand; this.pos = pos; }
    public InteractionHand getHand() { return hand; }
    public ItemStack getItemStack() { return getEntity().getItemInHand(hand); }
    public BlockPos getPos() { return pos; }
    public Level getLevel() { return getEntity().level(); }
    public InteractionResult getCancellationResult() { return cancellationResult; }
    public void setCancellationResult(InteractionResult r) { cancellationResult = r; }
    public static class EntityInteract extends PlayerInteractEvent {
        private final Entity target;
        public EntityInteract(Player p, InteractionHand h, Entity target) { super(p, h, target.blockPosition()); this.target = target; }
        public Entity getTarget() { return target; }
    }
    public static class EntityInteractSpecific extends EntityInteract {
        public EntityInteractSpecific(Player p, InteractionHand h, Entity target) { super(p, h, target); }
    }
    public static class RightClickItem extends PlayerInteractEvent {
        public RightClickItem(Player p, InteractionHand h) { super(p, h, p.blockPosition()); }
    }
    public static class RightClickBlock extends PlayerInteractEvent {
        private final net.minecraft.world.phys.BlockHitResult hit;
        public RightClickBlock(Player p, InteractionHand h, net.minecraft.world.phys.BlockHitResult hit) { super(p, h, hit.getBlockPos()); this.hit = hit; }
        public net.minecraft.world.phys.BlockHitResult getHitVec() { return hit; }
        public net.minecraft.core.Direction getFace() { return hit.getDirection(); }
    }
    public static class LeftClickBlock extends PlayerInteractEvent {
        public LeftClickBlock(Player p, BlockPos pos) { super(p, InteractionHand.MAIN_HAND, pos); }
    }
    public static class RightClickEmpty extends PlayerInteractEvent {
        public RightClickEmpty(Player p, InteractionHand h) { super(p, h, p.blockPosition()); }
    }
}
