package com.hoang.wildcard.effects;

import net.minecraft.world.entity.monster.Enderman;
import net.minecraft.world.entity.monster.spider.Spider;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.EntitySpawnReason;

import com.hoang.wildcard.RoundManager;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.hoang.wildcard.fe.event.entity.living.*;
import com.hoang.wildcard.fe.event.entity.player.AttackEntityEvent;
import com.hoang.wildcard.fe.event.entity.player.CriticalHitEvent;
import com.hoang.wildcard.fe.event.entity.player.PlayerEvent;
import com.hoang.wildcard.fe.event.entity.player.PlayerXpEvent;
import com.hoang.wildcard.fe.eventbus.api.Event;
import com.hoang.wildcard.fe.eventbus.api.EventPriority;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;

import java.util.List;

import static com.hoang.wildcard.effects.Effects.*;

/** Damage, death, knockback and XP related card effects. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class CombatEffects {

    static boolean isBoss(Entity e) {
        return e instanceof EnderDragon || e instanceof WitherBoss || e instanceof Warden || e instanceof ElderGuardian;
    }

    static boolean melee(DamageSource src) {
        return src.getEntity() instanceof LivingEntity && src.getDirectEntity() == src.getEntity()
                && !src.is(DamageTypeTags.IS_PROJECTILE) && !src.is(DamageTypeTags.IS_EXPLOSION);
    }

    // ------------------------------------------------------------------ cancel damage

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        DamageSource src = e.getSource();
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        // Lò Phản Ứng: miễn nhiễm lửa và dung nham
        if (has(p, "e12") && src.is(DamageTypeTags.IS_FIRE)) {
            e.setCanceled(true);
            return;
        }
        // Đầu Sắt: không bị ngạt trong khối
        if (has(p, "r15") && src.is(DamageTypes.IN_WALL)) {
            e.setCanceled(true);
            return;
        }
        if (src.is(DamageTypeTags.IS_EXPLOSION)) {
            // kỹ năng Creeper bị cướp: tự nổ không chết
            if (now < st.selfExplosionImmuneUntil) {
                e.setCanceled(true);
                return;
            }
            // Rocket Jump: nổ không gây sát thương, chỉ hất bay lên
            if (has(p, "r16")) {
                e.setCanceled(true);
                p.setDeltaMovement(p.getDeltaMovement().add(0, 1.1, 0));
                p.needsSync = true;
                p.fallDistance = 0;
            }
        }
    }

    // ------------------------------------------------------------------ damage modifiers

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        DamageSource src = e.getSource();
        float amount = e.getAmount();
        long now = victim.level().getGameTime();

        // ----- the victim is a player
        if (victim instanceof ServerPlayer p) {
            PlayerState st = PlayerState.get(p);
            if (has(p, "u02") && melee(src) && src.getEntity() instanceof LivingEntity att && att != p) {
                att.hurt(p.damageSources().thorns(p), Math.max(0.5f, amount * 0.15f)); // Gai Góc
            }
            if (com.hoang.wildcard.Cards.debuffOn(p, "u02") && src.is(DamageTypeTags.IS_PROJECTILE)) amount *= 1.25f; // Da Giấy
            if (com.hoang.wildcard.Cards.debuffOn(p, "u19") && src.is(DamageTypeTags.IS_FALL)) amount += 1f;          // Tiếp Đất Cứng
            if (has(p, "r09")) {                                                        // Lộ Mặt
                if (st.ninja || p.hasEffect(MobEffects.INVISIBILITY)) {
                    p.removeEffect(MobEffects.INVISIBILITY);
                    st.ninja = false;
                    st.revealedUntil = now + 60;
                }
                if (now < st.revealedUntil) amount *= 1.5f;
            }
            if (has(p, "r20") && st.stillTicks > 20) amount *= 1.2f;                     // Dễ Vỡ
            if (st.fortress) amount *= 0.4f;                                            // Pháo Đài Di Động
            if (has(p, "l01") && src.is(DamageTypes.LIGHTNING_BOLT)) amount *= 2f;      // Dẫn Điện
            if (com.hoang.wildcard.Cards.debuffOn(p, "c07")) {                                                        // Tiếng Gà
                p.level().playSound(null, p.blockPosition(), SoundEvents.CHICKEN_SOUNDS.get(net.minecraft.world.entity.animal.chicken.ChickenSoundVariants.SoundSet.CLASSIC).adultSounds().hurtSound().value(), SoundSource.PLAYERS, 1.2f, 1f);
            }
            if (has(p, "e05") && p.getRandom().nextFloat() < 0.25f) randomTeleport(p, 8); // Không Gian Bất Ổn
            if (has(p, "l07")) dropRandomHotbar(p);                                        // Rơi Xu
        }

        // ----- the attacker is a player
        if (src.getEntity() instanceof ServerPlayer p && victim != p) {
            PlayerState st = PlayerState.get(p);
            boolean direct = src.getDirectEntity() == p;
            ItemStack weapon = p.getMainHandItem();
            if (direct) {
                // Hô Biến: 5% biến mob thành gà
                if (has(p, "e08") && victim instanceof Monster && !isBoss(victim) && p.getRandom().nextFloat() < 0.05f) {
                    turnIntoChicken(victim);
                    e.setCanceled(true);
                    return;
                }
                if (has(p, "r10") && weapon.is(net.minecraft.tags.ItemTags.SWORDS)) {             // Kiếm Băng
                    victim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 1));
                }
                if (has(p, "r20")) p.addEffect(new MobEffectInstance(MobEffects.SPEED, 40, 1)); // Đánh Rồi Chạy
                if (has(p, "r17") && victim instanceof Mob && p.getRandom().nextFloat() < 0.10f) stealDrop(p, (Mob) victim, src); // Tắt Mắt
                if (has(p, "l01") && ++st.hitCounter % 3 == 0) smite(p, victim, 5f);    // Thần Sấm
            }
            if (has(p, "l19") && p.getRandom().nextFloat() < 0.25f) amount *= 2f;      // Nữ Thần May Mắn
        }
        e.setAmount(amount);
    }

    // Tiếng Sấm: chí mạng 20% gọi sét
    @SubscribeEvent
    public static void onCrit(CriticalHitEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !(e.getTarget() instanceof LivingEntity t)) return;
        boolean crit = e.getResult() == Event.Result.ALLOW || (e.getResult() == Event.Result.DEFAULT && e.isVanillaCritical());
        if (crit && has(p, "r07") && p.getRandom().nextFloat() < 0.2f) smite(p, t, 5f);
    }

    // Sóng Kiếm: đòn chém đầy lực bắn ra sóng kiếm 6 khối
    @SubscribeEvent
    public static void onPlayerAttack(AttackEntityEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "e06")) return;
        if (!(p.getMainHandItem().is(net.minecraft.tags.ItemTags.SWORDS)) || p.getAttackStrengthScale(0.5f) < 0.95f) return;
        ServerLevel level = p.level();
        Vec3 look = p.getLookAngle();
        Vec3 start = p.getEyePosition().add(0, -0.3, 0);
        for (int i = 1; i <= 6; i++) {
            Vec3 at = start.add(look.scale(i));
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0, 0, 0, 0);
            for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(0.9),
                    x -> x != p && x != e.getTarget() && !(x instanceof Player) && x.isAlive())) {
                if (le.getInvulnerableTime() <= 10) le.hurt(p.damageSources().playerAttack(p), 4f);
            }
        }
        level.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1f, 1.3f);
    }

    // Nhẹ Tênh: bị đánh văng xa gấp đôi
    @SubscribeEvent
    public static void onKnockback(LivingKnockBackEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && has(p, "r08")) e.setStrength(e.getStrength() * 2f);
    }

    // Mùi Tanh: mob phát hiện bạn từ xa hơn 25%
    @SubscribeEvent
    public static void onVisibility(LivingEvent.LivingVisibilityEvent e) {
        if (e.getEntity() instanceof Player p && !p.level().isClientSide() && com.hoang.wildcard.Cards.debuffOn(p, "c08")) e.modifyVisibility(1.25);
    }

    // Pháp Sư Xác Sống / Vệ Sĩ Sắt: đồng minh không tấn công chủ
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent e) {
        LivingEntity mob = e.getEntity();
        LivingEntity t = e.getNewTarget();
        if (t == null || !com.hoang.wildcard.compat.MC.hasUUID(com.hoang.wildcard.compat.MC.pdata(mob), OWNER_TAG)) return;
        if (t instanceof Player || (com.hoang.wildcard.compat.MC.hasUUID(com.hoang.wildcard.compat.MC.pdata(t), OWNER_TAG)
                && com.hoang.wildcard.compat.MC.getUUID(com.hoang.wildcard.compat.MC.pdata(t), OWNER_TAG).equals(com.hoang.wildcard.compat.MC.getUUID(com.hoang.wildcard.compat.MC.pdata(mob), OWNER_TAG)))) {
            e.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ death

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onDeath(LivingDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead.level().isClientSide()) return;

        if (dead instanceof ServerPlayer p) {
            if (playerDeath(p)) {
                e.setCanceled(true);
                return;
            }
            // Giữ Đồ: cất túi đồ để trả lại khi hồi sinh
            if (has(p, "e04") && !p.level().getGameRules().get(net.minecraft.world.level.gamerules.GameRules.KEEP_INVENTORY)) {
                ListTag inv = com.hoang.wildcard.compat.MC.saveInv(p);
                WData.get(p).extra.put("e04_inv", inv);
                p.getInventory().clearContent();
            }
            // Phiên Nổ Cuối
            if (has(p, "l17")) {
                p.level().explode(null, p.getX(), p.getY(), p.getZ(), 6f, Level.ExplosionInteraction.MOB);
            }
        }

        if (e.getSource().getEntity() instanceof ServerPlayer p && dead != p) onKill(p, dead);
    }

    /** Returns true if the player was saved from death. */
    private static boolean playerDeath(ServerPlayer p) {
        WData d = WData.get(p);
        CompoundTag round = d.extra.getCompoundOrEmpty("round");
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        ServerLevel level = p.level();
        // Phượng Hoàng (hồi chiêu 10 phút)
        if (has(p, "l13") && st.ready("l13", now, 12000)) {
            p.setHealth(p.getMaxHealth());
            p.removeAllEffects();
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 200, 0));
            for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(5), x -> x != p)) {
                le.igniteForSeconds(6);
                le.hurt(p.damageSources().inFire(), 6f);
            }
            level.sendParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 150, 2, 1, 2, 0.15);
            level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_DEATH, SoundSource.PLAYERS, 1f, 0.6f);
            p.sendSystemMessage(Component.translatable("msg.wildcard.phoenix").withStyle(ChatFormatting.GOLD));
            // Tro Tàn: đồ ăn hóa than
            Inventory inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (s.has(net.minecraft.core.component.DataComponents.FOOD)) inv.setItem(i, new ItemStack(Items.CHARCOAL, s.getCount()));
            }
            return true;
        }
        // Bất Tử: mỗi lượt 1 lần
        if (has(p, "l04") && !round.getBooleanOr("l04", false)) {
            round.putBoolean("l04", true);
            d.extra.put("round", round);
            int lost = d.extra.getIntOr("l04_lost", 0);
            if (p.experienceLevel > 0) p.giveExperienceLevels(-Math.min(5, p.experienceLevel)); // Cái Giá: mất 5 cấp XP
            p.setHealth(p.getMaxHealth());
            p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, 4));
            level.playSound(null, p.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1f, 1f);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 60, 0.5, 1, 0.5, 0.4);
            p.sendSystemMessage(Component.translatable("msg.wildcard.undying").withStyle(ChatFormatting.GOLD));
            return true;
        }
        // Thêm Một Mạng: mỗi lượt 1 lần, như Totem
        if (has(p, "r04") && !round.getBooleanOr("r04", false)) {
            round.putBoolean("r04", true);
            d.extra.put("round", round);
            p.setHealth(2f);
            p.removeAllEffects();
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
            p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 100, 1));
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 800, 0));
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 1200, 1)); // Hậu Chấn
            level.playSound(null, p.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1f, 1f);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 60, 0.5, 1, 0.5, 0.4);
            p.sendSystemMessage(Component.translatable("msg.wildcard.saved").withStyle(ChatFormatting.AQUA));
            return true;
        }
        return false;
    }

    private static void onKill(ServerPlayer p, LivingEntity dead) {
        ServerLevel level = p.level();
        RandomSource rng = p.getRandom();
        PlayerState st = PlayerState.get(p);
        WData d = WData.get(p);
        boolean mob = dead instanceof Mob;

        if (has(p, "u05")) p.heal(2f); // Hút Máu Nhẹ
        if (has(p, "u06")) {           // Pháo Hoa
            level.sendParticles(ParticleTypes.FIREWORK, dead.getX(), dead.getY() + 1, dead.getZ(), 40, 0.3, 0.3, 0.3, 0.2);
            level.playSound(null, dead.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1f, 1f);
            for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, dead.getBoundingBox().inflate(3),
                    x -> x != p && x != dead && x instanceof Enemy)) {
                le.hurt(p.damageSources().fireworks(null, p), 2f);
            }
        }
        if (com.hoang.wildcard.Cards.debuffOn(p, "u06") && mob && dead instanceof Enemy && rng.nextFloat() < 0.10f) { // Zombie Con
            Zombie z = net.minecraft.world.entity.EntityTypes.ZOMBIE.create(level, net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED);
            if (z != null) {
                z.setBaby(true);
                z.snapTo(dead.getX(), dead.getY(), dead.getZ(), dead.getYRot(), 0);
                level.addFreshEntity(z);
                z.setTarget(p);
            }
        }
        if (has(p, "u13") && dead instanceof Creeper) dropAt(level, dead.getX(), dead.getY() + 0.5, dead.getZ(), new ItemStack(Items.TNT)); // Thu Hoạch Creeper
        if (has(p, "r16") && dead instanceof Creeper) { // Hận Dỗi
            Vec3 at = dead.position();
            Scheduler.later(30, () -> level.explode(null, at.x, at.y, at.z, 3f, Level.ExplosionInteraction.MOB));
        }
        if (has(p, "l03") && mob) dropAt(level, dead.getX(), dead.getY() + 0.5, dead.getZ(), new ItemStack(Items.GOLD_INGOT)); // Vua Midas
        if (has(p, "e09") && mob) { // Hút Hồn / Hồn Ma Đeo Bám
            int kills = d.extra.getIntOr("e09_kills", 0) + 1;
            d.extra.putInt("e09_kills", kills);
            if (kills % 20 == 0) {
                Vex v = spawnNear(p, net.minecraft.world.entity.EntityTypes.VEX, 3, 6);
                if (v != null) v.setTarget(p);
            }
        }
        if (has(p, "l06") && dead instanceof Enemy && !isBoss(dead) && rng.nextFloat() < 0.20f) raiseAlly(p, dead); // Pháp Sư Xác Sống
        if (has(p, "l08") && mob) { // Đánh Cắp Kỹ Năng
            st.lastKilledType = dead.getType();
            String ab = dead instanceof Blaze ? "blaze" : dead instanceof Spider ? "spider"
                    : dead instanceof Enderman ? "enderman" : dead instanceof Creeper ? "creeper" : "";
            if (!ab.isEmpty()) {
                st.stolen = ab;
                st.stolenUntil = level.getGameTime() + 600;
                p.sendSystemMessage(Component.translatable("msg.wildcard.stolen", dead.getName()).withStyle(ChatFormatting.LIGHT_PURPLE));
                RoundManager.sync(p);
            }
        }
    }

    private static void raiseAlly(ServerPlayer p, LivingEntity dead) {
        ServerLevel level = p.level();
        Monster ally = p.getRandom().nextBoolean() ? net.minecraft.world.entity.EntityTypes.ZOMBIE.create(level, net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED) : net.minecraft.world.entity.EntityTypes.SKELETON.create(level, net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED);
        if (ally == null) return;
        ally.snapTo(dead.getX(), dead.getY(), dead.getZ(), dead.getYRot(), 0);
        ally.finalizeSpawn(level, level.getCurrentDifficultyAt(dead.blockPosition()), EntitySpawnReason.MOB_SUMMONED, null);
        com.hoang.wildcard.compat.MC.putUUID(com.hoang.wildcard.compat.MC.pdata(ally), OWNER_TAG, p.getUUID());
        ally.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET)); // không cháy nắng
        ally.setGlowingTag(true);
        ally.setCustomName(Component.literal("Đồng minh của " + p.getGameProfile().name()).withStyle(ChatFormatting.GREEN));
        level.addFreshEntity(ally);
        level.sendParticles(ParticleTypes.SOUL, ally.getX(), ally.getY() + 1, ally.getZ(), 20, 0.3, 0.6, 0.3, 0.02);
        AllyTracker.track(ally, 1200);
    }

    static void turnIntoChicken(LivingEntity victim) {
        ServerLevel level = (ServerLevel) victim.level();
        if (victim instanceof net.minecraft.world.entity.player.Player pl) { // v7: người chơi không bị xóa, chỉ "hóa gà" 6 giây
            pl.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 120, 1));
            pl.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1));
            pl.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 120, 0));
            pl.addEffect(new MobEffectInstance(MobEffects.JUMP_BOOST, 120, 1));
            level.sendParticles(ParticleTypes.POOF, pl.getX(), pl.getY() + 0.5, pl.getZ(), 20, 0.3, 0.3, 0.3, 0.02);
            level.playSound(null, pl.blockPosition(), SoundEvents.CHICKEN_SOUNDS.get(net.minecraft.world.entity.animal.chicken.ChickenSoundVariants.SoundSet.CLASSIC).adultSounds().ambientSound().value(), SoundSource.PLAYERS, 1.2f, 1f);
            pl.sendOverlayMessage(net.minecraft.network.chat.Component.translatable("msg.wildcard.chickened").withStyle(net.minecraft.ChatFormatting.YELLOW));
            return;
        }
        Chicken c = net.minecraft.world.entity.EntityTypes.CHICKEN.create(level, net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED);
        if (c == null) return;
        c.snapTo(victim.getX(), victim.getY(), victim.getZ(), victim.getYRot(), 0);
        level.addFreshEntity(c);
        level.sendParticles(ParticleTypes.POOF, victim.getX(), victim.getY() + 0.5, victim.getZ(), 20, 0.3, 0.3, 0.3, 0.02);
        level.playSound(null, victim.blockPosition(), SoundEvents.CHICKEN_SOUNDS.get(net.minecraft.world.entity.animal.chicken.ChickenSoundVariants.SoundSet.CLASSIC).adultSounds().ambientSound().value(), SoundSource.NEUTRAL, 1f, 1f);
        victim.discard();
    }

    static void stealDrop(ServerPlayer p, Mob mob, DamageSource src) {
        ServerLevel level = p.level();
        if (mob.getType().getDefaultLootTable().isEmpty()) return;
        LootTable table = level.getServer().reloadableRegistries().getLootTable(mob.getType().getDefaultLootTable().get());
        LootParams params = new LootParams.Builder(level)
                .withParameter(LootContextParams.THIS_ENTITY, mob)
                .withParameter(LootContextParams.ORIGIN, mob.position())
                .withParameter(LootContextParams.DAMAGE_SOURCE, src)
                .withOptionalParameter(LootContextParams.ATTACKING_ENTITY, p)
                .withOptionalParameter(LootContextParams.DIRECT_ATTACKING_ENTITY, p)
                .withParameter(LootContextParams.LAST_DAMAGE_PLAYER, p)
                .withLuck(p.getLuck())
                .create(LootContextParamSets.ENTITY);
        List<ItemStack> items = table.getRandomItems(params);
        for (ItemStack s : items) {
            if (!s.isEmpty()) {
                give(p, s.split(1));
                level.playSound(null, p.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.6f, 1.6f);
                return;
            }
        }
    }

    public static void randomTeleport(LivingEntity e, int range) {
        RandomSource r = e.getRandom();
        for (int i = 0; i < 16; i++) {
            double x = e.getX() + (r.nextDouble() - 0.5) * 2 * range;
            double y = e.getY() + r.nextInt(range) - range / 2.0;
            double z = e.getZ() + (r.nextDouble() - 0.5) * 2 * range;
            if (e.randomTeleport(x, y, z, true, (java.util.function.Predicate<net.minecraft.world.level.block.state.BlockState>) bs -> true)) {
                e.level().playSound(null, e.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 1f);
                return;
            }
        }
    }

    private static void dropRandomHotbar(ServerPlayer p) {
        int slot = p.getRandom().nextInt(9);
        ItemStack s = p.getInventory().getItem(slot);
        if (s.isEmpty()) return;
        p.getInventory().setItem(slot, ItemStack.EMPTY);
        ItemEntity ie = p.drop(s, true, net.minecraft.util.Prediction.SERVER_ONLY);
        if (ie != null) ie.setPickUpDelay(40);
    }

    // ------------------------------------------------------------------ XP

    // Học Nhanh: +20% XP
    @SubscribeEvent
    public static void onXp(PlayerXpEvent.XpChange e) {
        Player p = e.getEntity();
        if (p.level().isClientSide() || e.getAmount() <= 0 || !has(p, "c16")) return;
        float v = e.getAmount() * 1.2f;
        int whole = (int) v;
        if (p.getRandom().nextFloat() < v - whole) whole++;
        e.setAmount(whole);
    }

    // Hay Quên: chết không rơi cầu XP nào
    @SubscribeEvent
    public static void onXpDrop(LivingExperienceDropEvent e) {
        // v7.3: bỏ (trùng chỉ số XP với lợi ích), thay bằng tầm với -0,5 khối (V71Data)
    }

    // ------------------------------------------------------------------ respawn

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.isEndConquered()) return;
        WData d = WData.get(p);
        if (d.extra.contains("e04_inv")) { // Giữ Đồ
            ListTag inv = d.extra.getListOrEmpty("e04_inv");
            p.getInventory().clearContent();
            com.hoang.wildcard.compat.MC.loadInv(p, inv);
            d.extra.remove("e04_inv");
            p.inventoryMenu.broadcastChanges();
        }
        if (has(p, "e04")) { // Lạc Trôi: hồi sinh ở tọa độ ngẫu nhiên trong 1.000 khối
            ServerLevel level = p.level();
            RandomSource r = p.getRandom();
            for (int i = 0; i < 10; i++) {
                int x = p.getBlockX() + r.nextInt(2001) - 1000;
                int z = p.getBlockZ() + r.nextInt(2001) - 1000;
                int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                BlockPos at = new BlockPos(x, y, z);
                if (y > level.getMinY() + 1 && level.getFluidState(at.below()).isEmpty()) {
                    p.teleportTo(x + 0.5, y, z + 0.5);
                    break;
                }
            }
        }
        if (has(p, "l15")) p.setRespawnPosition(null, false); // Vô Gia Cư
        RoundManager.sync(p);
    }

    private CombatEffects() {}
}
