package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class PlayerEvent extends com.hoang.wildcard.fe.event.entity.living.LivingEvent {
    private final Player player;
    public PlayerEvent(Player p) { super(p); player = p; }
    @Override public Player getEntity() { return player; }
    public static class BreakSpeed extends PlayerEvent {
        private final BlockState state; private final float original; private float newSpeed; private final Optional<BlockPos> pos;
        public BreakSpeed(Player p, BlockState s, float original, BlockPos pos) { super(p); state = s; this.original = original; newSpeed = original; this.pos = Optional.ofNullable(pos); }
        public BlockState getState() { return state; }
        public float getOriginalSpeed() { return original; }
        public float getNewSpeed() { return newSpeed; }
        public void setNewSpeed(float s) { newSpeed = s; }
        public Optional<BlockPos> getPosition() { return pos; }
    }
    public static class PlayerLoggedInEvent extends PlayerEvent { public PlayerLoggedInEvent(Player p) { super(p); } }
    public static class PlayerLoggedOutEvent extends PlayerEvent { public PlayerLoggedOutEvent(Player p) { super(p); } }
    public static class PlayerRespawnEvent extends PlayerEvent {
        private final boolean endConquered;
        public PlayerRespawnEvent(Player p, boolean end) { super(p); endConquered = end; }
        public boolean isEndConquered() { return endConquered; }
    }
    public static class Clone extends PlayerEvent {
        private final Player original; private final boolean wasDeath;
        public Clone(Player p, Player original, boolean wasDeath) { super(p); this.original = original; this.wasDeath = wasDeath; }
        public Player getOriginal() { return original; }
        public boolean isWasDeath() { return wasDeath; }
    }
    public static class PlayerChangedDimensionEvent extends PlayerEvent {
        private final net.minecraft.resources.ResourceKey<Level> from, to;
        public PlayerChangedDimensionEvent(Player p, net.minecraft.resources.ResourceKey<Level> from, net.minecraft.resources.ResourceKey<Level> to) { super(p); this.from = from; this.to = to; }
        public net.minecraft.resources.ResourceKey<Level> getFrom() { return from; }
        public net.minecraft.resources.ResourceKey<Level> getTo() { return to; }
    }
    public static class StartTracking extends PlayerEvent {
        private final Entity target;
        public StartTracking(Player p, Entity target) { super(p); this.target = target; }
        public Entity getTarget() { return target; }
    }
}
