package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LivingFallEvent extends LivingEvent {
    private float distance, damageMultiplier;
    public LivingFallEvent(LivingEntity e, float d, float m) { super(e); distance = d; damageMultiplier = m; }
    public float getDistance() { return distance; }
    public void setDistance(float d) { distance = d; }
    public float getDamageMultiplier() { return damageMultiplier; }
    public void setDamageMultiplier(float m) { damageMultiplier = m; }
}
