package com.hoang.wildcard.fe.event.entity.player;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;

public class PlayerSetSpawnEvent extends PlayerEvent {
    private final BlockPos spawn;
    public PlayerSetSpawnEvent(Player p, BlockPos spawn) { super(p); this.spawn = spawn; }
    public BlockPos getNewSpawn() { return spawn; }
}
