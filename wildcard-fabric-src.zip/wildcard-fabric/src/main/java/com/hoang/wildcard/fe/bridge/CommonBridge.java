package com.hoang.wildcard.fe.bridge;

import com.hoang.wildcard.fe.common.MinecraftForge;
import com.hoang.wildcard.fe.event.RegisterCommandsEvent;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.EntityJoinLevelEvent;
import com.hoang.wildcard.fe.event.entity.living.LivingAttackEvent;
import com.hoang.wildcard.fe.event.entity.living.LivingDeathEvent;
import com.hoang.wildcard.fe.event.entity.player.*;
import com.hoang.wildcard.fe.event.level.BlockEvent;
import com.hoang.wildcard.fe.event.server.ServerStoppedEvent;
import com.hoang.wildcard.fe.event.server.ServerStartingEvent;
import com.hoang.wildcard.fe.eventbus.api.Event;
import com.hoang.wildcard.fe.server.ServerLifecycleHooks;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityLevelChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.*;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;

/** Fires the Forge-style events from Fabric API callbacks. Events with no Fabric callback are fired by mixins. */
public final class CommonBridge {
    static boolean post(Event e) { return MinecraftForge.EVENT_BUS.post(e); }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTING.register(s -> { ServerLifecycleHooks.current = s; post(new ServerStartingEvent(s)); });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> { post(new ServerStoppedEvent(s)); ServerLifecycleHooks.current = null; });

        ServerTickEvents.START_SERVER_TICK.register(s -> tick(s, TickEvent.Phase.START));
        ServerTickEvents.END_SERVER_TICK.register(s -> tick(s, TickEvent.Phase.END));

        CommandRegistrationCallback.EVENT.register((d, ctx, sel) -> post(new RegisterCommandsEvent(d, ctx)));

        // LivingAttackEvent = the start of hurtServer; cancel = no damage at all.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((e, src, amt) -> !post(new LivingAttackEvent(e, src, amt)));
        ServerLivingEntityEvents.ALLOW_DEATH.register((e, src, amt) -> !post(new LivingDeathEvent(e, src)));

        ServerEntityEvents.ENTITY_LOAD.register((en, level) -> {
            EntityJoinLevelEvent ev = new EntityJoinLevelEvent(en, level, Hooks.loadingFromDisk);
            if (post(ev) && !(en instanceof Player)) en.discard();
        });

        PlayerBlockBreakEvents.BEFORE.register((level, p, pos, state, be) -> !post(new BlockEvent.BreakEvent(level, pos, state, p)));

        UseEntityCallback.EVENT.register((p, level, hand, target, hit) -> {
            PlayerInteractEvent.EntityInteract ev = new PlayerInteractEvent.EntityInteract(p, hand, target);
            return post(ev) ? fail(ev.getCancellationResult()) : InteractionResult.PASS;
        });
        UseItemCallback.EVENT.register((p, level, hand) -> {
            PlayerInteractEvent.RightClickItem ev = new PlayerInteractEvent.RightClickItem(p, hand);
            return post(ev) ? fail(ev.getCancellationResult()) : InteractionResult.PASS;
        });
        UseBlockCallback.EVENT.register((p, level, hand, hit) -> {
            PlayerInteractEvent.RightClickBlock ev = new PlayerInteractEvent.RightClickBlock(p, hand, hit);
            return post(ev) ? fail(ev.getCancellationResult()) : InteractionResult.PASS;
        });
        AttackEntityCallback.EVENT.register((p, level, hand, target, hit) ->
                post(new AttackEntityEvent(p, target)) ? InteractionResult.FAIL : InteractionResult.PASS);

        ServerPlayConnectionEvents.JOIN.register((h, sender, s) -> post(new PlayerEvent.PlayerLoggedInEvent(h.player)));
        ServerPlayConnectionEvents.DISCONNECT.register((h, s) -> post(new PlayerEvent.PlayerLoggedOutEvent(h.player)));
        ServerPlayerEvents.COPY_FROM.register((old, now, alive) -> post(new PlayerEvent.Clone(now, old, !alive)));
        ServerPlayerEvents.AFTER_RESPAWN.register((old, now, alive) -> post(new PlayerEvent.PlayerRespawnEvent(now, alive)));
        ServerEntityLevelChangeEvents.AFTER_PLAYER_CHANGE_LEVEL.register((p, from, to) ->
                post(new PlayerEvent.PlayerChangedDimensionEvent(p, from.dimension(), to.dimension())));
        EntityTrackingEvents.START_TRACKING.register((target, viewer) -> post(new PlayerEvent.StartTracking(viewer, target)));

        EntitySleepEvents.ALLOW_SLEEPING.register((p, pos) -> {
            PlayerSleepInBedEvent ev = new PlayerSleepInBedEvent(p, pos);
            post(ev);
            return ev.getResultStatus();
        });
        EntitySleepEvents.STOP_SLEEPING.register((e, pos) -> {
            if (e instanceof Player p) post(new PlayerWakeUpEvent(p, false, true));
        });
        EntitySleepEvents.ALLOW_SETTING_SPAWN.register((p, pos) -> !post(new PlayerSetSpawnEvent(p, pos)));
    }

    private static InteractionResult fail(InteractionResult r) {
        return r == null || r == InteractionResult.PASS ? InteractionResult.FAIL : r;
    }

    private static void tick(MinecraftServer s, TickEvent.Phase ph) {
        post(new TickEvent.ServerTickEvent(ph, s));
        for (ServerPlayer p : new ArrayList<>(s.getPlayerList().getPlayers())) post(new TickEvent.PlayerTickEvent(ph, p));
    }

    private CommonBridge() {}
}
