package com.hoang.wildcard.fe.eventbus.api;

/** Shim of Forge's Event: cancel flag + result. */
public class Event {
    public enum Result { DENY, DEFAULT, ALLOW }
    private boolean canceled;
    private Result result = Result.DEFAULT;
    public boolean isCancelable() { return true; }
    public boolean isCanceled() { return canceled; }
    public void setCanceled(boolean c) { canceled = c; }
    public Result getResult() { return result; }
    public void setResult(Result r) { result = r; }
}
