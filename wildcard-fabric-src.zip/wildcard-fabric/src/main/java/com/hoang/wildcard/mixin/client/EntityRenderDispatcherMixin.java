package com.hoang.wildcard.mixin.client;

import com.hoang.wildcard.client.BatClient;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** M1 bat form: the player model (body, armor, held items, name tag, shadow) is not drawn; BatClient draws a bat instead. */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void wildcard$batForm(Entity entity, Frustum frustum, double x, double y, double z, float pt,
                                                     CallbackInfoReturnable<Boolean> cir) {
        if (BatClient.hide(entity)) cir.setReturnValue(false);
    }
}
