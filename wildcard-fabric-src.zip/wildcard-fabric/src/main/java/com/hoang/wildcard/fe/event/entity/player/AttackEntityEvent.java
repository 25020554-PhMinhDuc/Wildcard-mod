package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class AttackEntityEvent extends PlayerEvent {
    private final Entity target;
    public AttackEntityEvent(Player p, Entity target) { super(p); this.target = target; }
    public Entity getTarget() { return target; }
}
