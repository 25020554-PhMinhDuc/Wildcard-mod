package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class PlayerXpEvent extends PlayerEvent {
    public PlayerXpEvent(Player p) { super(p); }
    public static class XpChange extends PlayerXpEvent {
        private int amount;
        public XpChange(Player p, int a) { super(p); amount = a; }
        public int getAmount() { return amount; }
        public void setAmount(int a) { amount = a; }
    }
    public static class LevelChange extends PlayerXpEvent {
        private int levels;
        public LevelChange(Player p, int l) { super(p); levels = l; }
        public int getLevels() { return levels; }
        public void setLevels(int l) { levels = l; }
    }
    public static class PickupXp extends PlayerXpEvent {
        private final ExperienceOrb orb;
        public PickupXp(Player p, ExperienceOrb o) { super(p); orb = o; }
        public ExperienceOrb getOrb() { return orb; }
    }
}
