package com.hoang.wildcard.client;

import com.hoang.wildcard.effects.BatForm;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * v9: draws players in M1 bat form as a vanilla bat. One client-only {@link Bat} per player follows the player every tick;
 * the player's own renderer (body, armor, held items, name) is skipped by mixin.client.EntityRenderDispatcherMixin.
 */
public final class BatClient {
    private static final Map<Integer, Bat> BATS = new HashMap<>();
    private static int nextId = -0x5A7000;

    /** Mixin hook: skip rendering a player that is a bat right now. */
    public static boolean hide(Entity e) {
        return e instanceof Player && BatForm.CLIENT.contains(e.getId());
    }

    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        if (level == null) {
            BATS.clear();
            BatForm.CLIENT.clear();
            return;
        }
        // bỏ dơi của người chơi đã hết dạng dơi / rời khỏi
        for (Iterator<Map.Entry<Integer, Bat>> it = BATS.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<Integer, Bat> en = it.next();
            Bat bat = en.getValue();
            boolean keep = BatForm.CLIENT.contains(en.getKey()) && level.getEntity(en.getKey()) instanceof Player && bat.level() == level;
            if (!keep) {
                if (bat.level() == level) level.removeEntity(bat.getId(), Entity.RemovalReason.DISCARDED);
                it.remove();
            }
        }
        for (Integer id : BatForm.CLIENT) {
            if (!(level.getEntity(id) instanceof Player p) || !p.isAlive()) continue;
            Bat bat = BATS.get(id);
            if (bat == null) {
                bat = new Bat(net.minecraft.world.entity.EntityTypes.BAT, level) {
                    @Override
                    public boolean isPickable() {
                        return false; // không chặn tia nhắm: người khác vẫn đánh trúng người chơi
                    }
                };
                bat.setId(nextId--);
                bat.setResting(false);
                bat.setSilent(true);
                bat.setNoAi(true);
                bat.noPhysics = true;
                place(bat, p);
                bat.setOldPosAndRot();
                level.addEntity(bat);
                BATS.put(id, bat);
            } else {
                place(bat, p);
            }
            // người chơi dạng dơi chỉ có thể bay
            if (p == mc.player && !p.getAbilities().flying) {
                p.getAbilities().mayfly = true;
                p.getAbilities().flying = true;
            }
        }
    }

    private static void place(Bat bat, Player p) {
        bat.xo = bat.getX();
        bat.yo = bat.getY();
        bat.zo = bat.getZ();
        bat.xOld = bat.getX();
        bat.yOld = bat.getY();
        bat.zOld = bat.getZ();
        bat.yRotO = bat.getYRot();
        bat.xRotO = bat.getXRot();
        bat.yBodyRotO = bat.yBodyRot;
        bat.yHeadRotO = bat.getYHeadRot();
        // ngồi giữa hộp va chạm đã thu nhỏ của người chơi
        bat.setPos(p.getX(), p.getY() + Math.max(0, p.getBbHeight() - 0.9) * 0.5, p.getZ());
        bat.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);
        bat.setYRot(p.getYRot());
        bat.setXRot(0);
        bat.setYBodyRot(p.getYRot());
        bat.setYHeadRot(p.getYHeadRot());
        bat.setResting(false);
    }

    private BatClient() {}
}
