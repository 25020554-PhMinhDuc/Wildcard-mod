package com.hoang.wildcard.mixin.client;

import com.hoang.wildcard.client.ClientCompat;
import net.minecraft.client.gui.components.debug.DebugScreenEntryList;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Mất Phương Hướng (u14): the F3 screen hides coordinates, biome and light. */
@Mixin(DebugScreenEntryList.class)
public abstract class DebugEntriesMixin {
    @Inject(method = "isCurrentlyEnabled", at = @At("HEAD"), cancellable = true)
    private void wildcard$hide(Identifier id, CallbackInfoReturnable<Boolean> cir) {
        if (ClientCompat.COORD_ENTRIES.contains(id) && ClientCompat.hideCoords()) cir.setReturnValue(false);
    }
}
