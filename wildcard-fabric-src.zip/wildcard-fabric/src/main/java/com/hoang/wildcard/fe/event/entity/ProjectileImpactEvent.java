package com.hoang.wildcard.fe.event.entity;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ProjectileImpactEvent extends com.hoang.wildcard.fe.event.entity.EntityEvent {
    public enum ImpactResult { DEFAULT, SKIP_ENTITY, STOP_AT_CURRENT, STOP_AT_CURRENT_NO_DAMAGE }
    private final net.minecraft.world.phys.HitResult ray; private final net.minecraft.world.entity.projectile.Projectile projectile;
    private ImpactResult result = ImpactResult.DEFAULT;
    public ProjectileImpactEvent(net.minecraft.world.entity.projectile.Projectile p, net.minecraft.world.phys.HitResult ray) { super(p); this.projectile = p; this.ray = ray; }
    public net.minecraft.world.phys.HitResult getRayTraceResult() { return ray; }
    public net.minecraft.world.entity.projectile.Projectile getProjectile() { return projectile; }
    public void setImpactResult(ImpactResult r) { result = r; if (r != ImpactResult.DEFAULT) setCanceled(true); }
    public ImpactResult getImpactResult() { return result; }
}
