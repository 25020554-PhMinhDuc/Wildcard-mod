package com.hoang.wildcard.client;

import net.minecraft.ChatFormatting;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientAdvancements;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.jspecify.annotations.Nullable;

import java.util.*;

/**
 * v7.2: progress of every advancement (hotkey U). Left: the advancements, right: which criteria are done and which are
 * still missing, e.g. "A Balanced Diet" lists every food already eaten and every food not eaten yet.
 */
public class AdvProgressScreen extends WScreen implements ClientAdvancements.Listener {
    private static final int ROW = 22;
    private final Map<Advancement, AdvancementProgress> progress = new LinkedHashMap<>();
    private final List<Advancement> list = new ArrayList<>();
    private Advancement selected;
    private boolean onlyOpen = true;
    private int listScroll, critScroll;
    private int lx, ly, lw, lh, rx, rw;

    public AdvProgressScreen() {
        super(Component.translatable("gui.wildcard.adv.title"));
    }

    /** v7.3: always show advancements, items, mobs and biomes with the game's own Vietnamese names. */
    private static net.minecraft.locale.Language vi;

    private static net.minecraft.locale.Language vi() {
        if (vi == null) {
            try {
                vi = net.minecraft.client.resources.language.ClientLanguage.loadFrom(Minecraft.getInstance().getResourceManager(), List.of("en_us", "vi_vn"), false);
            } catch (Exception ex) {
                vi = net.minecraft.locale.Language.getInstance();
            }
        }
        return vi;
    }

    private static String key(String k, String fallback) {
        return vi().has(k) ? vi().getOrDefault(k) : fallback;
    }

    private static String tr(Component c) {
        if (c.getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents tc && vi().has(tc.getKey())) {
            String s = vi().getOrDefault(tc.getKey());
            Object[] args = tc.getArgs();
            if (args.length == 0) return s;
            Object[] out = new Object[args.length];
            for (int i = 0; i < args.length; i++) out[i] = args[i] instanceof Component ac ? tr(ac) : String.valueOf(args[i]);
            try {
                return String.format(s, out);
            } catch (Exception ex) {
                return s;
            }
        }
        return c.getString();
    }

    @Override
    protected void init() {
        vi = null; // nạp lại mỗi lần mở (phòng khi đổi gói tài nguyên)
        ClientAdvancements adv = Minecraft.getInstance().player != null ? Minecraft.getInstance().player.connection.getAdvancements() : null;
        if (adv != null) { adv.setListener(this); refill(adv); }
        lx = 10;
        ly = 30;
        lw = Mth.clamp(width / 3, 120, 200);
        lh = height - ly - 34;
        rx = lx + lw + 10;
        rw = width - rx - 10;
        addRenderableWidget(Button.builder(filterLabel(), b -> {
            onlyOpen = !onlyOpen;
            b.setMessage(filterLabel());
            rebuild();
        }).bounds(lx, height - 28, lw, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose()).bounds(width - 110, height - 28, 100, 20).build());
        rebuild();
    }

    private Component filterLabel() {
        return Component.translatable(onlyOpen ? "gui.wildcard.adv.only_open" : "gui.wildcard.adv.all");
    }

    @Override
    public void removed() {
        if (Minecraft.getInstance().player != null) Minecraft.getInstance().player.connection.getAdvancements().setListener(null);
    }

    private void rebuild() {
        list.clear();
        for (Map.Entry<Advancement, AdvancementProgress> e : progress.entrySet()) {
            Advancement a = e.getKey();
            DisplayInfo d = a.display().orElse(null);
            if (d == null || a.parent().isEmpty() && tot(a) <= 1 && d.title().getString().isEmpty()) continue;
            AdvancementProgress p = e.getValue();
            if (d.hidden() && !p.hasProgress()) continue;
            if (onlyOpen && p.isDone()) continue;
            list.add(a);
        }
        // nhiều tiêu chí và gần xong lên trước
        list.sort(Comparator.<Advancement>comparingInt(a -> tot(a) > 1 ? 0 : 1)
                .thenComparing(a -> -progress.get(a).getPercent())
                .thenComparing(a -> tr(a.display().orElse(null).title())));
        int keep = selected == null ? -1 : list.indexOf(selected);
        if (keep >= 0) selected = list.get(keep); // v9: cùng thành tựu sau khi server cập nhật (đối tượng mới)
        else {
            selected = list.isEmpty() ? null : list.get(0);
            critScroll = 0;
        }
        listScroll = Mth.clamp(listScroll, 0, Math.max(0, list.size() * ROW - lh));
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawCenteredString(font, title.copy().withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), width / 2, 10, 0xFFFFFF);
        // danh sách
        g.fill(lx - 2, ly - 2, lx + lw + 2, ly + lh + 2, 0xAA000000);
        g.enableScissor(lx, ly, lx + lw, ly + lh);
        for (int i = 0; i < list.size(); i++) {
            int y = ly + i * ROW - listScroll;
            if (y + ROW < ly || y > ly + lh) continue;
            Advancement a = list.get(i);
            AdvancementProgress p = progress.get(a);
            boolean hover = mx >= lx && mx < lx + lw && my >= Math.max(ly, y) && my < Math.min(ly + lh, y + ROW);
            if (a.equals(selected)) g.fill(lx, y, lx + lw, y + ROW, 0x664A7BD0);
            else if (hover) g.fill(lx, y, lx + lw, y + ROW, 0x33FFFFFF);
            g.renderItem(a.display().orElse(null).icon().create(), lx + 2, y + 3);
            String name = font.plainSubstrByWidth(tr(a.display().orElse(null).title()), lw - 24);
            int col = p.isDone() ? 0xFF55FF55 : a.display().orElse(null).type() == net.minecraft.advancements.AdvancementType.CHALLENGE ? 0xFFD58CFF : 0xFFFFFFFF;
            g.drawString(font, name, lx + 22, y + 3, col, false);
            int total = tot(a);
            int done = count(p.getCompletedCriteria());
            g.drawString(font, done + "/" + total, lx + 22, y + 12, 0xFF9A9AA8, false);
            int bw = lw - 60;
            g.fill(lx + 52, y + 14, lx + 52 + bw, y + 17, 0xFF333333);
            g.fill(lx + 52, y + 14, lx + 52 + (int) (bw * p.getPercent()), y + 17, p.isDone() ? 0xFF55FF55 : 0xFFE0B040);
        }
        g.disableScissor();
        if (list.isEmpty()) g.drawCenteredString(font, Component.translatable("gui.wildcard.adv.empty"), lx + lw / 2, ly + 10, 0xAAAAAA);

        // chi tiết
        g.fill(rx - 2, ly - 2, rx + rw + 2, ly + lh + 2, 0xAA000000);
        if (selected != null) drawDetail(g, selected, progress.get(selected));
        super.render(g, mx, my, pt);
    }

    private void drawDetail(GuiGraphics g, Advancement a, AdvancementProgress p) {
        DisplayInfo d = a.display().orElse(null);
        g.renderItem(d.icon().create(), rx + 2, ly + 2);
        g.drawString(font, Component.literal(tr(d.title())).withStyle(ChatFormatting.BOLD), rx + 22, ly + 2, p.isDone() ? 0xFF55FF55 : 0xFFFFD866, true);
        List<FormattedCharSequence> desc = font.split(Component.literal(tr(d.description())), rw - 24);
        int y = ly + 13;
        for (FormattedCharSequence line : desc) {
            g.drawString(font, line, rx + 22, y, 0xFFCCCCCC, false);
            y += 9;
        }
        y = Math.max(y, ly + 22) + 4;
        List<String> done = sorted(p.getCompletedCriteria()), open = sorted(p.getRemainingCriteria());
        int colW = (rw - 6) / 2;
        int top = y;
        g.drawString(font, Component.translatable("gui.wildcard.adv.done", done.size()).withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), rx + 2, top, 0xFFFFFF, false);
        g.drawString(font, Component.translatable("gui.wildcard.adv.open", open.size()).withStyle(ChatFormatting.RED, ChatFormatting.BOLD), rx + 6 + colW, top, 0xFFFFFF, false);
        top += 12;
        g.fill(rx, top - 2, rx + rw, top - 1, 0x55FFFFFF);
        int bottom = ly + lh;
        g.enableScissor(rx, top, rx + rw, bottom);
        int rows = Math.max(done.size(), open.size());
        for (int i = 0; i < rows; i++) {
            int ry = top + i * 10 - critScroll;
            if (ry + 10 < top || ry > bottom) continue;
            if (i < done.size()) g.drawString(font, "✔ " + font.plainSubstrByWidth(pretty(done.get(i)), colW - 12), rx + 2, ry, 0xFF55FF55, false);
            if (i < open.size()) g.drawString(font, "✘ " + font.plainSubstrByWidth(pretty(open.get(i)), colW - 12), rx + 6 + colW, ry, 0xFFFF6B6B, false);
        }
        g.disableScissor();
        maxCrit = Math.max(0, rows * 10 - (bottom - top));
    }

    private int maxCrit;

    private static int count(Iterable<String> it) {
        int n = 0;
        for (String ignored : it) n++;
        return n;
    }

    private List<String> sorted(Iterable<String> it) {
        List<String> l = new ArrayList<>();
        for (String s : it) l.add(s);
        l.sort(Comparator.comparing(this::pretty));
        return l;
    }

    /** "minecraft:apple" -> "Táo", biome -> its name, entity -> its name; otherwise the raw criterion name. */
    private String pretty(String crit) {
        Identifier rl = Identifier.tryParse(crit);
        if (rl == null) return crit;
        if (!crit.contains(":")) rl = Identifier.fromNamespaceAndPath("minecraft", crit);
        if (BuiltInRegistries.ITEM.containsKey(rl)) {
            var it = BuiltInRegistries.ITEM.getValue(rl);
            return key(it.getDescriptionId(), Component.translatable(it.getDescriptionId()).getString());
        }
        if (BuiltInRegistries.ENTITY_TYPE.containsKey(rl)) {
            var et = BuiltInRegistries.ENTITY_TYPE.getValue(rl);
            return key(et.getDescriptionId(), et.getDescription().getString());
        }
        String biome = "biome." + rl.getNamespace() + "." + rl.getPath();
        if (vi().has(biome)) return vi().getOrDefault(biome);
        if (BuiltInRegistries.BLOCK.containsKey(rl)) {
            var b = BuiltInRegistries.BLOCK.getValue(rl);
            return key(b.getDescriptionId(), b.getName().getString());
        }
        String eff = "effect." + rl.getNamespace() + "." + rl.getPath();
        if (vi().has(eff)) return vi().getOrDefault(eff);
        return crit;
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && mx >= lx && mx < lx + lw && my >= ly && my < ly + lh) {
            int i = (int) ((my - ly + listScroll) / ROW);
            if (i >= 0 && i < list.size()) {
                selected = list.get(i);
                critScroll = 0;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (mx < rx - 4) listScroll = Mth.clamp(listScroll - (int) (delta * ROW), 0, Math.max(0, list.size() * ROW - lh));
        else critScroll = Mth.clamp(critScroll - (int) (delta * 20), 0, maxCrit);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (keyMatches(ClientSetup.KEY_ADV, key, scan)) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ ClientAdvancements.Listener (26.3)

    private void refill(ClientAdvancements adv) {
        progress.clear();
        for (var e : adv.progress().entrySet()) progress.put(e.getKey().value(), e.getValue());
        if (width > 0) rebuild();
    }

    @Override
    public void onAdvancementsUpdated() {
        if (Minecraft.getInstance().player != null) refill(Minecraft.getInstance().player.connection.getAdvancements());
    }

    @Override
    public void onSelectedTabChanged(net.minecraft.advancements.AdvancementHolder a) {
    }

    @Override
    public void onAdvancementsCleared() {
        progress.clear();
    }

    /** v9: on 26.3 the client copy of an advancement has no criteria map; count from the synced progress instead. */
    private int tot(Advancement a) {
        AdvancementProgress p = progress.get(a);
        if (p == null) return a.requirements().size();
        return Math.max(a.requirements().size(), count(p.getCompletedCriteria()) + count(p.getRemainingCriteria()));
    }
}
