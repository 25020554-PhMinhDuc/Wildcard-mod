package com.hoang.wildcard.client;

import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.ModParticles;
import net.fabricmc.fabric.api.client.particle.v1.ParticleProviderRegistry;

public final class ParticleSetup {
    /** Called from the client entrypoint. */
    public static void providers() {
        for (Element e : Element.values()) {
            ParticleProviderRegistry.getInstance().register(ModParticles.RUNE.get(e).get(), sprites ->
                    (type, level, x, y, z, vx, vy, vz, rng) -> new MagicParticle(level, x, y, z, vx, vy, vz, sprites, e, true));
        }
    }

    private ParticleSetup() {}
}
