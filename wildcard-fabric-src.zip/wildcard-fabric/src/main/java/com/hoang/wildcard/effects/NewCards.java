package com.hoang.wildcard.effects;

import net.minecraft.world.entity.monster.Enderman;
import net.minecraft.world.entity.monster.spider.Spider;
import net.minecraft.world.entity.animal.rabbit.Rabbit;
import net.minecraft.world.entity.animal.bee.Bee;
import net.minecraft.world.entity.animal.cow.Cow;
import net.minecraft.world.entity.animal.pig.Pig;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.world.entity.animal.chicken.Chicken;

import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.JukeboxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import com.hoang.wildcard.fe.common.ForgeMod;
import com.hoang.wildcard.fe.common.Tags;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.EntityJoinLevelEvent;
import com.hoang.wildcard.fe.event.entity.living.*;
import com.hoang.wildcard.fe.event.entity.player.*;
import com.hoang.wildcard.fe.event.level.BlockEvent;
import com.hoang.wildcard.fe.event.level.ExplosionEvent;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;

import java.util.function.Predicate;

import static com.hoang.wildcard.effects.Effects.*;

/** Passive buffs and debuffs of the v2 cards (c21-c40, u21-u60, r21-r25) and the skill-driven combat hooks. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class NewCards {

    // ================================================================== helpers

    static boolean near(Level level, BlockPos c, int r, Predicate<BlockState> test) {
        for (BlockPos q : BlockPos.betweenClosed(c.offset(-r, -1, -r), c.offset(r, 2, r))) {
            if (test.test(level.getBlockState(q))) return true;
        }
        return false;
    }

    static boolean melee(DamageSource src) {
        return CombatEffects.melee(src);
    }

    static boolean holding(Player p, Item... items) {
        for (Item i : items) if (p.getMainHandItem().is(i) || p.getOffhandItem().is(i)) return true;
        return false;
    }

    static boolean hot(ServerPlayer p) {
        return p.level().dimension() == Level.NETHER || p.level().getBiome(p.blockPosition()).value().getBaseTemperature() > 1.0f;
    }

    static boolean undead(Entity e) {
        return e instanceof LivingEntity le && com.hoang.wildcard.compat.MC.undead(le);
    }

    static void alertMonsters(ServerPlayer p, double r) {
        if (p.isCreative()) return;
        for (Monster m : p.level().getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(r), x -> x.getTarget() == null)) m.setTarget(p);
    }

    /** Extra hunger multiplier, used by {@link Effects}' exhaustion tracker. */
    static float exhaustMult(Player p) {
        float m = 1f;
        // v7.2: bỏ các bất lợi tốn đói (c22, u57, u59 - xem V72Cards)
        m *= GenEffects.exhaustMult(p) * TrollDebuffs.exhaustMult(p);
        return m;
    }

    // ================================================================== ticking

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Player pl = e.player;
        if (pl.level().isClientSide()) {
            // Tay Bận: cầm bản đồ hoặc la bàn thì không chạy nước rút được (sprint is client-side)
            if (com.hoang.wildcard.Cards.debuffOn(pl, "c40") && holding(pl, Items.MAP, Items.FILLED_MAP, Items.COMPASS, Items.RECOVERY_COMPASS)) pl.setSprinting(false);
            return;
        }
        if (!(pl instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        WData d = WData.get(p);
        if (d.cards.isEmpty()) return;
        PlayerState st = PlayerState.get(p);
        ServerLevel level = p.level();
        RandomSource rng = p.getRandom();
        long now = level.getGameTime();
        int tc = p.tickCount;
        BlockPos bp = p.blockPosition();

        // ---- every tick
        if (has(p, "c24") && p.isUnderWater() && rng.nextInt(4) == 0) p.setAirSupply(Math.min(p.getMaxAirSupply(), p.getAirSupply() + 1));
        if (has(p, "c30") && p.isInPowderSnow && p.getTicksFrozen() > 0) p.setTicksFrozen(0);
        if (has(p, "c28") && tc % 2 == 0) {
            for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(2.5), x -> !x.hasPickUpDelay())) {
                ie.setPos(p.getX(), p.getY() + 0.2, p.getZ());
            }
        }
        armorTracker(p, st, rng);
        waterTracker(p, st, now);
        fireTracker(p, st);

        // Đấu Sĩ: hết chuỗi
        if (st.num("r25_streak") > 0 && now >= st.time("r25_until")) {
            st.num("r25_streak", 0);
            if (has(p, "r25")) effect(p, MobEffects.SLOWNESS, 100, 0);
        }

        if (tc % 10 == 0) attributes(p, st, now);
        if (tc % 20 == 0) everySecond(p, st, level, bp, now, rng);

        // Mũi Thính
        if (has(p, "c36") && tc % 400 == 0) {
            for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(12), x -> x instanceof Enemy)) {
                m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20, 0, false, false));
            }
        }
        // Ngộp Thở
        if (com.hoang.wildcard.Cards.debuffOn(p, "u35") && p.getY() < 0 && tc % 1200 == 600) effect(p, MobEffects.NAUSEA, 60, 0);
        // Lóa Nắng
        if (com.hoang.wildcard.Cards.debuffOn(p, "u46") && tc % 1200 == 0 && level.isBrightOutside() && !level.isRaining() && level.canSeeSky(bp.above())) {
            Net.toPlayer(p, new Net.Fx("flash", 20));
        }
    }

    private static void attributes(ServerPlayer p, PlayerState st, long now) {
        AttributeModifier.Operation ADD = AttributeModifier.Operation.ADD_VALUE;
        AttributeModifier.Operation MUL = AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL;
        attr(p, Attributes.MOVEMENT_SPEED, "c22_speed", 0.05, MUL, has(p, "c22"));
        attr(p, Attributes.MAX_HEALTH, "c29_hp", 2, ADD, has(p, "c29"));
        attr(p, Attributes.ATTACK_SPEED, "c29_as", -0.05, MUL, has(p, "c29"));
        attr(p, ForgeMod.SWIM_SPEED.get(), "c32_swim", 0.15, MUL, has(p, "c32"));
        boolean mapInHand = holding(p, Items.MAP, Items.FILLED_MAP, Items.COMPASS, Items.RECOVERY_COMPASS);
        attr(p, Attributes.MOVEMENT_SPEED, "c40_speed", 0.10, MUL, has(p, "c40") && mapInHand);
        attr(p, Attributes.ATTACK_DAMAGE, "u21_dmg", 1, ADD, has(p, "u21"));
        attr(p, Attributes.ATTACK_SPEED, "u21_as", -0.10, MUL, has(p, "u21"));
        attr(p, Attributes.ARMOR, "u22_armor", 1, ADD, has(p, "u22"));
        attr(p, Attributes.ARMOR_TOUGHNESS, "u22_tough", 1, ADD, has(p, "u22"));
        attr(p, ForgeMod.BLOCK_REACH.get(), "u29_reach", 1.5, ADD, has(p, "u29"));
        attr(p, ForgeMod.ENTITY_REACH.get(), "u29_ereach", -0.5, ADD, has(p, "u29"));
        attr(p, Attributes.KNOCKBACK_RESISTANCE, "u33_kb", 0.5, ADD, has(p, "u33"));
        attr(p, ForgeMod.SWIM_SPEED.get(), "u42_swim", 0.30, MUL, has(p, "u42"));
        attr(p, Attributes.MOVEMENT_SPEED, "u42_wet", -0.10, MUL, has(p, "u42") && now < st.time("u42_wet"));
        int armorCount = 0;
        for (ItemStack a : com.hoang.wildcard.compat.MC.armor(p)) if (!a.isEmpty()) armorCount++;
        attr(p, Attributes.MOVEMENT_SPEED, "u48_heavy", -0.10, MUL, has(p, "u48") && armorCount == 4);
        attr(p, Attributes.ATTACK_SPEED, "u51_as", 0.10, MUL, has(p, "u51"));
        // ---- Thần thoại
        double lost = Mythic.lostHealth(WData.get(p));
        attr(p, Attributes.MAX_HEALTH, "mythic_lost", -lost, ADD, lost > 0);
        attr(p, Attributes.ARMOR, "m02_armor", 0, ADD, false); // v8: giáp chuyển sang GenExtra
        attr(p, Attributes.ATTACK_SPEED, "m03_as", 0, MUL, false); // v8: chuyển sang GenExtra
        attr(p, ForgeMod.BLOCK_REACH.get(), "m04_reach", 3, ADD, has(p, "m04"));
        attr(p, Attributes.MAX_HEALTH, "m05_hp", 0, ADD, false); // v7.1: bỏ -máu tối đa
        attr(p, Attributes.ATTACK_SPEED, "m05_as", 0, MUL, false); // v7.3: bỏ (trùng tốc đánh +40%)
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    private static void everySecond(ServerPlayer p, PlayerState st, ServerLevel level, BlockPos bp, long now, RandomSource rng) {
        boolean sunny = level.isBrightOutside() && !level.isRaining() && level.canSeeSky(bp.above());
        FoodData fd = p.getFoodData();
        int secs = p.tickCount / 20;

        // ---- Phổ biến
        if (com.hoang.wildcard.Cards.debuffOn(p, "c24") && p.isInWaterOrRain() && !p.isInWater()) effect(p, MobEffects.SLOWNESS, 40, 0);
        if (has(p, "c27") && holding(p, Items.TORCH, Items.SOUL_TORCH)) keep(p, MobEffects.NIGHT_VISION, 0);
        if (com.hoang.wildcard.Cards.debuffOn(p, "c27") && near(level, bp, 2, s -> s.is(BlockTags.FIRE) || s.is(Blocks.LAVA) || (s.is(BlockTags.CAMPFIRES) && s.getValue(CampfireBlock.LIT)))) {
            effect(p, MobEffects.WEAKNESS, 40, 0);
        }
        if (com.hoang.wildcard.Cards.debuffOn(p, "c30") && (level.dimension() == Level.NETHER || level.getBiome(bp).is(Biomes.DESERT))) effect(p, MobEffects.SLOWNESS, 40, 0);
        if (com.hoang.wildcard.Cards.debuffOn(p, "c36") && now >= st.time("c36_pollen") && near(level, bp, 1, s -> s.is(BlockTags.FLOWERS))) {
            effect(p, MobEffects.NAUSEA, 60, 0);
            st.time("c36_pollen", now + 200);
        }
        // ---- Không phổ biến
        if (has(p, "u23") && p.isUnderWater()) {
            keep(p, MobEffects.HASTE, 0);
            keep(p, MobEffects.NIGHT_VISION, 0);
        }
        if (com.hoang.wildcard.Cards.debuffOn(p, "u26") && p.isSprinting() && secs % 2 == 0) alertMonsters(p, 12);
        if (com.hoang.wildcard.Cards.debuffOn(p, "u31") && p.getY() < 0) effect(p, MobEffects.MINING_FATIGUE, 40, 0);
        if (has(p, "u32")) {
            for (Bee b : level.getEntitiesOfClass(Bee.class, p.getBoundingBox().inflate(16), x -> x.getTarget() == p)) {
                b.setTarget(null);
                b.stopBeingAngry();
            }
        }
        if (has(p, "u34") && fd.getFoodLevel() >= 20) effect(p, MobEffects.STRENGTH, 40, 0);
        if (com.hoang.wildcard.Cards.debuffOn(p, "u34") && fd.getFoodLevel() < 6) effect(p, MobEffects.WEAKNESS, 40, 0);
        if (has(p, "u35") && p.getY() < 0) effect(p, MobEffects.SPEED, 40, 0);
        if (has(p, "u39")) {
            boolean fire = near(level, bp, 3, s -> s.is(BlockTags.CAMPFIRES) && s.getValue(CampfireBlock.LIT));
            st.num("u39_secs", fire ? st.num("u39_secs") + 1 : 0);
            if (fire && secs % 3 == 0) p.heal(1f);
            if (st.num("u39_secs") > 10) {
                effect(p, MobEffects.BLINDNESS, 40, 0);
                st.num("u39_secs", 0);
            }
        }
        if (has(p, "u41") && p.getVehicle() instanceof AbstractHorse h) h.addEffect(new MobEffectInstance(MobEffects.SPEED, 40, 0, false, false));
        if (com.hoang.wildcard.Cards.debuffOn(p, "u44") && !p.isCreative()) {
            for (Enderman em : level.getEntitiesOfClass(Enderman.class, p.getBoundingBox().inflate(16))) {
                if (em.getTarget() == null) em.setTarget(p);
            }
        }
        if (has(p, "u45") && fd.getFoodLevel() >= 18 && secs % 4 == 0) p.heal(1f);
        if (has(p, "u46") && level.getMaxLocalRawBrightness(bp) < 7) {
            for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(8), x -> x instanceof Enemy)) {
                m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 30, 0, false, false));
            }
        }
        if (has(p, "u54") && p.getHealth() < p.getMaxHealth() * 0.5f) effect(p, MobEffects.SPEED, 40, 0);
        if (com.hoang.wildcard.Cards.debuffOn(p, "u55") && p.experienceLevel >= 30) effect(p, MobEffects.SLOWNESS, 40, 0);
        if (has(p, "u56") && fullMoonNight(level)) {
            effect(p, MobEffects.STRENGTH, 40, 0);
            effect(p, MobEffects.SPEED, 40, 0);
        }
        if (has(p, "u60") && secs % 4 == 0 && near(level, bp, 6, s -> s.is(Blocks.JUKEBOX) && s.getValue(JukeboxBlock.HAS_RECORD))) p.heal(1f);
        // ---- Hiếm
        if (has(p, "r21") && level.isDarkOutside()) keep(p, MobEffects.GLOWING, 0);
        if (has(p, "r22") && p.getHealth() < p.getMaxHealth() * 0.3f && st.ready("r22", now, 1200)) {
            p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 100, 0, false, false, true));
            Skills.clearAggro(p, 32);
            level.sendParticles(ParticleTypes.SQUID_INK, p.getX(), p.getY() + 1, p.getZ(), 30, 0.4, 0.5, 0.4, 0.02);
        }
        if (has(p, "r23") && hot(p)) effect(p, MobEffects.SLOWNESS, 40, 0);
        // ---- Thần thoại
        boolean outdoorsDay = level.dimension() == Level.OVERWORLD && level.isBrightOutside() && !level.isRaining() && level.canSeeSky(bp.above());
        // v8: nắng của M1, Haste của M3, Mù của M5 chuyển sang MythicV8
        if (has(p, "m02")) {
            keep(p, MobEffects.FIRE_RESISTANCE, 0);
            Mythic.dragonArmor(p);
        }
    }

    static boolean fullMoonNight(Level level) {
        return level.dimension() == Level.OVERWORLD && level.isDarkOutside() && level.environmentAttributes().getDimensionValue(net.minecraft.world.attribute.EnvironmentAttributes.MOON_PHASE) == net.minecraft.world.level.MoonPhase.FULL_MOON;
    }

    /** Giáp Bền: 25% of armor durability loss is undone. */
    private static void armorTracker(ServerPlayer p, PlayerState st, RandomSource rng) {
        if (!has(p, "u48")) return;
        for (int i = 0; i < 4; i++) {
            ItemStack a = com.hoang.wildcard.compat.MC.armor(p).get(i);
            int id = a.isEmpty() ? -1 : Item.getId(a.getItem());
            if (a.isDamageableItem() && st.num("u48_i" + i) == id) {
                int prev = st.num("u48_d" + i);
                if (a.getDamageValue() > prev && rng.nextFloat() < 0.25f) a.setDamageValue(prev);
            }
            st.num("u48_i" + i, id);
            st.num("u48_d" + i, a.getDamageValue());
        }
    }

    private static void waterTracker(ServerPlayer p, PlayerState st, long now) {
        boolean in = p.isInWater();
        boolean was = st.num("wet") == 1;
        if (was && !in) {
            if (com.hoang.wildcard.Cards.debuffOn(p, "u23")) effect(p, MobEffects.SLOWNESS, 100, 0); // Mắc Cạn
            if (com.hoang.wildcard.Cards.debuffOn(p, "u42")) st.time("u42_wet", now + 200);                     // Lông Ướt
        }
        st.num("wet", in ? 1 : 0);
        // Chuột Rút
        if (com.hoang.wildcard.Cards.debuffOn(p, "c32")) {
            int under = p.isUnderWater() ? st.num("c32_under") + 1 : 0;
            if (under > 600) {
                effect(p, MobEffects.MINING_FATIGUE, 60, 1); // v7.3: thay Chậm Chạp (trùng tốc bơi)
                under = 0;
            }
            st.num("c32_under", under);
        }
    }

    /** Tóc Dễ Cháy (+1 s) and Dễ Bắt Lửa (+50%) when the player catches fire. */
    private static void fireTracker(ServerPlayer p, PlayerState st) {
        int fire = p.getRemainingFireTicks();
        int prev = st.num("fire");
        if (fire > 0 && prev <= 0) {
            int extra = 0;
            if (com.hoang.wildcard.Cards.debuffOn(p, "c38")) extra += 20;
            if (com.hoang.wildcard.Cards.debuffOn(p, "u24")) extra += fire / 2;
            if (extra > 0) p.setRemainingFireTicks(fire + extra);
        }
        st.num("fire", p.getRemainingFireTicks());
    }

    // ================================================================== combat

    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        DamageSource src = e.getSource();
        if (has(p, "u57") && src.is(DamageTypes.STARVE)) { e.setCanceled(true); return; }   // Sinh Tồn
        if (has(p, "u59") && src.is(DamageTypes.HOT_FLOOR)) { e.setCanceled(true); return; } // Chân Chịu Nhiệt
        if (has(p, "u36") && melee(src) && p.getRandom().nextFloat() < 0.10f) {              // Phản Xạ Nhanh
            e.setCanceled(true);
            effect(p, MobEffects.SLOWNESS, 20, 1);
            p.level().playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_NODAMAGE, SoundSource.PLAYERS, 1f, 1.6f);
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        DamageSource src = e.getSource();
        LivingEntity victim = e.getEntity();
        float amount = e.getAmount();
        long now = victim.level().getGameTime();

        // ---- the player deals damage
        if (src.getEntity() instanceof ServerPlayer p && victim != p) {
            PlayerState st = PlayerState.get(p);
            boolean m = melee(src);
            ItemStack main = p.getMainHandItem();
            float mult = 1f;
            if (m && com.hoang.wildcard.Cards.debuffOn(p, "c21")) mult *= 0.95f;                                            // Răng Sữa
            if (has(p, "u25") && p.level().dimension() == Level.OVERWORLD) mult *= p.level().isDarkOutside() ? 1.15f : com.hoang.wildcard.Cards.debuffOn(p, "u25") ? 0.90f : 1f;
            if (has(p, "u43") && undead(victim)) mult *= 1.20f;
            if (has(p, "u44") && (victim instanceof Creeper || victim instanceof Enderman)) mult *= 1.25f;
            if (com.hoang.wildcard.Cards.debuffOn(p, "u54") && p.getHealth() < p.getMaxHealth() * 0.3f) mult *= 0.80f;
            if (has(p, "r21") && undead(victim)) mult *= 1.50f;
            if (has(p, "r25") && now < st.time("r25_until")) mult *= 1f + 0.10f * st.num("r25_streak");
            if (has(p, "m04") && m) mult *= 0.30f;                                               // Tay Yếu
            amount *= mult;
            if (m) {
                String key = "wc35_" + p.getStringUUID();
                if (has(p, "c35") && !com.hoang.wildcard.compat.MC.pdata(victim).getBooleanOr(key, false)) {           // Ra Đòn Trước
                    com.hoang.wildcard.compat.MC.pdata(victim).putBoolean(key, true);
                    amount += 2f;
                }
                if (has(p, "u49") && main.is(net.minecraft.tags.ItemTags.AXES)) {
                    amount += 2f;
                    effect(p, MobEffects.SLOWNESS, 20, 0);                           // Rìu Nặng
                }
                if (has(p, "u50") && main.is(net.minecraft.tags.ItemTags.SWORDS)) {
                    amount += 1.5f;
                    int hits = st.num("u50_hits") + 1;
                    if (hits >= 20) {
                        effect(p, MobEffects.MINING_FATIGUE, 60, 1);                           // Mỏi Cổ Tay
                        hits = 0;
                    }
                    st.num("u50_hits", hits);
                }
                if (has(p, "u24") && p.getRandom().nextFloat() < 0.15f) victim.igniteForSeconds(3);
                if (has(p, "r23")) {
                    victim.setTicksFrozen(Math.min(victim.getTicksRequiredToFreeze() + 100, victim.getTicksFrozen() + 50));
                    victim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 0));
                }
                if (com.hoang.wildcard.Cards.debuffOn(p, "c33") && com.hoang.wildcard.compat.MC.itemPath(main).startsWith("iron_") && p.getRandom().nextFloat() < 0.10f) {
                    main.hurtAndBreak(1, p, EquipmentSlot.MAINHAND);
                }
            }
            e.setAmount(amount);
            if (has(p, "m01") && m) p.heal(amount * 0.50f);                                       // Khát Máu (v8: 50%)
        }

        // ---- the player takes damage
        if (victim instanceof ServerPlayer p) {
            PlayerState st = PlayerState.get(p);
            Entity att = src.getEntity();
            boolean m = melee(src);
            float mult = 1f;
            if (m && has(p, "c21")) mult *= 0.90f;                                            // Da Cá Sấu
            if (has(p, "c38") && src.is(DamageTypeTags.IS_FIRE)) mult *= 0.75f;               // Chịu Nhiệt
            if (com.hoang.wildcard.Cards.debuffOn(p, "u32") && att instanceof Bee) mult *= 3f;                              // Ong Đốt Đau
            if (com.hoang.wildcard.Cards.debuffOn(p, "u43") && (att instanceof Spider)) mult *= 1.30f;                      // Ghét Nhện
            if (has(p, "u58") && p.isShiftKeyDown() && src.is(DamageTypeTags.IS_PROJECTILE)) mult *= 0.85f;
            if (com.hoang.wildcard.Cards.debuffOn(p, "u58") && m && att != null) {                                          // Lưng Hở
                Vec3 to = att.position().subtract(p.position()).multiply(1, 0, 1);
                Vec3 look = Vec3.directionFromRotation(0, p.getYRot());
                if (to.lengthSqr() > 1e-4 && to.normalize().dot(look) < -0.5) mult *= 1.25f;
            }
            if (has(p, "r22") && p.level().getMaxLocalRawBrightness(p.blockPosition()) > 12) mult *= 1.10f; // Sợ Ánh Sáng
            e.setAmount(e.getAmount() * mult);

            RandomSource rng = p.getRandom();
            if (com.hoang.wildcard.Cards.debuffOn(p, "u33") && rng.nextFloat() < 0.10f) effect(p, MobEffects.NAUSEA, 40, 0);
            if (com.hoang.wildcard.Cards.debuffOn(p, "u41") && p.getVehicle() != null && rng.nextFloat() < 0.25f) p.stopRiding();
            if (com.hoang.wildcard.Cards.debuffOn(p, "u45") && rng.nextFloat() < 0.10f) effect(p, MobEffects.SLOWNESS, 60, 1);
            // Phản Đòn (kỹ năng Sử thi) and Giáp Điện (kỹ năng Huyền thoại)
            if (m && att instanceof LivingEntity le && le != p) {
                if (now < st.time("e18_reflect")) le.hurt(p.damageSources().thorns(p), e.getAmount() * 0.5f);
                if (now < st.time("l01_shock") && now >= st.time("l01_zap")) {
                    st.time("l01_zap", now + 10);
                    smite(p, le, 4f);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onCrit(CriticalHitEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && com.hoang.wildcard.Cards.debuffOn(p, "u51") && e.isVanillaCritical()) e.setDamageModifier(1.25f); // Thiếu Lực
    }

    @SubscribeEvent
    public static void onVisibility(LivingEvent.LivingVisibilityEvent e) {
        if (e.getEntity() instanceof Player p && has(p, "u26") && p.isShiftKeyDown()) e.modifyVisibility(0.5); // Ẩn Mình
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer p) || e.getEntity() == p) return;
        LivingEntity dead = e.getEntity();
        ServerLevel level = p.level();
        RandomSource rng = p.getRandom();
        long now = level.getGameTime();
        PlayerState st = PlayerState.get(p);
        if (has(p, "c31")) { // Thợ Săn
            Item meat = dead instanceof Cow ? Items.BEEF : dead instanceof Pig ? Items.PORKCHOP : dead instanceof Sheep ? Items.MUTTON
                    : dead instanceof Chicken ? Items.CHICKEN : dead instanceof Rabbit ? Items.RABBIT : null;
            if (meat != null) dropAt(level, dead.getX(), dead.getY() + 0.3, dead.getZ(), new ItemStack(meat));
        }
        if (com.hoang.wildcard.Cards.debuffOn(p, "c35") && dead instanceof Mob) effect(p, MobEffects.WEAKNESS, 60, 0); // Đuối Sức
        if (has(p, "u47") && dead instanceof Enemy && rng.nextFloat() < 0.03f) {
            dropAt(level, dead.getX(), dead.getY() + 0.3, dead.getZ(), new ItemStack(Items.EMERALD));
        }
        if (has(p, "r25") && dead instanceof Mob) { // Đấu Sĩ
            int s = now < st.time("r25_until") ? Math.min(5, st.num("r25_streak") + 1) : 1;
            st.num("r25_streak", s);
            st.time("r25_until", now + 200);
            actionBar(p, Component.literal("Đấu Sĩ x" + s).withStyle(ChatFormatting.GOLD));
        }
    }

    // ================================================================== movement

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (p.level().isClientSide()) {
            Vec3 v = p.getDeltaMovement();
            if (com.hoang.wildcard.Cards.debuffOn(p, "u22")) p.setDeltaMovement(v.x, v.y * 0.9, v.z);                      // Nặng Vai
            v = p.getDeltaMovement();
            if (has(p, "u28") && p.isShiftKeyDown()) p.setDeltaMovement(v.x, v.y * 1.5, v.z); // Bước Nhảy Ếch
            return;
        }
        if (!(p instanceof ServerPlayer sp)) return;
        if (com.hoang.wildcard.Cards.debuffOn(sp, "c26") && !sp.isCreative() && sp.getRandom().nextInt(7) == 0) effect(sp, MobEffects.SLOWNESS, 30, 0); // Đầu Gối Yếu
        // Lướt: chạy nước rút + nhảy
        if (has(sp, "u04") && sp.isSprinting() && PlayerState.get(sp).ready("u04", sp.level().getGameTime(), 400)) {
            Vec3 look = Skills.flatLook(sp);
            Skills.push(sp, new Vec3(look.x * 1.6, 0.25, look.z * 1.6));
            sp.level().sendParticles(ParticleTypes.CLOUD, sp.getX(), sp.getY() + 0.2, sp.getZ(), 15, 0.3, 0.1, 0.3, 0.02);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.8f, 1.6f);
            sp.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 100, 0)); // Say Xe
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (has(p, "m05") || p.level().getGameTime() < PlayerState.get(p).time("nofall")) {
            e.setCanceled(true);
            return;
        }
        if (has(p, "c26")) e.setDistance(Math.max(0f, e.getDistance() - 1f));       // Nhảy Nhẹ
        if (com.hoang.wildcard.Cards.debuffOn(p, "u28") && e.getDistance() >= 4f) alertMonsters(p, 16);          // Đáp Đất Ồn
    }

    // ================================================================== items, blocks, food

    @SubscribeEvent
    public static void onUseFinish(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getItem();
        FoodData fd = p.getFoodData();
        if (has(p, "c23") && s.is(Items.BREAD)) fd.eat(2, 0.1f);                       // Bánh Mì Tình Yêu
        if (com.hoang.wildcard.Cards.debuffOn(p, "c23") && s.is(ItemTags.FISHES)) effect(p, MobEffects.NAUSEA, 100, 0);
        if (com.hoang.wildcard.Cards.debuffOn(p, "c31") && s.is(ItemTags.MEAT)) effect(p, MobEffects.NAUSEA, 60, 0);
        if (com.hoang.wildcard.Cards.debuffOn(p, "u27") && s.is(Items.ROTTEN_FLESH)) {
            p.removeEffect(MobEffects.HUNGER);
            effect(p, MobEffects.SLOWNESS, 600, 0);
            effect(p, MobEffects.NAUSEA, 200, 0);
        }
        if (com.hoang.wildcard.Cards.debuffOn(p, "u30") && s.getItem() instanceof PotionItem) {
            effect(p, MobEffects.REGENERATION, 100, 0);
            effect(p, MobEffects.NAUSEA, 60, 0);
        }
        if (has(p, "u32") && s.is(Items.HONEY_BOTTLE)) p.heal(4f);
    }

    @SubscribeEvent
    public static void onUseStart(LivingEntityUseItemEvent.Start e) {
        // Hiệp Sĩ Rồng: không dùng được khiên
        if (e.getEntity() instanceof Player p && has(p, "m02") && e.getItem().getItem() instanceof ShieldItem) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onUseTick(LivingEntityUseItemEvent.Tick e) {
        // Kéo Cung Nhanh: bow charges twice as fast (runs on both sides so the animation matches)
        if (e.getEntity() instanceof Player p && has(p, "u40") && e.getItem().getItem() instanceof BowItem && e.getDuration() > 1) {
            e.setDuration(e.getDuration() - 1);
        }
    }

    @SubscribeEvent
    public static void onEffectAdded(MobEffectEvent.Added e) {
        // Kháng Độc: Độc chỉ kéo dài một nửa
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "u27")) return;
        MobEffectInstance inst = e.getEffectInstance();
        if (inst.getEffect() != MobEffects.POISON) return;
        int total = inst.getDuration();
        int half = total / 2;
        Scheduler.later(half, () -> {
            MobEffectInstance cur = p.getEffect(MobEffects.POISON);
            if (cur != null && cur.getDuration() <= total - half + 2) p.removeEffect(MobEffects.POISON);
        });
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || !(e.getLevel() instanceof ServerLevel level) || p.isCreative()) return;
        BlockState s = e.getState();
        BlockPos pos = e.getPos();
        RandomSource rng = p.getRandom();
        if (s.is(Tags.Blocks.ORES_COAL)) {
            if (has(p, "c25") && rng.nextFloat() < 0.10f) dropAt(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.COAL));
            if (com.hoang.wildcard.Cards.debuffOn(p, "c25")) effect(p, MobEffects.MINING_FATIGUE, 100, 0);
        }
        if (has(p, "u31") && s.is(Tags.Blocks.ORES_DIAMOND) && rng.nextFloat() < 0.10f) {
            dropAt(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.DIAMOND));
        }
        if (has(p, "c33") && rng.nextFloat() < 0.01f) dropAt(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.IRON_NUGGET));
        ItemStack main = p.getMainHandItem();
        if (com.hoang.wildcard.Cards.debuffOn(p, "c33") && com.hoang.wildcard.compat.MC.itemPath(main).startsWith("iron_") && rng.nextFloat() < 0.10f) {
            main.hurtAndBreak(1, p, EquipmentSlot.MAINHAND); // Gỉ Sét
        }
    }

    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        Player p = e.getEntity();
        BlockState s = e.getState();
        if (has(p, "u53") && (s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.BASE_STONE_NETHER) || s.is(Tags.Blocks.STONE) || s.is(Tags.Blocks.COBBLESTONE))) {
            e.setNewSpeed(e.getNewSpeed() * 1.25f);
        }
        if (com.hoang.wildcard.Cards.debuffOn(p, "u53") && s.is(BlockTags.LOGS)) e.setNewSpeed(e.getNewSpeed() * 0.8f);
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !(e.getLevel() instanceof ServerLevel level) || !has(p, "c37")) return;
        BlockState s = e.getPlacedBlock();
        if (!s.is(Blocks.TORCH) && !s.is(Blocks.WALL_TORCH)) return;
        RandomSource rng = p.getRandom();
        if (!p.isCreative() && rng.nextFloat() < 0.10f) Scheduler.later(1, () -> give(p, new ItemStack(Items.TORCH))); // Tiết Kiệm Đuốc
        if (rng.nextFloat() < 0.10f) { // Đuốc Yếu
            BlockPos pos = e.getPos().immutable();
            Scheduler.later(1200, () -> {
                BlockState now = level.getBlockState(pos);
                if (now.is(Blocks.TORCH) || now.is(Blocks.WALL_TORCH)) {
                    level.removeBlock(pos, false);
                    level.sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 6, 0.1, 0.1, 0.1, 0.01);
                }
            });
        }
    }

    @SubscribeEvent
    public static void onPickup(EntityItemPickupEvent e) {
        // Túi Thủng
        if (e.getEntity() instanceof ServerPlayer p && com.hoang.wildcard.Cards.debuffOn(p, "c28") && p.getRandom().nextFloat() < 0.02f) {
            e.setCanceled(true);
            e.getItem().setPickUpDelay(40);
            Vec3 v = new Vec3(p.getRandom().nextGaussian() * 0.15, 0.25, p.getRandom().nextGaussian() * 0.15);
            e.getItem().setDeltaMovement(v);
        }
    }

    @SubscribeEvent
    public static void onXpPickup(PlayerXpEvent.PickupXp e) {
        if (e.getEntity() instanceof ServerPlayer p && has(p, "u55")) p.giveExperiencePoints(1); // Hút Kinh Nghiệm
    }

    @SubscribeEvent
    public static void onWake(PlayerWakeUpEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.wakeImmediately() || !has(p, "c34")) return;
        effect(p, MobEffects.REGENERATION, 600, 0);  // Hơi Ấm
        if (com.hoang.wildcard.Cards.debuffOn(p, "c34")) effect(p, MobEffects.SLOWNESS, 200, 0); // Ngáy To
    }

    @SubscribeEvent
    public static void onFished(ItemFishedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "u37")) return;
        e.damageRodBy(Math.max(1, e.getRodDamage()) * 2); // Dây Câu Mục
        if (p.getRandom().nextFloat() < 0.10f) {           // Câu Kho Báu
            Item[] loot = {Items.NAME_TAG, Items.SADDLE, Items.NAUTILUS_SHELL, Items.BOW, Items.FISHING_ROD, Items.LILY_PAD, Items.EMERALD};
            give(p, new ItemStack(loot[p.getRandom().nextInt(loot.length)]));
        }
    }

    @SubscribeEvent
    public static void onBonemeal(BonemealEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.getLevel().isClientSide() || !has(p, "u38")) return;
        if (!p.isCreative() && p.getRandom().nextFloat() < 0.30f) Scheduler.later(1, () -> give(p, new ItemStack(Items.BONE_MEAL)));
        effect(p, MobEffects.NAUSEA, 40, 0);
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || e.loadedFromDisk() || !(e.getEntity() instanceof AbstractArrow a)) return;
        if (!(a.getOwner() instanceof ServerPlayer p)) return;
        RandomSource rng = p.getRandom();
        if (has(p, "c39")) a.setBaseDamage(com.hoang.wildcard.compat.MC.baseDamage(a) + 0.5);       // Cung Thủ Tập Sự
        boolean wobble = (com.hoang.wildcard.Cards.debuffOn(p, "u40") && rng.nextFloat() < 0.15f)          // Lệch Tâm
                || (com.hoang.wildcard.Cards.debuffOn(p, "u52") && p.getFoodData().getFoodLevel() < 10);   // Run Khi Đói
        if (wobble) {
            Vec3 v = a.getDeltaMovement();
            double sp = v.length() * 0.25;
            a.setDeltaMovement(v.add(rng.nextGaussian() * sp, rng.nextGaussian() * sp * 0.5, rng.nextGaussian() * sp));
        }
        if (has(p, "u52")) { // Mắt Đại Bàng
            a.setNoGravity(true);
            Scheduler.later(20, () -> {
                if (a.isAlive()) a.setNoGravity(false);
            });
        }
    }

    @SubscribeEvent
    public static void onLoose(ArrowLooseEvent e) {
        // Ngắm Lâu: phải kéo căng hết mới bắn được
        if (e.getEntity() instanceof ServerPlayer p && com.hoang.wildcard.Cards.debuffOn(p, "c39") && e.getCharge() < 20) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        // Hóa Sói: đêm trăng tròn dân làng không giao dịch
        if (e.getEntity() instanceof ServerPlayer p && e.getTarget() instanceof AbstractVillager && com.hoang.wildcard.Cards.debuffOn(p, "u56") && fullMoonNight(p.level())) {
            e.setCanceled(true);
            actionBar(p, Component.translatable("msg.wildcard.fullmoon").withStyle(ChatFormatting.DARK_RED));
        }
    }

    @SubscribeEvent
    public static void onExplosion(ExplosionEvent.Detonate e) {
        // Tai Thính
        if (e.getLevel().isClientSide()) return;
        Vec3 c = e.getExplosion().center();
        for (Player pl : e.getLevel().players()) {
            if (pl instanceof ServerPlayer p && com.hoang.wildcard.Cards.debuffOn(p, "u60") && p.position().distanceToSqr(c) < 100) effect(p, MobEffects.NAUSEA, 60, 0);
        }
    }

    /** Called when a new round starts (after a pick). */
    static void onRoundStart(ServerPlayer p) {
        // v8: M3 bị phạt khi lên cấp (MythicV8.onLevel), không còn mỗi lượt
        if (has(p, "r24")) { // Nợ Nần
            if (p.getInventory().countItem(Items.EMERALD) >= 2) {
                p.getInventory().clearOrCountMatchingItems(s -> s.is(Items.EMERALD), true, 2, p.inventoryMenu.getCraftSlots());
                p.sendSystemMessage(Component.translatable("msg.wildcard.debt").withStyle(ChatFormatting.GOLD));
            } else {
                effect(p, MobEffects.WEAKNESS, 1200, 0);
                p.sendSystemMessage(Component.translatable("msg.wildcard.debt.fail").withStyle(ChatFormatting.RED));
            }
        }
    }

    private NewCards() {}
}
