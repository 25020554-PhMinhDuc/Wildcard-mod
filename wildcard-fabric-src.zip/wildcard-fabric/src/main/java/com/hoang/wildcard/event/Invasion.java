package com.hoang.wildcard.event;

import com.hoang.wildcard.*;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.levelgen.Heightmap;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.EntityJoinLevelEvent;
import com.hoang.wildcard.fe.event.entity.living.LivingDeathEvent;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;

import java.util.*;

/**
 * v7 world event "Quái Vật Xâm Lăng" (Monster Invasion). Each time night falls there is a 20% chance (config), +5% for every night without one (v7.3), back to 20% once it happens. Announced
 * 60 s before, lasts 90 s. Players standing close together count as one place; every place gets its own wave:
 * <ul>
 *   <li>1 player: 3 special zombies + 5 special skeletons. Kill them all: 1 Uncommon+ card.</li>
 *   <li>2+ players: 5-10 strays, 5-10 witches, 5-10 drowned with tridents, 3-5 phantoms (more players = more mobs).
 *       Kill them all: every player of that place gets 1 Rare+ card.</li>
 *   <li>3+ players: 20% chance of a raider band (7 pillagers, 5 vindicators, 2 ravagers, 1 evoker) added to the wave
 *       (still 1 Rare+ each), and 3% chance of a Warden: killing it gives every player 1 Epic+ card.</li>
 * </ul>
 * Whatever is left when the time runs out disappears, without a reward.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class Invasion {
    private static final Random RNG = new Random();
    private static final String TAG = "wildcard_invasion";
    private static final List<Wave> WAVES = new ArrayList<>();
    private static int counter = 0;
    private static int activeId = 0;
    private static long startAt = -1, endAt = -1;
    private static boolean warned;
    private static long lastNight = -1;

    private static final class Wave {
        final Set<UUID> players = new LinkedHashSet<>();
        final Set<UUID> mobs = new HashSet<>();
        final Set<UUID> warden = new HashSet<>();
        final ServerLevel level;
        final Rarity reward;
        int total;
        boolean cleared, wardenDone;
        final ServerBossEvent bar = new ServerBossEvent(java.util.UUID.randomUUID(), Component.empty(), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);

        Wave(ServerLevel level, Rarity reward) {
            this.level = level;
            this.reward = reward;
        }
    }

    /** v7.3: nights in a row without an invasion (saved with the world). */
    public static final class Pity extends net.minecraft.world.level.saveddata.SavedData {
        int misses;

        static Pity load(net.minecraft.nbt.CompoundTag t) {
            Pity p = new Pity();
            p.misses = t.getIntOr("misses", 0);
            return p;
        }

        static final net.minecraft.world.level.saveddata.SavedDataType<Pity> TYPE = com.hoang.wildcard.compat.MC.savedType("invasion", Pity::new, Pity::load, x -> x.save(new net.minecraft.nbt.CompoundTag()));

        public net.minecraft.nbt.CompoundTag save(net.minecraft.nbt.CompoundTag t) {
            t.putInt("misses", misses);
            return t;
        }
    }

    static Pity pity(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(Pity.TYPE);
    }

    /** /wildcard invasion: start after the normal warning, or right away with {@code now}. */
    public static void schedule(MinecraftServer server, boolean now) {
        if (activeId != 0) finish(server);
        long t = server.overworld().getGameTime();
        startAt = now ? t : t + Config.INVASION_WARN_SECONDS.get() * 20L;
        warned = now;
        if (!now) warn(server);
        else start(server);
    }

    private static void warn(MinecraftServer server) {
        warned = true;
        broadcast(server, Component.translatable("msg.wildcard.invasion.warn", Config.INVASION_WARN_SECONDS.get()).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
        for (ServerPlayer p : server.getPlayerList().getPlayers())
            p.level().playSound(null, p.blockPosition(), SoundEvents.RAID_HORN.value(), SoundSource.MASTER, 2f, 1f);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = e.getServer();
        ServerLevel ow = server.overworld();
        long now = ow.getGameTime();
        if (now % 20 != 0) return;
        // trời vừa tối: tung xúc xắc
        long dt = com.hoang.wildcard.compat.MC.dayTime(ow) % 24000, day = com.hoang.wildcard.compat.MC.dayTime(ow) / 24000;
        if (dt >= 13000 && dt < 13200 && day != lastNight) {
            lastNight = day;
            // v7.3: 20% + 5% mỗi đêm trượt, về lại 20% khi sự kiện xảy ra
            Pity pity = pity(server);
            double chance = Math.min(1.0, Config.INVASION_CHANCE.get() + Config.INVASION_STEP.get() * pity.misses);
            if (activeId == 0 && startAt < 0 && Config.INVASION_CHANCE.get() > 0 && !server.getPlayerList().getPlayers().isEmpty()) {
                if (RNG.nextDouble() < chance) {
                    pity.misses = 0;
                    schedule(server, false);
                } else pity.misses++;
                pity.setDirty();
            }
        }
        if (startAt >= 0 && activeId == 0) {
            long left = startAt - now;
            if (left > 0 && left <= 200) {
                for (ServerPlayer p : server.getPlayerList().getPlayers())
                    p.sendOverlayMessage(Component.translatable("msg.wildcard.invasion.count", left / 20).withStyle(ChatFormatting.RED));
            }
            if (now >= startAt) start(server);
            return;
        }
        if (activeId == 0) return;
        if (now >= endAt) {
            finish(server);
            return;
        }
        for (Wave w : WAVES) updateBar(w, now);
    }

    private static void start(MinecraftServer server) {
        ServerLevel ow = server.overworld();
        long now = ow.getGameTime();
        startAt = -1;
        WAVES.clear();
        activeId = ++counter;
        endAt = now + Config.INVASION_SECONDS.get() * 20L;
        List<ServerPlayer> all = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isSpectator()) continue;
            if (p.level() != ow) {
                p.sendSystemMessage(Component.translatable("msg.wildcard.invasion.away").withStyle(ChatFormatting.GRAY));
                continue;
            }
            all.add(p);
        }
        broadcast(server, Component.translatable("msg.wildcard.invasion.start", Config.INVASION_SECONDS.get()).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("title.wildcard.invasion").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)));
            p.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("title.wildcard.invasion.sub", Config.INVASION_SECONDS.get())));
            p.level().playSound(null, p.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.MASTER, 0.7f, 0.8f);
        }
        // gom người chơi đứng gần nhau thành một nơi
        double r = Config.INVASION_GROUP_RADIUS.get();
        List<List<ServerPlayer>> groups = new ArrayList<>();
        Set<ServerPlayer> left = new LinkedHashSet<>(all);
        while (!left.isEmpty()) {
            ServerPlayer first = left.iterator().next();
            List<ServerPlayer> g = new ArrayList<>();
            Deque<ServerPlayer> q = new ArrayDeque<>(List.of(first));
            left.remove(first);
            while (!q.isEmpty()) {
                ServerPlayer cur = q.poll();
                g.add(cur);
                for (Iterator<ServerPlayer> it = left.iterator(); it.hasNext(); ) {
                    ServerPlayer o = it.next();
                    if (o.distanceToSqr(cur) <= r * r) {
                        it.remove();
                        q.add(o);
                    }
                }
            }
            groups.add(g);
        }
        for (List<ServerPlayer> g : groups) spawnWave(ow, g);
    }

    private static void spawnWave(ServerLevel level, List<ServerPlayer> group) {
        int n = group.size();
        double cx = 0, cz = 0;
        for (ServerPlayer p : group) {
            cx += p.getX();
            cz += p.getZ();
        }
        cx /= n;
        cz /= n;
        Wave w = new Wave(level, n >= 2 ? Rarity.RARE : Rarity.UNCOMMON);
        for (ServerPlayer p : group) w.players.add(p.getUUID());
        if (n == 1) {
            for (int i = 0; i < 3; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.ZOMBIE, cx, cz, group, false, true);
            for (int i = 0; i < 5; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.SKELETON, cx, cz, group, false, true);
        } else {
            int extra = Math.min(5, (n - 2) * 2);
            int many = Math.min(10, 5 + extra + RNG.nextInt(Math.max(1, 6 - extra)));
            for (int i = 0; i < many; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.STRAY, cx, cz, group, false, false);
            many = Math.min(10, 5 + extra + RNG.nextInt(Math.max(1, 6 - extra)));
            for (int i = 0; i < many; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.WITCH, cx, cz, group, false, false);
            many = Math.min(10, 5 + extra + RNG.nextInt(Math.max(1, 6 - extra)));
            for (int i = 0; i < many; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.DROWNED, cx, cz, group, false, false);
            int ph = Math.min(5, 3 + (n - 2) + RNG.nextInt(2));
            for (int i = 0; i < ph; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.PHANTOM, cx, cz, group, true, false);
            if (n >= 3 && RNG.nextDouble() < 0.20) { // đám Cướp dân làng điên loạn
                for (int i = 0; i < 7; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.PILLAGER, cx, cz, group, false, false);
                for (int i = 0; i < 5; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.VINDICATOR, cx, cz, group, false, false);
                for (int i = 0; i < 2; i++) spawn(level, w, net.minecraft.world.entity.EntityTypes.RAVAGER, cx, cz, group, false, false);
                spawn(level, w, net.minecraft.world.entity.EntityTypes.EVOKER, cx, cz, group, false, false);
                for (ServerPlayer p : group) p.sendSystemMessage(Component.translatable("msg.wildcard.invasion.raiders").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
            }
            if (n >= 3 && RNG.nextDouble() < 0.03) { // Warden
                Mob warden = spawn(level, w, net.minecraft.world.entity.EntityTypes.WARDEN, cx, cz, group, false, false);
                if (warden != null) {
                    w.mobs.remove(warden.getUUID());
                    w.warden.add(warden.getUUID());
                    for (ServerPlayer p : group) p.sendSystemMessage(Component.translatable("msg.wildcard.invasion.warden").withStyle(ChatFormatting.DARK_AQUA, ChatFormatting.BOLD));
                }
            }
        }
        w.total = w.mobs.size();
        for (ServerPlayer p : group) w.bar.addPlayer(p);
        WAVES.add(w);
        updateBar(w, level.getGameTime());
    }

    private static Mob spawn(ServerLevel level, Wave w, EntityType<? extends Mob> type, double cx, double cz, List<ServerPlayer> group,
                             boolean air, boolean special) {
        Mob m = type.create(level, net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED);
        if (m == null) return null;
        double ang = RNG.nextDouble() * Math.PI * 2, dist = 10 + RNG.nextDouble() * 10;
        int x = (int) Math.floor(cx + Math.cos(ang) * dist), z = (int) Math.floor(cz + Math.sin(ang) * dist);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) + (air ? 14 + RNG.nextInt(6) : 0);
        m.snapTo(x + 0.5, y, z + 0.5, RNG.nextFloat() * 360, 0);
        m.finalizeSpawn(level, level.getCurrentDifficultyAt(BlockPos.containing(m.position())), EntitySpawnReason.EVENT, null);
        if (type == net.minecraft.world.entity.EntityTypes.DROWNED) m.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.TRIDENT));
        if (special) { // zombie / skeleton đặc biệt
            m.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
            m.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.CHAINMAIL_CHESTPLATE));
            if (type == net.minecraft.world.entity.EntityTypes.ZOMBIE) m.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
            else {
                ItemStack bow = new ItemStack(Items.BOW);
                com.hoang.wildcard.compat.MC.enchant(bow, level, net.minecraft.world.item.enchantment.Enchantments.POWER, 2);
                m.setItemSlot(EquipmentSlot.MAINHAND, bow);
            }
            var hp = m.getAttribute(Attributes.MAX_HEALTH);
            if (hp != null) hp.setBaseValue(30);
            m.setHealth(30);
            var spd = m.getAttribute(Attributes.MOVEMENT_SPEED);
            if (spd != null) spd.setBaseValue(spd.getBaseValue() * 1.15);
        }
        for (EquipmentSlot s : EquipmentSlot.values()) m.setDropChance(s, 0f); // đồ của quái sự kiện không rơi
        m.setCustomName(Component.translatable("entity.wildcard.invader", m.getType().getDescription()).withStyle(ChatFormatting.DARK_RED));
        m.setCustomNameVisible(false);
        m.setGlowingTag(true);
        m.setPersistenceRequired();
        com.hoang.wildcard.compat.MC.pdata(m).putInt(TAG, activeId);
        ServerPlayer target = group.get(RNG.nextInt(group.size()));
        m.setTarget(target);
        level.addFreshEntity(m);
        w.mobs.add(m.getUUID());
        com.hoang.wildcard.fx.Vfx.portal(level, m.position().add(0, 1, 0), com.hoang.wildcard.fx.Element.BLOOD, ang, 1.0, 20);
        return m;
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (activeId == 0 || e.getEntity().level().isClientSide()) return;
        if (com.hoang.wildcard.compat.MC.pdata(e.getEntity()).getIntOr(TAG, 0) != activeId) return;
        UUID id = e.getEntity().getUUID();
        MinecraftServer server = e.getEntity().level().getServer();
        for (Wave w : WAVES) {
            if (w.mobs.remove(id) && w.mobs.isEmpty() && !w.cleared) {
                w.cleared = true;
                rewardAll(server, w, w.reward, "reward.wildcard.invasion");
            }
            if (w.warden.remove(id) && !w.wardenDone) {
                w.wardenDone = true;
                rewardAll(server, w, Rarity.EPIC, "reward.wildcard.invasion.warden");
            }
            if (server != null) updateBar(w, server.overworld().getGameTime());
        }
    }

    private static void rewardAll(MinecraftServer server, Wave w, Rarity min, String reason) {
        if (server == null) return;
        for (UUID u : w.players) {
            ServerPlayer p = server.getPlayerList().getPlayer(u);
            if (p == null) continue;
            RoundManager.giveReward(p, RoundManager.rewardCard(WData.get(p), min), Component.translatable(reason));
        }
    }

    private static void updateBar(Wave w, long now) {
        int alive = w.mobs.size() + w.warden.size();
        long secs = Math.max(0, (endAt - now) / 20);
        if (w.cleared && w.warden.isEmpty()) {
            w.bar.setName(Component.translatable("bar.wildcard.invasion.cleared").withStyle(ChatFormatting.GREEN));
            w.bar.setColor(BossEvent.BossBarColor.GREEN);
            w.bar.setProgress(1f);
            return;
        }
        w.bar.setName(Component.translatable("bar.wildcard.invasion", alive, secs).withStyle(ChatFormatting.DARK_RED));
        w.bar.setProgress(Math.max(0f, Math.min(1f, (float) (endAt - now) / (Config.INVASION_SECONDS.get() * 20f))));
    }

    private static void finish(MinecraftServer server) {
        boolean anyLeft = false;
        for (Wave w : WAVES) {
            Set<UUID> rest = new HashSet<>(w.mobs);
            rest.addAll(w.warden);
            if (!rest.isEmpty()) anyLeft = true;
            for (UUID u : rest) {
                Entity ent = w.level.getEntity(u);
                if (ent != null) ent.discard();
            }
            if (!w.cleared) {
                for (UUID u : w.players) {
                    ServerPlayer p = server.getPlayerList().getPlayer(u);
                    if (p != null) p.sendSystemMessage(Component.translatable("msg.wildcard.invasion.failed").withStyle(ChatFormatting.GRAY));
                }
            }
            w.bar.removeAllPlayers();
        }
        WAVES.clear();
        if (activeId != 0) broadcast(server, Component.translatable(anyLeft ? "msg.wildcard.invasion.end" : "msg.wildcard.invasion.end.win").withStyle(ChatFormatting.GRAY));
        activeId = 0;
        startAt = -1;
        endAt = -1;
    }

    /** Invasion mobs left over from an old event (e.g. after a restart) never come back. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        int id = com.hoang.wildcard.compat.MC.pdata(e.getEntity()).getIntOr(TAG, 0);
        if (id != 0 && id != activeId) e.setCanceled(true);
    }

    private static void broadcast(MinecraftServer server, Component msg) {
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    private Invasion() {}
}
