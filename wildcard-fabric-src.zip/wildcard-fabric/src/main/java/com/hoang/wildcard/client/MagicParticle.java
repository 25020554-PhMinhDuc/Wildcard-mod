package com.hoang.wildcard.client;

import com.hoang.wildcard.fx.Element;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.SingleQuadParticle;

/** Glowing spell particle: animated element sparks, or a tinted floating rune. */
public class MagicParticle extends SingleQuadParticle {
    private final SpriteSet sprites;
    private final boolean rune;
    private final float startSize;

    MagicParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                  SpriteSet sprites, Element e, boolean rune) {
        super(level, x, y, z, sprites.get(level.getRandom()));
        this.sprites = sprites;
        this.rune = rune;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.hasPhysics = false;
        if (rune) {
            this.lifetime = 26 + random.nextInt(10);
            this.friction = 0.97f;
            this.gravity = 0;
            this.quadSize = 0.16f + random.nextFloat() * 0.05f;
            this.rCol = ((e.rgb >> 16) & 255) / 255f;
            this.gCol = ((e.rgb >> 8) & 255) / 255f;
            this.bCol = (e.rgb & 255) / 255f;
            setSprite(sprites.get(random));
        } else {
            this.lifetime = 12 + random.nextInt(10);
            this.friction = 0.9f;
            this.gravity = switch (e) {
                case BLOOD, EARTH -> 0.06f;
                case FROST -> 0.01f;
                case FIRE, HOLY, ARCANE, VOID -> -0.015f;
                default -> 0f;
            };
            this.quadSize = 0.12f + random.nextFloat() * 0.08f;
            setSpriteFromAge(sprites);
        }
        this.startSize = quadSize;
    }

    @Override
    public void tick() {
        super.tick();
        if (!removed) {
            float t = age / (float) lifetime;
            if (rune) {
                alpha = t < 0.15f ? t / 0.15f : t > 0.6f ? (1 - t) / 0.4f : 1f;
            } else {
                setSpriteFromAge(sprites);
                quadSize = startSize * (1 - t * 0.5f);
                alpha = t > 0.7f ? (1 - t) / 0.3f : 1f;
            }
        }
    }

    @Override
    protected Layer getLayer() {
        return Layer.TRANSLUCENT;
    }

    @Override
    protected int getLightCoords(float partialTick) {
        return 0xF000F0;
    }
}
