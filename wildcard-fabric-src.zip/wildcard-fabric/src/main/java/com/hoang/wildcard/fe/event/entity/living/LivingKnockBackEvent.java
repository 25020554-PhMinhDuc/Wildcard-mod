package com.hoang.wildcard.fe.event.entity.living;

import net.minecraft.world.entity.LivingEntity;

public class LivingKnockBackEvent extends LivingEvent {
    private float strength;
    public LivingKnockBackEvent(LivingEntity e, float strength) { super(e); this.strength = strength; }
    public float getStrength() { return strength; }
    public void setStrength(float s) { strength = s; }
}
