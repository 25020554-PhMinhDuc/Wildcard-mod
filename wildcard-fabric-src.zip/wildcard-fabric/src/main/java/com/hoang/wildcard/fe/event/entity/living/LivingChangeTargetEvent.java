package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LivingChangeTargetEvent extends LivingEvent {
    private final LivingEntity original; private LivingEntity newTarget;
    public LivingChangeTargetEvent(LivingEntity e, LivingEntity target) { super(e); original = target; newTarget = target; }
    public LivingEntity getNewTarget() { return newTarget; }
    public void setNewTarget(LivingEntity t) { newTarget = t; }
    public LivingEntity getOriginalTarget() { return original; }
}
