package com.hoang.wildcard.client;

import com.hoang.wildcard.WildcardMod;
import net.minecraft.client.KeyMapping;
import com.hoang.wildcard.fe.api.distmarker.Dist;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public final class ClientSetup {
    public static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(net.minecraft.resources.Identifier.fromNamespaceAndPath("wildcard", "main"));
    /** Skill loadout keys: G H J K L. */
    public static final KeyMapping[] KEY_SKILLS = {
            new KeyMapping("key.wildcard.skill1", GLFW.GLFW_KEY_G, CATEGORY),
            new KeyMapping("key.wildcard.skill2", GLFW.GLFW_KEY_H, CATEGORY),
            new KeyMapping("key.wildcard.skill3", GLFW.GLFW_KEY_J, CATEGORY),
            new KeyMapping("key.wildcard.skill4", GLFW.GLFW_KEY_K, CATEGORY),
            new KeyMapping("key.wildcard.skill5", GLFW.GLFW_KEY_L, CATEGORY)};
    public static final KeyMapping KEY_CARDS = new KeyMapping("key.wildcard.cards", GLFW.GLFW_KEY_B, CATEGORY);
    public static final KeyMapping KEY_ENDER = new KeyMapping("key.wildcard.ender", GLFW.GLFW_KEY_N, CATEGORY);
    /** v7.1 Lời Nguyền Pharaoh: phun cát. */
    public static final KeyMapping KEY_SAND = new KeyMapping("key.wildcard.sand", GLFW.GLFW_KEY_X, CATEGORY);
    /** v7.2: bảng tiến trình thành tựu. */
    public static final KeyMapping KEY_ADV = new KeyMapping("key.wildcard.advprogress", GLFW.GLFW_KEY_U, CATEGORY);

    /** Called from the client entrypoint. */
    public static void keys() {
        for (KeyMapping k : KEY_SKILLS) net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper.registerKeyMapping(k);
        for (KeyMapping k : new KeyMapping[]{KEY_CARDS, KEY_ENDER, KEY_SAND, KEY_ADV})
            net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper.registerKeyMapping(k);
    }

    /** Short label of the key currently bound to skill slot {@code i}, e.g. "G". */
    public static String skillKeyLabel(int i) {
        String s = KEY_SKILLS[i].getTranslatedKeyMessage().getString();
        return s.length() > 3 ? s.substring(0, 3) : s;
    }

    private ClientSetup() {}
}
