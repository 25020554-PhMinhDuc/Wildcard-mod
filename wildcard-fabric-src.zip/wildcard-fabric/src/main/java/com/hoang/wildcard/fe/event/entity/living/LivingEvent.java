package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LivingEvent extends com.hoang.wildcard.fe.event.entity.EntityEvent {
    private final LivingEntity living;
    public LivingEvent(LivingEntity e) { super(e); living = e; }
    @Override public LivingEntity getEntity() { return living; }
    public static class LivingJumpEvent extends LivingEvent { public LivingJumpEvent(LivingEntity e) { super(e); } }
    public static class LivingVisibilityEvent extends LivingEvent {
        private double mod; private final Entity looking;
        public LivingVisibilityEvent(LivingEntity e, Entity looking, double mod) { super(e); this.looking = looking; this.mod = mod; }
        public void modifyVisibility(double m) { mod *= m; }
        public double getVisibilityModifier() { return mod; }
        public Entity getLookingEntity() { return looking; }
    }
}
