package com.hoang.wildcard.fe.registries;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

/** Shim: Forge registries backed by vanilla BuiltInRegistries. */
public final class ForgeRegistries {
    public static final class Reg<T> {
        private final Registry<T> r;
        Reg(Registry<T> r) { this.r = r; }
        public Identifier getKey(T t) { return r.getKey(t); }
        public T getValue(Identifier id) { return r.getValue(id); }
        public boolean containsKey(Identifier id) { return r.containsKey(id); }
        public Iterable<T> getValues() { return r; }
        public Registry<T> registry() { return r; }
    }
    public static final Reg<net.minecraft.world.item.Item> ITEMS = new Reg<>(BuiltInRegistries.ITEM);
    public static final Reg<net.minecraft.world.level.block.Block> BLOCKS = new Reg<>(BuiltInRegistries.BLOCK);
    public static final Reg<net.minecraft.world.entity.EntityType<?>> ENTITY_TYPES = new Reg<>(BuiltInRegistries.ENTITY_TYPE);
    public static final Reg<net.minecraft.sounds.SoundEvent> SOUND_EVENTS = new Reg<>(BuiltInRegistries.SOUND_EVENT);
    public static final Reg<net.minecraft.core.particles.ParticleType<?>> PARTICLE_TYPES = new Reg<>(BuiltInRegistries.PARTICLE_TYPE);
    public static final Reg<net.minecraft.world.effect.MobEffect> MOB_EFFECTS = new Reg<>(BuiltInRegistries.MOB_EFFECT);
    private ForgeRegistries() {}
}
