package com.hoang.wildcard.fe.eventbus.api;

import java.util.function.Consumer;
public interface IEventBus {
    void register(Object target);
    <T extends Event> void addListener(Consumer<T> listener);
    boolean post(Event e);
}
