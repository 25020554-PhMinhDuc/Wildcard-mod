package com.hoang.wildcard;

import com.hoang.wildcard.client.ClientState;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.*;

import static com.hoang.wildcard.Rarity.*;

/** Registry of all cards (150 / 196 / 54 / 25 / 10 / 5). Texts live in assets/wildcard/lang/*.json. */
public final class Cards {
    public static final Map<String, Card> ALL = new LinkedHashMap<>();

    static Card add(String id, Rarity r, Item buff, Item debuff, String... tags) {
        Card c = new Card(id, r, buff, debuff, Set.of(tags));
        ALL.put(id, c);
        return c;
    }

    static {
        // ---------------- Phổ biến ----------------
        add("c01", COMMON, Items.RABBIT_FOOT, Items.NOTE_BLOCK, "jump");
        add("c02", COMMON, Items.BREAD, Items.FERMENTED_SPIDER_EYE, "hunger");
        add("c03", COMMON, Items.STONE_PICKAXE, Items.STICK);
        add("c04", COMMON, Items.ENDER_EYE, Items.SUNFLOWER);
        add("c05", COMMON, Items.HOPPER, Items.EXPERIENCE_BOTTLE, "magnet");
        add("c06", COMMON, Items.CAMPFIRE, Items.ICE, "campfire");
        add("c07", COMMON, Items.EGG, Items.FEATHER);
        add("c08", COMMON, Items.FISHING_ROD, Items.COD);
        add("c09", COMMON, Items.LEATHER_CHESTPLATE, Items.ANVIL);
        add("c10", COMMON, Items.COOKED_BEEF, Items.BEEF);
        add("c11", COMMON, Items.STONE_AXE, Items.OAK_LOG);
        add("c12", COMMON, Items.LEATHER_BOOTS, Items.PAPER);
        add("c13", COMMON, Items.ARROW, Items.BOW);
        add("c14", COMMON, Items.BED.red(), Items.ZOMBIE_HEAD, "sleep");
        add("c15", COMMON, Items.TROPICAL_FISH, Items.IRON_INGOT, "swim");
        add("c16", COMMON, Items.EXPERIENCE_BOTTLE, Items.BOOK);
        add("c17", COMMON, Items.TORCH, Items.DYED_CANDLE.black());
        add("c18", COMMON, Items.WHEAT, Items.WHEAT_SEEDS);
        add("c19", COMMON, Items.HAY_BLOCK, Items.CHAINMAIL_BOOTS);
        add("c20", COMMON, Items.EMERALD, Items.IRON_BLOCK, "trade");
        add("c21", COMMON, Items.TURTLE_SCUTE, Items.BONE_MEAL);
        add("c22", COMMON, Items.LEATHER_BOOTS, Items.ROTTEN_FLESH);
        add("c23", COMMON, Items.BREAD, Items.COD);
        add("c24", COMMON, Items.TURTLE_HELMET, Items.WATER_BUCKET);
        add("c25", COMMON, Items.COAL, Items.COAL_ORE);
        add("c26", COMMON, Items.FEATHER, Items.LEATHER_LEGGINGS, "fall");
        add("c27", COMMON, Items.TORCH, Items.FLINT_AND_STEEL, "fire");
        add("c28", COMMON, Items.HOPPER, Items.LEATHER, "magnet");
        add("c29", COMMON, Items.APPLE, Items.SLIME_BALL, "maxhp");
        add("c30", COMMON, Items.WOOL.white(), Items.SAND, "cold");
        add("c31", COMMON, Items.PORKCHOP, Items.CARROT, "meat");
        add("c32", COMMON, Items.PRISMARINE_SHARD, Items.KELP, "swim");
        add("c33", COMMON, Items.IRON_NUGGET, Items.IRON_PICKAXE);
        add("c34", COMMON, Items.BED.white(), Items.NOTE_BLOCK, "sleep");
        add("c35", COMMON, Items.STONE_SWORD, Items.FERMENTED_SPIDER_EYE);
        add("c36", COMMON, Items.SNIFFER_EGG, Items.POPPY);
        add("c37", COMMON, Items.TORCH, Items.SOUL_TORCH);
        add("c38", COMMON, Items.MAGMA_CREAM, Items.BLAZE_POWDER, "burn");
        add("c39", COMMON, Items.ARROW, Items.BOW);
        add("c40", COMMON, Items.MAP, Items.COMPASS);
        // ---------------- Không phổ biến ----------------
        add("u01", UNCOMMON, Items.DIAMOND_ORE, Items.GLOWSTONE_DUST);
        add("u02", UNCOMMON, Items.CACTUS, Items.SPECTRAL_ARROW);
        add("u03", UNCOMMON, Items.VINE, Items.LADDER, "climb");
        add("u04", UNCOMMON, Items.FEATHER, Items.POTION, "dash");
        add("u05", UNCOMMON, Items.REDSTONE, Items.BONE, "maxhp");
        add("u06", UNCOMMON, Items.FIREWORK_ROCKET, Items.ROTTEN_FLESH);
        add("u07", UNCOMMON, Items.BREWING_STAND, Items.SPLASH_POTION, "potion");
        add("u08", UNCOMMON, Items.IRON_SHOVEL, Items.SAND);
        add("u09", UNCOMMON, Items.COD, Items.PHANTOM_MEMBRANE);
        add("u10", UNCOMMON, Items.SUGAR, Items.COOKED_PORKCHOP, "speed");
        add("u11", UNCOMMON, Items.BOW, Items.STRING, "bow");
        add("u12", UNCOMMON, Items.SNOWBALL, Items.POWDER_SNOW_BUCKET);
        add("u13", UNCOMMON, Items.TNT, Items.CREEPER_HEAD);
        add("u14", UNCOMMON, Items.COMPASS, Items.MAP);
        add("u15", UNCOMMON, Items.PUFFERFISH, Items.DEAD_BUSH, "swim");
        add("u16", UNCOMMON, Items.IRON_AXE, Items.WOODEN_AXE, "axe");
        add("u17", UNCOMMON, Items.OAK_SAPLING, Items.HANGING_ROOTS);
        add("u18", UNCOMMON, Items.EMERALD, Items.GOLD_NUGGET, "trade");
        add("u19", UNCOMMON, Items.RABBIT_FOOT, Items.SLIME_BALL, "jump", "dash");
        add("u20", UNCOMMON, Items.ENDER_CHEST, Items.ENDERMITE_SPAWN_EGG);
        add("u21", UNCOMMON, Items.IRON_SWORD, Items.ANVIL);
        add("u22", UNCOMMON, Items.IRON_CHESTPLATE, Items.CHAINMAIL_LEGGINGS);
        add("u23", UNCOMMON, Items.HEART_OF_THE_SEA, Items.DRIED_KELP, "swim");
        add("u24", UNCOMMON, Items.BLAZE_POWDER, Items.FLINT_AND_STEEL, "burn");
        add("u25", UNCOMMON, Items.PHANTOM_MEMBRANE, Items.SUNFLOWER);
        add("u26", UNCOMMON, Items.DYE.gray(), Items.OAK_LEAVES);
        add("u27", UNCOMMON, Items.MILK_BUCKET, Items.ROTTEN_FLESH);
        add("u28", UNCOMMON, Items.SLIME_BALL, Items.NOTE_BLOCK, "jump");
        add("u29", UNCOMMON, Items.SCAFFOLDING, Items.WOODEN_SWORD, "reach");
        add("u30", UNCOMMON, Items.BREWING_STAND, Items.FERMENTED_SPIDER_EYE, "potion");
        add("u31", UNCOMMON, Items.DIAMOND, Items.DEEPSLATE, "deep");
        add("u32", UNCOMMON, Items.HONEY_BOTTLE, Items.BEE_NEST);
        add("u33", UNCOMMON, Items.IRON_BOOTS, Items.POISONOUS_POTATO);
        add("u34", UNCOMMON, Items.GOLDEN_CARROT, Items.BOWL);
        add("u35", UNCOMMON, Items.LANTERN, Items.COBBLED_DEEPSLATE, "deep");
        add("u36", UNCOMMON, Items.RABBIT_HIDE, Items.COBWEB);
        add("u37", UNCOMMON, Items.FISHING_ROD, Items.STRING);
        add("u38", UNCOMMON, Items.BONE_MEAL, Items.DYE.brown());
        add("u39", UNCOMMON, Items.CAMPFIRE, Items.CHARCOAL, "campfire");
        add("u40", UNCOMMON, Items.BOW, Items.TARGET);
        add("u41", UNCOMMON, Items.SADDLE, Items.LEAD);
        add("u42", UNCOMMON, Items.SALMON, Items.WET_SPONGE, "swim");
        add("u43", UNCOMMON, Items.ZOMBIE_HEAD, Items.SPIDER_EYE, "undead");
        add("u44", UNCOMMON, Items.ENDER_PEARL, Items.ENDERMAN_SPAWN_EGG);
        add("u45", UNCOMMON, Items.GLISTERING_MELON_SLICE, Items.SPIDER_EYE);
        add("u46", UNCOMMON, Items.ENDER_EYE, Items.SUNFLOWER);
        add("u47", UNCOMMON, Items.EMERALD, Items.GOLD_NUGGET, "trade");
        add("u48", UNCOMMON, Items.DIAMOND_CHESTPLATE, Items.IRON_LEGGINGS);
        add("u49", UNCOMMON, Items.IRON_AXE, Items.STONE_AXE, "axe");
        add("u50", UNCOMMON, Items.IRON_SWORD, Items.STRING);
        add("u51", UNCOMMON, Items.GOLDEN_SWORD, Items.WOODEN_SWORD);
        add("u52", UNCOMMON, Items.SPECTRAL_ARROW, Items.ARROW);
        add("u53", UNCOMMON, Items.STONE_PICKAXE, Items.OAK_LOG);
        add("u54", UNCOMMON, Items.GOLDEN_HELMET, Items.BANNER.white());
        add("u55", UNCOMMON, Items.EXPERIENCE_BOTTLE, Items.ENCHANTED_BOOK);
        add("u56", UNCOMMON, Items.WOLF_SPAWN_EGG, Items.BONE);
        add("u57", UNCOMMON, Items.COOKED_BEEF, Items.ROTTEN_FLESH, "hunger");
        add("u58", UNCOMMON, Items.SHIELD, Items.ARROW);
        add("u59", UNCOMMON, Items.MAGMA_BLOCK, Items.NETHERRACK);
        add("u60", UNCOMMON, Items.JUKEBOX, Items.GUNPOWDER);
        // ---------------- Hiếm ----------------
        add("r01", RARE, Items.IRON_GOLEM_SPAWN_EGG, Items.SCAFFOLDING, "size", "maxhp", "reach");
        add("r02", RARE, Items.TIPPED_ARROW, Items.TNT, "bow");
        add("r03", RARE, Items.DIRT, Items.SAND);
        add("r04", RARE, Items.TOTEM_OF_UNDYING, Items.WOODEN_SWORD, "death");
        add("r05", RARE, Items.SPYGLASS, Items.GLOWSTONE);
        add("r06", RARE, Items.ENDER_PEARL, Items.IRON_BOOTS, "magnet", "jump");
        add("r07", RARE, Items.LIGHTNING_ROD.weathering().unaffected(), Items.LIGHTNING_ROD.weathering().unaffected());
        add("r08", RARE, Items.FEATHER, Items.SLIME_BLOCK, "fall");
        add("r09", RARE, Items.DYE.black(), Items.GLOW_INK_SAC);
        add("r10", RARE, Items.IRON_SWORD, Items.FURNACE);
        add("r11", RARE, Items.BONE, Items.MUTTON);
        add("r12", RARE, Items.ANVIL, Items.CHIPPED_ANVIL);
        add("r13", RARE, Items.LILY_PAD, Items.WATER_BUCKET, "water");
        add("r14", RARE, Items.SLIME_BALL, Items.SPIDER_EYE);
        add("r15", RARE, Items.IRON_HELMET, Items.CHAINMAIL_HELMET);
        add("r16", RARE, Items.FIREWORK_ROCKET, Items.CREEPER_HEAD);
        add("r17", RARE, Items.GOLDEN_SWORD, Items.IRON_BARS);
        add("r18", RARE, Items.GLOW_BERRIES, Items.ROTTEN_FLESH, "hunger");
        add("r19", RARE, Items.LINGERING_POTION, Items.SPLASH_POTION, "potion");
        add("r20", RARE, Items.GOLDEN_BOOTS, Items.GLASS_PANE);
        add("r21", RARE, Items.BEACON, Items.GLOW_INK_SAC, "undead");
        add("r22", RARE, Items.ECHO_SHARD, Items.TORCH);
        add("r23", RARE, Items.BLUE_ICE, Items.MAGMA_BLOCK, "cold");
        add("r24", RARE, Items.EMERALD_BLOCK, Items.PAPER, "trade");
        add("r25", RARE, Items.NETHERITE_SWORD, Items.LEATHER);
        // ---------------- Sử thi ----------------
        add("e01", EPIC, Items.FIRE_CHARGE, Items.FLINT_AND_STEEL);
        add("e02", EPIC, Items.FEATHER, Items.ELYTRA, "jump");
        add("e03", EPIC, Items.IRON_BLOCK, Items.HONEYCOMB);
        add("e04", EPIC, Items.CHEST, Items.COMPASS, "death", "respawn");
        add("e05", EPIC, Items.ENDER_PEARL, Items.CHORUS_FRUIT);
        add("e06", EPIC, Items.DIAMOND_SWORD, Items.SPYGLASS, "camera");
        add("e07", EPIC, Items.DIAMOND, Items.ANVIL);
        add("e08", EPIC, Items.CHICKEN_SPAWN_EGG, Items.CHICKEN);
        add("e10", EPIC, Items.DIAMOND_PICKAXE, Items.SCULK_SHRIEKER);
        add("e11", EPIC, Items.PHANTOM_MEMBRANE, Items.PISTON);
        add("e12", EPIC, Items.LAVA_BUCKET, Items.GRASS_BLOCK, "fire");
        add("e13", EPIC, Items.COBWEB, Items.SPIDER_EYE, "climb");
        add("e16", EPIC, Items.GOLDEN_APPLE, Items.REDSTONE_BLOCK);
        add("e18", EPIC, Items.SHIELD, Items.IRON_CHESTPLATE);
        add("e20", EPIC, Items.BLAST_FURNACE, Items.CHEST);
        // ---------------- Huyền thoại ----------------
        add("l01", LEGENDARY, Items.LIGHTNING_ROD.weathering().unaffected(), Items.IRON_CHESTPLATE);
        add("l02", LEGENDARY, Items.DRAGON_HEAD, Items.LADDER, "fly");
        add("l04", LEGENDARY, Items.TOTEM_OF_UNDYING, Items.WITHER_ROSE, "death", "maxhp");
        add("l05", LEGENDARY, Items.NETHERITE_PICKAXE, Items.GRAVEL);
        add("l20", LEGENDARY, Items.CLOCK, Items.PACKED_ICE);
        // ---------------- Thần thoại ----------------
        // Mỗi người chỉ giữ 1 thẻ Thần thoại; đổi sang thẻ khác mất 1 tim vĩnh viễn.
        add("m01", MYTHIC, Items.BAT_SPAWN_EGG, Items.SUNFLOWER, "mythic");
        add("m02", MYTHIC, Items.DRAGON_HEAD, Items.SHIELD, "mythic");
        add("m03", MYTHIC, Items.CLOCK, Items.SKELETON_SKULL, "mythic");
        add("m04", MYTHIC, Items.BRICKS, Items.WOODEN_SWORD, "mythic");
        add("m05", MYTHIC, Items.END_CRYSTAL, Items.STAINED_GLASS.black(), "mythic");

        // ---------------- Thẻ meme đặc biệt (code riêng trong effects/MemeCards) ----------------
        add("u61", RARE, Items.BANNER.white(), Items.WOODEN_SWORD).meme = true;   // La Peace
        add("u62", RARE, Items.GOLDEN_HELMET, Items.FEATHER).meme = true;       // Hotbar Lơ Lửng
        add("u63", RARE, Items.TRIPWIRE_HOOK, Items.CHEST).meme = true;         // Trap Card
        add("u64", RARE, Items.GOLD_INGOT, Items.EXPERIENCE_BOTTLE).meme = true; // Jackpot

        // ---------------- Thẻ sinh tự động (GenData) ----------------
        GenData.load();

        // ---------------- Kỹ năng thủ công: mỗi thẻ đúng 1 kỹ năng (số gốc, hồi chiêu giây) ----------------
        sk1("r01", 0, 25); sk1("r02", 0, 30); sk1("r03", 0, 30); sk1("r04", 0, 45); sk1("r05", 0, 40);
        sk1("r06", 0, 20); sk1("r07", 0, 25); sk1("r08", 0, 20); sk1("r09", 0, 45); sk1("r10", 0, 30);
        sk1("r11", 0, 90); sk1("r12", 0, 120); sk1("r13", 0, 10); sk1("r14", 0, 5); sk1("r15", 0, 15);
        sk1("r16", 0, 15); sk1("r17", 0, 30); sk1("r18", 0, 60); sk1("r19", 0, 20); sk1("r20", 0, 10);
        sk1("r21", 0, 30); sk1("r22", 0, 60); sk1("r23", 0, 15); sk1("r24", 0, 60); sk1("r25", 0, 40);
        sk1("e01", 0, 8); sk1("e02", 1, 30); sk1("e03", 0, 30); sk1("e04", 0, 300); sk1("e05", 0, 12);
        sk1("e06", 0, 10); sk1("e07", 0, 60); sk1("e08", 0, 60); sk1("e10", 0, 60); sk1("e11", 0, 10);
        sk1("e12", 0, 40); sk1("e13", 1, 8); sk1("e16", 1, 90); sk1("e18", 1, 60); sk1("e20", 0, 120);
        sk1("l01", 1, 90); sk1("l02", 0, 90); sk1("l04", 2, 180); sk1("l05", 0, 30); sk1("l20", 0, 180);
        // v8: M1, M2, M3, M5 có 2 chiêu (v9: cả M4)
        sk1("m01", 1, 30); sk1("m01", 0, 30);
        sk1("m02", 0, 12); sk1("m02", 2, 60);
        sk1("m03", 0, 45); sk1("m03", 3, 240);
        sk1("m04", 0, 20); sk1("m04", 1, 15); // v9: M4 có 2 chiêu
        sk1("m05", 1, 60); sk1("m05", 0, 2);
        sk1("u61", 0, 45); sk1("u62", 0, 60); sk1("u63", 0, 60); sk1("u64", 0, 120);

        // ---------------- v7.1: thẻ mới từ ảnh của người chơi (effects/V71Cards) ----------------
        V71Data.load();

        // ---------------- v6: thêm lợi ích / bất lợi theo độ hiếm (troll giờ là bất lợi thường) ----------------
        GenExtra.load();
        for (Card c : ALL.values()) {
            if (c.rarity.ordinal() < RARE.ordinal()) { // chỉ thẻ Rare trở lên có kỹ năng kích hoạt
                c.skills.clear();
                c.skillOrig.clear();
                c.genSkill = null;
            }
            List<String> deb = new ArrayList<>(c.xDebuff);
            if (c.gen != null) deb.addAll(Arrays.asList(c.gen.debuff));
            for (String m : deb) if (m.startsWith("troll:") && !c.trolls.contains(m.substring(6))) c.trolls.add(m.substring(6));
        }
    }

    /** Hand-made skill: {@code orig} is the skill number used by the code, texts and icon. */
    private static void sk1(String id, int orig, int cooldown) {
        Card c = ALL.get(id);
        c.skills.add(cooldown);
        c.skillOrig.add(orig);
    }

    /** v6 extra buffs and debuffs of a card (see GenExtra). */
    static void x(String id, String[] buffs, String[] debuffs) {
        Card c = ALL.get(id);
        if (c == null) return;
        c.xBuff.addAll(Arrays.asList(buffs));
        c.xDebuff.addAll(Arrays.asList(debuffs));
    }

    /** Data-driven card (see GenData). */
    static void card(String id, Rarity r, Item buff, Item debuff, boolean meme, String[] buffs, String[] debuffs) {
        Card c = new Card(id, r, buff, debuff, Set.of());
        c.meme = meme;
        c.gen = new GenSpec(buffs, debuffs);
        ALL.put(id, c);
    }

    /** Generated skill for a card (see GenData). */
    static void skill(String id, String kind, String element, double a, double b, String eff, int amp, int cooldown) {
        Card c = ALL.get(id);
        if (c == null) return;
        c.genSkill = new GenSkill(kind, element, a, b, eff, amp);
        c.skills.add(cooldown);
        c.skillOrig.add(0);
    }

    public static Card get(String id) {
        return ALL.get(id);
    }

    /** Works on both sides: server reads saved data, client reads synced state of the local player. */
    public static boolean has(Player p, String id) {
        if (p == null) return false;
        if (p.level().isClientSide()) return ClientState.has(id);
        boolean on = WData.get(p).equipped.contains(id); // only equipped cards are active
        if (on) com.hoang.wildcard.effects.MaxStars.touch(p, id);
        return on;
    }

    /** v8: like {@link #has}, but false once a Common/Uncommon card reaches max stars (its debuffs are gone). Use on debuff code. */
    public static boolean debuffOn(Player p, String id) {
        if (!has(p, id)) return false;
        Card c = get(id);
        if (c == null) return true;
        int st = p.level().isClientSide() ? ClientState.STARS.getOrDefault(id, 0) : WData.get(p).stars.getOrDefault(id, 0);
        return !c.debuffGone(st);
    }

    private Cards() {}
}
