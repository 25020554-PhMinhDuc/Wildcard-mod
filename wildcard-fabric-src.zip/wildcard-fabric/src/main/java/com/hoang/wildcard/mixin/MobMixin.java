package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.living.LivingChangeTargetEvent;
import com.hoang.wildcard.fe.event.entity.living.MobSpawnEvent;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.level.ServerLevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Mob.class)
public abstract class MobMixin {
    @Inject(method = "finalizeSpawn", at = @At("HEAD"))
    private void wildcard$finalize(ServerLevelAccessor level, DifficultyInstance diff, EntitySpawnReason reason, SpawnGroupData data,
                                   CallbackInfoReturnable<SpawnGroupData> cir) {
        Mob m = (Mob) (Object) this;
        MobSpawnEvent.FinalizeSpawn ev = new MobSpawnEvent.FinalizeSpawn(m, level, m.getX(), m.getY(), m.getZ(), reason);
        Hooks.post(ev);
        if (ev.isSpawnCancelled() || ev.isCanceled()) m.discard();
    }

    @WrapMethod(method = "setTarget")
    private void wildcard$target(LivingEntity target, Operation<Void> orig) {
        Mob m = (Mob) (Object) this;
        if (m.level().isClientSide()) { orig.call(target); return; }
        LivingChangeTargetEvent ev = new LivingChangeTargetEvent(m, target);
        if (Hooks.post(ev)) return;
        orig.call(ev.getNewTarget());
    }
}
