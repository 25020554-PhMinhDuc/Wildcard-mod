package com.hoang.wildcard.compat;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.core.Holder;
import net.minecraft.core.UUIDUtil;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

import java.util.UUID;
import java.util.function.Consumer;

/** Helpers that stand in for Forge / 1.20.1 APIs removed in Minecraft 26.3. */
public final class MC {
    /** Replacement for Forge's Entity#getPersistentData (copied on player death, like PERSISTED_NBT_TAG). */
    public static final AttachmentType<CompoundTag> PDATA = AttachmentRegistry.<CompoundTag>builder()
            .persistent(CompoundTag.CODEC).initializer(CompoundTag::new).copyOnDeath()
            .buildAndRegister(Identifier.fromNamespaceAndPath("wildcard", "pdata"));

    public static void init() {}

    public static CompoundTag pdata(Entity e) {
        return ((AttachmentTarget) (Object) e).getAttachedOrCreate(PDATA);
    }

    // UUID helpers (CompoundTag#putUUID/getUUID/hasUUID were removed)
    public static void putUUID(CompoundTag t, String k, UUID u) { t.store(k, UUIDUtil.CODEC, u); }
    public static UUID getUUID(CompoundTag t, String k) { return t.read(k, UUIDUtil.CODEC).orElse(null); }
    public static boolean hasUUID(CompoundTag t, String k) { return t.read(k, UUIDUtil.CODEC).isPresent(); }

    // Item custom data (ItemStack#getTag/hasTag/getOrCreateTag were removed)
    public static boolean hasTag(ItemStack s) {
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        return d != null && !d.isEmpty();
    }
    public static CompoundTag tag(ItemStack s) {
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        return d == null ? null : d.copyTag();
    }
    public static void editTag(ItemStack s, Consumer<CompoundTag> f) { CustomData.update(DataComponents.CUSTOM_DATA, s, f); }

    // Time of day (moved to world clocks)
    public static long dayTime(Level l) { return l.getDefaultClockTime(); }
    public static void setDayTime(ServerLevel l, long t) {
        l.dimensionType().defaultClock().ifPresent(c -> l.clockManager().setTotalTicks(c, t));
    }

    public static boolean isOp(CommandSourceStack s) { return s.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER); }

    /** Replacement for ServerPlayer#playNotifySound: a sound only this player hears. */
    public static void notify(ServerPlayer p, Holder<SoundEvent> s, SoundSource src, float vol, float pitch) {
        p.connection.send(new ClientboundSoundPacket(s, src, p.getX(), p.getY(), p.getZ(), vol, pitch, p.getRandom().nextLong()));
    }
    public static void notify(ServerPlayer p, SoundEvent s, SoundSource src, float vol, float pitch) {
        notify(p, Holder.direct(s), src, vol, pitch);
    }

    // MobType was removed; use entity type tags
    public static boolean undead(Entity e) { return e.typeHolder().is(EntityTypeTags.UNDEAD); }
    public static boolean arthropod(Entity e) { return e.typeHolder().is(EntityTypeTags.ARTHROPOD); }
    public static boolean illager(Entity e) { return e.typeHolder().is(EntityTypeTags.ILLAGER); }
    public static boolean aquatic(Entity e) { return e.typeHolder().is(EntityTypeTags.AQUATIC); }

    /** AbstractArrow#getBaseDamage was removed; the field is still there (26.3 is not obfuscated). */
    public static double baseDamage(net.minecraft.world.entity.projectile.arrow.AbstractArrow a) {
        try { var f = net.minecraft.world.entity.projectile.arrow.AbstractArrow.class.getDeclaredField("baseDamage"); f.setAccessible(true); return f.getDouble(a); }
        catch (ReflectiveOperationException e) { return 2.0; }
    }

    /** Worn armor pieces (Inventory#armor was removed). */
    public static java.util.List<ItemStack> armor(net.minecraft.world.entity.LivingEntity e) {
        java.util.List<ItemStack> l = new java.util.ArrayList<>();
        for (net.minecraft.world.entity.EquipmentSlot s : new net.minecraft.world.entity.EquipmentSlot[]{
                net.minecraft.world.entity.EquipmentSlot.FEET, net.minecraft.world.entity.EquipmentSlot.LEGS,
                net.minecraft.world.entity.EquipmentSlot.CHEST, net.minecraft.world.entity.EquipmentSlot.HEAD})
            l.add(e.getItemBySlot(s));
        return l;
    }

    /** Enchant with a vanilla enchantment key (enchantments are data-driven now). */
    public static void enchant(ItemStack s, Level level, net.minecraft.resources.ResourceKey<net.minecraft.world.item.enchantment.Enchantment> key, int lvl) {
        level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT).get(key).ifPresent(h -> s.enchant(h, lvl));
    }

    /** SavedData type backed by the old load(CompoundTag) / save(CompoundTag) pair. */
    public static <T extends net.minecraft.world.level.saveddata.SavedData> net.minecraft.world.level.saveddata.SavedDataType<T> savedType(
            String name, java.util.function.Supplier<T> ctor, java.util.function.Function<CompoundTag, T> load, java.util.function.Function<T, CompoundTag> save) {
        return new net.minecraft.world.level.saveddata.SavedDataType<>(Identifier.fromNamespaceAndPath("wildcard", name), ctor,
                CompoundTag.CODEC.xmap(load, save), net.minecraft.util.datafix.DataFixTypes.SAVED_DATA_COMMAND_STORAGE);
    }

    /** Item id path, e.g. "iron_chestplate". */
    public static String itemPath(ItemStack s) { return net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(s.getItem()).getPath(); }

    public static Holder<SoundEvent> wolf(java.util.function.Function<net.minecraft.world.entity.animal.wolf.WolfSoundVariant.WolfSoundSet, Holder<SoundEvent>> f) {
        return f.apply(net.minecraft.sounds.SoundEvents.WOLF_SOUNDS.get(net.minecraft.world.entity.animal.wolf.WolfSoundVariants.SoundSet.CLASSIC).adultSounds());
    }

    /** Saves every inventory slot (Inventory#save(ListTag) was removed). */
    public static net.minecraft.nbt.ListTag saveInv(net.minecraft.world.entity.player.Player p) {
        var ops = net.minecraft.resources.RegistryOps.create(net.minecraft.nbt.NbtOps.INSTANCE, p.registryAccess());
        net.minecraft.nbt.ListTag l = new net.minecraft.nbt.ListTag();
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) continue;
            final int slot = i;
            ItemStack.CODEC.encodeStart(ops, s).result().ifPresent(t -> {
                CompoundTag c = new CompoundTag();
                c.putInt("Slot", slot);
                c.put("Item", t);
                l.add(c);
            });
        }
        return l;
    }

    public static void loadInv(net.minecraft.world.entity.player.Player p, net.minecraft.nbt.ListTag l) {
        var ops = net.minecraft.resources.RegistryOps.create(net.minecraft.nbt.NbtOps.INSTANCE, p.registryAccess());
        var inv = p.getInventory();
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompoundOrEmpty(i);
            int slot = c.getIntOr("Slot", -1);
            var t = c.get("Item");
            if (slot < 0 || slot >= inv.getContainerSize() || t == null) continue;
            ItemStack.CODEC.parse(ops, t).result().ifPresent(s -> inv.setItem(slot, s));
        }
    }

    public static int enchLevel(Level level, ItemStack s, net.minecraft.resources.ResourceKey<net.minecraft.world.item.enchantment.Enchantment> key) {
        return level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT).get(key)
                .map(h -> net.minecraft.world.item.enchantment.EnchantmentHelper.getItemEnchantmentLevel(h, s)).orElse(0);
    }

    public static float exhaustion(net.minecraft.world.food.FoodData fd) {
        try { var f = net.minecraft.world.food.FoodData.class.getDeclaredField("exhaustionLevel"); f.setAccessible(true); return f.getFloat(fd); }
        catch (ReflectiveOperationException e) { return 0f; }
    }

    public static boolean is(ItemStack s, net.minecraft.tags.TagKey<net.minecraft.world.item.Item> t) { return s.is(t); }

    public static net.minecraft.world.damagesource.DamageSource damage(Entity e, net.minecraft.resources.ResourceKey<net.minecraft.world.damagesource.DamageType> key, Entity by) {
        var h = e.level().registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getOrThrow(key);
        return by == null ? new net.minecraft.world.damagesource.DamageSource(h) : new net.minecraft.world.damagesource.DamageSource(h, by);
    }

    public static Iterable<net.minecraft.world.effect.MobEffectInstance> potionEffects(ItemStack s) {
        var pc = s.get(DataComponents.POTION_CONTENTS);
        return pc == null ? java.util.List.of() : pc.getAllEffects();
    }

    private MC() {}
}
