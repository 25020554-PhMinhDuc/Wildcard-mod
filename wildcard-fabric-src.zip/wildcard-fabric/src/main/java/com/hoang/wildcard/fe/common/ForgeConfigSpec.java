package com.hoang.wildcard.fe.common;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.function.Supplier;

/** Shim of ForgeConfigSpec: values stored in config/wildcard-common.json (keys = path joined with '.'). */
public final class ForgeConfigSpec {
    private final List<ConfigValue<?>> values;
    private ForgeConfigSpec(List<ConfigValue<?>> values) { this.values = values; }

    /** Loads (and writes back, adding missing keys) the json file. */
    public void load(Path file) {
        JsonObject o = new JsonObject();
        try { if (Files.exists(file)) o = JsonParser.parseString(Files.readString(file)).getAsJsonObject(); }
        catch (Exception e) { com.hoang.wildcard.WildcardMod.LOG.warn("Wildcard: không đọc được {}, dùng mặc định", file, e); }
        for (ConfigValue<?> v : values) if (o.has(v.key)) v.read(o.get(v.key));
        JsonObject out = new JsonObject();
        for (ConfigValue<?> v : values) {
            if (v.comment != null) out.addProperty("_" + v.key, v.comment);
            out.add(v.key, v.write());
        }
        try { Files.createDirectories(file.getParent()); Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(out)); }
        catch (Exception e) { com.hoang.wildcard.WildcardMod.LOG.warn("Wildcard: không ghi được {}", file, e); }
    }

    public static class ConfigValue<T> implements Supplier<T> {
        final String key; final String comment; T value; final T def;
        ConfigValue(String key, String comment, T def) { this.key = key; this.comment = comment; this.value = def; this.def = def; }
        @Override public T get() { return value; }
        public void set(T v) { value = v; }
        public T getDefault() { return def; }
        @SuppressWarnings("unchecked")
        void read(JsonElement e) {
            try {
                Object v;
                if (def instanceof Integer) v = e.getAsInt();
                else if (def instanceof Double) v = e.getAsDouble();
                else if (def instanceof Boolean) v = e.getAsBoolean();
                else if (def instanceof List<?>) { List<String> l = new ArrayList<>(); for (JsonElement x : e.getAsJsonArray()) l.add(x.getAsString()); v = l; }
                else v = e.getAsString();
                value = clamp((T) v);
            } catch (Exception ex) { value = def; }
        }
        T clamp(T v) { return v; }
        JsonElement write() {
            if (value instanceof Number n) return new JsonPrimitive(n);
            if (value instanceof Boolean b) return new JsonPrimitive(b);
            if (value instanceof List<?> l) { JsonArray a = new JsonArray(); for (Object x : l) a.add(String.valueOf(x)); return a; }
            return new JsonPrimitive(String.valueOf(value));
        }
    }
    public static class IntValue extends ConfigValue<Integer> {
        final int min, max;
        IntValue(String k, String c, int d, int min, int max) { super(k, c, d); this.min = min; this.max = max; }
        @Override Integer clamp(Integer v) { return Math.max(min, Math.min(max, v)); }
    }
    public static class DoubleValue extends ConfigValue<Double> {
        final double min, max;
        DoubleValue(String k, String c, double d, double min, double max) { super(k, c, d); this.min = min; this.max = max; }
        @Override Double clamp(Double v) { return Math.max(min, Math.min(max, v)); }
    }
    public static class BooleanValue extends ConfigValue<Boolean> { BooleanValue(String k, String c, boolean d) { super(k, c, d); } }

    public static class Builder {
        private final Deque<String> path = new ArrayDeque<>();
        private final List<ConfigValue<?>> values = new ArrayList<>();
        private String comment;
        public Builder comment(String... c) { comment = String.join(" ", c); return this; }
        public Builder translation(String k) { return this; }
        public Builder push(String p) { path.addLast(p); return this; }
        public Builder pop() { path.pollLast(); return this; }
        private String key(String k) { return path.isEmpty() ? k : String.join(".", path) + "." + k; }
        private <V extends ConfigValue<?>> V add(V v) { values.add(v); comment = null; return v; }
        public IntValue defineInRange(String k, int d, int min, int max) { return add(new IntValue(key(k), comment, d, min, max)); }
        public DoubleValue defineInRange(String k, double d, double min, double max) { return add(new DoubleValue(key(k), comment, d, min, max)); }
        public BooleanValue define(String k, boolean d) { return add(new BooleanValue(key(k), comment, d)); }
        public <T> ConfigValue<T> define(String k, T d) { return add(new ConfigValue<>(key(k), comment, d)); }
        @SuppressWarnings({"unchecked", "rawtypes"})
        public <T> ConfigValue<List<? extends T>> defineList(String k, List<? extends T> d, Predicate<Object> validator) { return (ConfigValue) add(new ConfigValue<>(key(k), comment, new ArrayList<>(d))); }
        @SuppressWarnings({"unchecked", "rawtypes"})
        public <T> ConfigValue<List<? extends T>> defineListAllowEmpty(String k, List<? extends T> d, Predicate<Object> validator) { return defineList(k, d, validator); }
        public ForgeConfigSpec build() { return new ForgeConfigSpec(values); }
    }
}
