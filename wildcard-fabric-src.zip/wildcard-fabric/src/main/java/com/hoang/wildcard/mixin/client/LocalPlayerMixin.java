package com.hoang.wildcard.mixin.client;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.client.event.MovementInputUpdateEvent;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** MovementInputUpdateEvent: lets cards rewrite the keyboard input right after it is read. */
@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {
    @Shadow public ClientInput input;

    @Inject(method = "aiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/ClientInput;tick()V", shift = At.Shift.AFTER))
    private void wildcard$input(CallbackInfo ci) {
        Input k = input.keyPresses;
        Vec2 mv = ((ClientInputAccessor) input).wildcard$getMove();
        MovementInputUpdateEvent.Input in = new MovementInputUpdateEvent.Input();
        in.forwardImpulse = mv.y; in.leftImpulse = mv.x;
        in.up = k.forward(); in.down = k.backward(); in.left = k.left(); in.right = k.right();
        in.jumping = k.jump(); in.shiftKeyDown = k.shift(); in.sprinting = k.sprint();
        Hooks.post(new MovementInputUpdateEvent((LocalPlayer) (Object) this, in));
        input.keyPresses = new Input(in.up, in.down, in.left, in.right, in.jumping, in.shiftKeyDown, in.sprinting);
        ((ClientInputAccessor) input).wildcard$setMove(new Vec2(in.leftImpulse, in.forwardImpulse));
    }
}
