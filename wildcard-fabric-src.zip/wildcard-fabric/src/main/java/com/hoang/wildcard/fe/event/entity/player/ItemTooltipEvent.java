package com.hoang.wildcard.fe.event.entity.player;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ItemTooltipEvent extends PlayerEvent {
    private final ItemStack stack; private final List<net.minecraft.network.chat.Component> tooltip; private final net.minecraft.world.item.TooltipFlag flags;
    public ItemTooltipEvent(ItemStack stack, Player p, List<net.minecraft.network.chat.Component> tip, net.minecraft.world.item.TooltipFlag flags) { super(p); this.stack = stack; this.tooltip = tip; this.flags = flags; }
    public ItemStack getItemStack() { return stack; }
    public List<net.minecraft.network.chat.Component> getToolTip() { return tooltip; }
    public net.minecraft.world.item.TooltipFlag getFlags() { return flags; }
}
