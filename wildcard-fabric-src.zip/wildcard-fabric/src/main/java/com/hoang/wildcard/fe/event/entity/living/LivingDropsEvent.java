package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LivingDropsEvent extends LivingEvent {
    private final DamageSource source; private final Collection<net.minecraft.world.entity.item.ItemEntity> drops; private final boolean recentlyHit;
    public LivingDropsEvent(LivingEntity e, DamageSource s, Collection<net.minecraft.world.entity.item.ItemEntity> drops, boolean recentlyHit) { super(e); source = s; this.drops = drops; this.recentlyHit = recentlyHit; }
    public DamageSource getSource() { return source; }
    public Collection<net.minecraft.world.entity.item.ItemEntity> getDrops() { return drops; }
    public boolean isRecentlyHit() { return recentlyHit; }
}
