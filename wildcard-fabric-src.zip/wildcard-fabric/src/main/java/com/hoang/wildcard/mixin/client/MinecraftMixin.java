package com.hoang.wildcard.mixin.client;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.PlayerInteractEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** PlayerInteractEvent.RightClickEmpty: right click on air with an empty main hand. */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Inject(method = "startUseItem", at = @At("HEAD"))
    private void wildcard$rightClick(CallbackInfo ci) {
        Minecraft mc = (Minecraft) (Object) this;
        if (mc.player == null || mc.gameMode == null || mc.player.isHandsBusy()) return;
        if (mc.hitResult != null && mc.hitResult.getType() != HitResult.Type.MISS) return;
        if (mc.player.getMainHandItem().isEmpty()) Hooks.post(new PlayerInteractEvent.RightClickEmpty(mc.player, InteractionHand.MAIN_HAND));
    }
}
