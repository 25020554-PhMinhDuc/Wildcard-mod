package com.hoang.wildcard.fe.common;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;

/** Shim: Forge tags mapped to the common "c" tags used by Fabric. */
public final class Tags {
    public static final class Blocks {
        private static TagKey<Block> c(String p) { return TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", p)); }
        public static final TagKey<Block> COBBLESTONE = c("cobblestones");
        public static final TagKey<Block> GLASS = c("glass_blocks");
        public static final TagKey<Block> GLASS_PANES = c("glass_panes");
        public static final TagKey<Block> ORES = c("ores");
        public static final TagKey<Block> ORES_COAL = c("ores/coal");
        public static final TagKey<Block> ORES_DIAMOND = c("ores/diamond");
        public static final TagKey<Block> ORES_IRON = c("ores/iron");
        public static final TagKey<Block> ORES_GOLD = c("ores/gold");
        public static final TagKey<Block> STONE = c("stones");
    }
    public static final class Items {
        private static TagKey<Item> c(String p) { return TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("c", p)); }
        public static final TagKey<Item> ORES = c("ores");
    }
    private Tags() {}
}
