package com.hoang.wildcard.fe.registries;

import net.minecraft.resources.Identifier;
import java.util.function.Supplier;

public final class RegistryObject<T> implements Supplier<T> {
    final Identifier id; final Supplier<? extends T> factory; T value;
    RegistryObject(Identifier id, Supplier<? extends T> f) { this.id = id; this.factory = f; }
    @Override public T get() { if (value == null) throw new IllegalStateException("Wildcard: " + id + " chưa đăng ký"); return value; }
    public Identifier getId() { return id; }
    public boolean isPresent() { return value != null; }
}
