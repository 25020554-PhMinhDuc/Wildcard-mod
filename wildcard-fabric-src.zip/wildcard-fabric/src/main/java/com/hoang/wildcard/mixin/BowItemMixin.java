package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.player.ArrowLooseEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BowItem.class)
public abstract class BowItemMixin {
    @Inject(method = "releaseUsing", at = @At("HEAD"), cancellable = true)
    private void wildcard$loose(ItemStack bow, Level level, LivingEntity e, int timeLeft, CallbackInfoReturnable<Boolean> cir) {
        if (!(e instanceof Player p) || level.isClientSide()) return;
        int charge = ((BowItem) (Object) this).getUseDuration(bow, e) - timeLeft;
        boolean ammo = p.hasInfiniteMaterials() || !p.getProjectile(bow).isEmpty();
        if (Hooks.post(new ArrowLooseEvent(p, bow, level, charge, ammo))) cir.setReturnValue(false);
    }
}
