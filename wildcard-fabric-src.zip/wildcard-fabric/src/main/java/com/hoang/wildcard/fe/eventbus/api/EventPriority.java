package com.hoang.wildcard.fe.eventbus.api;

public enum EventPriority { HIGHEST, HIGH, NORMAL, LOW, LOWEST }
