package com.hoang.wildcard.event;

import com.hoang.wildcard.*;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.EntityJoinLevelEvent;
import com.hoang.wildcard.fe.event.entity.player.EntityItemPickupEvent;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;

import java.util.*;

/**
 * v5 world event "Mưa Thẻ" (Card Rain): every N Minecraft days (default 7), announced 60 s before.
 * 100 Rare+ cards fall from the sky onto the chunks the online players stand in (shared between them).
 * Each player may take only one card per event (v6: after confirming; rarity is hidden); then the cards dropped for them vanish.
 * Whatever is left disappears after 30 s.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class CardRain {
    private static final Random RNG = new Random();
    /** Live drops of the running event: owner uuid -> item entity uuids. */
    private static final Map<UUID, List<UUID>> DROPS = new HashMap<>();
    private static int activeId = 0;
    private static long endTick = 0;

    // ---------------- lưu trạng thái theo thế giới ----------------
    public static final class State extends SavedData {
        long next;      // game time of the next rain (0 = not scheduled yet)
        boolean warned;
        int counter;

        static State load(CompoundTag t) {
            State s = new State();
            s.next = t.getLongOr("next", 0L);
            s.warned = t.getBooleanOr("warned", false);
            s.counter = t.getIntOr("counter", 0);
            return s;
        }

        static final net.minecraft.world.level.saveddata.SavedDataType<State> TYPE = com.hoang.wildcard.compat.MC.savedType("card_rain", State::new, State::load, x -> x.save(new CompoundTag()));

        public CompoundTag save(CompoundTag t) {
            t.putLong("next", next);
            t.putBoolean("warned", warned);
            t.putInt("counter", counter);
            return t;
        }
    }

    static State state(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(State.TYPE);
    }

    private static long interval() {
        return Config.RAIN_DAYS.get() * 24000L;
    }

    /** /wildcard rain: schedule the rain to start after the normal warning (or right away with {@code now}). */
    public static void schedule(MinecraftServer server, boolean now) {
        State s = state(server);
        long t = server.overworld().getGameTime();
        s.next = now ? t : t + Config.RAIN_WARN_SECONDS.get() * 20L;
        s.warned = now;
        s.setDirty();
        if (now) start(server, s);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = e.getServer();
        ServerLevel ow = server.overworld();
        long now = ow.getGameTime();
        if (activeId != 0 && now >= endTick) finish(server);
        if (Config.RAIN_DAYS.get() <= 0 || now % 20 != 0) return;
        State s = state(server);
        if (s.next <= 0) {
            s.next = now + interval();
            s.setDirty();
            return;
        }
        long warnAt = s.next - Config.RAIN_WARN_SECONDS.get() * 20L;
        if (!s.warned && now >= warnAt) {
            s.warned = true;
            s.setDirty();
            broadcast(server, Component.translatable("msg.wildcard.rain.warn", Config.RAIN_WARN_SECONDS.get()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
            for (ServerPlayer p : server.getPlayerList().getPlayers())
                p.level().playSound(null, p.blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1f, 0.8f);
        }
        long left = s.next - now;
        if (s.warned && left > 0 && left <= 200 && left % 20 == 0) { // đếm ngược 10 giây cuối
            for (ServerPlayer p : server.getPlayerList().getPlayers())
                p.sendOverlayMessage(Component.translatable("msg.wildcard.rain.count", left / 20).withStyle(ChatFormatting.GOLD));
        }
        if (now >= s.next) start(server, s);
    }

    private static void start(MinecraftServer server, State s) {
        long now = server.overworld().getGameTime();
        s.next = now + interval();
        s.warned = false;
        s.counter++;
        s.setDirty();
        if (activeId != 0) finish(server);
        activeId = s.counter;
        endTick = now + Config.RAIN_PICK_SECONDS.get() * 20L + 60; // + 3 giây cho thẻ rơi xuống
        DROPS.clear();
        PENDING.clear();
        DECLINED.clear();

        List<ServerPlayer> targets = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isSpectator()) continue;
            if (p.level().dimensionType().hasCeiling()) { // Nether: không có bầu trời
                p.sendSystemMessage(Component.translatable("msg.wildcard.rain.ceiling").withStyle(ChatFormatting.GRAY));
                continue;
            }
            targets.add(p);
        }
        broadcast(server, Component.translatable("msg.wildcard.rain.start", Config.RAIN_PICK_SECONDS.get()).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("title.wildcard.rain").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD)));
            p.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("title.wildcard.rain.sub", Config.RAIN_PICK_SECONDS.get())));
            p.level().playSound(null, p.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.MASTER, 1f, 0.8f);
        }
        if (targets.isEmpty()) return;

        List<Card> pool = new ArrayList<>();
        for (Card c : Cards.ALL.values()) if (c.rarity.ordinal() >= Rarity.RARE.ordinal()) pool.add(c);
        Set<String> disabled = new HashSet<>(Config.DISABLED_CARDS.get());
        pool.removeIf(c -> disabled.contains(c.id));
        if (pool.isEmpty()) return;
        int total = Config.RAIN_CARDS.get();
        final int id = activeId;
        for (int i = 0; i < total; i++) {
            ServerPlayer owner = targets.get(i % targets.size());
            Card card = rollCard(pool);
            int delay = RNG.nextInt(60); // rơi rải rác trong 3 giây
            com.hoang.wildcard.effects.Scheduler.later(delay, () -> drop(owner, card, id));
        }
    }

    /** Rare+ card picked with the normal rarity odds (rarer = less often), then a random card of that rarity. */
    private static Card rollCard(List<Card> pool) {
        Rarity r = Rarity.RARE;
        for (int i = 0; i < 2000; i++) {
            Rarity x = RoundManager.rollRarity();
            if (x.ordinal() >= Rarity.RARE.ordinal()) {
                r = x;
                break;
            }
        }
        for (int k = r.ordinal(); k >= Rarity.RARE.ordinal(); k--) {
            List<Card> of = new ArrayList<>();
            for (Card c : pool) if (c.rarity.ordinal() == k) of.add(c);
            if (!of.isEmpty()) return of.get(RNG.nextInt(of.size()));
        }
        return pool.get(RNG.nextInt(pool.size()));
    }

    /** One card falling somewhere in the owner's chunk, 20-35 blocks above the ground. */
    private static void drop(ServerPlayer owner, Card card, int id) {
        if (id != activeId || owner.isRemoved()) return;
        ServerLevel level = owner.level();
        BlockPos chunk = owner.chunkPosition().getWorldPosition();
        int x = chunk.getX() + RNG.nextInt(16), z = chunk.getZ() + RNG.nextInt(16);
        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        ItemStack stack = CardItem.of(card);
        com.hoang.wildcard.compat.MC.editTag(stack, t -> t.putInt("rain", id));
        ItemEntity item = new ItemEntity(level, x + 0.5, ground + 20 + RNG.nextInt(15), z + 0.5, stack);
        item.setDeltaMovement(RNG.nextGaussian() * 0.05, -0.2, RNG.nextGaussian() * 0.05);
        item.setNoPickUpDelay();
        item.setGlowingTag(true);
        item.setCustomName(Component.translatable("item.wildcard.card.mystery").withStyle(ChatFormatting.WHITE)); // v6: không lộ độ hiếm
        item.setCustomNameVisible(true);
        item.setUnlimitedLifetime();
        level.addFreshEntity(item);
        DROPS.computeIfAbsent(owner.getUUID(), u -> new ArrayList<>()).add(item.getUUID());
    }

    /** Open "do you want this card?" offers: player -> (entity id, expiry tick). */
    private static final Map<UUID, long[]> PENDING = new HashMap<>();
    /** After "No" the same card does not ask again for a few seconds: player -> (entity id, until tick). */
    private static final Map<UUID, long[]> DECLINED = new HashMap<>();
    private static final int ASK_SECONDS = 10;

    /**
     * v6: touching a rain card no longer takes it (a card falling on your head used to count as your pick).
     * The card must be lying on the ground, and the player is asked first.
     */
    @SubscribeEvent
    public static void onPickup(EntityItemPickupEvent e) {
        ItemEntity item = e.getItem();
        ItemStack stack = item.getItem();
        if (!(stack.getItem() instanceof CardItem) || !com.hoang.wildcard.compat.MC.hasTag(stack) || !com.hoang.wildcard.compat.MC.tag(stack).contains("rain")) return;
        e.setCanceled(true);
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (com.hoang.wildcard.compat.MC.tag(stack).getIntOr("rain", 0) != activeId) {
            item.discard();
            return;
        }
        if (!item.onGround()) return; // còn đang rơi
        WData d = WData.get(p);
        long now = p.level().getGameTime();
        if (d.extra.getIntOr("rain_claimed", 0) == activeId) {
            if (now % 40 == 0) p.sendOverlayMessage(Component.translatable("msg.wildcard.rain.already").withStyle(ChatFormatting.GRAY));
            return;
        }
        long[] pend = PENDING.get(p.getUUID());
        if (pend != null && now < pend[1]) return;
        long[] dec = DECLINED.get(p.getUUID());
        if (dec != null && dec[0] == item.getId() && now < dec[1]) return;
        PENDING.put(p.getUUID(), new long[]{item.getId(), now + (ASK_SECONDS + 2) * 20L});
        Net.toPlayer(p, new Net.RainOffer(item.getId(), ASK_SECONDS));
    }

    /** Client answered the offer. Everything is checked again on the server. */
    public static void answer(ServerPlayer p, int entityId, boolean yes) {
        long[] asked = PENDING.remove(p.getUUID());
        if (asked == null || asked[0] != entityId) return;
        long now = p.level().getGameTime();
        if (!yes) {
            DECLINED.put(p.getUUID(), new long[]{entityId, now + 100});
            return;
        }
        if (activeId == 0) {
            p.sendOverlayMessage(Component.translatable("msg.wildcard.rain.gone").withStyle(ChatFormatting.GRAY));
            return;
        }
        var ent = p.level().getEntity(entityId);
        if (!(ent instanceof ItemEntity item) || item.isRemoved() || p.distanceToSqr(item) > 36) {
            p.sendOverlayMessage(Component.translatable("msg.wildcard.rain.gone").withStyle(ChatFormatting.GRAY));
            return;
        }
        ItemStack stack = item.getItem();
        if (!(stack.getItem() instanceof CardItem) || !com.hoang.wildcard.compat.MC.hasTag(stack) || com.hoang.wildcard.compat.MC.tag(stack).getIntOr("rain", 0) != activeId) return;
        WData d = WData.get(p);
        if (d.extra.getIntOr("rain_claimed", 0) == activeId) return;
        d.extra.putInt("rain_claimed", activeId);
        Card card = CardItem.card(stack);
        item.discard();
        if (card == null || d.stars.getOrDefault(card.id, 0) >= Card.MAX_STARS) card = RoundManager.rewardCard(d, Rarity.RARE); // đã đủ sao
        RoundManager.giveReward(p, card, Component.translatable("reward.wildcard.rain"));
        // phần thẻ rơi cho người này biến mất
        removeDrops(p.level().getServer(), DROPS.remove(p.getUUID()));
    }

    /** Leftover rain cards from an old event (e.g. after a restart) never come back. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof ItemEntity item)) return;
        ItemStack stack = item.getItem();
        if (stack.getItem() instanceof CardItem && com.hoang.wildcard.compat.MC.hasTag(stack) && com.hoang.wildcard.compat.MC.tag(stack).contains("rain") && com.hoang.wildcard.compat.MC.tag(stack).getIntOr("rain", 0) != activeId) {
            e.setCanceled(true);
        }
    }

    private static void finish(MinecraftServer server) {
        for (List<UUID> list : DROPS.values()) removeDrops(server, list);
        DROPS.clear();
        PENDING.clear();
        DECLINED.clear();
        if (activeId != 0) broadcast(server, Component.translatable("msg.wildcard.rain.end").withStyle(ChatFormatting.GRAY));
        activeId = 0;
    }

    private static void removeDrops(MinecraftServer server, List<UUID> ids) {
        if (ids == null) return;
        for (ServerLevel level : server.getAllLevels()) {
            for (UUID u : ids) {
                var ent = level.getEntity(u);
                if (ent != null) ent.discard();
            }
        }
    }

    private static void broadcast(MinecraftServer server, Component msg) {
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    private CardRain() {}
}
