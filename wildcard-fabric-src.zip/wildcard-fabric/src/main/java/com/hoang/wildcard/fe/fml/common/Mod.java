package com.hoang.wildcard.fe.fml.common;

import com.hoang.wildcard.fe.api.distmarker.Dist;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.TYPE)
public @interface Mod {
    String value();
    @Retention(RetentionPolicy.RUNTIME) @Target(ElementType.TYPE)
    @interface EventBusSubscriber {
        String modid() default "";
        Bus bus() default Bus.FORGE;
        Dist[] value() default {Dist.CLIENT, Dist.DEDICATED_SERVER};
        enum Bus { FORGE, MOD }
    }
}
