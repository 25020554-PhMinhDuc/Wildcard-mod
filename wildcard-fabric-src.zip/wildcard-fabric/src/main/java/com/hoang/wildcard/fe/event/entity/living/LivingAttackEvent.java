package com.hoang.wildcard.fe.event.entity.living;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class LivingAttackEvent extends LivingEvent {
    private final DamageSource source; private final float amount;
    public LivingAttackEvent(LivingEntity e, DamageSource s, float a) { super(e); source = s; amount = a; }
    public DamageSource getSource() { return source; }
    public float getAmount() { return amount; }
}
