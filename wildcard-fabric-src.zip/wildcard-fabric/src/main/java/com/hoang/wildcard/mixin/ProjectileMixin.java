package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import com.hoang.wildcard.fe.event.entity.ProjectileImpactEvent;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileDeflection;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Projectile.class)
public abstract class ProjectileMixin {
    @Inject(method = "hitTargetOrDeflectSelf", at = @At("HEAD"), cancellable = true)
    private void wildcard$impact(HitResult hit, CallbackInfoReturnable<ProjectileDeflection> cir) {
        Projectile self = (Projectile) (Object) this;
        if (hit.getType() == HitResult.Type.MISS || self.level().isClientSide()) return;
        if (Hooks.post(new ProjectileImpactEvent(self, hit))) cir.setReturnValue(ProjectileDeflection.NONE);
    }
}
