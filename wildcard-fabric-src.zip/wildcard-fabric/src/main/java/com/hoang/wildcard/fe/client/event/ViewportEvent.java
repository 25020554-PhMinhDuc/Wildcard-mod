package com.hoang.wildcard.fe.client.event;

import com.hoang.wildcard.fe.eventbus.api.Event;

public class ViewportEvent extends Event {
    public static class ComputeCameraAngles extends ViewportEvent {
        private float yaw, pitch, roll; private final double pt;
        public ComputeCameraAngles(float yaw, float pitch, float roll, double pt) { this.yaw = yaw; this.pitch = pitch; this.roll = roll; this.pt = pt; }
        public float getYaw() { return yaw; } public void setYaw(float v) { yaw = v; }
        public float getPitch() { return pitch; } public void setPitch(float v) { pitch = v; }
        public float getRoll() { return roll; } public void setRoll(float v) { roll = v; }
        public double getPartialTick() { return pt; }
    }
}
