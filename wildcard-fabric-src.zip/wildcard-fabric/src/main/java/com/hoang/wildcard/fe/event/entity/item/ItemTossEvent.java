package com.hoang.wildcard.fe.event.entity.item;

import com.hoang.wildcard.fe.eventbus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ItemTossEvent extends com.hoang.wildcard.fe.event.entity.EntityEvent {
    private final Player player;
    public ItemTossEvent(net.minecraft.world.entity.item.ItemEntity item, Player player) { super(item); this.player = player; }
    @Override public net.minecraft.world.entity.item.ItemEntity getEntity() { return (net.minecraft.world.entity.item.ItemEntity) super.getEntity(); }
    public Player getPlayer() { return player; }
}
