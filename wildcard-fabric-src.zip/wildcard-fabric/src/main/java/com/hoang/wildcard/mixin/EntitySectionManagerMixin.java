package com.hoang.wildcard.mixin;

import com.hoang.wildcard.fe.bridge.Hooks;
import net.minecraft.world.level.entity.PersistentEntitySectionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Marks entities that come from chunk storage (EntityJoinLevelEvent#loadedFromDisk). */
@Mixin(PersistentEntitySectionManager.class)
public abstract class EntitySectionManagerMixin {
    @Inject(method = {"processPendingLoads", "addLegacyChunkEntities"}, at = @At("HEAD"))
    private void wildcard$startLoad(CallbackInfo ci) { Hooks.loadingFromDisk = true; }

    @Inject(method = {"processPendingLoads", "addLegacyChunkEntities"}, at = @At("RETURN"))
    private void wildcard$endLoad(CallbackInfo ci) { Hooks.loadingFromDisk = false; }
}
