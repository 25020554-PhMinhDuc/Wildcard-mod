package com.hoang.wildcard.client;


import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.vehicle.boat.Boat;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import com.hoang.wildcard.fe.api.distmarker.Dist;
import com.hoang.wildcard.fe.client.event.*;
import com.hoang.wildcard.fe.common.Tags;
import com.hoang.wildcard.fe.event.TickEvent;
import com.hoang.wildcard.fe.event.entity.player.PlayerInteractEvent;
import com.hoang.wildcard.fe.eventbus.api.SubscribeEvent;
import com.hoang.wildcard.fe.fml.common.Mod;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/** Client-only effects: movement tweaks, camera, overlays, fog, X-ray and ability keys. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    public static int flashTicks;
    /** Troll debuffs: Bàn Phím Ngược, Rung Màn Hình, Hotbar Lơ Lửng paused by the skill. */
    public static int invertTicks, shakeTicks, hotbarHoldTicks;
    private static boolean hotbarPushed;
    /** Quét Quặng (kỹ năng): ore outlines in 12 blocks while > 0. */
    public static int xrayTicks;
    private static boolean prevJump;
    private static boolean doubleJumpUsed;
    private static int crouchTicks;
    private static Vec3 prevMotion = Vec3.ZERO;
    private static final List<BlockPos> XRAY = new ArrayList<>();
    private static int heartbeatCooldown;

    private static boolean has(String id) {
        return ClientState.has(id);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        if (flashTicks > 0) flashTicks--;
        if (invertTicks > 0) invertTicks--;
        if (shakeTicks > 0) shakeTicks--;
        if (hotbarHoldTicks > 0) hotbarHoldTicks--;

        if (xrayTicks > 0) xrayTicks--;
        for (int i = 0; i < ClientSetup.KEY_SKILLS.length; i++) {
            while (ClientSetup.KEY_SKILLS[i].consumeClick()) Net.toServer(new Net.Ability(Net.Ability.SLOT_BASE + i));
        }
        while (ClientSetup.KEY_ENDER.consumeClick()) Net.toServer(new Net.Ability(Net.Ability.ENDER));
        while (ClientSetup.KEY_CARDS.consumeClick()) {
            if (mc.gui.screen() == null) mc.gui.setScreen(new CardsScreen());
        }

        if (p.isSpectator() || p.getAbilities().flying) {
            prevMotion = p.getDeltaMovement();
            return;
        }
        Vec3 dm = p.getDeltaMovement();
        boolean jumpDown = mc.options.keyJump.isDown();

        // Nhảy Kép
        if (p.onGround()) doubleJumpUsed = false;
        if (has("e02") && jumpDown && !prevJump && !p.onGround() && !doubleJumpUsed && !p.isInWater() && !p.onClimbable()) {
            doubleJumpUsed = true;
            p.setDeltaMovement(dm.x * 1.1, 0.55, dm.z * 1.1);
            for (int i = 0; i < 8; i++) {
                mc.level.addParticle(ParticleTypes.CLOUD, p.getX(), p.getY(), p.getZ(),
                        (p.getRandom().nextDouble() - 0.5) * 0.2, -0.05, (p.getRandom().nextDouble() - 0.5) * 0.2);
            }
            dm = p.getDeltaMovement();
        }
        prevJump = jumpDown;

        // Thằn Lằn (giữ Space sát tường) / Người Nhện / kỹ năng nhện bị cướp
        boolean spider = has("e13") || "spider".equals(ClientState.stolen);
        if (p.horizontalCollision && ((has("u03") && jumpDown) || spider)) {
            double up = p.isShiftKeyDown() ? Math.max(dm.y, 0) : 0.2;
            p.setDeltaMovement(dm.x, up, dm.z);
            p.fallDistance = 0;
            dm = p.getDeltaMovement();
        }
        // Sợ Thang
        if (has("u03") && p.onClimbable() && dm.y > -0.15) {
            p.setDeltaMovement(dm.x, -0.15, dm.z);
            dm = p.getDeltaMovement();
        }
        // Lông Vũ
        if (has("r08") && !p.onGround() && p.isShiftKeyDown() && dm.y < -0.12) {
            p.setDeltaMovement(dm.x, -0.12, dm.z);
            dm = p.getDeltaMovement();
        }
        // Chạy Trên Nước
        if (has("r13") && p.isSprinting() && !p.isInWater()) {
            BlockPos below = BlockPos.containing(p.getX(), p.getY() - 0.2, p.getZ());
            if (mc.level.getFluidState(below).is(FluidTags.WATER) && mc.level.getBlockState(below.above()).isAir()) {
                if (p.getY() < below.getY() + 1.0) p.setPos(p.getX(), below.getY() + 1.0, p.getZ());
                p.setDeltaMovement(dm.x, Math.max(0, dm.y), dm.z);
                p.setOnGround(true);
                p.fallDistance = 0;
                dm = p.getDeltaMovement();
            }
        }
        // Nặng Như Chì: đứng yên trong nước thì chìm
        if (has("c15") && p.isInWater() && p.input.getMoveVector().lengthSquared() == 0 && !p.input.keyPresses.jump()) {
            p.setDeltaMovement(dm.x, dm.y - 0.03, dm.z);
            dm = p.getDeltaMovement();
        }
        // Hụt Hơi
        if (has("u10") && p.getFoodData().getFoodLevel() < 10 && p.isSprinting()) p.setSprinting(false);
        // Không Phanh: mặt đất trơn như băng
        if (has("l11") && p.onGround() && !p.isInWater()) {
            p.setDeltaMovement(dm.x * 0.35 + prevMotion.x * 0.64, dm.y, dm.z * 0.35 + prevMotion.z * 0.64);
            dm = p.getDeltaMovement();
        }
        // Thuyền Trưởng
        if (has("e14") && p.getVehicle() instanceof Boat boat && boat.getControllingPassenger() == p) {
            Vec3 v = boat.getDeltaMovement();
            if (v.horizontalDistance() < 1.1 && v.horizontalDistance() > 0.01) boat.setDeltaMovement(v.x * 1.15, v.y, v.z * 1.15);
        }
        prevMotion = p.getDeltaMovement();

        // X-Quang: cúi 3 giây
        crouchTicks = p.isShiftKeyDown() ? crouchTicks + 1 : 0;
        if (xrayTicks > 0) {
            if (xrayTicks % 10 == 0) scanOres(mc.level, p.blockPosition(), 12);
        } else if (has("e10") && crouchTicks >= 60) {
            if (crouchTicks % 10 == 0) scanOres(mc.level, p.blockPosition(), 8);
        } else if (!XRAY.isEmpty()) {
            XRAY.clear();
        }

        // Tim Đập Nhanh
        if (heartbeatCooldown > 0) heartbeatCooldown--;
        if (has("e16") && p.getHealth() < p.getMaxHealth() * 0.5f && heartbeatCooldown == 0) {
            heartbeatCooldown = 18;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.WARDEN_HEARTBEAT, 1.0f, 1.2f));
        }
    }

    private static void scanOres(Level level, BlockPos center, int r) {
        XRAY.clear();
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-r, -r, -r), center.offset(r, r, r))) {
            if (level.getBlockState(pos).is(Tags.Blocks.ORES)) XRAY.add(pos.immutable());
        }
    }

    // Fan: right click on air with an empty hand (fires only on the client)
    @SubscribeEvent
    public static void onRightClickEmpty(PlayerInteractEvent.RightClickEmpty e) {
        if (!e.getItemStack().isEmpty() || e.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        if (has("r14") && e.getEntity().isShiftKeyDown()) {
            Net.toServer(new Net.Ability(Net.Ability.TONGUE)); // Lưỡi Ếch
        } else if (has("e11")) {
            Net.toServer(new Net.Ability(Net.Ability.FAN));
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        float roll = e.getRoll();
        if (has("e06")) roll += 10f; // Màn Hình Nghiêng
        if (has("e14") && mc.player.onGround() && !(mc.player.getVehicle() instanceof Boat)) { // Say Sóng
            double t = (mc.player.tickCount + e.getPartialTick()) / 20.0;
            roll += (float) (Math.sin(t * 1.3) * 2.5);
            e.setPitch(e.getPitch() + (float) (Math.sin(t * 0.9) * 1.2));
        }
        if (shakeTicks > 0) { // Rung Màn Hình
            double t = (mc.player.tickCount + e.getPartialTick());
            roll += (float) (Math.sin(t * 2.7) * 6);
            e.setYaw(e.getYaw() + (float) (Math.sin(t * 3.3) * 2));
            e.setPitch(e.getPitch() + (float) (Math.cos(t * 2.9) * 2));
        }
        e.setRoll(roll);
    }

    /** Bàn Phím Ngược: W/S and A/D swap. */
    @SubscribeEvent
    public static void onInput(MovementInputUpdateEvent e) {
        if (invertTicks <= 0) return;
        var in = e.getInput();
        in.forwardImpulse = -in.forwardImpulse;
        in.leftImpulse = -in.leftImpulse;
        boolean up = in.up, left = in.left;
        in.up = in.down;
        in.down = up;
        in.left = in.right;
        in.right = left;
    }

    /** Hotbar Lơ Lửng: the hotbar drifts around the screen. */
    /** v9: wraps the vanilla hotbar HUD element; returns true when the pose was pushed. */
    public static boolean onHotbarPre(GuiGraphics g, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || hotbarHoldTicks > 0) return false;
        if (!has("u62") && !com.hoang.wildcard.effects.TrollDebuffs.has(mc.player, "t21")) return false;
        double t = (mc.player.tickCount + partialTick) / 20.0;
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        float dx = (float) (Math.sin(t * 0.7) * (w / 2.0 - 100));
        float dy = (float) (-(Math.sin(t * 1.1) * 0.5 + 0.5) * (h - 60));
        g.pose().pushPose();
        g.pose().translate(dx, dy, 0);
        return true;
    }

    public static void onOverlay(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        int w = g.guiWidth(), h = g.guiHeight();
        if (has("l12")) g.fill(0, 0, w, h, 0x30B0B0B8); // Cận Thị: màn hình mờ nhẹ
        if (has("e16") && mc.player.getHealth() < mc.player.getMaxHealth() * 0.5f) { // viền đỏ
            float pulse = 0.6f + 0.4f * (float) Math.sin(mc.player.tickCount * 0.35);
            int a = (int) (150 * pulse);
            int strong = (a << 24) | 0xC00000;
            int none = 0x00C00000;
            int band = Math.max(12, h / 5);
            g.fillGradient(0, 0, w, band, strong, none);
            g.fillGradient(0, h - band, w, h, none, strong);
            for (int i = 0; i < band; i += 2) {
                int alpha = (int) (a * (1f - i / (float) band));
                int c = (alpha << 24) | 0xC00000;
                g.fill(i, 0, i + 2, h, c);
                g.fill(w - i - 2, 0, w - i, h, c);
            }
        }
        if (mc.gui.screen() == null) SkillHud.render(g, mc);
        if (flashTicks > 0) { // Lóa Mắt
            int a = Math.min(255, flashTicks * 25);
            g.fill(0, 0, w, h, (a << 24) | 0xFFFFFF);
        }
    }

    // X-Quang: viền quặng (v9: drawn with the level render context)
    public static void onRenderLevel(net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext ctx) {
        if (XRAY.isEmpty()) return;
        Vec3 cam = Minecraft.getInstance().gameRenderer.mainCamera().position();
        List<BlockPos> boxes = new ArrayList<>(XRAY);
        ctx.submitNodeCollector().submitCustomGeometry(ctx.poseStack(), net.minecraft.client.renderer.rendertype.RenderTypes.linesTranslucentNoDepthWrite(), (pose, bb) -> {
            Matrix4f m = pose.pose();
            for (BlockPos pos : boxes) {
                float x0 = (float) (pos.getX() - cam.x), y0 = (float) (pos.getY() - cam.y), z0 = (float) (pos.getZ() - cam.z);
                float x1 = x0 + 1, y1 = y0 + 1, z1 = z0 + 1;
                float[][] c = {{x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, {x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}};
                int[][] edges = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
                for (int[] ed : edges) {
                    float nx = c[ed[1]][0] - c[ed[0]][0], ny = c[ed[1]][1] - c[ed[0]][1], nz = c[ed[1]][2] - c[ed[0]][2];
                    bb.addVertex(m, c[ed[0]][0], c[ed[0]][1], c[ed[0]][2]).setColor(1f, 0.85f, 0.2f, 1f).setNormal(nx, ny, nz).setLineWidth(2f);
                    bb.addVertex(m, c[ed[1]][0], c[ed[1]][1], c[ed[1]][2]).setColor(1f, 0.85f, 0.2f, 1f).setNormal(nx, ny, nz).setLineWidth(2f);
                }
            }
        });
    }

    private ClientEvents() {}
}
