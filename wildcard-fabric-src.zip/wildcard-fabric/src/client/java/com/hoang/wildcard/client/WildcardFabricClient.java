package com.hoang.wildcard.client;

import net.fabricmc.api.ClientModInitializer;

public final class WildcardFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        com.hoang.wildcard.WildcardFabric.LOG.info("Wildcard client sẵn sàng");
    }
}
