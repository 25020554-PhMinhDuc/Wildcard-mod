# Wildcard Hỗn Loạn – Fabric 26.3 (v9.0.0-alpha1)

Bản port từ Forge 1.20.1 sang Fabric 26.3 (Java 25). Toàn bộ thẻ, màn hình chọn thẻ (đếm ngược 5 giây),
HUD, hiệu ứng 3D và lệnh `/wildcard` đã được chuyển. Các sự kiện Forge cũ được giả lập bằng
callback của Fabric API (`fe/bridge/CommonBridge`, `client/ClientBridge`) và mixin (`mixin/`).

## Build
1. Chép `.github/workflows/build-fabric.yml` vào `.github/workflows/` của repo.
2. Để thư mục `wildcard-fabric/` (hoặc file `wildcard-fabric-src.zip`) ở gốc repo rồi push.
3. Vào tab Actions, tải artifact `wildcard-fabric-jar`.

Cần cài: Fabric Loader 0.20.1+ và Fabric API 0.166.0+26.3.

## Thay đổi so với bản Forge
- Cận Thị: còn lớp mờ màn hình, bỏ phần sương mù gần.
- Đêm Vĩnh Cửu (e33): bỏ hiệu ứng trời tối phía client (phần server vẫn chạy).
- Tĩnh Lặng: chỉ đóng băng hoạt ảnh đi, không đóng băng hoạt ảnh đánh.
- Phông chữ Ngân Hà trong chat chỉ áp dụng cho tin nhắn hệ thống/game.
- X-Quang: đường viền có thể không nhìn xuyên tường.
