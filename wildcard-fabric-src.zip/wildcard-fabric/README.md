# Wildcard Hỗn Loạn – Fabric 26.3 (đang port từ Forge 1.20.1)

Bước 1: khung mod. Mục tiêu là xác nhận GitHub Actions build được với Fabric 26.3.

Cách build: chép `.github/workflows/build-fabric.yml` vào thư mục `.github/workflows/` của repo,
và để thư mục `wildcard-fabric/` (hoặc file `wildcard-fabric-src.zip`) ở gốc repo. Workflow tự dò
phiên bản Fabric Loader, Fabric API và Loom mới nhất cho 26.3.
