package com.hoang.wildcard.net;

import com.hoang.wildcard.RoundManager;
import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.client.ClientPackets;
import com.hoang.wildcard.effects.Abilities;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class Net {
    private static final String VERSION = "7";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(WildcardMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);
    private static boolean registered;

    public static void register() {
        if (registered) return;
        registered = true;
        int id = 0;
        CH.messageBuilder(OpenChoice.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenChoice::encode).decoder(OpenChoice::decode).consumerMainThread(OpenChoice::handle).add();
        CH.messageBuilder(Sync.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(Sync::encode).decoder(Sync::decode).consumerMainThread(Sync::handle).add();
        CH.messageBuilder(Fx.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(Fx::encode).decoder(Fx::decode).consumerMainThread(Fx::handle).add();
        CH.messageBuilder(Choose.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(Choose::encode).decoder(Choose::decode).consumerMainThread(Choose::handle).add();
        CH.messageBuilder(Ability.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(Ability::encode).decoder(Ability::decode).consumerMainThread(Ability::handle).add();
        CH.messageBuilder(SetSlot.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SetSlot::encode).decoder(SetSlot::decode).consumerMainThread(SetSlot::handle).add();
        CH.messageBuilder(ToggleEquip.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ToggleEquip::encode).decoder(ToggleEquip::decode).consumerMainThread(ToggleEquip::handle).add();
        CH.messageBuilder(Vfx.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(Vfx::encode).decoder(Vfx::decode).consumerMainThread(Vfx::handle).add();
        CH.messageBuilder(RainOffer.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(RainOffer::encode).decoder(RainOffer::decode).consumerMainThread(RainOffer::handle).add();
        CH.messageBuilder(RainAnswer.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(RainAnswer::encode).decoder(RainAnswer::decode).consumerMainThread(RainAnswer::handle).add();
    }

    /** Sends to every player within 96 blocks of a point in that level. */
    public static void near(net.minecraft.server.level.ServerLevel level, double x, double y, double z, Object msg) {
        CH.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, 96, level.dimension())), msg);
    }

    public static void toPlayer(ServerPlayer p, Object msg) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), msg);
    }

    public static void toServer(Object msg) {
        CH.sendToServer(msg);
    }

    private static void writeList(FriendlyByteBuf buf, List<String> list) {
        buf.writeVarInt(list.size());
        for (String s : list) buf.writeUtf(s);
    }

    private static List<String> readList(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<String> l = new ArrayList<>(n);
        for (int i = 0; i < n; i++) l.add(buf.readUtf());
        return l;
    }

    /** Server -> client: open the card choice screen. */
    public record OpenChoice(List<String> ids, int seconds, int round) {
        public void encode(FriendlyByteBuf buf) {
            writeList(buf, ids);
            buf.writeVarInt(seconds);
            buf.writeVarInt(round);
        }

        public static OpenChoice decode(FriendlyByteBuf buf) {
            return new OpenChoice(readList(buf), buf.readVarInt(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPackets.openChoice(this));
        }
    }

    /** Server -> client: the list of owned cards and the G H J K L skill loadout. */
    /** {@code stars}: "cardId=count" for every duplicated card. */
    public record Sync(List<String> cards, List<String> equipped, String stolen, List<String> loadout, List<String> stars) {
        public void encode(FriendlyByteBuf buf) {
            writeList(buf, cards);
            writeList(buf, equipped);
            buf.writeUtf(stolen);
            writeList(buf, loadout);
            writeList(buf, stars);
        }

        public static Sync decode(FriendlyByteBuf buf) {
            return new Sync(readList(buf), readList(buf), buf.readUtf(), readList(buf), readList(buf));
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPackets.sync(this));
        }
    }

    /** Server -> client: a one-shot visual effect (flash, sneeze, close screen...). */
    public record Fx(String type, int value) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeUtf(type);
            buf.writeVarInt(value);
        }

        public static Fx decode(FriendlyByteBuf buf) {
            return new Fx(buf.readUtf(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPackets.fx(this));
        }
    }

    /** Server -> client: v4 spell visual (see client.VfxClient for kinds). */
    public record Vfx(int kind, int el, int id, float x, float y, float z, float a, float b, float c, float d, int life) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeByte(kind);
            buf.writeByte(el);
            buf.writeVarInt(id);
            buf.writeFloat(x);
            buf.writeFloat(y);
            buf.writeFloat(z);
            buf.writeFloat(a);
            buf.writeFloat(b);
            buf.writeFloat(c);
            buf.writeFloat(d);
            buf.writeVarInt(life);
        }

        public static Vfx decode(FriendlyByteBuf buf) {
            return new Vfx(buf.readByte(), buf.readByte(), buf.readVarInt(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.hoang.wildcard.client.VfxClient.handle(this));
        }
    }

    /** Client -> server: chosen card index (0..2). */
    public record Choose(int index) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(index + 1);
        }

        public static Choose decode(FriendlyByteBuf buf) {
            return new Choose(buf.readVarInt() - 1);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) RoundManager.onChoose(p, index);
        }
    }

    /** Client -> server: an ability key was pressed. */
    public record Ability(int kind) {
        public static final int ENDER = 2, FAN = 3, TONGUE = 4, SLOT_BASE = 10;

        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(kind);
        }

        public static Ability decode(FriendlyByteBuf buf) {
            return new Ability(buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) Abilities.use(p, kind);
        }
    }

    /** Client -> server: put skill "cardId:index" (or "" to clear) into loadout slot 0..4. */
    public record SetSlot(int slot, String entry) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(slot);
            buf.writeUtf(entry);
        }

        public static SetSlot decode(FriendlyByteBuf buf) {
            return new SetSlot(buf.readVarInt(), buf.readUtf(64));
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) RoundManager.setSlot(p, slot, entry);
        }
    }

    /** Client -> server: equip or unequip an owned card. */
    public record ToggleEquip(String id) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeUtf(id);
        }

        public static ToggleEquip decode(FriendlyByteBuf buf) {
            return new ToggleEquip(buf.readUtf(64));
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) RoundManager.toggleEquip(p, id);
        }
    }

    /** Server -> client (v6): the player touched a Card Rain card; ask "do you want this card?". Rarity stays hidden. */
    public record RainOffer(int entity, int seconds) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(entity);
            buf.writeVarInt(seconds);
        }

        public static RainOffer decode(FriendlyByteBuf buf) {
            return new RainOffer(buf.readVarInt(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPackets.rainOffer(this));
        }
    }

    /** Client -> server (v6): answer to {@link RainOffer}. */
    public record RainAnswer(int entity, boolean yes) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(entity);
            buf.writeBoolean(yes);
        }

        public static RainAnswer decode(FriendlyByteBuf buf) {
            return new RainAnswer(buf.readVarInt(), buf.readBoolean());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) com.hoang.wildcard.event.CardRain.answer(p, entity, yes);
        }
    }

    private Net() {}
}
