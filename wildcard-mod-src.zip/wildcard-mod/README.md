# Wildcard Hỗn Loạn – Forge 1.20.1

Mod lấy cảm hứng từ ARAM Hỗn Loạn: cứ 20 phút mỗi người chơi được chọn 1 trong 3 thẻ wildcard.
Mỗi thẻ có 1 **LỢI ÍCH** và 1 **BẤT LỢI**, hiệu ứng vĩnh viễn và cộng dồn.

## Build file .jar

Cần JDK 17 (Temurin/Adoptium). Trong thư mục này chạy:

```
# Windows
gradlew.bat build
# macOS / Linux
./gradlew build
```

File mod nằm ở `build/libs/wildcard-chaos-1.20.1-3.1.0.jar`. Bỏ vào thư mục `mods` của Forge **1.20.1** (47.x).
Chạy thử trong môi trường dev: `gradlew runClient`.

Nếu đẩy lên GitHub, workflow `.github/workflows/build.yml` sẽ tự build và đính kèm file .jar vào mục Actions → Artifacts.

## Cách chơi (v3)

- Boss bar đếm ngược tới lượt chọn kế tiếp (**20:00**). Còn 10 giây có chuông báo.
- Hết giờ: 3 thẻ úp bay vào và xoay. Thẻ **Sử thi trở lên phát sáng** màu độ hiếm khi còn úp.
  Bấm vào thẻ (hoặc **1 / 2 / 3**) để **lật**, bấm lần nữa để **chọn**. **Space** lật hết. Còn 5 giây thì tự lật hết.
- Âm thanh lật thẻ: thường, VIP (Sử thi), Huyền thoại, Thần thoại và thẻ meme đều khác nhau.
- Trong lúc chọn bạn bất tử và mob quanh 16 khối đứng yên. Quá 30 giây sẽ tự chọn ngẫu nhiên.
- **Mỗi thẻ đúng 1 kỹ năng** (kể cả Phổ biến). Dùng kỹ năng có vòng phép, hạt theo hệ và âm thanh riêng của thẻ.
- Kỹ năng gây hại trúng **cả người chơi khác** khi server bật PvP (đồng đội cùng team thì không).
- Chỉ **20 thẻ được trang bị** mới có tác dụng. Kho thẻ (B): chuột phải để trang bị / tháo, xếp 5 ô kỹ năng **G H J K L**.

| Phím | Chức năng |
| --- | --- |
| **G H J K L** | 5 ô kỹ năng do bạn tự xếp |
| **B** | Kho thẻ |
| **N** | Ender Chest Bỏ Túi |

## Luật roll (v3)

Mỗi ô trong 3 thẻ quay riêng:

| Độ hiếm | Tỉ lệ mỗi ô | Ghi chú |
| --- | --- | --- |
| Thần thoại (đỏ) | 0,01% | bảo hiểm: 150 lượt không thấy thì lượt sau chắc chắn có |
| Huyền thoại (vàng) | 0,5% | bảo hiểm: 50 lượt không thấy thì lượt sau chắc chắn có |
| Sử thi (tím) | 5% | |
| Hiếm (xanh dương) | ≈ 2,4% | phần còn lại rút từ bộ bài 2000 lá |
| Không phổ biến (xanh lá) | ≈ 9,6% | |
| Phổ biến (xám) | ≈ 82,4% | thẻ Phổ biến được nhân bản cho đủ 2000 lá |

- **Lệch bảo hiểm:** thẻ bảo hiểm rút từ tất cả thẻ Huyền thoại / Thần thoại, nên có thể trùng thẻ bạn đã có.
- **Trùng thẻ (rất cao):** mỗi ô có 60% ra lại thẻ bạn đã sở hữu (nếu có). Chọn thẻ trùng thì thẻ đó **lên sao**:
  tối đa 5 sao; mỗi sao: lợi ích +8%, bất lợi -6% (cấp hiệu ứng: lợi ích +1 cấp ở 5 sao, bất lợi -1 cấp từ 3 sao), hồi chiêu -10% (18 giây → 16 giây). Không còn +1 máu.
- Tất cả chỉnh được trong `config/wildcard-common.toml` mục `chances` (`suThiPercent`, `huyenThoaiPercent`,
  `thanThoaiPercent`, `poolSize`, `pityHuyenThoai`, `pityThanThoai`, `trungThePercent`). Thời gian: `roundSecondsV3`.

## Số thẻ (490)

| Độ hiếm | Số thẻ | id |
| --- | --- | --- |
| Common | 160 | c01–c160 |
| Uncommon | 206 | u01–u210 trừ u61–u64 |
| Rare | 67 | r01–r63, cộng u61 La Peace, u62 Hotbar Lơ Lửng, u63 Trap Card, u64 Jackpot (lên Rare ở v6 để giữ kỹ năng) |
| Epic | 35 | e01–e08, e10–e13, e16, e18, e20, e21–e40 |
| Legendary | 17 | l01, l02, l04, l05, l20, l21–l32 |
| Mythic | 5 | m01–m05 |

Thẻ c41+, u65+, r26+, e21+, l21+ và kỹ năng của thẻ thường được sinh bằng `gen/gen_cards.py` (dữ liệu trong `GenData.java`,
chữ trong file lang). Bất lợi luôn nặng hơn lợi ích. Khoảng 1/3 là thẻ meme (tên meme, âm thanh lật thẻ riêng).

Mỗi người chỉ giữ **1 thẻ Thần thoại**; đổi sang thẻ Thần thoại khác thì thẻ cũ (và sao của nó) bị thay. Từ v4.2 không còn mất tim.

## Bất lợi troll / meme

Từ v6 troll không còn là phần riêng: troll là một **bất lợi bình thường** của thẻ, ghi chung trong phần Bất lợi.
Số lợi ích và bất lợi theo độ hiếm: Common/Uncommon 1, Rare 2, Epic 3, Legendary 4, Mythic 5, không cái nào trùng loại trên cùng một thẻ
(phần thêm nằm trong `GenExtra.java`, sinh bằng `gen/v6_cards.py`). Có 25 loại troll: Hắt Xì Đồ, Vine Boom, Bàn Phím Ngược, Lag Giả,
Creeper Ma, Skill Issue, NPC, Đói Như Sói, Trượt Tay, Đồ Mau Hỏng, Say Xe, Chớp Tắt, Fan Cứng (gà), Thuế Thu Nhập, Phát Sáng,
Trượt Vỏ Chuối, Rung Màn Hình, Gió Lùa, Nam Châm Quái, Chân Thủy Tinh, Hotbar Lơ Lửng, Ohio, Rickroll, Bruh, Mất Sóng.

## Phép kiểu sách phép (v3.1)

142 kỹ năng (mọi thẻ Hiếm trở lên được sinh tự động và khoảng 30% thẻ thường) là phép kiểu sách phép, vẽ và code riêng,
vẫn giữ vòng phép rune khi cast: Hỏa Tiễn, Mũi Băng Nhọn, Phi Đạn Ma Thuật (tự bám), Giáo Sét, Sét Chuỗi, Huyết Trảm,
Tia Băng Giá, Nanh Quỷ, Đom Đóm Thánh, Cầu Axit, Hơi Thở Rồng / Băng Giá, Phản Phép, Rễ Trói, Tàn Lụi. Code ở `effects/Spells.java`,
icon ở `textures/gui/skill/` (sinh bằng `gen/spell_icons.py`).

- **La Peace**: thêm bất lợi, đào quặng kim cương có 35% chỉ ra lapis.
- **Jackpot**: trúng lớn thì bất tử 15 giây kèm nhạc `sounds/meme/jackpot_win.ogg`.

## Âm thanh (thay bằng file của bạn)

Mod kèm âm thanh tự tổng hợp (không dùng clip có bản quyền). Muốn dùng clip meme thật, đặt file **.ogg mono** cùng tên đè lên:

| File | Phát khi |
| --- | --- |
| `sounds/roll/spin.ogg` | thẻ bắt đầu xoay |
| `sounds/roll/flip.ogg`, `vip.ogg`, `legendary.ogg`, `mythic.ogg`, `meme.ogg` | lật thẻ thường / Sử thi / Huyền thoại / Thần thoại / meme |
| `sounds/meme/lapeace.ogg` | thẻ La Peace (ví dụ clip Speed / Kai Cenat) |
| `sounds/meme/jackpot.ogg` | kỹ năng Quay Hũ |
| `sounds/meme/jackpot_win.ogg` | Jackpot trúng lớn (đang là nhạc Hakari bạn gửi, 15,8 giây) |
| `sounds/meme/trap.ogg`, `vineboom.ogg`, `bruh.ogg`, `rickroll.ogg`, `sus.ogg`, `sigma.ogg`, `fail.ogg` | các meme tương ứng |
| `sounds/skill/<hệ>.ogg` | kỹ năng theo hệ (fire, frost, storm, blood, void, holy, earth, wind, arcane) |

Đường dẫn đầy đủ: `src/main/resources/assets/wildcard/sounds/...` (hoặc làm resource pack cùng đường dẫn `assets/wildcard/sounds/`).
Muốn 1 thẻ có âm thanh riêng: thêm file `sounds/card/<id>.ogg` rồi sửa mục `card.<id>` trong `sounds.json` thành `"wildcard:card/<id>"`.

## Lệnh (OP)

```
/wildcard list            xem thẻ đang có
/wildcard now             mở lượt chọn ngay
/wildcard timer <giây>    đặt thời gian tới lượt kế
/wildcard give <id>       nhận thẻ (id xem bảng Số thẻ)
/wildcard remove <id>     bỏ thẻ
/wildcard clear           xóa toàn bộ và đặt lại
```

## Trạng thái thẻ

Tất cả thẻ đều có code. Các điểm còn khác so với bản thiết kế:

| Thẻ | Ghi chú |
| --- | --- |
| c08 Cần Thủ Câu Cá | Lợi ích (cá cắn câu nhanh hơn) **chưa làm**, Forge 1.20.1 không có event cho thời gian chờ cá. Bất lợi Mùi Tanh đã làm. |
| c12 Bước Nhẹ | Chỉ chống giẫm hỏng đất trồng, chưa chặn bàn đạp và Sculk Sensor. |
| r01 Khổng Lồ / To Xác | Có +4 HP và +1 tầm với. Phần phóng to người và hitbox (To Xác) **chưa làm**, cần thư viện Pehkui. |
| r10 Lò Lạnh | Bất lợi (lò nung chậm gấp đôi) **chưa làm**. |
| c07 Tiếng Gà | Phát tiếng gà khi bị đánh, nhưng tiếng người vẫn còn. |
| r19 Phù Thủy Tập Sự | Mob ở vùng 4–8 khối nhận hiệu ứng với nửa thời lượng. |

## Cấu trúc mã

- `RoundManager` – đếm giờ, roll độ hiếm, pity, leo thang, áp thẻ, boss bar, bất tử khi chọn.
- `Cards` – danh sách thẻ (độ hiếm, icon, nhãn xung đột, hồi chiêu kỹ năng). Chữ nằm trong `assets/wildcard/lang/vi_vn.json`.
- `WData` – dữ liệu lưu trong NBT người chơi (giữ qua chết và thoát game).
- `effects/` – `Effects` (hiệu ứng theo thời gian), `CombatEffects`, `WorldEffects`, `NewCards` (thẻ c21+/u21+/r21+), `Skills` (kỹ năng G–L), `Abilities` (phím).
- `client/WildcardScreen` – màn hình chọn thẻ; `client/CardsScreen` – kho thẻ (B); `client/SkillHud` – ô kỹ năng; `client/CardArt` – vẽ thẻ; `client/ClientEvents` – camera, lớp phủ, X-Quang, di chuyển phía client.

## Hiệu ứng phép thuật (v2.1)
- 9 hệ: lửa, băng, sét, máu, hư không, thánh, đất, gió, bí thuật. Mỗi hệ có particle riêng (`textures/particle/<hệ>_spark_*.png`) và rune phát sáng (`rune_*.png`, tô màu theo hệ).
- Dùng skill: vòng phép xoay dưới chân + cột tia sáng + âm thanh cast. Sóng chấn động, tia, vòng skill cũng có thêm particle theo hệ.
- Nhận thẻ: vòng phép theo màu độ hiếm.
- Icon 16x16 cho từng skill (`textures/gui/skill/<thẻ>_<số>.png`) hiện trên HUD, thanh G-L và trong màn B.
- Hệ của từng skill: `fx/SkillFx.java`.

## v4.0 – Hiệu ứng 3D phát sáng (thay toàn bộ hạt cũ)

Hạt cũ (tia lửa, hạt hệ, vòng phẳng, vệt chém) đã bị xoá. Chỉ giữ vòng phép rune khi niệm. Mọi hiệu ứng phép giờ được vẽ thẳng trong thế giới bởi `client/VfxClient.java` (tự viết, không chép mod khác):

| Hiệu ứng | Dùng cho |
|---|---|
| Cầu khối 3D lập lòe + đuôi khối nhỏ dần | mọi đạn phép (Hỏa Tiễn, Đại Hỏa Cầu, sao băng, đom đóm...) |
| Sét dày phát sáng nhiều lớp, có nhánh, chớp đổi hình | Giáo Sét, Sét Chuỗi, tia hệ Bão |
| Tia phép liền, phát sáng, nhấp nháy | Tia Băng, Cột Sáng Thần, tia ngắm |
| Hố đen: lõi khối đen xoay + tia sáng hồng toả ra + đĩa sáng | Hố Đen |
| Hàng cột băng khối trồi lên lần lượt | Tia Băng Giá |
| Cổng xoáy tím dựng đứng | dịch chuyển (blink) |
| Chùm tia sáng toả + mảnh sáng | trúng sét, nổ, Cột Sáng Thần |
| Mảnh khối văng + loé sáng, vòng sóng | va chạm, nổ, sóng chấn |
| Dòng khối phun hình nón | Hơi Thở Rồng / Băng Giá |

Gói tin mới `Net.Vfx` (phiên bản mạng 6). Phía server gọi `fx/Vfx`. Các kỹ năng Sử thi trở lên viết tay cũng chuyển sang hiệu ứng mới qua `Skills.puff/ring/beam`.

### v4.1 – Thêm kiểu hiệu ứng cùng phong cách

| Hiệu ứng mới | Dùng cho |
|---|---|
| Cột sáng mờ dần lên trên, khối sáng bay lên | hồi máu, buff, ăn, Sigma, khiêu khích (đỏ) |
| Mái vòm phát sáng có lưới | khiên, Khiên Băng, Phản Phép |
| Lốc xoáy khối đi lên | buff, nhảy, kéo |
| Vùng đất sủi bọt khối | nguyền, Tàn Lụi, Cầu Axit |
| Gai đá / băng mọc thành vòng | Rễ Trói, Mũi Băng trúng đích, sóng chấn hệ Đất/Băng |
| Hàng gai hư không | Nanh Quỷ |
| Cổng xoáy | triệu hồi sói |
| Chùm tia sáng | sóng chấn các hệ khác, Phản Phép |

## v4.2
* **Trùng thẻ:** tối đa 5 sao. Mỗi sao: lợi ích +8%, bất lợi -6%, hồi chiêu -10% (tooltip hiện hồi chiêu đã giảm). Thẻ sinh tự động: mọi chỉ số đều nhân theo sao. Thẻ viết tay: chỉ số thuộc tính (máu, giáp, tốc độ, sát thương...) nhân theo sao. Bỏ +1 máu mỗi sao.
* **Thần thoại:** đổi sang thẻ Thần thoại khác không còn mất tim (tim đã mất trước đây được trả lại).
* **Bộ âm thanh 9 hệ** (`gen/element_sounds.py`): mỗi hệ 3 tiếng niệm `sounds/skill/<hệ>_1..3.ogg` và 3 tiếng nổ `sounds/impact/<hệ>_1..3.ogg`, game chọn ngẫu nhiên. Muốn thay bằng tiếng thật: đặt file .ogg cùng tên đè lên (mono, 44,1 kHz là đẹp nhất).

## v5.0.0
* **Độ hiếm** hiển thị bằng tiếng Anh: Common, Uncommon, Rare, Epic, Legendary, Mythic.
* **Thẻ đủ 5 sao** không còn xuất hiện (lượt chọn, bảo hiểm, phần thưởng, Mưa Thẻ).
* **Thành tựu:** cứ 3 thành tựu trong một nhánh thì được 1 thẻ thưởng. Overworld (story, adventure, husbandry): Common trở lên. Nether: Rare trở lên. The End (cả End City): Epic trở lên. Công thức chế tạo và thành tựu ẩn không tính.
* **Boss lần đầu** (mỗi người 1 lần, ai đánh ở gần cũng được): Rồng Ender cho 1 thẻ Legendary; Wither, Warden, Elder Guardian cho 1 thẻ Epic trở lên.
* **Mưa Thẻ:** mỗi 7 ngày Minecraft. Báo trước 60 giây (10 giây cuối đếm ngược). 100 thẻ Rare trở lên (trong 440 thẻ, theo tỉ lệ độ hiếm như lúc quay thẻ: khoảng 30 Rare, 64 Epic, 6 Legendary, Mythic rất hiếm) rơi từ trời xuống chunk của từng người đang online (chia đều). Mỗi người nhặt 1 thẻ; nhặt xong thì phần thẻ rơi cho người đó biến mất. Sau 30 giây toàn bộ biến mất. Không rơi ở Nether. Lệnh OP: `/wildcard rain` (bắt đầu sau 60 giây), `/wildcard rain now`. Chỉnh trong config mục `cardRain`.
* **Âm thanh phép kiểu RPG** (`gen/element_sounds_v5.py`): tiếng niệm có lớp "gom phép" rít lên, tiếng nổ có reverb. Băng: nứt vỡ và mảnh băng leng keng. Sét: rè điện, nổ chát, sấm rền. Lửa: phừng, lách tách, nổ trầm. Máu: nhịp tim, tiếng ướt. Hư không: rền trầm, hút ngược. Thánh: hợp xướng và chuông. Đất: rung, đá vỡ. Gió: gió cuộn. Bí thuật: chuỗi nốt lấp lánh.

## v6.0.0
* **Âm thanh:** tiếng phép của các hệ dùng file bạn gửi (cắt khoảng lặng, mono 44,1 kHz, 3 biến thể cao độ cho tiếng niệm, 3 tiếng nổ ngắn).
  Lửa = fire, Băng = iced, Sét = lightning, Đất = earth, Hư không = dark, Gió = wind, Thánh = healing, Bí thuật = water. Hệ Máu vẫn dùng tiếng tự tạo.
  Vine Boom dùng file vine boom bạn gửi.
* **Mưa Thẻ:** thẻ rơi là "Thẻ bí ẩn", không lộ độ hiếm (không màu, không lấp lánh, không mô tả). Chạm vào thẻ không tự nhặt nữa:
  thẻ phải nằm trên đất, rồi hiện bảng "Bạn có muốn chọn thẻ này không?" (Có/Y hoặc Không/N, 10 giây). Chọn "Không" thì thẻ đó không hỏi lại trong 5 giây.
  Máy chủ kiểm tra lại khoảng cách, đợt mưa và lượt chọn trước khi trao thẻ.
* **Kỹ năng kích hoạt chỉ có ở thẻ Rare trở lên.** Common và Uncommon không còn kỹ năng (346 kỹ năng bị bỏ). 4 thẻ meme u61–u64 lên Rare để giữ kỹ năng.
* **Mỗi thẻ Rare+ có kỹ năng riêng hợp với thẻ:** 45 thẻ sinh tự động (r26–r50, e21–e30, l21–l25) được đặt tên mới và kỹ năng thiết kế lại
  (không có cặp loại phép + hệ nào trùng nhau, không trùng tên). Ví dụ Gấu Tuyết: Áo Giáp Tuyết; Thần Cuốc: Hố Sụt; Thủy Tặc Huyền Thoại: Đại Bác Hải Tặc.
* **Lợi ích / bất lợi theo độ hiếm** (xem phần troll ở trên).
* **Tên thẻ:** bỏ kiểu đánh số La Mã ("Siêu Nhân Gao V", "Đồ Tể III"...). Mọi thẻ có tên lợi ích và tên bất lợi riêng, không trùng.
* **Thành tựu:** thay luật theo nhánh. Cứ 3 thành tựu xanh (thường và mục tiêu) được 1 thẻ Rare trở lên; mỗi thành tựu tím (thử thách) được 1 thẻ Epic trở lên.
  Chỉnh trong config mục `advancements` (`greenEvery`, `purpleEvery`).
* Danh sách thẻ đầy đủ: `danh-sach-the-v6.md`.

## v6.1.0
* **Kỹ năng trúng mọi mục tiêu:** mọi mob (cả mob thụ động, dân làng, golem) và người chơi khác (khi server bật PvP). Không trúng bản thân và thú cưng của mình.
* **Sát thương chuẩn:** mọi sát thương kỹ năng dùng loại `wildcard:true_damage`, bỏ qua giáp, phù phép bảo vệ và khiên.
* **Sao của thẻ không có kỹ năng** (Common, Uncommon): mỗi sao lợi ích +20% (ví dụ sát thương cận chiến +1 thành +1,2), bất lợi giữ nguyên.
  Thẻ có kỹ năng giữ luật cũ (lợi ích +8%, bất lợi -6%, hồi chiêu -10% mỗi sao). Sao đổi màu theo cấp: 1 trắng, 2 xanh lá, 3 xanh dương, 4 tím, 5 vàng.
* **Ngưng Đọng Thời Gian** giờ đóng băng cả người chơi khác trong 20 khối suốt 6 giây (không đi, không nhảy, không đánh, bị giữ nguyên chỗ).
* **Cầu lửa:** bỏ hết cầu lửa vanilla/ghast. Bão Lửa, Cầu Lửa, Rồng Con, Mưa Thiên Thạch, Mưa Lửa, Đại Bác Hải Tặc dùng cầu lửa riêng:
  lõi trắng vàng, lưỡi lửa kéo đuôi, tàn lửa bay ra, nổ lửa khi chạm.
* **Hiệp Sĩ Rồng – Phun Lửa** làm lại: vòng rune trước miệng, luồng lửa 2,4 giây đi theo hướng nhìn, lửa cháy loang trên mặt đất, nổ bùng ở cuối.

## v7.0.0
* **Chiêu khống chế trúng cả người chơi:** làm chậm, đóng băng, trói, mù, kéo, hất văng, phát sáng, độc, Ngưng Đọng... đều trúng cả mob và người chơi khác (khi server bật PvP).
  Mô tả kỹ năng ghi rõ "Trúng cả mob và người chơi". Biến Gà với người chơi: hóa gà 6 giây (chậm, yếu, nhảy cao, rơi chậm) thay vì bị xóa.
* **Sao ghi rõ con số:** rê chuột lên thẻ (màn chọn thẻ hoặc phím B) để thấy từng chỉ số hiện tại → sao tiếp theo, ví dụ "Sát thương cận chiến: +0,5 → +0,6", và hồi chiêu "18s → 16s".
  Thẻ viết tay (không có dữ liệu chỉ số) hiện hệ số nhân, ví dụ "×1,2 → ×1,4".
* **Rơi thẻ từ quái vật:** quái vật (zombie, skeleton, creeper, enderman, stray, phantom, guardian...) bị người chơi hạ có 0,1% rơi 1 thẻ (theo tỉ lệ độ hiếm thường). Nhặt lên là nhận. Config `mobDrops.dropChance`.
* **Sự kiện Quái Vật Xâm Lăng:** 4% mỗi khi trời tối, báo trước 60 giây (10 giây cuối đếm ngược), kéo dài 1 phút 30 giây, thanh boss đếm quái còn lại và thời gian.
  Người chơi đứng gần nhau (48 khối) tính là một nơi, mỗi nơi một đợt quái, chỉ ở Overworld:
  - 1 người: 3 zombie và 5 skeleton đặc biệt (giáp, 30 máu, cung Power II). Hạ hết: 1 thẻ Uncommon trở lên.
  - 2 người trở lên: 5–10 stray, 5–10 phù thủy, 5–10 drowned cầm đinh ba, 3–5 phantom (càng đông càng nhiều). Hạ hết: mỗi người 1 thẻ Rare trở lên.
  - 3 người trở lên: 20% thêm đám Cướp dân làng (7 pillager, 5 vindicator, 2 ravager, 1 evoker), vẫn 1 thẻ Rare+ mỗi người; 3% xuất hiện Warden, hạ được thì mỗi người 1 thẻ Epic trở lên.
  - Hết giờ mà chưa hạ hết thì quái tan biến, không có thẻ. Đồ của quái sự kiện không rơi.
  Lệnh OP: `/wildcard invasion` (sau 60 giây), `/wildcard invasion now`. Config mục `invasion`.
* **Thẻ Mythic:** được sở hữu nhiều thẻ Mythic mà không mất gì, nhưng chỉ trang bị 1 thẻ Mythic một lúc. Trang bị Mythic khác ở phím B thì thẻ Mythic cũ tự tháo ra (vẫn còn trong bộ sưu tập).

## v7.1.0

- **Nhạc Rickroll** (bất lợi t23) thay bằng đoạn nhạc người chơi gửi, dài 7,6 giây.
- **Bỏ mọi bất lợi mất máu**: mất 1 máu mỗi X giây, "Hạ mob: tự mất máu", "Đào khối: đá văng vào mặt", máu tối đa âm (68 chỗ trong
  thẻ sinh tự động, đổi bằng `gen/v71_nohp.py`) và các thẻ viết tay c11, u05, u45, r13, l04, m01, m03, m05. Tim đã mất vĩnh viễn ở bản
  cũ (m03, l04) được trả lại. Sát thương từ lửa, sét, quái... vẫn giữ.
- **Lời Nguyền Wildcard** (`event/Curse`): đêm 3, 4, 6, 7, 9, 10... quái vật +25% máu tối đa, +15% sát thương; hết đêm thì gỡ.
  Config mục `curse` (everyNights, lastsNights, bonusHealth, bonusDamage). Lệnh `/wildcard curse` nguyền ngay đêm nay.
- **Bất lợi ẩn**: 20% thẻ chưa sở hữu trong lượt chọn hiện "???" ở ô bất lợi, chỉ lộ sau khi chọn (config `hiddenDebuff.chance`).
- **50 thẻ mới** chép từ ảnh (c151–c160, u201–u210, r51–r63, e31–e40, l26–l32; dữ liệu `gen/v71_cards.py`, hiệu ứng
  `effects/V71Cards` và `client/V71Client`). Thẻ giữ đúng 1 lợi ích + 1 bất lợi như ảnh, không có kỹ năng. Phím mới X: phun cát
  (Lời Nguyền Pharaoh). Kẻ Bay Lượn: nhấn nhảy khi đang rơi để lượn. Server riêng nên bật `allow-flight=true` cho Nhảy 2 Lần / Kẻ Bay Lượn.
