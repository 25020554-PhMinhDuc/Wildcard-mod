# Wildcard Hỗn Loạn – Forge 1.20.1

Mod lấy cảm hứng từ ARAM Hỗn Loạn: cứ 20 phút mỗi người chơi được chọn 1 trong 3 thẻ wildcard.
Mỗi thẻ có 1 **LỢI ÍCH** và 1 **BẤT LỢI**, hiệu ứng vĩnh viễn và cộng dồn.

## Build file .jar

Cần JDK 17 (Temurin/Adoptium). Trong thư mục này chạy:

```
# Windows
gradlew.bat build
# macOS / Linux
./gradlew build
```

File mod nằm ở `build/libs/wildcard-chaos-1.20.1-3.1.0.jar`. Bỏ vào thư mục `mods` của Forge **1.20.1** (47.x).
Chạy thử trong môi trường dev: `gradlew runClient`.

Nếu đẩy lên GitHub, workflow `.github/workflows/build.yml` sẽ tự build và đính kèm file .jar vào mục Actions → Artifacts.

## Cách chơi (v3)

- Boss bar đếm ngược tới lượt chọn kế tiếp (**20:00**). Còn 10 giây có chuông báo.
- Hết giờ: 3 thẻ úp bay vào và xoay. Thẻ **Sử thi trở lên phát sáng** màu độ hiếm khi còn úp.
  Bấm vào thẻ (hoặc **1 / 2 / 3**) để **lật**, bấm lần nữa để **chọn**. **Space** lật hết. Còn 5 giây thì tự lật hết.
- Âm thanh lật thẻ: thường, VIP (Sử thi), Huyền thoại, Thần thoại và thẻ meme đều khác nhau.
- Trong lúc chọn bạn bất tử và mob quanh 16 khối đứng yên. Quá 30 giây sẽ tự chọn ngẫu nhiên.
- **Mỗi thẻ đúng 1 kỹ năng** (kể cả Phổ biến). Dùng kỹ năng có vòng phép, hạt theo hệ và âm thanh riêng của thẻ.
- Kỹ năng gây hại trúng **cả người chơi khác** khi server bật PvP (đồng đội cùng team thì không).
- Chỉ **20 thẻ được trang bị** mới có tác dụng. Kho thẻ (B): chuột phải để trang bị / tháo, xếp 5 ô kỹ năng **G H J K L**.

| Phím | Chức năng |
| --- | --- |
| **G H J K L** | 5 ô kỹ năng do bạn tự xếp |
| **B** | Kho thẻ |
| **N** | Ender Chest Bỏ Túi |

## Luật roll (v3)

Mỗi ô trong 3 thẻ quay riêng:

| Độ hiếm | Tỉ lệ mỗi ô | Ghi chú |
| --- | --- | --- |
| Thần thoại (đỏ) | 0,01% | bảo hiểm: 150 lượt không thấy thì lượt sau chắc chắn có |
| Huyền thoại (vàng) | 0,5% | bảo hiểm: 50 lượt không thấy thì lượt sau chắc chắn có |
| Sử thi (tím) | 5% | |
| Hiếm (xanh dương) | ≈ 2,4% | phần còn lại rút từ bộ bài 2000 lá |
| Không phổ biến (xanh lá) | ≈ 9,6% | |
| Phổ biến (xám) | ≈ 82,4% | thẻ Phổ biến được nhân bản cho đủ 2000 lá |

- **Lệch bảo hiểm:** thẻ bảo hiểm rút từ tất cả thẻ Huyền thoại / Thần thoại, nên có thể trùng thẻ bạn đã có.
- **Trùng thẻ (rất cao):** mỗi ô có 60% ra lại thẻ bạn đã sở hữu (nếu có). Chọn thẻ trùng thì thẻ đó **lên sao**:
  mỗi sao giảm 8% hồi chiêu kỹ năng (tối đa 5 sao) và +1 máu tối đa (tối đa +20 cho cả bộ).
- Tất cả chỉnh được trong `config/wildcard-common.toml` mục `chances` (`suThiPercent`, `huyenThoaiPercent`,
  `thanThoaiPercent`, `poolSize`, `pityHuyenThoai`, `pityThanThoai`, `trungThePercent`). Thời gian: `roundSecondsV3`.

## Số thẻ (440)

| Độ hiếm | Số thẻ | id |
| --- | --- | --- |
| Phổ biến | 150 | c01–c150 |
| Không phổ biến | 200 | u01–u200 (u61 La Peace, u62 Hotbar Lơ Lửng, u63 Trap Card, u64 Jackpot) |
| Hiếm | 50 | r01–r50 |
| Sử thi | 25 | e01–e08, e10–e13, e16, e18, e20, e21–e30 |
| Huyền thoại | 10 | l01, l02, l04, l05, l20, l21–l25 |
| Thần thoại | 5 | m01–m05 |

Thẻ c41+, u65+, r26+, e21+, l21+ và kỹ năng của thẻ thường được sinh bằng `gen/gen_cards.py` (dữ liệu trong `GenData.java`,
chữ trong file lang). Bất lợi luôn nặng hơn lợi ích. Khoảng 1/3 là thẻ meme (tên meme, âm thanh lật thẻ riêng).

Mỗi người chỉ giữ **1 thẻ Thần thoại**; đổi sang thẻ Thần thoại khác thì **mất vĩnh viễn 1 tim**.

## Bất lợi troll / meme

Ngoài bất lợi chính, thẻ càng hiếm càng gánh thêm troll: Không phổ biến và Hiếm +1, Sử thi +2, Huyền thoại +3, Thần thoại +4.
Có 25 loại: Hắt Xì Đồ, Vine Boom, Bàn Phím Ngược, Lag Giả, Creeper Ma, Skill Issue, NPC, Đói Như Sói, Trượt Tay,
Đồ Mau Hỏng, Say Xe, Chớp Tắt, Fan Cứng (gà), Thuế Thu Nhập, Phát Sáng, Trượt Vỏ Chuối, Rung Màn Hình, Gió Lùa,
Nam Châm Quái, Chân Thủy Tinh, Hotbar Lơ Lửng, Ohio, Rickroll, Bruh, Mất Sóng. Rê chuột lên thẻ để xem chi tiết.

## Phép kiểu sách phép (v3.1)

142 kỹ năng (mọi thẻ Hiếm trở lên được sinh tự động và khoảng 30% thẻ thường) là phép kiểu sách phép, vẽ và code riêng,
vẫn giữ vòng phép rune khi cast: Hỏa Tiễn, Mũi Băng Nhọn, Phi Đạn Ma Thuật (tự bám), Giáo Sét, Sét Chuỗi, Huyết Trảm,
Tia Băng Giá, Nanh Quỷ, Đom Đóm Thánh, Cầu Axit, Hơi Thở Rồng / Băng Giá, Phản Phép, Rễ Trói, Tàn Lụi. Code ở `effects/Spells.java`,
icon ở `textures/gui/skill/` (sinh bằng `gen/spell_icons.py`).

- **La Peace**: thêm bất lợi, đào quặng kim cương có 35% chỉ ra lapis.
- **Jackpot**: trúng lớn thì bất tử 15 giây kèm nhạc `sounds/meme/jackpot_win.ogg`.

## Âm thanh (thay bằng file của bạn)

Mod kèm âm thanh tự tổng hợp (không dùng clip có bản quyền). Muốn dùng clip meme thật, đặt file **.ogg mono** cùng tên đè lên:

| File | Phát khi |
| --- | --- |
| `sounds/roll/spin.ogg` | thẻ bắt đầu xoay |
| `sounds/roll/flip.ogg`, `vip.ogg`, `legendary.ogg`, `mythic.ogg`, `meme.ogg` | lật thẻ thường / Sử thi / Huyền thoại / Thần thoại / meme |
| `sounds/meme/lapeace.ogg` | thẻ La Peace (ví dụ clip Speed / Kai Cenat) |
| `sounds/meme/jackpot.ogg` | kỹ năng Quay Hũ |
| `sounds/meme/jackpot_win.ogg` | Jackpot trúng lớn (đang là nhạc Hakari bạn gửi, 15,8 giây) |
| `sounds/meme/trap.ogg`, `vineboom.ogg`, `bruh.ogg`, `rickroll.ogg`, `sus.ogg`, `sigma.ogg`, `fail.ogg` | các meme tương ứng |
| `sounds/skill/<hệ>.ogg` | kỹ năng theo hệ (fire, frost, storm, blood, void, holy, earth, wind, arcane) |

Đường dẫn đầy đủ: `src/main/resources/assets/wildcard/sounds/...` (hoặc làm resource pack cùng đường dẫn `assets/wildcard/sounds/`).
Muốn 1 thẻ có âm thanh riêng: thêm file `sounds/card/<id>.ogg` rồi sửa mục `card.<id>` trong `sounds.json` thành `"wildcard:card/<id>"`.

## Lệnh (OP)

```
/wildcard list            xem thẻ đang có
/wildcard now             mở lượt chọn ngay
/wildcard timer <giây>    đặt thời gian tới lượt kế
/wildcard give <id>       nhận thẻ (id xem bảng Số thẻ)
/wildcard remove <id>     bỏ thẻ
/wildcard clear           xóa toàn bộ và đặt lại
```

## Trạng thái thẻ

Tất cả thẻ đều có code. Các điểm còn khác so với bản thiết kế:

| Thẻ | Ghi chú |
| --- | --- |
| c08 Cần Thủ Câu Cá | Lợi ích (cá cắn câu nhanh hơn) **chưa làm**, Forge 1.20.1 không có event cho thời gian chờ cá. Bất lợi Mùi Tanh đã làm. |
| c12 Bước Nhẹ | Chỉ chống giẫm hỏng đất trồng, chưa chặn bàn đạp và Sculk Sensor. |
| r01 Khổng Lồ / To Xác | Có +4 HP và +1 tầm với. Phần phóng to người và hitbox (To Xác) **chưa làm**, cần thư viện Pehkui. |
| r10 Lò Lạnh | Bất lợi (lò nung chậm gấp đôi) **chưa làm**. |
| c07 Tiếng Gà | Phát tiếng gà khi bị đánh, nhưng tiếng người vẫn còn. |
| r19 Phù Thủy Tập Sự | Mob ở vùng 4–8 khối nhận hiệu ứng với nửa thời lượng. |

## Cấu trúc mã

- `RoundManager` – đếm giờ, roll độ hiếm, pity, leo thang, áp thẻ, boss bar, bất tử khi chọn.
- `Cards` – danh sách thẻ (độ hiếm, icon, nhãn xung đột, hồi chiêu kỹ năng). Chữ nằm trong `assets/wildcard/lang/vi_vn.json`.
- `WData` – dữ liệu lưu trong NBT người chơi (giữ qua chết và thoát game).
- `effects/` – `Effects` (hiệu ứng theo thời gian), `CombatEffects`, `WorldEffects`, `NewCards` (thẻ c21+/u21+/r21+), `Skills` (kỹ năng G–L), `Abilities` (phím).
- `client/WildcardScreen` – màn hình chọn thẻ; `client/CardsScreen` – kho thẻ (B); `client/SkillHud` – ô kỹ năng; `client/CardArt` – vẽ thẻ; `client/ClientEvents` – camera, lớp phủ, X-Quang, di chuyển phía client.

## Hiệu ứng phép thuật (v2.1)
- 9 hệ: lửa, băng, sét, máu, hư không, thánh, đất, gió, bí thuật. Mỗi hệ có particle riêng (`textures/particle/<hệ>_spark_*.png`) và rune phát sáng (`rune_*.png`, tô màu theo hệ).
- Dùng skill: vòng phép xoay dưới chân + cột tia sáng + âm thanh cast. Sóng chấn động, tia, vòng skill cũng có thêm particle theo hệ.
- Nhận thẻ: vòng phép theo màu độ hiếm.
- Icon 16x16 cho từng skill (`textures/gui/skill/<thẻ>_<số>.png`) hiện trên HUD, thanh G-L và trong màn B.
- Hệ của từng skill: `fx/SkillFx.java`.
