# Wildcard Hỗn Loạn – Forge 1.20.1

Mod lấy cảm hứng từ ARAM Hỗn Loạn: cứ 6 phút mỗi người chơi được chọn 1 trong 3 thẻ wildcard.
Mỗi thẻ có 1 **LỢI ÍCH** và 1 **BẤT LỢI**, hiệu ứng vĩnh viễn và cộng dồn.

## Build file .jar

Cần JDK 17 (Temurin/Adoptium). Trong thư mục này chạy:

```
# Windows
gradlew.bat build
# macOS / Linux
./gradlew build
```

File mod nằm ở `build/libs/wildcard-chaos-1.20.1-1.0.0.jar`. Bỏ vào thư mục `mods` của Forge **1.20.1** (47.x).
Chạy thử trong môi trường dev: `gradlew runClient`.

Nếu đẩy lên GitHub, workflow `.github/workflows/build.yml` sẽ tự build và đính kèm file .jar vào mục Actions → Artifacts.

## Cách chơi

- Thanh boss bar trên cùng đếm ngược tới lượt chọn kế tiếp (6:00). Còn 10 giây có chuông báo.
- Hết giờ: màn hình 3 thẻ hiện ra. Click vào thẻ hoặc bấm **1 / 2 / 3** để chọn, **R** hoặc nút *Đổi bài* để đổi cả 3 thẻ.
- Trong lúc chọn bạn bất tử và mob quanh 16 khối đứng yên. Quá 30 giây sẽ tự chọn ngẫu nhiên.
- Chọn xong: hiệu ứng áp dụng ngay, có hạt và âm thanh theo màu độ hiếm, chat thông báo cả server.

| Phím (đổi được trong Options → Controls) | Kỹ năng |
| --- | --- |
| **V** | Lướt (Không phổ biến), Rồng Con (Huyền thoại) |
| **G** | Lưỡi Ếch, Bắn tơ (Người Nhện), Ngưng Đọng Thời Gian, kỹ năng cướp được (Đánh Cắp Kỹ Năng) |
| **B** | Ender Chest Bỏ Túi |
| Chuột phải tay không | Quạt Gió |
| Space trên không | Nhảy Kép |

## Luật roll

- Tỉ lệ mỗi thẻ: Phổ biến 40, Không phổ biến 28, Hiếm 18, Sử thi 10, Huyền thoại 4.
- Pity: 4 lượt liền không thấy Sử thi trở lên thì lượt sau chắc chắn có 1 thẻ Sử thi/Huyền thoại.
- Leo thang: từ lượt 6, mỗi lượt chuyển 2% từ Phổ biến sang Sử thi + Huyền thoại (Phổ biến tối thiểu 20%).
- Đổi bài: bắt đầu 1 lượt, cứ 3 lần chọn được thêm 1, giữ tối đa 2.
- 3 thẻ trong một lượt luôn khác nhau, không ra lại thẻ đã có, không ra thẻ xung đột nhãn với thẻ đã có
  (ví dụ Chân Thỏ / Nhảy Xa / Nhảy Kép cùng nhãn `jump`).
- Tất cả chỉnh được trong `config/wildcard-common.toml` (thời gian, tỉ lệ, pity, reroll, danh sách thẻ bị tắt).

## Lệnh (OP)

```
/wildcard list            xem thẻ đang có
/wildcard now             mở lượt chọn ngay
/wildcard timer <giây>    đặt thời gian tới lượt kế
/wildcard give <id>       nhận thẻ (id: c01..c20, u01..u20, r01..r20, e01..e20, l01..l20)
/wildcard remove <id>     bỏ thẻ
/wildcard clear           xóa toàn bộ và đặt lại
```

## Trạng thái 100 thẻ

Cả 100 thẻ đều có code. Các điểm còn khác so với bản thiết kế:

| Thẻ | Ghi chú |
| --- | --- |
| c08 Cần Thủ Câu Cá | Lợi ích (cá cắn câu nhanh hơn) **chưa làm**, Forge 1.20.1 không có event cho thời gian chờ cá. Bất lợi Mùi Tanh đã làm. |
| c12 Bước Nhẹ | Chỉ chống giẫm hỏng đất trồng, chưa chặn bàn đạp và Sculk Sensor. |
| r01 Khổng Lồ / To Xác | Có +4 HP và +1 tầm với. Phần phóng to người và hitbox (To Xác) **chưa làm**, cần thư viện Pehkui. |
| r10 Lò Lạnh | Bất lợi (lò nung chậm gấp đôi) **chưa làm**. |
| c07 Tiếng Gà | Phát tiếng gà khi bị đánh, nhưng tiếng người vẫn còn. |
| e14 Thuyền Trưởng | Thuyền tăng tốc, đi trên đất là gần đúng. |
| e17 Móc Câu | Bấm thu dây khi phao đã cắm vào khối để bị kéo tới. |
| l12 Cận Thị | "Mờ" là lớp phủ xám nhạt + sương mù gần. |
| l15 Thuần Hóa Tất Cả | Cưỡi được mọi mob nhưng không điều khiển được hướng đi. |
| r19 Phù Thủy Tập Sự | Mob ở vùng 4–8 khối nhận hiệu ứng với nửa thời lượng. |

## Cấu trúc mã

- `RoundManager` – đếm giờ, roll độ hiếm, pity, leo thang, đổi bài, áp thẻ, boss bar, bất tử khi chọn.
- `Cards` – danh sách 100 thẻ (độ hiếm, icon, nhãn xung đột). Chữ nằm trong `assets/wildcard/lang/vi_vn.json`.
- `WData` – dữ liệu lưu trong NBT người chơi (giữ qua chết và thoát game).
- `effects/` – `Effects` (hiệu ứng theo thời gian), `CombatEffects`, `WorldEffects`, `Abilities`.
- `client/WildcardScreen` – màn hình chọn thẻ; `client/ClientEvents` – camera, lớp phủ, X-Quang, di chuyển phía client.
