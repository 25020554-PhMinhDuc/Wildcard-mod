# Wildcard Hỗn Loạn – Forge 1.20.1

Mod lấy cảm hứng từ ARAM Hỗn Loạn: cứ 6 phút mỗi người chơi được chọn 1 trong 3 thẻ wildcard.
Mỗi thẻ có 1 **LỢI ÍCH** và 1 **BẤT LỢI**, hiệu ứng vĩnh viễn và cộng dồn.

## Build file .jar

Cần JDK 17 (Temurin/Adoptium). Trong thư mục này chạy:

```
# Windows
gradlew.bat build
# macOS / Linux
./gradlew build
```

File mod nằm ở `build/libs/wildcard-chaos-1.20.1-1.0.0.jar`. Bỏ vào thư mục `mods` của Forge **1.20.1** (47.x).
Chạy thử trong môi trường dev: `gradlew runClient`.

Nếu đẩy lên GitHub, workflow `.github/workflows/build.yml` sẽ tự build và đính kèm file .jar vào mục Actions → Artifacts.

## Cách chơi

- Thanh boss bar trên cùng đếm ngược tới lượt chọn kế tiếp (6:00). Còn 10 giây có chuông báo.
- Hết giờ: màn hình 3 thẻ hiện ra. Click vào thẻ hoặc bấm **1 / 2 / 3** để chọn. **Không có đổi bài.**
- Trong lúc chọn bạn bất tử và mob quanh 16 khối đứng yên. Quá 30 giây sẽ tự chọn ngẫu nhiên.
- Chọn xong: hiệu ứng áp dụng ngay, có hạt và âm thanh theo màu độ hiếm, chat thông báo cả server.
- Thẻ Hiếm trở lên có **kỹ năng** (Hiếm 1, Sử thi 2, Huyền thoại 3, Thần thoại 5). Rê chuột lên thẻ để xem mô tả và hồi chiêu.

| Phím (đổi được trong Options → Controls) | Chức năng |
| --- | --- |
| **G H J K L** | Kỹ năng 1–5 của thẻ đang dùng (góc phải dưới màn hình hiện ô kỹ năng và hồi chiêu) |
| **B** | Kho thẻ: xem mọi thẻ đã có; nhấn vào thẻ Hiếm trở lên để gắn kỹ năng của nó vào G H J K L |
| **N** | Ender Chest Bỏ Túi |
| Chuột phải tay không | Quạt Gió |
| Chạy nước rút + nhảy | Lướt |
| Space trên không | Nhảy Kép |

Thẻ có kỹ năng mới nhận sẽ tự thành thẻ đang dùng.

## Luật roll

- Mỗi ô trong 3 thẻ tự quay độ hiếm theo trọng số: Không phổ biến 67, Phổ biến 36, Hiếm 18, Sử thi 5, Huyền thoại 1, Thần thoại 0,1
  (tổng 127,1 nên tỉ lệ thật ≈ 52,7% / 28,3% / 14,2% / 3,9% / 0,8% / 0,08%).
- Pity và leo thang **tắt** để giữ đúng tỉ lệ trên (bật lại trong config: `pityRounds`, `escalateStep`).
- 3 thẻ trong một lượt luôn khác nhau, không ra lại thẻ đã có, không ra thẻ xung đột nhãn với thẻ đã có
  (ví dụ Chân Thỏ / Nhảy Xa / Nhảy Kép cùng nhãn `jump`). Hết thẻ ở độ hiếm đã quay thì lấy độ hiếm gần nhất.
- Tất cả chỉnh được trong `config/wildcard-common.toml` (thời gian, tỉ lệ, pity, danh sách thẻ bị tắt).

## Số thẻ

| Độ hiếm | Số thẻ | id |
| --- | --- | --- |
| Phổ biến (xám) | 40 | c01–c40 |
| Không phổ biến (xanh lá) | 60 | u01–u60 |
| Hiếm (xanh dương) | 25 | r01–r25 |
| Sử thi (tím) | 15 | e01–e08, e10–e13, e16, e18, e20 |
| Huyền thoại (vàng) | 5 | l01, l02, l04, l05, l20 |
| Thần thoại (đỏ) | 5 | m01 Huyết Tộc Cổ Đại, m02 Hiệp Sĩ Rồng, m03 Thần Thời Gian, m04 Đấng Tạo Hóa, m05 Chúa Tể Hư Không |

Mỗi người chỉ giữ **1 thẻ Thần thoại**. Thẻ Thần thoại khác vẫn có thể ra trong lượt chọn; chọn nó thì thẻ cũ bị thay
và bạn **mất vĩnh viễn 1 tim** (màn chọn thẻ ghi cảnh báo đỏ dưới thẻ đó).

## Lệnh (OP)

```
/wildcard list            xem thẻ đang có
/wildcard now             mở lượt chọn ngay
/wildcard timer <giây>    đặt thời gian tới lượt kế
/wildcard give <id>       nhận thẻ (id xem bảng Số thẻ)
/wildcard remove <id>     bỏ thẻ
/wildcard clear           xóa toàn bộ và đặt lại
```

## Trạng thái thẻ

Tất cả thẻ đều có code. Các điểm còn khác so với bản thiết kế:

| Thẻ | Ghi chú |
| --- | --- |
| c08 Cần Thủ Câu Cá | Lợi ích (cá cắn câu nhanh hơn) **chưa làm**, Forge 1.20.1 không có event cho thời gian chờ cá. Bất lợi Mùi Tanh đã làm. |
| c12 Bước Nhẹ | Chỉ chống giẫm hỏng đất trồng, chưa chặn bàn đạp và Sculk Sensor. |
| r01 Khổng Lồ / To Xác | Có +4 HP và +1 tầm với. Phần phóng to người và hitbox (To Xác) **chưa làm**, cần thư viện Pehkui. |
| r10 Lò Lạnh | Bất lợi (lò nung chậm gấp đôi) **chưa làm**. |
| c07 Tiếng Gà | Phát tiếng gà khi bị đánh, nhưng tiếng người vẫn còn. |
| r19 Phù Thủy Tập Sự | Mob ở vùng 4–8 khối nhận hiệu ứng với nửa thời lượng. |

## Cấu trúc mã

- `RoundManager` – đếm giờ, roll độ hiếm, pity, leo thang, áp thẻ, boss bar, bất tử khi chọn.
- `Cards` – danh sách thẻ (độ hiếm, icon, nhãn xung đột, hồi chiêu kỹ năng). Chữ nằm trong `assets/wildcard/lang/vi_vn.json`.
- `WData` – dữ liệu lưu trong NBT người chơi (giữ qua chết và thoát game).
- `effects/` – `Effects` (hiệu ứng theo thời gian), `CombatEffects`, `WorldEffects`, `NewCards` (thẻ c21+/u21+/r21+), `Skills` (kỹ năng G–L), `Abilities` (phím).
- `client/WildcardScreen` – màn hình chọn thẻ; `client/CardsScreen` – kho thẻ (B); `client/SkillHud` – ô kỹ năng; `client/CardArt` – vẽ thẻ; `client/ClientEvents` – camera, lớp phủ, X-Quang, di chuyển phía client.
