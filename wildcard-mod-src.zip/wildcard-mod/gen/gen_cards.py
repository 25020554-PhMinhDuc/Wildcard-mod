# Generates GenData.java + lang entries for the v3 card set.
import json, random, sys, os
R = random.Random(20261103)
ROOT = '/home/claude/wildcard-mod/src/main'
TIER = {'c': 0, 'u': 1, 'r': 2, 'e': 3, 'l': 4}
RAR = {'c': 'COMMON', 'u': 'UNCOMMON', 'r': 'RARE', 'e': 'EPIC', 'l': 'LEGENDARY'}
ROMAN = ['I', 'II', 'III', 'IV', 'V']

def pct(x): return f"{round(x*100)}%"
def num(x):
    return (f"{x:.1f}".rstrip('0').rstrip('.')).replace('.', ',')

COND = {'always': '', 'night': 'Ban đêm', 'day': 'Ban ngày', 'rain': 'Khi trời mưa', 'water': 'Khi ở trong nước',
        'nether': 'Ở Nether', 'deep': 'Dưới độ cao Y=0', 'high': 'Trên độ cao Y=100', 'dark': 'Ở chỗ tối',
        'sneak': 'Khi đang cúi', 'sprint': 'Khi chạy nước rút', 'lowhp': 'Khi máu dưới 40%', 'fullhp': 'Khi máu đầy',
        'armorless': 'Khi không mặc giáp', 'unarmed': 'Khi tay không', 'dayout': 'Ban ngày ngoài trời'}
EFF = {'speed': 'Tốc Độ', 'haste': 'Đào Nhanh', 'strength': 'Sức Mạnh', 'jump': 'Nhảy Cao', 'regen': 'Hồi Máu',
       'resistance': 'Kháng Cự', 'fire_res': 'Kháng Lửa', 'water_breath': 'Thở Dưới Nước', 'night_vision': 'Nhìn Đêm',
       'dolphin': 'Cá Heo', 'luck': 'May Mắn', 'slow_fall': 'Rơi Chậm', 'invis': 'Tàng Hình',
       'slowness': 'Chậm Chạp', 'fatigue': 'Đào Chậm', 'weakness': 'Yếu Ớt', 'hunger': 'Đói', 'glowing': 'Phát Sáng',
       'unluck': 'Xui Xẻo', 'blindness': 'Mù', 'nausea': 'Buồn Nôn', 'darkness': 'Bóng Tối', 'poison': 'Độc',
       'levitation': 'Bay Lơ Lửng'}
SRC = {'fall': 'khi rơi', 'fire': 'từ lửa', 'explosion': 'từ vụ nổ', 'projectile': 'từ tên và đạn', 'magic': 'từ phép thuật',
       'melee': 'cận chiến', 'drown': 'do đuối nước', 'freeze': 'do đóng băng'}
TGT = {'undead': 'mob xác sống', 'arthropod': 'nhện và côn trùng', 'illager': 'dân làng ác', 'water': 'mob dưới nước',
       'animal': 'động vật', 'all': 'mọi mục tiêu', 'player': 'người chơi khác'}

def effdesc(e, amp, cond, bad=False):
    c = COND[cond]
    base = f"{EFF[e]} {ROMAN[amp]}"
    return f"{c}: {base}" if c else f"{base} vĩnh viễn"

# ---------------------------------------------------------------- buffs (spec, desc)
def B(t):
    k = R.choice(['speed', 'maxhp', 'attack', 'armor', 'toughness', 'luck', 'kbres', 'atkspeed', 'reach', 'swim',
                  'eff', 'eff', 'eff', 'inc', 'inc', 'out', 'out', 'killheal', 'killxp', 'killfood', 'minexp',
                  'minehaste', 'regen', 'food', 'exh', 'xp'])
    if k == 'speed': v = [.06, .1, .15, .2, .3][t]; return k, f"attr:speed:{v}", f"Tốc chạy +{pct(v)}"
    if k == 'maxhp': v = [2, 4, 6, 8, 10][t]; return k, f"attr:maxhp:{v}", f"Máu tối đa +{v//2} tim"
    if k == 'attack': v = [1, 1.5, 2, 3, 4][t]; return k, f"attr:attack:{v}", f"Sát thương cận chiến +{num(v)}"
    if k == 'armor': v = [2, 3, 4, 6, 8][t]; return k, f"attr:armor:{v}", f"Giáp +{v}"
    if k == 'toughness': v = [1, 2, 3, 4, 5][t]; return k, f"attr:toughness:{v}", f"Độ cứng giáp +{v}"
    if k == 'luck': v = [1, 2, 3, 4, 5][t]; return k, f"attr:luck:{v}", f"May Mắn +{v} (rương và câu cá tốt hơn)"
    if k == 'kbres': v = [.2, .3, .5, .7, 1][t]; return k, f"attr:kbres:{v}", f"Kháng đẩy lùi {pct(v)}"
    if k == 'atkspeed': v = [.1, .15, .2, .3, .4][t]; return k, f"attr:atkspeed:{v}", f"Tốc đánh +{pct(v)}"
    if k == 'reach': v = [.5, 1, 1.5, 2, 3][t]; return k, f"attr:reach:{v}", f"Tầm với +{num(v)} khối"
    if k == 'swim': v = [.3, .5, .7, 1, 1.5][t]; return k, f"attr:swim:{v}", f"Bơi nhanh hơn {pct(v)}"
    if k == 'eff':
        pairs = [('night_vision', 'dark'), ('speed', 'day'), ('speed', 'rain'), ('haste', 'deep'), ('strength', 'night'),
                 ('resistance', 'lowhp'), ('fire_res', 'nether'), ('water_breath', 'water'), ('dolphin', 'water'),
                 ('jump', 'always'), ('slow_fall', 'sneak'), ('strength', 'lowhp'), ('speed', 'sprint'), ('luck', 'always'),
                 ('haste', 'dayout'), ('speed', 'night'), ('resistance', 'night'), ('strength', 'unarmed'), ('speed', 'armorless')]
        if t >= 2: pairs += [('regen', 'lowhp'), ('invis', 'sneak'), ('haste', 'always'), ('strength', 'fullhp'), ('resistance', 'armorless')]
        e, c = R.choice(pairs)
        amp = 1 if t >= 3 and e in ('speed', 'haste', 'strength', 'jump', 'resistance') else 0
        if t == 4 and e in ('speed', 'haste', 'jump'): amp = 2
        return 'eff_' + e, f"eff:{e}:{amp}:{c}", effdesc(e, amp, c)
    if k == 'inc':
        s = R.choice(list(SRC)); m = [.8, .7, .55, .4, .25][t]
        return 'inc', f"inc:{s}:{m}", f"Giảm {pct(1-m)} sát thương {SRC[s]}"
    if k == 'out':
        tg = R.choice(list(TGT)); m = ([1.06, 1.1, 1.15, 1.2, 1.3] if tg == 'all' else [1.25, 1.35, 1.5, 1.75, 2])[t]
        return 'out', f"out:{tg}:{m}", f"+{pct(m-1)} sát thương lên {TGT[tg]}"
    if k == 'killheal': v = [1, 1.5, 2, 3, 4][t]; return k, f"kill:heal:{v}", f"Hạ mob: hồi {num(v)} máu"
    if k == 'killxp': v = [2, 3, 5, 7, 10][t]; return k, f"kill:xp:{v}", f"Hạ mob: thêm {v} XP"
    if k == 'killfood': v = [1, 2, 3, 4, 5][t]; return k, f"kill:food:{v}", f"Hạ mob: hồi {v} điểm đói"
    if k == 'minexp': v = [10, 15, 20, 30, 40][t]; return k, f"mine:xp:{v}", f"Đào khối: {v}% rơi thêm XP"
    if k == 'minehaste': a = 1 if t >= 3 else 0; return k, f"mine:haste:{a}", f"Đào đá: Đào Nhanh {ROMAN[a]} trong 3 giây"
    if k == 'regen': v = [20, 15, 10, 8, 5][t]; return k, f"regen:{v}", f"Cứ {v} giây hồi 1 máu"
    if k == 'food': v = [1, 2, 3, 4, 5][t]; return k, f"food:{v}", f"Ăn gì cũng thêm {v} điểm đói"
    if k == 'exh': v = [.85, .75, .6, .5, .4][t]; return k, f"exh:{v}", f"Tốn đói ít hơn {pct(1-v)}"
    v = [1.15, 1.25, 1.4, 1.6, 2][t]; return 'xp', f"xp:{v}", f"XP nhận được +{pct(v-1)}"

TROLLS = ['t%02d' % i for i in range(1, 26)]
TROLLS_NOT_FOR_GEN = {'t21'}  # floating hotbar is the special card's thing

def D(t):
    k = R.choice(['speed', 'maxhp', 'attack', 'armor', 'luck', 'atkspeed', 'reach', 'eff', 'eff', 'eff', 'inc', 'inc',
                  'incall', 'out', 'killhurt', 'killhunger', 'minehurt', 'drain', 'food', 'exh', 'xp', 'troll', 'troll'])
    if k == 'speed': v = [.08, .12, .18, .22, .3][t]; return k, f"attr:speed:-{v}", f"Tốc chạy -{pct(v)}"
    if k == 'maxhp': v = [2, 3, 4, 6, 8][t]; return k, f"attr:maxhp:-{v}", f"Máu tối đa -{num(v/2)} tim"
    if k == 'attack': v = [1, 1.5, 2, 2.5, 3][t]; return k, f"attr:attack:-{v}", f"Sát thương cận chiến -{num(v)}"
    if k == 'armor': v = [2, 3, 4, 5, 6][t]; return k, f"attr:armor:-{v}", f"Giáp -{v}"
    if k == 'luck': v = [1, 2, 3, 4, 5][t]; return k, f"attr:luck:-{v}", f"Xui Xẻo: May Mắn -{v}"
    if k == 'atkspeed': v = [.1, .15, .2, .25, .3][t]; return k, f"attr:atkspeed:-{v}", f"Tốc đánh -{pct(v)}"
    if k == 'reach': v = [.5, .75, 1, 1.25, 1.5][t]; return k, f"attr:reach:-{v}", f"Tầm với -{num(v)} khối"
    if k == 'eff':
        pairs = [('slowness', 'night'), ('slowness', 'rain'), ('slowness', 'water'), ('fatigue', 'deep'), ('fatigue', 'day'),
                 ('weakness', 'day'), ('weakness', 'night'), ('weakness', 'rain'), ('weakness', 'fullhp'), ('hunger', 'water'),
                 ('hunger', 'sprint'), ('hunger', 'rain'), ('glowing', 'always'), ('unluck', 'always'), ('blindness', 'rain'),
                 ('nausea', 'lowhp'), ('darkness', 'deep'), ('slowness', 'sneak'), ('weakness', 'unarmed'), ('slowness', 'dayout')]
        if t >= 2: pairs += [('fatigue', 'always'), ('weakness', 'always'), ('slowness', 'day'), ('poison', 'lowhp'), ('blindness', 'night')]
        e, c = R.choice(pairs)
        amp = 1 if t >= 3 and e in ('slowness', 'fatigue', 'weakness', 'hunger') else 0
        return 'eff_' + e, f"eff:{e}:{amp}:{c}", effdesc(e, amp, c, True)
    if k == 'inc':
        s = R.choice(list(SRC)); m = [1.25, 1.35, 1.5, 1.75, 2][t]
        return 'inc', f"inc:{s}:{m}", f"Nhận thêm {pct(m-1)} sát thương {SRC[s]}"
    if k == 'incall': m = [1.1, 1.15, 1.2, 1.25, 1.35][t]; return k, f"inc:all:{m}", f"Nhận thêm {pct(m-1)} mọi sát thương"
    if k == 'out':
        tg = R.choice(list(TGT)); m = ([.9, .85, .8, .75, .7] if tg == 'all' else [.7, .6, .5, .4, .3])[t]
        return 'out', f"out:{tg}:{m}", f"-{pct(1-m)} sát thương lên {TGT[tg]}"
    if k == 'killhurt': v = [1, 1.5, 2, 3, 4][t]; return k, f"kill:hurt:{v}", f"Hạ mob: tự mất {num(v)} máu"
    if k == 'killhunger': v = [1, 2, 3, 4, 5][t]; return k, f"kill:hunger:{v}", f"Hạ mob: mất {v} điểm đói"
    if k == 'minehurt': v = [5, 8, 10, 12, 15][t]; return k, f"mine:hurt:{v}", f"Đào khối: {v}% bị đá văng vào mặt (mất 1 máu)"
    if k == 'drain': v = [60, 45, 35, 25, 20][t]; return k, f"drain:{v}", f"Cứ {v} giây mất 1 máu (không chết vì cái này)"
    if k == 'food': v = [1, 1, 2, 2, 3][t]; return k, f"food:-{v}", f"Ăn gì cũng bớt {v} điểm đói"
    if k == 'exh': v = [1.3, 1.5, 1.75, 2, 2.5][t]; return k, f"exh:{v}", f"Tốn đói gấp {num(v)} lần"
    if k == 'xp': v = [.85, .75, .6, .5, .4][t]; return k, f"xp:{v}", f"XP nhận được -{pct(1-v)}"
    tid = R.choice([x for x in TROLLS if x not in TROLLS_NOT_FOR_GEN])
    return 'troll', f"troll:{tid}", None  # text comes from the troll itself

# ---------------------------------------------------------------- names and icons
BUFF_NAMES = {
 'speed': ['Chân Sáo', 'Dép Tổ Ong', 'Gió Lốc', 'Chạy Deadline', 'Tia Chớp Nhỏ', 'Shipper Hỏa Tốc'],
 'maxhp': ['Da Dày', 'Cơm Mẹ Nấu', 'Khỏe Như Trâu', 'Tim Thép', 'Thể Lực Gym'],
 'attack': ['Tay To', 'Cú Đấm Thép', 'Bàn Tay Vàng', 'Đấm Phát Chết Luôn', 'Cơ Bắp'],
 'armor': ['Áo Giáp Tre', 'Da Cá Sấu', 'Vỏ Rùa', 'Chống Đạn'],
 'toughness': ['Cứng Cáp', 'Lì Đòn', 'Xương Sắt'],
 'luck': ['Ăn Hên', 'Nhân Phẩm Cao', 'Bùa May', 'Cỏ Bốn Lá'],
 'kbres': ['Chân Bám Đất', 'Nặng Ký', 'Trụ Cột'],
 'atkspeed': ['Tay Nhanh', 'APM Cao', 'Spam Click'],
 'reach': ['Tay Dài', 'Gậy Như Ý', 'Với Tới Trời'],
 'swim': ['Kình Ngư', 'Vây Cá', 'Người Cá'],
 'inc': ['Da Mặt Dày', 'Miễn Nhiễm', 'Lì Lợm', 'Không Đau'],
 'out': ['Khắc Tinh', 'Săn Quái', 'Đồ Tể', 'Chuyên Gia'],
 'killheal': ['Hút Hồn', 'Ăn Mừng', 'Tiếp Sức'],
 'killxp': ['Cày Cuốc', 'Thu Hoạch', 'Farm Thủ'],
 'killfood': ['Ăn Tại Chỗ', 'Bữa Chiến Thắng'],
 'minexp': ['Thợ Mỏ Chăm', 'Đào Vàng'],
 'minehaste': ['Hăng Say', 'Cuốc Thần'],
 'regen': ['Tự Lành', 'Ngủ Ngon', 'Thuốc Bổ'],
 'food': ['Ăn Khỏe', 'Bụng Bự', 'Ăn No Lâu'],
 'exh': ['Tiết Kiệm', 'Ít Calo', 'Sống Khỏe'],
 'xp': ['Học Bá', 'Chăm Học', 'Đọc Sách'],
}
EFF_BUFF_NAMES = {'night_vision': ['Mắt Mèo', 'Đèn Pin'], 'speed': ['Nhanh Như Gió', 'Tăng Tốc'], 'haste': ['Cuốc Nhanh', 'Tay Máy'],
 'strength': ['Cuồng Nộ', 'Hổ Báo'], 'resistance': ['Gồng Mình', 'Lì Như Đá'], 'fire_res': ['Quen Nóng', 'Da Chịu Nhiệt'],
 'water_breath': ['Mang Cá', 'Lặn Sâu'], 'dolphin': ['Cá Heo', 'Lướt Sóng'], 'jump': ['Lò Xo', 'Chân Ếch'],
 'slow_fall': ['Lông Ngỗng', 'Dù Lượn'], 'luck': ['Cầu Được Ước Thấy', 'Số Hưởng'], 'regen': ['Hồi Phục', 'Bất Khuất'],
 'invis': ['Ninja Lead', 'Biến Mất'], }
DEBUFF_NAMES = ['Còn Cái Nịt', 'Toang', 'Bruh', 'Ét O Ét', 'Hết Cứu', 'Ohio', 'Ao Trình', 'Gánh Còng Lưng', 'Phông Bạt',
 'Xu Cà Na', 'Ủa Alo', 'Báo Thủ', 'Tới Công Chuyện', 'Khóc Thét', 'Lag Như Mạng Nhà', 'Ping 999', 'Tạch', 'Cay',
 'Gà Mờ', 'Noob', 'Mất Gốc', 'Hack Não', 'Not Stonks', 'Sus', 'Bị Report', 'Afk', 'Rớt Mạng', 'Quên Mật Khẩu',
 'Đen Thôi Đỏ Quên Đi', 'Trầm Cảm', 'Thứ Hai Đầu Tuần', 'Deadline Dí', 'Cháy Túi', 'Sập Nguồn', 'Màn Hình Xanh',
 'Pin Yếu', 'Hết 4G', 'Bug Game', 'Lỗi 404', 'Tay Run', 'Mắt Kém', 'Chân Ngắn', 'Ngủ Gật', 'Say Xỉn', 'Lười Biếng',
 'Ăn Vạ', 'Hậu Đậu', 'Đãng Trí', 'Vụng Về', 'Mắc Mưa', 'Tụt Mood', 'Sợ Ma', 'Tóc Bết', 'Nợ Môn', 'Bị Bùng Kèo',
 'Mất Wifi', 'Spam Tin Nhắn', 'Bị Seen', 'Cú Đêm', 'Đau Lưng', 'Đau Răng', 'Cảm Cúm', 'Dị Ứng', 'Ế Bền Vững']
MEME_BUFF = ['Đỉnh Nóc Kịch Trần', 'Sigma', 'Gigachad', 'Stonks', 'Chill Guy', 'Pro Player', 'Flex Nhẹ', 'Bình Tĩnh Tự Tin',
 'Doge', 'Out Trình', 'Main Character', 'Hảo Hán', 'Đẹp Trai Có Gì Sai', 'Cân Team', 'Đu Trend', 'Hệ Tâm Linh',
 'Giàu Vì Bạn', 'Mãi Đỉnh', 'Tuổi Trẻ Tài Cao', 'Tâm Lý Vững', 'Rich Kid', 'Thánh Lầy', 'Vua Lì Đòn', 'Siêu Nhân Gao']
BUFF_ICON = {'speed': 'SUGAR', 'maxhp': 'GOLDEN_APPLE', 'attack': 'IRON_SWORD', 'armor': 'IRON_CHESTPLATE', 'toughness': 'DIAMOND_CHESTPLATE',
 'luck': 'RABBIT_FOOT', 'kbres': 'IRON_BLOCK', 'atkspeed': 'GOLDEN_SWORD', 'reach': 'STICK', 'swim': 'HEART_OF_THE_SEA', 'inc': 'SHIELD',
 'out': 'DIAMOND_SWORD', 'killheal': 'GLISTERING_MELON_SLICE', 'killxp': 'EXPERIENCE_BOTTLE', 'killfood': 'COOKED_BEEF',
 'minexp': 'IRON_PICKAXE', 'minehaste': 'DIAMOND_PICKAXE', 'regen': 'GOLDEN_CARROT', 'food': 'BREAD', 'exh': 'HONEY_BOTTLE', 'xp': 'ENCHANTED_BOOK'}
EFF_ICON = {'night_vision': 'GOLDEN_CARROT', 'speed': 'FEATHER', 'haste': 'GOLDEN_HELMET', 'strength': 'BLAZE_POWDER', 'resistance': 'TURTLE_HELMET',
 'fire_res': 'MAGMA_CREAM', 'water_breath': 'PUFFERFISH', 'dolphin': 'NAUTILUS_SHELL', 'jump': 'RABBIT_FOOT', 'slow_fall': 'PHANTOM_MEMBRANE',
 'luck': 'EMERALD', 'regen': 'GHAST_TEAR', 'invis': 'FERMENTED_SPIDER_EYE',
 'slowness': 'COBWEB', 'fatigue': 'WOODEN_AXE', 'weakness': 'FERMENTED_SPIDER_EYE', 'hunger': 'ROTTEN_FLESH', 'glowing': 'GLOWSTONE_DUST',
 'unluck': 'BLACK_CANDLE', 'blindness': 'INK_SAC', 'nausea': 'PUFFERFISH', 'darkness': 'SCULK_SHRIEKER', 'poison': 'SPIDER_EYE'}
DEBUFF_ICON = {'speed': 'COBWEB', 'maxhp': 'POISONOUS_POTATO', 'attack': 'WOODEN_SWORD', 'armor': 'LEATHER_CHESTPLATE', 'luck': 'BLACK_CANDLE',
 'atkspeed': 'SLIME_BALL', 'reach': 'DEAD_BUSH', 'inc': 'CHIPPED_ANVIL', 'incall': 'ANVIL', 'out': 'STICK', 'killhurt': 'WITHER_ROSE',
 'killhunger': 'BOWL', 'minehurt': 'GRAVEL', 'drain': 'REDSTONE', 'food': 'POISONOUS_POTATO', 'exh': 'ROTTEN_FLESH', 'xp': 'GLASS_BOTTLE',
 'troll': 'NOTE_BLOCK'}

used = {}
def uniq(name):
    n = used.get(name, 0); used[name] = n + 1
    return name if n == 0 else f"{name} {ROMAN[min(n, 4)]}"

# ---------------------------------------------------------------- skills
ELW = {'fire': 'Lửa', 'frost': 'Băng', 'storm': 'Sét', 'blood': 'Máu', 'void': 'Hư Không', 'holy': 'Thánh', 'earth': 'Đất', 'wind': 'Gió', 'arcane': 'Bí Thuật'}
KINDS = {  # kind: (weight, elements, name words)
 'bolt': (6, ['fire', 'frost', 'storm', 'void', 'arcane', 'blood'], ['Tia', 'Mũi', 'Đạn']),
 'nova': (5, ['earth', 'wind', 'fire', 'frost', 'storm', 'holy'], ['Sóng', 'Vòng', 'Chấn']),
 'heal': (3, ['holy', 'blood'], ['Hồi', 'Chữa Lành']),
 'buff': (4, ['holy', 'arcane', 'wind', 'fire', 'earth', 'blood'], ['Cường Hóa', 'Khí']),
 'curse': (3, ['void', 'frost', 'arcane', 'blood'], ['Nguyền', 'Lời Rủa']),
 'dash': (3, ['wind', 'storm', 'fire'], ['Lướt', 'Phóng']),
 'leap': (2, ['wind', 'earth'], ['Bật', 'Nhảy']),
 'blink': (2, ['void', 'arcane'], ['Bước', 'Dịch Chuyển']),
 'shield': (3, ['holy', 'earth', 'frost'], ['Khiên', 'Giáp']),
 'feast': (1, ['earth', 'holy'], ['Bữa Tiệc', 'Mâm Cơm']),
 'summon': (1, ['earth'], ['Gọi Sói']),
 'meteor': (2, ['fire'], ['Mưa', 'Cầu']),
 'pull': (2, ['void', 'storm', 'wind'], ['Hút', 'Kéo']),
 'taunt': (1, ['storm'], ['Vine Boom', 'Gáy To', 'Khiêu Khích']),
 'sigma': (1, ['arcane'], ['Ánh Nhìn Sigma', 'Lườm Cháy Mặt']),
 'sus': (1, ['void'], ['Kẻ Giả Mạo', 'Sus']),
}
BUFF_SK = ['speed', 'strength', 'resistance', 'haste', 'jump']
CURSE_SK = ['slowness', 'weakness', 'glowing']
def skill(t):
    kinds = list(KINDS); w = [KINDS[k][0] for k in kinds]
    k = R.choices(kinds, w)[0]
    el = R.choice(KINDS[k][1])
    words = KINDS[k][2]
    w0 = R.choice(words)
    name = w0 if k in ('summon', 'taunt', 'sigma', 'sus') else f"{w0} {ELW[el]}"
    a = b = 0; eff = ''; amp = 0
    if k == 'bolt':
        a = [3, 4, 6, 8, 11][t]; b = [12, 16, 20, 24, 28][t]; cd = [20, 18, 15, 14, 12][t]
        eff = {'fire': 'fire', 'frost': 'slowness', 'storm': 'glowing', 'void': 'weakness', 'arcane': 'glowing', 'blood': 'lifesteal'}[el]
        extra = {'fire': ', đốt 4 giây', 'slowness': ', làm chậm 3 giây', 'glowing': ', mục tiêu phát sáng 6 giây', 'weakness': ', gây Yếu Ớt 4 giây', 'lifesteal': ', hút 30% thành máu'}[eff]
        desc = f"Bắn vào mục tiêu đang nhìn trong {b} khối: {num(a)} sát thương{extra}"
    elif k == 'nova':
        a = [2, 3, 5, 7, 9][t]; b = [3, 4, 4.5, 5, 6][t]; cd = [30, 25, 22, 20, 18][t]
        desc = f"Sóng phép quanh {num(b)} khối: {num(a)} sát thương và hất văng"
    elif k == 'heal':
        a = [3, 4, 6, 8, 10][t]; cd = [45, 40, 35, 30, 30][t]; desc = f"Hồi ngay {num(a)} máu"
    elif k == 'buff':
        eff = R.choice(BUFF_SK); amp = 1 if t >= 3 else 0; b = [6, 8, 10, 12, 15][t]; cd = [45, 40, 35, 30, 30][t]
        desc = f"Bản thân nhận {EFF[eff]} {ROMAN[amp]} trong {b} giây"
    elif k == 'curse':
        eff = R.choice(CURSE_SK + (['poison'] if t >= 2 else []) + (['levitation'] if t >= 3 else [])); amp = 1 if t >= 3 else 0
        b = [4, 5, 6, 8, 10][t]; a = 6; cd = [35, 30, 28, 25, 22][t]
        desc = f"Kẻ địch trong 6 khối bị {EFF[eff]} {ROMAN[amp]} trong {b} giây"
    elif k == 'dash':
        a = [1.2, 1.4, 1.7, 2, 2.4][t]; cd = [12, 10, 9, 8, 7][t]; desc = "Lướt nhanh về phía trước"
    elif k == 'leap':
        a = [.8, 1, 1.2, 1.4, 1.7][t]; cd = [15, 13, 11, 10, 8][t]; desc = "Bật lên cao, không mất máu khi rơi"
    elif k == 'blink':
        a = [5, 7, 9, 12, 16][t]; cd = [25, 22, 18, 15, 12][t]; desc = f"Dịch chuyển tới {int(a)} khối theo hướng nhìn"
    elif k == 'shield':
        amp = [0, 0, 1, 2, 3][t]; b = 10; cd = [50, 45, 40, 35, 30][t]; desc = f"Nhận khiên Hấp Thụ {ROMAN[amp]} trong 10 giây"
    elif k == 'feast':
        a = [3, 4, 6, 8, 10][t]; cd = [90, 80, 70, 60, 50][t]; desc = f"Hồi {int(a)} điểm đói và no lâu"
    elif k == 'summon':
        a = [1, 1, 2, 2, 3][t]; cd = [120, 100, 90, 80, 70][t]; desc = f"Gọi {int(a)} sói chiến đấu cùng bạn 20 giây"
    elif k == 'meteor':
        a = [1, 1, 2, 3, 4][t]; cd = [25, 22, 20, 18, 15][t]; desc = f"Bắn {int(a)} cầu lửa theo hướng nhìn"
    elif k == 'pull':
        b = [5, 6, 7, 8, 10][t]; cd = [20, 18, 16, 14, 12][t]; desc = f"Kéo kẻ địch trong {b} khối về phía bạn"
    elif k == 'taunt':
        amp = [0, 0, 1, 1, 2][t]; cd = 40; desc = f"BOOM! Mọi mob trong 10 khối lao vào bạn, bạn được Kháng Cự {ROMAN[amp]} 5 giây"
    elif k == 'sigma':
        amp = 1 if t >= 3 else 0; cd = 30; desc = f"Lườm mục tiêu trong 16 khối: Yếu Ớt {ROMAN[amp]}, Chậm và Phát Sáng 8 giây"
    else:  # sus
        cd = 45; desc = "Tàng hình 6 giây, mob quanh bạn mất dấu"
    return dict(kind=k, el=el, a=a, b=b, eff=eff, amp=amp, cd=cd, name=name, desc=desc)

# ---------------------------------------------------------------- cards
lang = {}
java = []
gen_skills = {}
def ids(p, a, b): return [f"{p}{i:02d}" if i < 100 else f"{p}{i}" for i in range(a, b + 1)]
SPECIAL = {'u61', 'u62', 'u63', 'u64'}
NEW = ids('c', 41, 150) + ids('u', 61, 200) + ids('r', 26, 50) + ids('e', 21, 30) + ids('l', 21, 25)
meme_ids = set()
for cid in NEW:
    if cid in SPECIAL: continue
    t = TIER[cid[0]]
    nb = 1 if t < 2 else (2 if t < 4 else 3)
    nd = 1 if t < 2 else (2 if t < 4 else 3)
    buffs, bkeys = [], []
    while len(buffs) < nb:
        k, s, d = B(t)
        if k in bkeys or any(s.split(':')[:2] == x.split(':')[:2] for x, _ in buffs): continue
        buffs.append((s, d)); bkeys.append(k)
    debs, dkeys = [], []
    while len(debs) < nd:
        k, s, d = D(t)
        if k in dkeys and k != 'troll': continue
        if any(s == x for x, _ in debs): continue
        debs.append((s, d)); dkeys.append(k)
    meme = R.random() < 0.4 or 'troll' in dkeys
    k0 = bkeys[0]
    if meme:
        bn = uniq(R.choice(MEME_BUFF)); dn = uniq(R.choice(DEBUFF_NAMES)); meme_ids.add(cid)
    else:
        pool = EFF_BUFF_NAMES.get(k0[4:]) if k0.startswith('eff_') else BUFF_NAMES.get(k0)
        bn = uniq(R.choice(pool or ['Phúc Lợi'])); dn = uniq(R.choice(DEBUFF_NAMES))
    bicon = EFF_ICON.get(k0[4:], 'NETHER_STAR') if k0.startswith('eff_') else BUFF_ICON.get(k0, 'NETHER_STAR')
    d0 = dkeys[0]
    dicon = EFF_ICON.get(d0[4:], 'ROTTEN_FLESH') if d0.startswith('eff_') else DEBUFF_ICON.get(d0, 'ROTTEN_FLESH')
    lang[f"card.wildcard.{cid}.buff"] = bn
    lang[f"card.wildcard.{cid}.buff.desc"] = '. '.join(d for _, d in buffs)
    lang[f"card.wildcard.{cid}.debuff"] = dn
    dd = [d for _, d in debs if d]
    trolls = [s.split(':')[1] for s, d in debs if d is None]
    lang[f"card.wildcard.{cid}.debuff.desc"] = '. '.join(dd) if dd else 'Xem danh sách troll bên dưới'
    bj = ', '.join(f'"{s}"' for s, _ in buffs); dj = ', '.join(f'"{s}"' for s, _ in debs)
    java.append(f'        card("{cid}", {RAR[cid[0]]}, Items.{bicon}, Items.{dicon}, {str(meme).lower()}, new String[]{{{bj}}}, new String[]{{{dj}}});')

# skills: every card without a hand-made skill
HAND = set(ids('r', 1, 25)) | {f"e{i:02d}" for i in (1,2,3,4,5,6,7,8,10,11,12,13,16,18,20)} | {'l01','l02','l04','l05','l20','m01','m02','m03','m04','m05'} | SPECIAL
ALLSK = ids('c', 1, 150) + ids('u', 1, 200) + ids('r', 1, 50) + ids('e', 21, 30) + ids('l', 21, 25)
for cid in ALLSK:
    if cid in HAND: continue
    s = skill(TIER[cid[0]])
    gen_skills[cid] = s
    lang[f"skill.wildcard.{cid}.0"] = s['name']
    lang[f"skill.wildcard.{cid}.0.desc"] = s['desc']
    java.append(f'        skill("{cid}", "{s["kind"]}", "{s["el"]}", {s["a"]}, {s["b"]}, "{s["eff"]}", {s["amp"]}, {s["cd"]});')

src = '''package com.hoang.wildcard;

import net.minecraft.world.item.Items;

import static com.hoang.wildcard.Cards.card;
import static com.hoang.wildcard.Cards.skill;
import static com.hoang.wildcard.Rarity.*;

/** GENERATED by gen_cards.py: data-driven cards (c41+, u61+, r26+, e21+, l21+) and generated skills. Do not edit by hand. */
final class GenData {
    static void load() {
''' + '\n'.join(java[:len(java)//2]) + '''
        load2();
    }

    private static void load2() {
''' + '\n'.join(java[len(java)//2:]) + '''
    }

    private GenData() {}
}
'''
open(f'{ROOT}/java/com/hoang/wildcard/GenData.java', 'w').write(src)
json.dump(lang, open('/home/claude/gen/lang_gen.json', 'w'), ensure_ascii=False, indent=1)
json.dump({k: v for k, v in gen_skills.items()}, open('/home/claude/gen/skills_gen.json', 'w'), ensure_ascii=False)
json.dump(sorted(meme_ids), open('/home/claude/gen/meme_ids.json', 'w'))
print(len(NEW), 'new cards,', len(gen_skills), 'generated skills,', len(meme_ids), 'meme cards')
