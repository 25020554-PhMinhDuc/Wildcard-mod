"""v7.2: thay các bất lợi mất điểm thức ăn (food:-N, kill:hunger:N, exh>1, eff:hunger) bằng bất lợi khác."""
import json, re, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = os.path.join(ROOT, 'src/main/java/com/hoang/wildcard')
LANGS = [os.path.join(ROOT, 'src/main/resources/assets/wildcard/lang', f) for f in ('vi_vn.json', 'en_us.json')]
def num(x): return (f"{x:.2f}".rstrip('0').rstrip('.')).replace('.', ',')
def pct(x): return f"{round(x*100)}%"
TIER = {'c': 0, 'u': 1, 'r': 2, 'e': 3, 'l': 4, 'm': 4}

def old_text(spec):
    a = spec.split(':')
    if a[0] == 'food': return f"Ăn gì cũng bớt {-int(float(a[1]))} điểm đói"
    if a[:2] == ['kill', 'hunger']: return f"Hạ mob: mất {int(float(a[2]))} điểm đói"
    if a[0] == 'exh': return f"Tốn đói gấp {num(float(a[1]))} lần"
def bad(spec):
    a = spec.split(':')
    return (a[0] == 'food' and float(a[1]) < 0) or a[:2] == ['kill', 'hunger'] or (a[0] == 'exh' and float(a[1]) > 1)
def fam(spec):
    a = spec.split(':')
    if a[0] in ('attr', 'kill', 'mine'): return a[0] + a[1]
    if a[0] == 'inc' and a[1] == 'all': return 'incall'
    if a[0] == 'inc': return 'inc' + a[1]
    if a[0] == 'out': return 'out' + a[1]
    if a[0] == 'eff': return 'eff' + a[1]
    return a[0]
def D(k, t):
    if k == 'xp': v = [.85, .75, .6, .5, .4][t]; return f"xp:{v}", f"XP nhận được -{pct(1-v)}"
    if k == 'attratkspeed': v = [.1, .15, .2, .25, .3][t]; return f"attr:atkspeed:-{v}", f"Tốc đánh -{pct(v)}"
    if k == 'attrreach': v = [.5, .75, 1, 1.25, 1.5][t]; return f"attr:reach:-{v}", f"Tầm với -{num(v)} khối"
    if k == 'attrluck': v = [1, 2, 3, 4, 5][t]; return f"attr:luck:-{v}", f"Xui Xẻo: May Mắn -{v}"
    if k == 'attrarmor': v = [2, 3, 4, 5, 6][t]; return f"attr:armor:-{v}", f"Giáp -{v}"
    if k == 'attrspeed': v = [.08, .12, .18, .22, .3][t]; return f"attr:speed:-{v}", f"Tốc chạy -{pct(v)}"
    if k == 'attrattack': v = [1, 1.5, 2, 2.5, 3][t]; return f"attr:attack:-{v}", f"Sát thương cận chiến -{num(v)}"
    if k == 'incfall': m = [1.25, 1.35, 1.5, 1.75, 2][t]; return f"inc:fall:{m}", f"Nhận thêm {pct(m-1)} sát thương khi rơi"
    if k == 'outall': m = [.9, .85, .8, .75, .7][t]; return f"out:all:{m}", f"-{pct(1-m)} sát thương lên mọi mục tiêu"
    if k == 'effslowness': return "eff:slowness:0:night", "Ban đêm: Chậm Chạp I"
ORDER = ['xp', 'attrreach', 'attrluck', 'attratkspeed', 'incfall', 'attrarmor', 'attrspeed', 'outall', 'attrattack', 'effslowness']
NAMES = {'xp': ['Học Chậm', 'Não Cá Vàng', 'Hay Quên', 'Lơ Đãng', 'Mất Tập Trung', 'Ngủ Gật', 'Trí Nhớ Ngắn'],
         'attratkspeed': ['Tay Mỏi', 'Tay Run Run', 'Cổ Tay Đau', 'Vung Chậm', 'Tay Lười', 'Khuỷu Tay Cứng', 'Vai Nhức'],
         'attrreach': ['Tay Ngắn', 'Tay Khủng Long', 'Với Không Tới', 'Cánh Tay Cụt', 'Tay Ngắn Tũn', 'Ngắn Tay', 'Với Hụt'],
         'attrattack': ['Đấm Yếu', 'Tay Bông', 'Nắm Đấm Mềm', 'Đấm Như Gãi', 'Lực Tay Yếu', 'Đánh Như Muỗi', 'Cú Đấm Bông'],
         'attrluck': ['Đen Đủi', 'Số Nhọ', 'Xui Tận Mạng', 'Mèo Đen Ngang Đường', 'Sao Quả Tạ', 'Gương Vỡ', 'Thứ Sáu 13'],
         'attrarmor': ['Giáp Rỉ', 'Áo Rách', 'Giáp Giấy', 'Áo Mỏng', 'Khóa Giáp Lỏng', 'Giáp Thủng', 'Áo Mưa Rách'],
         'attrspeed': ['Chân Nặng', 'Dép Tổ Ong', 'Chậm Như Sên', 'Chân Chì', 'Lết Bộ', 'Giày Chật', 'Chuột Rút'],
         'incfall': ['Xương Giòn', 'Gót Chân Kính', 'Ngã Đau', 'Tiếp Đất Dở', 'Đầu Gối Thủy Tinh', 'Mắt Cá Yếu', 'Hạ Cánh Xấu'],
         'outall': ['Đánh Lệch', 'Ra Đòn Hụt', 'Run Tay', 'Thiếu Lực', 'Mất Phong Độ', 'Ngại Va Chạm', 'Hiền Khô'],
         'effslowness': ['Buồn Ngủ', 'Cú Đêm Hỏng', 'Mắt Díp']}

lang = [json.load(open(f, encoding='utf-8')) for f in LANGS]
L = lang[0]
used = set(v.lower() for k, v in L.items() if k.startswith('card.wildcard.') and (k.endswith('.buff') or k.endswith('.debuff')))
changed = []
# họ bất lợi có sẵn của mỗi thẻ (gộp GenData + GenExtra)
sides = {}
src = {fn: open(os.path.join(J, fn), encoding='utf-8').read() for fn in ('GenData.java', 'GenExtra.java')}
for fn, s in src.items():
    for m in re.finditer(r'^\s*(card|x)\("(\w+)".*$', s, flags=re.M):
        arrs = re.findall(r'new String\[\]\{([^}]*)\}', m.group(0))
        sides.setdefault(m.group(2), set()).update(fam(x) for x in re.findall(r'"([^"]+)"', arrs[1]))
for fn in ('GenData.java', 'GenExtra.java'):
    def fix(m):
        line = m.group(0)
        cid = re.search(r'\("(\w+)"', line).group(1)
        arrs = re.findall(r'new String\[\]\{([^}]*)\}', line)
        deb = re.findall(r'"([^"]+)"', arrs[1])
        hungerEff = [s for s in deb if s.startswith('eff:hunger:')]
        if not any(bad(s) for s in deb) and not hungerEff: return line
        t = TIER[cid[0]]
        fams = sides[cid]
        key = f'card.wildcard.{cid}.debuff.desc'
        new = []
        for s in deb:
            if s.startswith('eff:hunger:'):
                ns = s.replace('eff:hunger:', 'eff:fatigue:')
                new.append(ns)
                for d in lang:
                    if key in d: d[key] = d[key].replace('Đói I', 'Đào Chậm I')
                changed.append((cid, s, ns))
                continue
            if not bad(s): new.append(s); continue
            k = next(k for k in ORDER[(sum(map(ord, cid)) % 4):] + ORDER if k not in fams)
            fams.add(k)
            spec, txt = D(k, t)
            new.append(spec)
            for d in lang:
                if key in d:
                    ot = old_text(s)
                    if ot in d[key]: d[key] = d[key].replace(ot, txt, 1)
                    else: print('WARN', cid, ot, '|', d[key])
            if len(deb) == 1:
                nm = next((n for n in NAMES[k] if n.lower() not in used), None)
                if nm:
                    used.add(nm.lower())
                    for d in lang: d[f'card.wildcard.{cid}.debuff'] = nm
            changed.append((cid, s, spec))
        old = 'new String[]{' + arrs[1] + '}'
        i = line.rfind(old)
        return line[:i] + 'new String[]{' + ', '.join(f'"{x}"' for x in new) + '}' + line[i + len(old):]
    s = re.sub(r'^\s*(card|x)\(.*$', fix, src[fn], flags=re.M)
    open(os.path.join(J, fn), 'w', encoding='utf-8').write(s)
for f, d in zip(LANGS, lang):
    json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(len(changed), 'mods replaced')
for c in changed: print(*c)
