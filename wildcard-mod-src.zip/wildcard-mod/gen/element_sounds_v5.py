# v5 RPG spell sound pack (original synthesis, 44.1 kHz mono): per school 3 cast + 3 impact variants.
# Layers per sound: magic swell (reverse-air riser + shimmer), the school's signature, a body hit, Schroeder reverb tail.
# Output: sounds/skill/<el>_<n>.ogg and sounds/impact/<el>_<n>.ogg (same names as v4.2, so sounds.json is unchanged).
import numpy as np, subprocess, os, wave, sys
SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/wildcard-mod/src/main/resources/assets/wildcard/sounds'
for d in ('skill', 'impact'): os.makedirs(f'{OUT}/{d}', exist_ok=True)
TMP = '/tmp/claude-0/snd5'; os.makedirs(TMP, exist_ok=True)

def N(d): return int(SR * d)
def t(n): return np.arange(n) / SR
def dec(n, tau): return np.exp(-np.arange(n) / (SR * tau))
def ramp(n, p=2.0): return np.linspace(0, 1, n) ** p
def env(n, a, r, p=2.0):
    e = np.ones(n); A = max(1, min(n, N(a))); e[:A] = np.linspace(0, 1, A) ** 1.3
    R = min(n - A, N(r))
    if R > 0: e[-R:] *= np.linspace(1, 0, R) ** p
    return e
def biquad(x, f, q, kind='bp'):
    """Time-varying RBJ biquad; f may be an array."""
    f = np.broadcast_to(np.asarray(f, float), x.shape); y = np.zeros_like(x)
    x1 = x2 = y1 = y2 = 0.0
    w = 2 * np.pi * np.clip(f, 20, SR * 0.45) / SR; cw = np.cos(w); al = np.sin(w) / (2 * q)
    for i in range(len(x)):
        c, a = cw[i], al[i]
        if kind == 'bp': b0, b1, b2 = a, 0.0, -a
        elif kind == 'lp': b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0
        else: b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0
        a0 = 1 + a; a1 = -2 * c; a2 = 1 - a
        yi = (b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0
        x2, x1, y2, y1 = x1, x[i], y1, yi; y[i] = yi
    return y
def osc(f, n, kind='sine'):
    f = np.broadcast_to(np.asarray(f, float), (n,)); ph = 2 * np.pi * np.cumsum(f) / SR
    if kind == 'sine': return np.sin(ph)
    if kind == 'saw': return 2 * ((ph / (2 * np.pi)) % 1) - 1
    if kind == 'tri': return 2 * np.abs(2 * ((ph / (2 * np.pi)) % 1) - 1) - 1
    return np.sign(np.sin(ph))
def fm(fc, ratio, index, n, tau):
    m = osc(fc * ratio, n) * index * dec(n, tau * 0.6)
    ph = 2 * np.pi * np.cumsum(np.full(n, fc)) / SR + m
    return np.sin(ph) * dec(n, tau)
def pad(x, n): return np.concatenate([x, np.zeros(max(0, n - len(x)))])[:n]
def mix(*xs):
    n = max(len(x) for x in xs); return sum(pad(x, n) for x in xs)
def at(x, sec, n):
    o = np.zeros(n); i = N(sec); m = min(len(x), n - i)
    if m > 0: o[i:i + m] = x[:m]
    return o
def comb(x, d, g):
    D = N(d); y = np.copy(x)
    for i in range(D, len(y)): y[i] += g * y[i - D]
    return y
def allpass(x, d, g):
    D = N(d); y = np.zeros_like(x); buf = np.zeros(len(x) + D)
    for i in range(len(x)):
        bd = buf[i]; v = x[i] + g * bd; y[i] = bd - g * v; buf[i + D] = v
    return y
def reverb(x, size=1.0, wet=0.35, damp=6000):
    tail = np.concatenate([x, np.zeros(N(1.2 * size))])
    c = sum(comb(tail, d * size, 0.78) for d in (0.0297, 0.0371, 0.0411, 0.0437)) / 4
    c = biquad(c, damp, 0.7, 'lp')
    for d in (0.005, 0.0017): c = allpass(c, d, 0.7)
    return tail * (1 - wet) + c * wet * 2.2
def noise(n, rng): return rng.uniform(-1, 1, n)

# ---------- shared layers ----------
def swell(n, rng, f0=400, f1=5000, q=1.2):
    """Air riser: band-passed noise sweeping up, louder towards the end (the 'charging magic' feel)."""
    return biquad(noise(n, rng), np.geomspace(f0, f1, n), q) * ramp(n, 2.2)
def shimmer(n, rng, freqs, count=24, tau=0.25):
    o = np.zeros(n)
    for s in rng.uniform(0, n / SR * 0.85, count):
        f = rng.choice(freqs) * rng.choice([1, 2, 4]) * (1 + rng.normal(0, 0.003))
        L = N(tau * 3); o += at(fm(f, 1.41, 1.2, L, tau) * rng.uniform(0.3, 1), s, n)
    return o
def sub_hit(n, f0, f1, tau): return osc(np.geomspace(f0, f1, n), n) * dec(n, tau)
def whoosh(n, rng, f0, f1, q=2.0): return biquad(noise(n, rng), np.geomspace(f0, f1, n), q) * env(n, 0.35, 0.5)
def crack(rng, dur=0.03, lo=3000): x = noise(N(dur), rng) * dec(N(dur), dur / 5); return biquad(x, lo, 0.5, 'hp')
def shatter(n, rng, count=60, lo=2500, hi=9000):
    """Glass / ice breaking: many tiny resonant grains plus ringing shards."""
    o = np.zeros(n)
    for s in np.sort(rng.exponential(0.12, count)):
        if s > n / SR * 0.8: continue
        L = N(0.06); g = biquad(noise(L, rng) * dec(L, 0.006), rng.uniform(lo, hi), 12) * rng.uniform(0.3, 1)
        o += at(g, s, n)
    for s in rng.exponential(0.2, count // 4):
        if s > n / SR * 0.8: continue
        L = N(0.5); f = rng.uniform(2500, 6500)
        o += at((osc(f, L) + 0.5 * osc(f * 2.31, L) + 0.3 * osc(f * 3.7, L)) * dec(L, 0.09) * rng.uniform(0.1, 0.4), s, n)
    return o
def flame(n, rng, base=300):
    roar = biquad(noise(n, rng), base + 200 * np.abs(biquad(noise(n, rng), 3, 0.7, 'lp')) * 40, 0.8)
    crackles = np.zeros(n)
    for s in rng.uniform(0, n / SR, int(n / SR * 80)):
        L = N(0.006); crackles += at(noise(L, rng) * dec(L, 0.0012) * rng.uniform(0.2, 1), s, n)
    return roar * 1.5 + biquad(crackles, 2500, 0.6, 'hp') * 0.6
def zap(n, rng, f=90):
    buzz = np.tanh(4 * osc(f * (1 + 0.5 * (rng.random(n) > 0.97)), n, 'saw'))
    return biquad(buzz, 1800, 1.0) * (0.5 + 0.5 * (biquad(noise(n, rng), 30, 0.7, 'lp') * 30 > 0))
def thunder(n, rng):
    rumble = biquad(noise(n, rng), np.geomspace(900, 80, n), 0.7, 'lp') * 4
    return rumble * dec(n, 0.6) * (0.6 + 0.4 * np.abs(biquad(noise(n, rng), 5, 0.7, 'lp')) * 25)
def choir(n, notes, cutoff=2200):
    v = sum(osc(f * (1 + d), n, 'saw') for f in notes for d in (-0.004, 0, 0.005))
    return biquad(v, cutoff, 0.8, 'lp') / (len(notes) * 3)
def heartbeat(rng, tau=0.07):
    L = N(0.25); return sub_hit(L, 75, 40, tau) + biquad(noise(L, rng) * dec(L, 0.02), 200, 1.5) * 0.4
def debris(n, rng, count=40, lo=300, hi=1500, start=0.05):
    o = np.zeros(n)
    for s in start + rng.exponential(0.18, count):
        if s > n / SR * 0.9: continue
        L = N(0.03); o += at(biquad(noise(L, rng) * dec(L, 0.005), rng.uniform(lo, hi), 4) * rng.uniform(0.2, 1), s, n)
    return o

def norm(x, lvl=1.0): return x / (np.abs(x).max() + 1e-9) * lvl
def save(name, x):
    x = x - np.mean(x); x = norm(x); x = np.tanh(x * 1.6) / np.tanh(1.6); x = norm(x, 0.92)
    f = min(len(x), N(0.03)); x[-f:] *= np.linspace(1, 0, f)
    w = f'{TMP}/{name.replace("/", "_")}.wav'
    with wave.open(w, 'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', w, '-c:a', 'libvorbis', '-q:a', '6', f'{OUT}/{name}.ogg'], check=True)
    os.remove(w)

# ---------- casts ----------
def fire_cast(rng, v):
    n = N(1.3); hit = 0.55 + 0.05 * v
    return reverb(mix(swell(n, rng, 200, 2500) * 0.6, at(flame(N(0.9), rng, 250 + 60 * v) * env(N(0.9), 0.05, 0.6), hit - 0.1, n),
                      at(whoosh(N(0.7), rng, 300, 3000) * 1.4, hit - 0.15, n), at(sub_hit(N(0.6), 110, 45, 0.18) * 1.2, hit, n)), 0.9, 0.25)
def frost_cast(rng, v):
    n = N(1.4); notes = [[1318.5, 1568, 1975.5], [1174.7, 1480, 1760], [1396.9, 1661.2, 2093]][v]
    return reverb(mix(swell(n, rng, 1200, 9000, 2) * 0.35, shimmer(n, rng, notes, 26, 0.3) * 0.7,
                      at(crack(rng, 0.05, 2500) * 1.2, 0.55, n), at(shatter(N(0.8), rng, 35, 3000, 9000) * 0.8, 0.56, n),
                      at(sub_hit(N(0.3), 300, 140, 0.06) * 0.5, 0.55, n)), 1.2, 0.4, 9000)
def storm_cast(rng, v):
    n = N(1.2); z = zap(N(0.6), rng, 80 + 25 * v) * env(N(0.6), 0.3, 0.1)
    return reverb(mix(swell(n, rng, 500, 7000) * 0.4, at(z, 0.0, n) * 0.8, at(crack(rng, 0.04, 1500) * 1.6, 0.6, n),
                      at(thunder(N(0.6), rng) * 0.6, 0.6, n), at(shimmer(N(0.5), rng, [2637, 3136], 10, 0.05) * 0.4, 0.6, n)), 0.9, 0.3)
def blood_cast(rng, v):
    n = N(1.2)
    wet = biquad(noise(N(0.5), rng), np.geomspace(1800, 300, N(0.5)), 3) * env(N(0.5), 0.05, 0.4)
    return reverb(mix(at(heartbeat(rng) * 1.3, 0.0, n), at(heartbeat(rng), 0.28, n), swell(n, rng, 150, 1500, 2) * 0.4,
                      at(wet * 1.2, 0.55, n), at(choir(N(0.7), [110, 130.8, 164.8], 900) * env(N(0.7), 0.2, 0.4) * 0.8, 0.45, n)), 1.0, 0.35, 3500)
def void_cast(rng, v):
    n = N(1.5)
    drone = choir(n, [55, 58.3 + v, 82.4], 600) * env(n, 0.6, 0.4) * 1.5
    rev = biquad(noise(n, rng), np.geomspace(200, 6000, n), 2) * ramp(n, 4) * 1.2
    return reverb(mix(drone, rev, at(sub_hit(N(0.8), 70, 25, 0.3) * 1.3, 1.05, n)), 1.5, 0.5, 4000)
def holy_cast(rng, v):
    n = N(1.6); notes = [[261.6, 329.6, 392, 523.3], [293.7, 370, 440, 587.3], [349.2, 440, 523.3, 698.5]][v]
    return reverb(mix(choir(n, notes, 3000) * env(n, 0.4, 0.8) * 1.4, shimmer(n, rng, [n2 * 2 for n2 in notes], 20, 0.4) * 0.5,
                      swell(n, rng, 2000, 10000, 3) * 0.2, at(fm(1046.5, 3.5, 2, N(1.0), 0.5) * 0.5, 0.6, n)), 1.6, 0.5, 9000)
def earth_cast(rng, v):
    n = N(1.3)
    rumble = biquad(noise(n, rng), 70, 0.7, 'lp') * 8 * env(n, 0.3, 0.5)
    grind = biquad(noise(n, rng), 450 + 100 * v, 1.5) * env(n, 0.2, 0.5) * (0.5 + 0.5 * np.abs(biquad(noise(n, rng), 6, 0.7, 'lp')) * 30)
    return reverb(mix(rumble, grind * 0.7, at(sub_hit(N(0.7), 90, 35, 0.25) * 1.5, 0.6, n), at(debris(N(0.7), rng, 30), 0.6, n) * 0.8), 0.8, 0.2, 3000)
def wind_cast(rng, v):
    n = N(1.3); f = 500 + 1500 * np.sin(np.linspace(0, np.pi * (1 + 0.3 * v), n)) ** 2
    gust = biquad(noise(n, rng), f, 3) * env(n, 0.3, 0.5)
    return reverb(mix(gust * 1.5, osc(f * 2, n) * 0.04 * env(n, 0.4, 0.4), at(whoosh(N(0.5), rng, 3000, 400, 2) * 1.2, 0.7, n)), 1.0, 0.3, 7000)
def arcane_cast(rng, v):
    n = N(1.3); scale = [523.3, 622.3, 784, 932.3, 1046.5, 1244.5]
    arp = np.zeros(n)
    for i, f in enumerate(scale if v != 1 else scale[::-1]):
        arp += at(fm(f, 2.0, 1.5, N(0.6), 0.18) * 0.6, 0.05 + i * 0.075, n)
    return reverb(mix(arp, swell(n, rng, 600, 6000, 1.5) * 0.5, shimmer(n, rng, scale, 14, 0.2) * 0.4,
                      at(sub_hit(N(0.4), 200, 80, 0.1) * 0.6, 0.55, n)), 1.3, 0.45, 8000)

# ---------- impacts ----------
def fire_imp(rng, v):
    n = N(1.6)
    return reverb(mix(sub_hit(n, 120, 30, 0.35) * 1.6, biquad(noise(n, rng), np.geomspace(3000, 200, n), 0.7, 'lp') * 2.5 * dec(n, 0.3),
                      flame(n, rng, 400) * dec(n, 0.5) * 0.7, debris(n, rng, 30, 800, 3000) * 0.5), 1.0, 0.25, 5000)
def frost_imp(rng, v):
    n = N(1.5)
    return reverb(mix(crack(rng, 0.06, 2000) * 2.0, shatter(n, rng, 80 + 10 * v), sub_hit(N(0.4), 220, 90, 0.07) * 0.6,
                      shimmer(n, rng, [2093, 2637, 3136], 12, 0.25) * 0.3), 1.2, 0.35, 10000)
def storm_imp(rng, v):
    n = N(2.0)
    return reverb(mix(crack(rng, 0.08, 1200) * 2.2, thunder(n, rng) * 1.6, at(zap(N(0.3), rng, 120) * dec(N(0.3), 0.1) * 0.6, 0.0, n),
                      sub_hit(n, 60, 30, 0.5) * 0.8), 1.4, 0.3, 6000)
def blood_imp(rng, v):
    n = N(1.0)
    splat = biquad(noise(n, rng), np.geomspace(2500, 300, n), 2) * dec(n, 0.08)
    return reverb(mix(splat * 1.6, sub_hit(n, 140, 45, 0.15) * 1.3, debris(n, rng, 20, 200, 900) * 0.6), 0.8, 0.25, 3000)
def void_imp(rng, v):
    n = N(1.8)
    warble = osc(np.geomspace(300, 40, n) * (1 + 0.2 * osc(9 + 3 * v, n)), n) * dec(n, 0.5) * 0.7
    implode = biquad(noise(n, rng), np.geomspace(6000, 100, n), 3) * dec(n, 0.35)
    return reverb(mix(sub_hit(n, 70, 20, 0.6) * 1.8, warble, implode * 1.2), 1.6, 0.45, 3500)
def holy_imp(rng, v):
    n = N(2.0); notes = [523.3, 659.3, 784, 1046.5, 1318.5]
    bell = sum(fm(f, 3.5, 2.5, n, 0.8) for f in notes[v % 2: 4 + v % 2]) * 0.35
    return reverb(mix(bell, crack(rng, 0.03, 4000) * 0.8, shimmer(n, rng, notes, 16, 0.4) * 0.4, sub_hit(N(0.5), 160, 70, 0.15) * 0.6), 1.8, 0.5, 10000)
def earth_imp(rng, v):
    n = N(1.6)
    return reverb(mix(sub_hit(n, 90, 25, 0.45) * 2.0, biquad(noise(n, rng), 400, 0.7, 'lp') * 3 * dec(n, 0.25), debris(n, rng, 70, 300, 2000, 0.03)), 1.0, 0.2, 3000)
def wind_imp(rng, v):
    n = N(1.2)
    return reverb(mix(biquad(noise(n, rng), np.geomspace(3500, 250, n), 2.5) * dec(n, 0.35) * 1.8, sub_hit(N(0.4), 100, 50, 0.1) * 0.7), 1.0, 0.3, 7000)
def arcane_imp(rng, v):
    n = N(1.4); scale = [784, 932.3, 1046.5, 1244.5, 1568]
    pop = sub_hit(N(0.15), 900, 150, 0.04)
    sparks = sum(at(fm(f, 2.0, 2, N(0.5), 0.12) * 0.4, 0.02 + 0.04 * i, n) for i, f in enumerate(scale[::-1]))
    return reverb(mix(pop * 1.5, sparks, swell(N(0.3), rng, 6000, 800, 2)[::-1] * 0.3), 1.3, 0.45, 8000)

CAST = dict(fire=fire_cast, frost=frost_cast, storm=storm_cast, blood=blood_cast, void=void_cast, holy=holy_cast, earth=earth_cast, wind=wind_cast, arcane=arcane_cast)
IMP = dict(fire=fire_imp, frost=frost_imp, storm=storm_imp, blood=blood_imp, void=void_imp, holy=holy_imp, earth=earth_imp, wind=wind_imp, arcane=arcane_imp)
if __name__ == '__main__':
    only = sys.argv[2:] or list(CAST)
    for i, el in enumerate(only):
        for v in range(3):
            save(f'skill/{el}_{v + 1}', CAST[el](np.random.default_rng(100 * i + v), v))
            save(f'impact/{el}_{v + 1}', IMP[el](np.random.default_rng(100 * i + v + 50), v))
        print(el, flush=True)
