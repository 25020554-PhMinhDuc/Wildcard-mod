# v6.0.0: card redesign.
#  - only Rare+ cards keep an active skill; every Rare+ generated card gets its own fitting, unique skill
#  - buff/debuff count by rarity: C/U 1, R 2, E 3, L 4, M 5 (no duplicate kind on one card)
#  - trolls become ordinary debuffs (spread so the same troll is not everywhere)
#  - no more "Name II / III / V": every card gets a unique name
import json, re, random, sys
sys.argv = ['x', '/tmp/claude-0/unused']; sys.path.insert(0, '/home/claude/gen')
import icons
from icons import sym
for _l in open('/home/claude/gen/spell_icons.py'):
    if _l.startswith("sym('"): exec(_l)  # extra spell symbols (icicle, missile, lance, ...)
R = random.Random(60000)
ROOT = '/home/claude/wildcard-mod/src/main'
J = f'{ROOT}/java/com/hoang/wildcard'
LANGS = [f'{ROOT}/resources/assets/wildcard/lang/{x}.json' for x in ('vi_vn', 'en_us')]
L = json.load(open(LANGS[0]))
gd = open(f'{J}/GenData.java').read()
cards_src = open(f'{J}/Cards.java').read()

RANK = {'COMMON': 0, 'UNCOMMON': 1, 'RARE': 2, 'EPIC': 3, 'LEGENDARY': 4, 'MYTHIC': 5}
COUNT = {0: 1, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5}
PROMOTE = {'u61', 'u62', 'u63', 'u64'}  # meme cards keep their skills -> become Rare
rar = {}
for cid, r in re.findall(r'add\("(\w+)", (\w+)', cards_src): rar[cid] = RANK[r]
spec = {}
for m in re.finditer(r'card\("(\w+)", (\w+), Items\.\w+, Items\.\w+, \w+, new String\[\]\{([^}]*)\}, new String\[\]\{([^}]*)\}\);', gd):
    rar[m.group(1)] = RANK[m.group(2)]
    spec[m.group(1)] = ([x.strip().strip('"') for x in m.group(3).split(',') if x.strip()],
                        [x.strip().strip('"') for x in m.group(4).split(',') if x.strip()])
for c in PROMOTE: rar[c] = 2
ORDER = list(rar)

def num(x): return (f"{x:.1f}".rstrip('0').rstrip('.')).replace('.', ',')
def pct(x): return f"{round(x*100)}%"
ROMAN = ['I', 'II', 'III', 'IV', 'V']

# =============================================================== 1. skills of the generated Rare+ cards
ELW = {'fire': 'lửa', 'frost': 'băng', 'storm': 'sét', 'blood': 'máu', 'void': 'hư không', 'holy': 'thánh', 'earth': 'đất', 'wind': 'gió', 'arcane': 'bí thuật'}
EFFN = {'speed': 'Tốc Độ', 'haste': 'Đào Nhanh', 'strength': 'Sức Mạnh', 'resistance': 'Kháng Cự', 'jump': 'Nhảy Cao', 'glowing': 'Phát Sáng',
        'slowness': 'Chậm Chạp', 'weakness': 'Yếu Ớt', 'poison': 'Độc'}
def params(kind, t, el, eff):
    i = t - 2
    P = lambda *v: v[i]
    if kind == 'bolt':
        a, b, cd = P(6, 8, 11), P(20, 24, 28), P(15, 14, 12)
        ex = {'fire': ', đốt 4 giây', 'slowness': ', làm chậm 3 giây', 'glowing': ', mục tiêu phát sáng 6 giây', 'weakness': ', gây Yếu Ớt 4 giây', 'lifesteal': ', hút 30% thành máu'}[eff]
        return a, b, cd, 0, f"Bắn vào mục tiêu đang nhìn trong {b} khối: {num(a)} sát thương{ex}"
    if kind == 'nova':
        a, b, cd = P(5, 7, 9), P(4.5, 5, 6), P(22, 20, 18)
        return a, b, cd, 0, f"Sóng {ELW[el]} quanh {num(b)} khối: {num(a)} sát thương và hất văng"
    if kind == 'heal':
        a, cd = P(6, 8, 10), P(35, 30, 30); return a, 0, cd, 0, f"Hồi ngay {num(a)} máu"
    if kind == 'buff':
        amp = 1 if t >= 3 else 0; b, cd = P(10, 12, 15), P(35, 30, 30)
        return 0, b, cd, amp, f"Bản thân nhận {EFFN[eff]} {ROMAN[amp]} trong {b} giây"
    if kind == 'curse':
        amp = 1 if t >= 3 else 0; b, cd = P(6, 8, 10), P(28, 25, 22)
        return 6, b, cd, amp, f"Kẻ địch trong 6 khối bị {EFFN[eff]} {ROMAN[amp]} trong {b} giây"
    if kind == 'dash':
        a, cd = P(1.7, 2, 2.4), P(9, 8, 7); return a, 0, cd, 0, "Lướt nhanh về phía trước, không mất máu khi rơi"
    if kind == 'leap':
        a, cd = P(1.2, 1.4, 1.7), P(11, 10, 8); return a, 0, cd, 0, "Bật lên thật cao, không mất máu khi rơi"
    if kind == 'shield':
        amp, cd = P(1, 2, 3), P(40, 35, 30); return 0, 10, cd, amp, f"Nhận khiên Hấp Thụ {ROMAN[amp]} trong 10 giây"
    if kind == 'feast':
        a, cd = P(6, 8, 10), P(70, 60, 50); return a, 0, cd, 0, f"Hồi {int(a)} điểm đói và no lâu"
    if kind == 'meteor':
        a, cd = P(2, 3, 4), P(20, 18, 15); return a, 0, cd, 0, f"Bắn {int(a)} quả cầu lửa theo hướng nhìn"
    if kind == 'pull':
        b, cd = P(7, 8, 10), P(16, 14, 12); return 0, b, cd, 0, f"Kéo kẻ địch trong {b} khối về phía bạn"
    if kind == 'taunt':
        amp = P(1, 1, 2); return 0, 0, 40, amp, f"Thách đấu: mọi mob trong 10 khối lao vào bạn, bạn được Kháng Cự {ROMAN[amp]} 5 giây"
    if kind == 'firebolt':
        a, cd = P(7, 9, 12), P(9, 8, 7); return a, 0, cd, 0, f"Bắn quả cầu lửa bay thẳng: {num(a)} sát thương, đốt 5 giây"
    if kind == 'icicle':
        a, cd = P(6, 8, 10), P(9, 8, 7); return a, 0, cd, 0, f"Phóng mũi băng bay nhanh: {num(a)} sát thương, làm chậm và đóng băng"
    if kind == 'magic_missile':
        a, cd = P(4, 5, 6), P(12, 11, 10); return a, 0, cd, 0, f"3 quả đạn tự bám mục tiêu, mỗi quả {num(a)} sát thương"
    if kind == 'lightning_lance':
        a, b, cd = P(8, 11, 14), P(24, 28, 32), P(20, 18, 16)
        return a, b, cd, 0, f"Phóng giáo sét vào mục tiêu trong {b} khối: {num(a)} sát thương kèm tia sét"
    if kind == 'chain_lightning':
        a, cd = P(7, 8.5, 10), P(22, 20, 18); return a, 0, cd, 0, f"Sét đánh mục tiêu rồi nhảy sang 3 kẻ gần đó: {num(a)} sát thương, giảm dần"
    if kind == 'blood_slash':
        a, cd = P(7, 9, 11), P(9, 8, 7); return a, 0, cd, 0, f"Chém vòng cung phía trước: {num(a)} sát thương, hút một phần thành máu"
    if kind == 'ray_of_frost':
        a, b, cd = P(6, 8, 10), P(14, 16, 18), P(16, 14, 12)
        return a, b, cd, 0, f"Tia băng xuyên thẳng {b} khối: {num(a)} sát thương mọi kẻ trên đường, đóng băng"
    if kind == 'fang_strike':
        b, cd = P(8, 10, 12), P(16, 14, 12); return 0, b, cd, 0, f"Hàng {b} gọng kìm trồi lên từ mặt đất phía trước (6 sát thương mỗi cái)"
    if kind == 'wisp':
        a, cd = P(5, 7, 9), P(14, 12, 10); return a, 0, cd, 0, f"Thả đốm sáng bay tìm kẻ địch: {num(a)} sát thương, hồi cho bạn {num(a/2)} máu"
    if kind == 'acid_orb':
        a, b, cd = P(4, 5, 6), P(3, 3.5, 4), P(20, 18, 16)
        return a, b, cd, 0, f"Ném bình axit: {num(a)} sát thương, vỡ ra vũng độc bán kính {num(b)} khối"
    if kind == 'breath':
        a, cd = P(12, 16, 22), P(24, 21, 18)
        what = 'lửa, đốt cháy' if el == 'fire' else 'nước lạnh, làm chậm'
        return a, 0, cd, 0, f"Phun {what} hình nón 6 khối trong 2 giây, tổng {num(a)} sát thương"
    if kind == 'counterspell':
        cd = P(30, 26, 22); return 0, 0, cd, 0, "Xóa mọi hiệu ứng của kẻ địch trong 10 khối và gỡ hiệu ứng xấu trên người bạn"
    if kind == 'root':
        b, cd = P(5, 6, 7), P(24, 22, 20); return 0, b, cd, 0, f"Trói chân kẻ địch trong 6 khối suốt {b} giây"
    if kind == 'fireball':
        a, b, cd = P(9, 12, 16), P(3.5, 4, 5), P(16, 14, 12)
        return a, b, cd, 0, f"Ném quả cầu lửa lớn, nổ bán kính {num(b)} khối: {num(a)} sát thương, đốt và hất văng"
    if kind == 'starfall':
        a, b, cd = P(3.5, 4.5, 6), P(5, 6, 7), P(32, 28, 24)
        return a, b, cd, 0, f"12 sao băng rơi quanh chỗ bạn nhìn (bán kính {b} khối), mỗi viên {num(a)} sát thương"
    if kind == 'black_hole':
        a, b, cd = P(8, 11, 14), P(7, 8, 9), P(36, 32, 28)
        return a, b, cd, 0, f"Mặt đất sụt thành hố 3 giây, hút kẻ địch trong {b} khối rồi sập xuống: {num(a)} sát thương"
    if kind == 'ice_shield':
        a, b, cd = P(8, 10, 12), P(10, 12, 14), P(30, 26, 22)
        return a, b, cd, 0, f"Áo băng xoay quanh bạn {b} giây: giảm sát thương, thêm giáp, đóng băng kẻ lại gần"
    if kind == 'sunbeam':
        a, cd = P(8, 11, 14), P(18, 16, 14)
        return a, 0, cd, 0, f"Giáng cột sáng từ trời xuống mục tiêu: {num(a)} sát thương (gấp đôi với undead), hồi máu cho bạn"
    raise KeyError(kind)

# id: (card name, kind, element, skill name, eff, icon)
DESIGN = {
 'r26': ('Thương Thủ Thành', 'dash', 'earth', 'Xung Phong Khiên', '', 'dash'),
 'r27': ('Chân Chạy Marathon', 'buff', 'wind', 'Nước Rút', 'speed', 'gust'),
 'r28': ('Thợ Mỏ Lão Luyện', 'nova', 'earth', 'Chấn Động Hầm Mỏ', '', 'shockwave'),
 'r29': ('Gấu Tuyết', 'ice_shield', 'frost', 'Áo Giáp Tuyết', '', 'snow'),
 'r30': ('Thợ Lặn Hang Ngầm', 'pull', 'wind', 'Xoáy Nước Ngầm', '', 'swirl'),
 'r31': ('Cột Đá Giữa Biển', 'root', 'earth', 'Neo Đá', '', 'root'),
 'r32': ('Tử Thần Tập Sự', 'blood_slash', 'blood', 'Nhát Hái Máu', '', 'slash'),
 'r33': ('Thợ Săn Tiền Thưởng', 'curse', 'arcane', 'Treo Thưởng', 'glowing', 'eye'),
 'r34': ('Kẻ Lội Dung Nham', 'fireball', 'fire', 'Hỏa Cầu Liều Mạng', '', 'fireball'),
 'r35': ('Thợ Săn Biển Sâu', 'icicle', 'frost', 'Lao Móc Băng', '', 'icicle'),
 'r36': ('Đô Vật Làng', 'taunt', 'storm', 'Thách Đấu', '', 'roar'),
 'r37': ('Thợ Diệt Nhện', 'acid_orb', 'earth', 'Bình Thuốc Diệt Côn Trùng', '', 'acid'),
 'r38': ('Hiệp Sĩ Dòng Đền', 'sunbeam', 'holy', 'Phán Quyết', '', 'sun'),
 'r39': ('Thiền Sư', 'buff', 'arcane', 'Thiền Định', 'resistance', 'moon'),
 'r40': ('Kình Ngư Kháng Phép', 'dash', 'wind', 'Lướt Sóng', '', 'feather'),
 'r41': ('Lính Gác Đêm', 'bolt', 'holy', 'Pháo Sáng', 'glowing', 'flame'),
 'r42': ('Cá Voi Lưng Gù', 'breath', 'frost', 'Cột Nước Lạnh', '', 'breath'),
 'r43': ('Thợ Leo Vách Đá', 'leap', 'wind', 'Nhảy Vách', '', 'uparrow'),
 'r44': ('Người Giữ Rạn San Hô', 'heal', 'holy', 'Sóng Chữa Lành', '', 'heartplus'),
 'r45': ('Đầu Bếp Chiến Trường', 'feast', 'earth', 'Nồi Lẩu Dã Chiến', '', 'chest'),
 'r46': ('Người Đá Hầm Mỏ', 'shield', 'earth', 'Da Đá', '', 'shield'),
 'r47': ('Kẻ Đào Kho Báu', 'buff', 'holy', 'Cơn Sốt Vàng', 'haste', 'pickaxe'),
 'r48': ('Thầy Lang Rừng', 'wisp', 'holy', 'Đom Đóm Chữa Lành', '', 'wisp'),
 'r49': ('Rái Cá Khổng Lồ', 'nova', 'wind', 'Sóng Cuộn', '', 'tornado'),
 'r50': ('Thợ Mỏ Ham Ăn', 'nova', 'fire', 'Nổ Mìn', '', 'explosion'),
 'e21': ('Gấu Trúc Lăn', 'leap', 'earth', 'Bật Nhảy Gấu Trúc', '', 'uparrow'),
 'e22': ('Giáp Bọ Cánh Cứng', 'fang_strike', 'earth', 'Hàm Bọ Kìm', '', 'fangs'),
 'e23': ('Linh Vật May Mắn', 'starfall', 'arcane', 'Sao Băng Ước Nguyện', '', 'meteor'),
 'e24': ('Kẻ Diệt Cướp Làng', 'dash', 'fire', 'Truy Kích', '', 'dash'),
 'e25': ('Thợ Mỏ Cởi Trần', 'buff', 'fire', 'Cơ Bắp Bốc Lửa', 'strength', 'fist'),
 'e26': ('Thần Cuốc', 'black_hole', 'earth', 'Hố Sụt', '', 'blackhole'),
 'e27': ('Thợ Săn Pháp Sư', 'counterspell', 'arcane', 'Phản Phép', '', 'reflect'),
 'e28': ('Võ Sĩ Quyền Anh', 'nova', 'storm', 'Cú Đấm Chấn Động', '', 'fist'),
 'e29': ('Kình Ngư Bơi Sải', 'ray_of_frost', 'frost', 'Dòng Hải Lưu Lạnh', '', 'ray'),
 'e30': ('Chiến Binh Thủy Triều', 'lightning_lance', 'storm', 'Đinh Ba Sấm Sét', '', 'lance'),
 'l21': ('Đại Kiếm Sĩ', 'blood_slash', 'storm', 'Trảm Phong Lôi', '', 'sword'),
 'l22': ('Thợ Mỏ Đáy Biển', 'magic_missile', 'frost', 'Thủy Lôi Tầm Nhiệt', '', 'missile'),
 'l23': ('Long Vương Biển', 'breath', 'fire', 'Hơi Thở Rồng Biển', '', 'breath'),
 'l24': ('Thần Mưa Bão', 'chain_lightning', 'storm', 'Sấm Truyền', '', 'cloudbolt'),
 'l25': ('Thủy Tặc Huyền Thoại', 'meteor', 'fire', 'Đại Bác Hải Tặc', '', 'fireball'),
}
assert len({(v[1], v[2]) for v in DESIGN.values()}) == len(DESIGN), 'kind+element must be unique'
assert len({v[3] for v in DESIGN.values()}) == len(DESIGN)
lang = {}
lines = gd.split('\n'); out = []
ICON_DIR = f'{ROOT}/resources/assets/wildcard/textures/gui/skill'
import os
removed_sk = 0
for l in lines:
    m = re.match(r'\s*skill\("(\w+)"', l)
    if m:
        cid = m.group(1)
        if rar[cid] < 2:  # v6: Common/Uncommon: no active skill
            removed_sk += 1
            for k in (f'skill.wildcard.{cid}.0', f'skill.wildcard.{cid}.0.desc'): L.pop(k, None)
            p = f'{ICON_DIR}/{cid}_0.png'
            if os.path.exists(p): os.remove(p)
            continue
        name, kind, el, sname, eff, ic = DESIGN[cid]
        a, b, cd, amp, desc = params(kind, min(rar[cid], 4), el, eff)
        l = f'        skill("{cid}", "{kind}", "{el}", {a}, {b}, "{eff}", {amp}, {cd});'
        lang[f'skill.wildcard.{cid}.0'] = sname
        lang[f'skill.wildcard.{cid}.0.desc'] = desc
        icons.icon(el, ic).save(f'{ICON_DIR}/{cid}_0.png')
    out.append(l)
gd = '\n'.join(out)
# hand-made duplicate skill name
lang['skill.wildcard.m05.1'] = 'Bước Hư Không'

# =============================================================== 2. extra buffs / debuffs
SRC = {'fall': 'khi rơi', 'fire': 'từ lửa', 'explosion': 'từ vụ nổ', 'projectile': 'từ tên và đạn', 'magic': 'từ phép thuật',
       'melee': 'cận chiến', 'drown': 'do đuối nước', 'freeze': 'do đóng băng'}
TGT = {'undead': 'mob xác sống', 'arthropod': 'nhện và côn trùng', 'illager': 'dân làng ác', 'water': 'mob dưới nước', 'animal': 'động vật', 'all': 'mọi mục tiêu'}
def B(k, t):
    t = min(t, 4)
    if k == 'speed': v = [.06, .1, .15, .2, .3][t]; return f"attr:speed:{v}", f"Tốc chạy +{pct(v)}"
    if k == 'maxhp': v = [2, 4, 6, 8, 10][t]; return f"attr:maxhp:{v}", f"Máu tối đa +{v//2} tim"
    if k == 'attack': v = [1, 1.5, 2, 3, 4][t]; return f"attr:attack:{v}", f"Sát thương cận chiến +{num(v)}"
    if k == 'armor': v = [2, 3, 4, 6, 8][t]; return f"attr:armor:{v}", f"Giáp +{v}"
    if k == 'toughness': v = [1, 2, 3, 4, 5][t]; return f"attr:toughness:{v}", f"Độ cứng giáp +{v}"
    if k == 'luck': v = [1, 2, 3, 4, 5][t]; return f"attr:luck:{v}", f"May Mắn +{v}"
    if k == 'kbres': v = [.2, .3, .5, .7, 1][t]; return f"attr:kbres:{v}", f"Kháng đẩy lùi {pct(v)}"
    if k == 'atkspeed': v = [.1, .15, .2, .3, .4][t]; return f"attr:atkspeed:{v}", f"Tốc đánh +{pct(v)}"
    if k == 'reach': v = [.5, 1, 1.5, 2, 3][t]; return f"attr:reach:{v}", f"Tầm với +{num(v)} khối"
    if k == 'swim': v = [.3, .5, .7, 1, 1.5][t]; return f"attr:swim:{v}", f"Bơi nhanh hơn {pct(v)}"
    if k == 'inc':
        s = R.choice(list(SRC)); m = [.8, .7, .55, .4, .25][t]; return f"inc:{s}:{m}", f"Giảm {pct(1-m)} sát thương {SRC[s]}"
    if k == 'out':
        tg = R.choice(list(TGT)); m = ([1.06, 1.1, 1.15, 1.2, 1.3] if tg == 'all' else [1.25, 1.35, 1.5, 1.75, 2])[t]
        return f"out:{tg}:{m}", f"+{pct(m-1)} sát thương lên {TGT[tg]}"
    if k == 'killheal': v = [1, 1.5, 2, 3, 4][t]; return f"kill:heal:{v}", f"Hạ mob: hồi {num(v)} máu"
    if k == 'killxp': v = [2, 3, 5, 7, 10][t]; return f"kill:xp:{v}", f"Hạ mob: thêm {v} XP"
    if k == 'killfood': v = [1, 2, 3, 4, 5][t]; return f"kill:food:{v}", f"Hạ mob: hồi {v} điểm đói"
    if k == 'minexp': v = [10, 15, 20, 30, 40][t]; return f"mine:xp:{v}", f"Đào khối: {v}% rơi thêm XP"
    if k == 'minehaste': a = 1 if t >= 3 else 0; return f"mine:haste:{a}", f"Đào đá: Đào Nhanh {ROMAN[a]} trong 3 giây"
    if k == 'regen': v = [20, 15, 10, 8, 5][t]; return f"regen:{v}", f"Cứ {v} giây hồi 1 máu"
    if k == 'food': v = [1, 2, 3, 4, 5][t]; return f"food:{v}", f"Ăn gì cũng thêm {v} điểm đói"
    if k == 'exh': v = [.85, .75, .6, .5, .4][t]; return f"exh:{v}", f"Tốn đói ít hơn {pct(1-v)}"
    if k == 'xp': v = [1.15, 1.25, 1.4, 1.6, 2][t]; return f"xp:{v}", f"XP nhận được +{pct(v-1)}"
    raise KeyError(k)
def D(k, t):
    t = min(t, 4)
    if k == 'speed': v = [.08, .12, .18, .22, .3][t]; return f"attr:speed:-{v}", f"Tốc chạy -{pct(v)}"
    if k == 'maxhp': v = [2, 3, 4, 6, 8][t]; return f"attr:maxhp:-{v}", f"Máu tối đa -{num(v/2)} tim"
    if k == 'attack': v = [1, 1.5, 2, 2.5, 3][t]; return f"attr:attack:-{v}", f"Sát thương cận chiến -{num(v)}"
    if k == 'armor': v = [2, 3, 4, 5, 6][t]; return f"attr:armor:-{v}", f"Giáp -{v}"
    if k == 'luck': v = [1, 2, 3, 4, 5][t]; return f"attr:luck:-{v}", f"Xui Xẻo: May Mắn -{v}"
    if k == 'atkspeed': v = [.1, .15, .2, .25, .3][t]; return f"attr:atkspeed:-{v}", f"Tốc đánh -{pct(v)}"
    if k == 'reach': v = [.5, .75, 1, 1.25, 1.5][t]; return f"attr:reach:-{v}", f"Tầm với -{num(v)} khối"
    if k == 'inc':
        s = R.choice(list(SRC)); m = [1.25, 1.35, 1.5, 1.75, 2][t]; return f"inc:{s}:{m}", f"Nhận thêm {pct(m-1)} sát thương {SRC[s]}"
    if k == 'incall': m = [1.1, 1.15, 1.2, 1.25, 1.35][t]; return f"inc:all:{m}", f"Nhận thêm {pct(m-1)} mọi sát thương"
    if k == 'out':
        tg = R.choice(list(TGT)); m = ([.9, .85, .8, .75, .7] if tg == 'all' else [.7, .6, .5, .4, .3])[t]
        return f"out:{tg}:{m}", f"-{pct(1-m)} sát thương lên {TGT[tg]}"
    if k == 'killhurt': v = [1, 1.5, 2, 3, 4][t]; return f"kill:hurt:{v}", f"Hạ mob: tự mất {num(v)} máu"
    if k == 'killhunger': v = [1, 2, 3, 4, 5][t]; return f"kill:hunger:{v}", f"Hạ mob: mất {v} điểm đói"
    if k == 'minehurt': v = [5, 8, 10, 12, 15][t]; return f"mine:hurt:{v}", f"Đào khối: {v}% bị đá văng vào mặt (mất 1 máu)"
    if k == 'drain': v = [60, 45, 35, 25, 20][t]; return f"drain:{v}", f"Cứ {v} giây mất 1 máu (không chết vì cái này)"
    if k == 'food': v = [1, 1, 2, 2, 3][t]; return f"food:-{v}", f"Ăn gì cũng bớt {v} điểm đói"
    if k == 'exh': v = [1.3, 1.5, 1.75, 2, 2.5][t]; return f"exh:{v}", f"Tốn đói gấp {num(v)} lần"
    if k == 'xp': v = [.85, .75, .6, .5, .4][t]; return f"xp:{v}", f"XP nhận được -{pct(1-v)}"
    raise KeyError(k)
BK = ['speed', 'maxhp', 'attack', 'armor', 'toughness', 'luck', 'kbres', 'atkspeed', 'reach', 'swim', 'inc', 'out', 'killheal',
      'killxp', 'killfood', 'minexp', 'minehaste', 'regen', 'food', 'exh', 'xp']
DK = ['speed', 'maxhp', 'attack', 'armor', 'luck', 'atkspeed', 'reach', 'inc', 'incall', 'out', 'killhurt', 'killhunger',
      'minehurt', 'drain', 'food', 'exh', 'xp']
def mkey(s):  # family of a mod, used to keep one card free of duplicates
    a = s.split(':')
    if a[0] in ('attr',):
        return a[1]
    if a[0] == 'eff': return 'eff_' + a[1]
    if a[0] == 'kill': return 'kill' + a[1]
    if a[0] == 'mine': return 'mine' + a[1]
    if a[0] == 'inc': return 'incall' if a[1] == 'all' else 'inc'
    if a[0] == 'troll': return 'troll_' + a[1]
    return a[0]
# keywords in hand-written texts -> family, so extras never repeat what the card already does
KW = [('speed', r'tốc chạy|tốc độ|chạy nhanh|chậm'), ('maxhp', r'máu tối đa|\bhp\b|tim'), ('attack', r'sát thương cận chiến|sát thương'),
      ('armor', r'giáp'), ('luck', r'may mắn|xui'), ('kbres', r'đẩy lùi'), ('atkspeed', r'tốc đánh|đánh nhanh'), ('reach', r'tầm với'),
      ('swim', r'bơi'), ('regen', r'hồi máu|regeneration|hồi \d+ ?hp'), ('food', r'\băn\b|đói'), ('exh', r'đói'), ('xp', r'\bxp\b'),
      ('killheal', r'hạ mob'), ('minexp', r'đào'), ('minehaste', r'đào'), ('inc', r'sát thương (khi rơi|từ|do)|miễn nhiễm'),
      ('incall', r'mọi sát thương'), ('drain', r'mất 1 máu'), ('out', r'sát thương lên')]
def hand_keys(text):
    t = text.lower(); return {k for k, rx in KW if re.search(rx, t)}

TROLLS = ['t%02d' % i for i in range(1, 26) if i != 21]
troll_use = {t: 0 for t in TROLLS}
for cid, (bs, ds) in spec.items():
    for d in ds:
        if d.startswith('troll:'): troll_use[d[6:]] = troll_use.get(d[6:], 0) + 1
TN = lambda t: L[f'troll.wildcard.{t}']
TD = lambda t: L[f'troll.wildcard.{t}.desc']
def troll_text(t): return f"{TN(t)}: {TD(t)}"

extra_java = []
for cid in ORDER:
    r = rar[cid]; n = COUNT[r]
    if cid in spec:
        bs, ds = spec[cid]
        bkeys = {mkey(x) for x in bs}; dkeys = {mkey(x) for x in ds}
        bdesc = L[f'card.wildcard.{cid}.buff.desc']; ddesc = L[f'card.wildcard.{cid}.debuff.desc']
        nb, nd = len(bs), len(ds)
        # base debuff text: trolls used to say "see the troll list below"
        tr = [x[6:] for x in ds if x.startswith('troll:')]
        if tr:
            parts = [] if ddesc.startswith('Xem danh sách troll') else [ddesc.rstrip('.')]
            ddesc = '. '.join(parts + [troll_text(t) for t in tr])
    else:
        bdesc = L[f'card.wildcard.{cid}.buff.desc']; ddesc = L[f'card.wildcard.{cid}.debuff.desc']
        bkeys = hand_keys(bdesc); dkeys = hand_keys(ddesc); nb = nd = 1
    xb, xd = [], []
    bt, dt = [bdesc.rstrip('. ')], [ddesc.rstrip('. ')]
    tries = 0
    while nb + len(xb) < n and tries < 500:
        tries += 1
        k = R.choice(BK)
        if k in bkeys: continue
        s, d = B(k, r); bkeys.add(k); xb.append(s); bt.append(d)
    ntroll = sum(1 for x in dkeys if x.startswith('troll_'))
    tries = 0
    while nd + len(xd) < n and tries < 500:
        tries += 1
        if r >= 2 and ntroll < 2 and R.random() < 0.4:
            t = min((x for x in TROLLS if 'troll_' + x not in dkeys), key=lambda x: (troll_use[x], R.random()))
            troll_use[t] += 1; ntroll += 1; dkeys.add('troll_' + t); xd.append('troll:' + t); dt.append(troll_text(t)); continue
        k = R.choice(DK)
        if k in dkeys: continue
        s, d = D(k, r); dkeys.add(k); xd.append(s); dt.append(d)
    lang[f'card.wildcard.{cid}.buff.desc'] = '. '.join(bt)
    lang[f'card.wildcard.{cid}.debuff.desc'] = '. '.join(dt)
    if xb or xd:
        jb = ', '.join(f'"{x}"' for x in xb); jd = ', '.join(f'"{x}"' for x in xd)
        extra_java.append(f'        x("{cid}", new String[]{{{jb}}}, new String[]{{{jd}}});')

open(f'{J}/GenExtra.java', 'w').write('''package com.hoang.wildcard;

import static com.hoang.wildcard.Cards.x;

/**
 * GENERATED by gen/v6_cards.py: extra buffs and debuffs so that a card has 1 (Common, Uncommon), 2 (Rare), 3 (Epic),
 * 4 (Legendary) or 5 (Mythic) of each, never two of the same kind. "troll:tXX" entries are troll debuffs.
 */
final class GenExtra {
    static void load() {
''' + '\n'.join(extra_java[:len(extra_java)//2]) + '''
        load2();
    }

    private static void load2() {
''' + '\n'.join(extra_java[len(extra_java)//2:]) + '''
    }

    private GenExtra() {}
}
''')

# =============================================================== 3. unique names (no "II / III / V")
RX = re.compile(r' (I|II|III|IV|V)$')
BUFF_POOL = {
 'speed': ['Chân Gió', 'Dép Lào Thần Tốc', 'Shipper Hỏa Tốc', 'Gót Sắt', 'Chạy Như Bay', 'Thỏ Rừng', 'Ngựa Non', 'Xe Ôm Công Nghệ'],
 'maxhp': ['Cơm Mẹ Nấu', 'Sữa Bò Tươi', 'Nồi Cháo Gà', 'Bò Mộng', 'Gân Trâu', 'Thể Lực Gym', 'Lực Sĩ Làng', 'Bánh Chưng To', 'Tim Gấu', 'Xương Rồng', 'Củ Nhân Sâm', 'Chè Đỗ Đen', 'Đậu Hũ Thần'],
 'attack': ['Nắm Đấm Đá', 'Tay Búa', 'Cú Đấm Thép', 'Găng Đấm Bốc'],
 'armor': ['Áo Giáp Tre', 'Da Tê Giác', 'Mai Rùa', 'Vảy Tê Tê', 'Nồi Đội Đầu', 'Áo Mưa Thép', 'Giáp Vỏ Sò', 'Áo Phao Sắt', 'Khiên Mo Cau'],
 'toughness': ['Lì Đòn', 'Xương Sắt', 'Gân Thép', 'Da Trâu', 'Cột Bê Tông', 'Đá Tảng', 'Kim Cương Thô', 'Gỗ Lim', 'Mặt Đường Nhựa', 'Thớt Nghiến', 'Tường Gạch'],
 'luck': ['Cỏ Bốn Lá', 'Bùa May', 'Mèo Thần Tài', 'Vé Số Trúng', 'Đồng Xu May Mắn', 'Lộc Đầu Năm', 'Móng Ngựa', 'Hên Xui', 'Phong Bao Lì Xì'],
 'kbres': ['Chân Bám Đất', 'Nặng Ký', 'Trụ Cột', 'Gốc Đa', 'Tảng Đá Lăn', 'Bao Cát'],
 'atkspeed': ['Tay Nhanh', 'APM Cao', 'Spam Click', 'Tay Chuột Vàng', 'Liên Hoàn Cước'],
 'reach': ['Tay Dài', 'Gậy Như Ý', 'Cần Câu Dài', 'Cây Sào Tre', 'Tay Vượn', 'Gậy Chọc Xoài', 'Cán Chổi'],
 'swim': ['Kình Ngư', 'Vây Cá', 'Rái Cá', 'Tôm Hùm', 'Chân Vịt', 'Áo Lặn', 'Cá Chuồn', 'Phao Bơi'],
 'inc': ['Da Mặt Dày', 'Miễn Nhiễm', 'Không Đau', 'Đệm Lò Xo', 'Áo Chống Cháy', 'Mũ Bảo Hiểm', 'Bình Cứu Hỏa', 'Khiên Gỗ', 'Áo Chống Đạn',
         'Bùa Chống Phép', 'Áo Phao', 'Bếp Lò Trong Người', 'Đệm Bông', 'Ô Che Mưa Tên', 'Hầm Trú Ẩn', 'Bao Tay Cách Nhiệt', 'Lá Chắn Gió',
         'Mai Rùa Thép', 'Giáp Chống Nổ', 'Áo Len Mẹ Đan', 'Bình Dưỡng Khí', 'Dù Hạ Cánh'],
 'out': ['Khắc Tinh', 'Đồ Tể', 'Pháp Sư Trừ Tà', 'Thợ Săn Ma', 'Thầy Cúng', 'Lá Bùa Vàng', 'Bình Xịt Côn Trùng', 'Vợt Muỗi Điện', 'Cảnh Sát Làng',
         'Ngư Dân', 'Lưới Đánh Cá', 'Thợ Săn Rừng', 'Đao Phủ', 'Kiếm Khách', 'Võ Sư', 'Tỏi Trừ Ma', 'Nước Thánh', 'Cung Thủ Làng', 'Đinh Ba Ngư Phủ',
         'Dao Phay', 'Người Chăn Cừu', 'Bẫy Chuột', 'Rắn Hổ Mang', 'Mèo Bắt Chuột', 'Thánh Kiếm'],
 'killheal': ['Hút Hồn', 'Ăn Mừng', 'Tiếp Sức', 'Hồi Xuân'],
 'killxp': ['Cày Cuốc', 'Thu Hoạch', 'Farm Thủ', 'Thợ Săn Kinh Nghiệm', 'Cày Thuê', 'Đi Săn Đêm', 'Lên Cấp Thần Tốc', 'Máy Cày', 'Cao Thủ Farm', 'Tay Chơi Rank', 'Học Việc Chăm'],
 'killfood': ['Ăn Tại Chỗ', 'Bữa Chiến Thắng', 'Nướng Ngoài Trời', 'Thịt Xiên Nướng'],
 'minexp': ['Thợ Mỏ Chăm', 'Đào Vàng', 'Mạch Quặng', 'Đèn Thợ Mỏ', 'Xe Goòng', 'Búa Chim', 'Thợ Đá', 'Hang Pha Lê', 'Đá Quý', 'Mỏ Than', 'Thợ Khoan', 'Hầm Đá', 'Chim Hoàng Yến', 'Mắt Tìm Quặng'],
 'minehaste': ['Hăng Say', 'Cuốc Thần', 'Cuốc Chim', 'Tay Khoan', 'Máy Xúc', 'Búa Tạ', 'Mũi Khoan Kim Cương', 'Chuột Chũi', 'Đào Hầm', 'Con Kiến Thợ', 'Cuốc Đất Trồng Rau', 'Thợ Đào Giếng', 'Xẻng Vàng', 'Giun Đất', 'Máy Khoan Đá'],
 'regen': ['Tự Lành', 'Ngủ Ngon', 'Thuốc Bổ', 'Trà Gừng', 'Cao Hổ Cốt', 'Dầu Gió', 'Thuốc Nam', 'Lá Xông', 'Nước Dừa', 'Băng Cá Nhân'],
 'food': ['Ăn Khỏe', 'Bụng Bự', 'Ăn No Lâu', 'Nồi Cơm Điện', 'Bánh Mì Pate', 'Phở Bò', 'Cơm Tấm', 'Bún Chả', 'Xôi Gà', 'Cơm Nắm', 'Bánh Bao', 'Hủ Tiếu'],
 'exh': ['Tiết Kiệm', 'Ít Calo', 'Sống Khỏe', 'Thở Đều', 'Yoga Buổi Sáng', 'Ăn Chay', 'Lạc Đà', 'Gấu Ngủ Đông', 'Ống Hút Tre'],
 'xp': ['Học Bá', 'Chăm Học', 'Đọc Sách', 'Thủ Khoa', 'Thư Viện', 'Gia Sư', 'Mọt Sách', 'Học Thêm'],
 'eff_speed': ['Nhanh Như Gió', 'Tăng Tốc', 'Đường Cao Tốc', 'Gió Mùa', 'Ván Trượt', 'Giày Patin', 'Xe Đạp Điện', 'Mèo Hoang'],
 'eff_night_vision': ['Mắt Mèo', 'Đèn Pin', 'Kính Hồng Ngoại', 'Cú Đêm Tinh Mắt'],
 'eff_haste': ['Cuốc Nhanh', 'Tay Máy', 'Thợ Mỏ Ban Ngày', 'Ca Đêm'],
 'eff_strength': ['Cuồng Nộ', 'Hổ Báo', 'Gấu Ngựa', 'Bò Tót'],
 'eff_dolphin': ['Cá Heo', 'Lướt Sóng', 'Cá Heo Hồng'],
 'eff_luck': ['Cầu Được Ước Thấy', 'Số Hưởng', 'Sao Chiếu Mệnh'],
 'eff_slow_fall': ['Lông Ngỗng', 'Dù Lượn', 'Bồ Công Anh'],
 'eff_regen': ['Hồi Phục', 'Bất Khuất', 'Phượng Hoàng Lửa'],
}
GENERIC_BUFF = ['Chill Guy', 'Out Trình', 'Main Character', 'Hảo Hán', 'Cân Team', 'Vua Lì Đòn', 'Thánh Lầy', 'Trùm Cuối', 'Người Hùng Xóm',
 'Bậc Thầy', 'Tay To Óc Bé', 'Phú Ông', 'Lão Làng', 'Đại Ca Lớp', 'Sư Phụ', 'Thần Đồng', 'Ông Hoàng', 'Nữ Hoàng', 'Siêu Sao', 'Cao Thủ Ẩn Danh',
 'Lớp Trưởng', 'Hội Trưởng', 'Trưởng Thôn', 'Cụ Non', 'Ông Bụt', 'Bà Tiên', 'Chú Cuội', 'Thánh Gióng', 'Sơn Tinh', 'Thạch Sanh', 'Trạng Quỳnh',
 'Mèo Ú', 'Chó Mực', 'Trâu Vàng', 'Gà Chọi', 'Đại Bàng', 'Hổ Mang Chúa', 'Sói Đầu Đàn', 'Gấu Bắc Cực', 'Cá Mập Con']
DEBUFF_POOL = {
 'speed': ['Chân Ngắn', 'Dép Tuột Quai', 'Kẹt Xe', 'Rùa Bò', 'Ốc Sên', 'Bùn Lầy', 'Giày Chật', 'Chuột Rút', 'Sên Trần'],
 'maxhp': ['Cảm Cúm', 'Thiếu Ngủ', 'Đau Răng', 'Đau Lưng', 'Dị Ứng', 'Sốt Nhẹ', 'Còi Xương', 'Thiếu Máu', 'Ho Khan', 'Đau Bụng', 'Viêm Họng', 'Gầy Nhom'],
 'attack': ['Tay Run', 'Tay Mềm Như Bún', 'Đấm Như Muỗi', 'Gãy Móng', 'Kiếm Cùn', 'Bong Gân'],
 'armor': ['Áo Rách', 'Giáp Giấy', 'Áo Thủng', 'Đồ Si', 'Giáp Bìa Các Tông', 'Áo Lưới', 'Giáp Nhựa', 'Áo Mỏng Tang', 'Giáp Rỉ Sét', 'Áo Ba Lỗ', 'Áo Mưa Rách', 'Giáp Vỡ', 'Quần Đùi', 'Giáp Thiếc', 'Áo Hở Vai'],
 'luck': ['Đen Thôi Đỏ Quên Đi', 'Mèo Đen Qua Đường', 'Gương Vỡ', 'Thứ Sáu Ngày 13', 'Xui Tận Mạng', 'Vé Số Trật', 'Quạ Kêu', 'Bước Chân Trái', 'Hạn Tam Tai', 'Sao Quả Tạ', 'Bể Gương', 'Rơi Đũa'],
 'atkspeed': ['Lag Như Mạng Nhà', 'Ping 999', 'Chuột Hỏng', 'Bàn Phím Kẹt', 'FPS Thấp', 'Tay Lười', 'Đứng Hình', 'Delay Đòn', 'Rớt Khung Hình', 'Chuột Hết Pin', 'Tay Cóng', 'Màn Hình Đơ'],
 'reach': ['Tay Ngắn', 'Với Không Tới', 'Khủng Long Tay Ngắn', 'Cánh Tay Cụt', 'Gậy Gãy', 'Mắt Kém', 'Cận Thị', 'Lùn Tịt', 'Tay Khoèo', 'Loạn Thị'],
 'inc': ['Da Giấy', 'Mỏng Manh', 'Dễ Vỡ', 'Sợ Lửa', 'Sợ Nước', 'Sợ Độ Cao', 'Bình Gas Rò', 'Bánh Đa Nhúng Nước', 'Thủy Tinh', 'Bóng Đèn Dây Tóc', 'Bông Gòn',
         'Kính Cận Vỡ', 'Đồ Sứ', 'Bia Tập Bắn', 'Bù Nhìn Rơm', 'Pháo Tép', 'Người Tuyết Tan', 'Hũ Sành', 'Bong Bóng Xà Phòng', 'Ly Thủy Tinh', 'Trứng Gà', 'Vỏ Trứng', 'Giấy Ăn', 'Cánh Chuồn'],
 'incall': ['Mỏng Như Lá Lúa', 'Hết Cứu', 'Ét O Ét', 'Toang', 'Da Bánh Tráng', 'Tờ Giấy Ướt', 'Búp Bê Sứ', 'Thủy Tinh Mỏng', 'Bánh Phồng Tôm', 'Vỏ Bánh Đa', 'Con Gà Công Nghiệp', 'Thịt Bò Khô', 'Bánh Quy Giòn'],
 'out': ['Đánh Như Gãi', 'Tay Mơ', 'Gà Mờ', 'Noob', 'Kiếm Gỗ', 'Sợ Ma', 'Sợ Nhện', 'Thương Động Vật', 'Không Nỡ Đánh', 'Ngại Va Chạm', 'Sợ Cá', 'Hiền Như Bụt',
         'Sợ Dân Làng', 'Tay Lụa', 'Mắt Lé', 'Đánh Hụt', 'Bắn Trượt', 'Sợ Xương', 'Ăn Chay Niệm Phật', 'Yêu Hòa Bình'],
 'killhurt': ['Bị Report', 'Nghiệp Quật', 'Ác Giả Ác Báo', 'Gậy Ông Đập Lưng Ông', 'Tự Vả', 'Đòn Phản Đòn', 'Quả Báo', 'Hồi Mã Thương'],
 'killhunger': ['Cháy Túi', 'Đánh Xong Đói', 'Bụng Réo', 'Mệt Bở Hơi Tai', 'Đuối Sức', 'Đói Meo', 'Thở Dốc'],
 'minehurt': ['Đá Văng', 'Sạt Lở', 'Vụn Đá', 'Bụi Than', 'Hầm Sập', 'Quặng Gai', 'Búa Tuột Tay', 'Bụi Mù', 'Đá Rơi'],
 'drain': ['Pin Yếu', 'Sập Nguồn', 'Màn Hình Xanh', 'Hao Pin', 'Rò Điện', 'Rỉ Máu', 'Đỉa Bám', 'Muỗi Đốt', 'Kiến Cắn', 'Hết Năng Lượng', 'Rò Rỉ', 'Chảy Máu Cam'],
 'food': ['Ăn Không Tiêu', 'Đau Dạ Dày', 'Đồ Ăn Nguội', 'Cơm Khê', 'Mì Gói Nở', 'Kén Ăn', 'Cơm Sống', 'Ăn Vạ', 'Bánh Mì Thiu', 'Ngộ Độc', 'Cháo Loãng',
          'Canh Mặn', 'Ăn Vặt', 'Biếng Ăn', 'Tiêu Chảy', 'Lẩu Nguội', 'Cơm Cháy', 'Đồ Ăn Hết Hạn', 'Trà Sữa Ít Trân Châu', 'Nước Lã'],
 'exh': ['Thở Hổn Hển', 'Lười Biếng', 'Ngủ Gật', 'Đói Bụng', 'Bụng Không Đáy', 'Mau Đói', 'Hết Hơi', 'Tụt Huyết Áp'],
 'xp': ['Mất Gốc', 'Nợ Môn', 'Quên Bài', 'Học Trước Quên Sau', 'Trốn Học', 'Bị Ghi Sổ', 'Thi Lại', 'Đãng Trí', 'Não Cá Vàng', 'Ngủ Trong Lớp', 'Lười Đọc Sách', 'Học Vẹt', 'Chép Bài', 'Bị Điểm Kém', 'Ngồi Bàn Cuối'],
 'eff_weakness': ['Yếu Như Sên', 'Bủn Rủn', 'Run Tay', 'Rã Rời', 'Thiếu Sắt', 'Ẻo Lả', 'Mỏi Gối', 'Uể Oải', 'Liệt Cơ', 'Đuối'],
 'eff_slowness': ['Ì Ạch', 'Lề Mề', 'Chậm Như Rùa', 'Chân Chì', 'Lết Bết', 'Nặng Nề', 'Đi Cà Nhắc', 'Lừ Đừ', 'Chậm Chạp'],
 'eff_darkness': ['Mất Điện', 'Sợ Bóng Tối', 'Cúp Điện', 'Hết Nến', 'Đèn Hỏng', 'Mù Đêm'],
 'eff_hunger': ['Đói Lả', 'Bụng Đói Cồn Cào', 'Thèm Ăn'],
 'eff_fatigue': ['Mệt Mỏi', 'Rã Tay', 'Ngán Việc'],
 'eff_unluck': ['Xui Xẻo', 'Vận Đen', 'Đen Đủi'],
 'troll': [],
}
GENERIC_DEBUFF = ['Ủa Alo', 'Báo Thủ', 'Tới Công Chuyện', 'Khóc Thét', 'Tạch', 'Cay', 'Hack Não', 'Not Stonks', 'Sus', 'Afk', 'Rớt Mạng',
 'Quên Mật Khẩu', 'Trầm Cảm', 'Thứ Hai Đầu Tuần', 'Deadline Dí', 'Hết 4G', 'Bug Game', 'Lỗi 404', 'Say Xỉn', 'Hậu Đậu', 'Vụng Về', 'Mắc Mưa', 'Tụt Mood',
 'Tóc Bết', 'Bị Bùng Kèo', 'Mất Wifi', 'Spam Tin Nhắn', 'Bị Seen', 'Cú Đêm', 'Ế Bền Vững', 'Ohio', 'Ao Trình', 'Gánh Còng Lưng', 'Phông Bạt', 'Xu Cà Na',
 'Còn Cái Nịt', 'Bruh', 'Cháy Máy', 'Đứt Cáp', 'Quạt Trần Kêu', 'Hàng Xóm Hát Karaoke', 'Muỗi Vo Ve', 'Mưa Dột', 'Nồi Cơm Khét', 'Quên Chìa Khóa',
 'Mất Dép', 'Kẹt Thang Máy', 'Thủng Lốp', 'Hết Xăng', 'Trễ Xe Buýt', 'Ngủ Quên', 'Báo Thức Hỏng', 'Đứt Dây Giày', 'Rơi Điện Thoại', 'Vỡ Màn Hình',
 'Hết Tiền Điện Thoại', 'Bị Chó Đuổi', 'Ong Đốt', 'Giẫm Phải Lego', 'Cắn Phải Lưỡi', 'Nấc Cụt', 'Hắt Xì Liên Tục', 'Tê Chân', 'Vấp Ngưỡng Cửa',
 'Mất Sổ Đỏ', 'Đi Lạc', 'Quên Đường Về', 'Đánh Rơi Ví', 'Ướt Như Chuột Lột', 'Cảm Nắng', 'Say Sóng', 'Say Xe', 'Mất Ngủ', 'Mơ Ác Mộng', 'Sún Răng',
 'Rụng Tóc', 'Gàu Bay', 'Mụn Bọc', 'Hôi Nách', 'Hôi Chân', 'Đầu Bù Tóc Rối', 'Quần Rách Gối', 'Áo Mặc Ngược', 'Đi Nhầm Dép', 'Ăn Nhầm Ớt', 'Uống Nhầm Giấm',
 'Bị Phạt Đứng', 'Bị Mẹ Mắng', 'Bị Cô Gọi Lên Bảng', 'Quên Làm Bài Tập', 'Hết Giờ Chơi', 'Bị Tịch Thu Điện Thoại', 'Cắt Mạng', 'Bị Khóa Tài Khoản',
 'Quên Lưu Game', 'Mất Save', 'Tải Lại Từ Đầu', 'Server Bảo Trì', 'Cập Nhật 99%', 'Bàn Phím Thiếu Phím', 'Tai Nghe Rè', 'Mic Hú', 'Webcam Mờ',
 'Màn Hình Sọc', 'Chuột Nhảy Lung Tung', 'Máy Nóng Ran', 'Quạt Tản Nhiệt Kêu', 'Ổ Cứng Đầy', 'Virus Máy Tính', 'Quảng Cáo Bật Lên', 'Popup Phiền Phức',
 'Gà Gáy Sớm', 'Chó Sủa Đêm', 'Mèo Cào', 'Chuột Gặm', 'Gián Bay', 'Thằn Lằn Rơi', 'Bị Nhện Giăng', 'Kiến Lửa', 'Rết Bò', 'Ong Vò Vẽ',
 'Trời Nồm', 'Nắng Gắt', 'Gió Lùa', 'Sương Mù', 'Đường Trơn', 'Ổ Gà', 'Ngập Nước', 'Mất Nước', 'Cúp Nước', 'Bể Ống Nước']
used_b, used_d = set(), set()
def first_key(lst, bad):
    if not lst: return None
    k = mkey(lst[0])
    return 'troll' if k.startswith('troll_') else k
taken_b = {DESIGN[c][0] for c in DESIGN}
def pick(pool, generic, used):
    for nm in R.sample(pool, len(pool)) if pool else []:
        if nm not in used: return nm
    for nm in R.sample(generic, len(generic)):
        if nm not in used: return nm
    raise RuntimeError('out of names')
# keep every hand-made name and the first gen use of a name; rename the rest
for cid in ORDER:
    bn = L[f'card.wildcard.{cid}.buff']; dn = L[f'card.wildcard.{cid}.debuff']
    if cid in DESIGN:
        bn = DESIGN[cid][0]
    elif cid not in spec:
        pass
    else:
        base = RX.sub('', bn)
        if RX.search(bn) or base in used_b or base in taken_b:
            bn = pick(BUFF_POOL.get(first_key(spec[cid][0], False), []), GENERIC_BUFF, used_b | taken_b)
        else:
            bn = base
    used_b.add(bn)
    if cid in spec:
        base = RX.sub('', dn)
        if RX.search(dn) or base in used_d:
            dn = pick(DEBUFF_POOL.get(first_key(spec[cid][1], True), []), GENERIC_DEBUFF, used_d)
        else:
            dn = base
    used_d.add(dn)
    lang[f'card.wildcard.{cid}.buff'] = bn
    lang[f'card.wildcard.{cid}.debuff'] = dn
# report leftovers
bnames = [lang[f'card.wildcard.{c}.buff'] for c in ORDER]; dnames = [lang[f'card.wildcard.{c}.debuff'] for c in ORDER]
from collections import Counter
dupb = [k for k, v in Counter(bnames).items() if v > 1]; dupd = [k for k, v in Counter(dnames).items() if v > 1]
print('dup buff names', dupb); print('dup debuff names', dupd)
print('roman left', [n for n in bnames + dnames if RX.search(n)])

open(f'{J}/GenData.java', 'w').write(gd)
L.update(lang)
for p in LANGS:
    json.dump(L, open(p, 'w'), ensure_ascii=False, indent=2)
print('removed skills', removed_sk, 'extras', len(extra_java), 'troll use', sorted(troll_use.values()))
