import json, re
J = '/home/claude/wildcard-mod/src/main/java/com/hoang/wildcard'
gen = json.load(open('skills_gen.json'))
fx = open(f'{J}/fx/SkillFx.java').read()
hand = {}
for m in re.finditer(r'put\(Element\.(\w+),([^;]*)\);', fx, re.S):
    for k in re.findall(r'"(\w+):(\d)"', m.group(2)):
        hand[k] = m.group(1).lower()
cards = open(f'{J}/Cards.java').read()
orig = {m.group(1): m.group(2) for m in re.finditer(r'sk1\("(\w+)", (\d+),', cards)}
ids = sorted(set(re.findall(r'add\("(\w+)"', cards)) | set(re.findall(r'card\("(\w+)"', open(f'{J}/GenData.java').read())))
S = {}
for n in ['spin', 'flip', 'vip', 'legendary', 'mythic', 'meme']:
    S[f'roll.{n}'] = {'subtitle': f'subtitles.wildcard.roll', 'sounds': [f'wildcard:roll/{n}']}
for n in ['vineboom', 'bruh', 'rickroll', 'trap', 'jackpot', 'lapeace', 'sus', 'fail', 'sigma']:
    S[f'meme.{n}'] = {'subtitle': f'subtitles.wildcard.meme.{n}', 'sounds': [f'wildcard:meme/{n}']}
special = {'u61': 'meme/lapeace', 'u62': 'skill/storm', 'u63': 'meme/trap', 'u64': 'meme/jackpot'}
for cid in ids:
    if cid in special: snd = special[cid]
    elif cid in gen: snd = 'skill/' + gen[cid]['el']
    elif cid in orig: snd = 'skill/' + hand.get((cid, orig[cid]), 'arcane')
    else: snd = 'skill/arcane'
    S[f'card.{cid}'] = {'subtitle': 'subtitles.wildcard.skill', 'sounds': [f'wildcard:{snd}']}
S['meme.jackpot_win'] = {'subtitle': 'subtitles.wildcard.meme.jackpot', 'sounds': [{'name': 'wildcard:meme/jackpot_win', 'stream': True}]}
for e in ['arcane','fire','frost','storm','blood','void','holy','earth','wind']:
    S[f'impact.{e}'] = {'subtitle': 'subtitles.wildcard.impact', 'sounds': [f'wildcard:impact/{e}']}
json.dump(S, open('/home/claude/wildcard-mod/src/main/resources/assets/wildcard/sounds.json', 'w'), indent=1)
print(len(ids), 'cards', len(S), 'events')
# subtitles
L = {'subtitles.wildcard.roll': 'Lật thẻ', 'subtitles.wildcard.skill': 'Dùng kỹ năng', 'subtitles.wildcard.impact': 'Phép nổ'}
for n, v in {'vineboom': 'BOOM!', 'bruh': 'Bruh', 'rickroll': 'Nhạc rickroll', 'trap': 'Bài bẫy!', 'jackpot': 'Nổ hũ',
             'lapeace': 'La Peace ✌', 'sus': 'Có kẻ sus', 'fail': 'Thất bại', 'sigma': 'Sigma'}.items():
    L[f'subtitles.wildcard.meme.{n}'] = v
for fn in ['vi_vn', 'en_us']:
    p = f'/home/claude/wildcard-mod/src/main/resources/assets/wildcard/lang/{fn}.json'
    d = json.load(open(p)); d.update(L); json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
