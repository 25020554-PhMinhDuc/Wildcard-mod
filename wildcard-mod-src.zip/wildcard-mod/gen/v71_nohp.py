"""v7.1: thay các bất lợi mất máu (drain, kill:hurt, mine:hurt, attr:maxhp âm) bằng bất lợi khác."""
import json, re, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = os.path.join(ROOT, 'src/main/java/com/hoang/wildcard')
LANGS = [os.path.join(ROOT, 'src/main/resources/assets/wildcard/lang', f) for f in ('vi_vn.json', 'en_us.json')]
def num(x): return (f"{x:.2f}".rstrip('0').rstrip('.')).replace('.', ',')
def pct(x): return f"{round(x*100)}%"
TIER = {'c': 0, 'u': 1, 'r': 2, 'e': 3, 'l': 4, 'm': 4}

def old_text(spec):
    a = spec.split(':')
    if a[0] == 'drain': return f"Cứ {a[1]} giây mất 1 máu (không chết vì cái này)"
    if a[:2] == ['kill', 'hurt']: return f"Hạ mob: tự mất {num(float(a[2]))} máu"
    if a[:2] == ['mine', 'hurt']: return f"Đào khối: {a[2]}% bị đá văng vào mặt (mất 1 máu)"
    if a[:2] == ['attr', 'maxhp']: return f"Máu tối đa -{num(-float(a[2]) / 2)} tim"
def bad(spec):
    a = spec.split(':')
    return a[0] == 'drain' or a[:2] in (['kill', 'hurt'], ['mine', 'hurt']) or (a[:2] == ['attr', 'maxhp'] and float(a[2]) < 0)
def fam(spec):
    a = spec.split(':')
    if a[0] in ('attr', 'kill', 'mine'): return a[0] + a[1]
    if a[0] == 'inc' and a[1] == 'all': return 'incall'
    return a[0]

def D(k, t):
    if k == 'killhunger': v = [1, 2, 3, 4, 5][t]; return f"kill:hunger:{v}", f"Hạ mob: mất {v} điểm đói"
    if k == 'food': v = [1, 1, 2, 2, 3][t]; return f"food:-{v}", f"Ăn gì cũng bớt {v} điểm đói"
    if k == 'exh': v = [1.3, 1.5, 1.75, 2, 2.5][t]; return f"exh:{v}", f"Tốn đói gấp {num(v)} lần"
    if k == 'xp': v = [.85, .75, .6, .5, .4][t]; return f"xp:{v}", f"XP nhận được -{pct(1-v)}"
    if k == 'attrattack': v = [1, 1.5, 2, 2.5, 3][t]; return f"attr:attack:-{v}", f"Sát thương cận chiến -{num(v)}"
    if k == 'attratkspeed': v = [.1, .15, .2, .25, .3][t]; return f"attr:atkspeed:-{v}", f"Tốc đánh -{pct(v)}"
    if k == 'attrreach': v = [.5, .75, 1, 1.25, 1.5][t]; return f"attr:reach:-{v}", f"Tầm với -{num(v)} khối"
    if k == 'attrluck': v = [1, 2, 3, 4, 5][t]; return f"attr:luck:-{v}", f"Xui Xẻo: May Mắn -{v}"
    if k == 'attrarmor': v = [2, 3, 4, 5, 6][t]; return f"attr:armor:-{v}", f"Giáp -{v}"
    if k == 'attrspeed': v = [.08, .12, .18, .22, .3][t]; return f"attr:speed:-{v}", f"Tốc chạy -{pct(v)}"
ORDER = ['exh', 'attratkspeed', 'killhunger', 'xp', 'attrreach', 'food', 'attrattack', 'attrluck', 'attrarmor', 'attrspeed']
NAMES = {'exh': ['Bụng Không Đáy', 'Ăn Hoài Không No', 'Dạ Dày Thủng', 'Đói Bụng Hoài', 'Ham Ăn'],
         'attratkspeed': ['Tay Mỏi', 'Tay Run', 'Cổ Tay Đau', 'Vung Chậm', 'Tay Lười'],
         'killhunger': ['Hì Hục', 'Đánh Mệt', 'Sau Trận Đói', 'Mồ Hôi Nhễ Nhại', 'Hao Sức'],
         'xp': ['Học Chậm', 'Não Cá Vàng', 'Hay Quên', 'Lơ Đãng', 'Mất Tập Trung'],
         'attrreach': ['Tay Ngắn', 'Tay Khủng Long', 'Với Không Tới', 'Cánh Tay Cụt', 'Tay Ngắn Tũn'],
         'food': ['Kén Ăn', 'Nhạt Miệng', 'Biếng Ăn', 'Ăn Không Ngon', 'Đồ Ăn Ôi'],
         'attrattack': ['Đấm Yếu', 'Tay Bông', 'Nắm Đấm Mềm', 'Đấm Như Gãi', 'Lực Tay Yếu'],
         'attrluck': ['Đen Đủi', 'Số Nhọ', 'Xui Tận Mạng', 'Mèo Đen Ngang Đường', 'Sao Quả Tạ'],
         'attrarmor': ['Giáp Rỉ', 'Áo Rách', 'Giáp Giấy', 'Áo Mỏng', 'Khóa Giáp Lỏng'],
         'attrspeed': ['Chân Nặng', 'Dép Tổ Ong', 'Chậm Như Sên', 'Chân Chì', 'Lết Bộ']}

lang = [json.load(open(f, encoding='utf-8')) for f in LANGS]
L = lang[0]
used_names = set(v for k, v in L.items() if k.startswith('card.wildcard.') and k.count('.') == 3)
changed = []
for fn in ('GenData.java', 'GenExtra.java'):
    path = os.path.join(J, fn); src = open(path, encoding='utf-8').read()
    def fix(m):
        line = m.group(0)
        cid = re.search(r'\("(\w+)"', line).group(1)
        arrs = re.findall(r'new String\[\]\{([^}]*)\}', line)
        deb = re.findall(r'"([^"]+)"', arrs[1])
        if not any(bad(s) for s in deb): return line
        t = TIER[cid[0]]
        # families already on the debuff side (generated + extras)
        fams = set(fam(s) for s in deb if not bad(s))
        for other in ('GenData.java', 'GenExtra.java'):
            pass
        new = []
        key = f'card.wildcard.{cid}.debuff.desc'
        for s in deb:
            if not bad(s): new.append(s); continue
            k = next(k for k in ORDER[(hash(cid) % 3):] + ORDER if k not in fams)
            fams.add(k)
            spec, txt = D(k, t)
            new.append(spec)
            for d in lang:
                if key in d:
                    ot = old_text(s)
                    if ot in d[key]: d[key] = d[key].replace(ot, txt)
                    else: print('WARN text not found', cid, ot, '|', d[key])
            # tên bất lợi của thẻ 1 bất lợi đặt theo họ cũ -> đổi tên
            if len(deb) == 1:
                nk = f'card.wildcard.{cid}.debuff'
                nm = next((n for n in NAMES[k] if n not in used_names), None)
                if nm:
                    used_names.add(nm)
                    for d in lang: d[nk] = nm
            changed.append((cid, s, spec))
        newarr = 'new String[]{' + ', '.join(f'"{x}"' for x in new) + '}'
        i = line.rfind('new String[]{' + arrs[1] + '}')
        return line[:i] + newarr + line[i + len('new String[]{' + arrs[1] + '}'):]
    src = re.sub(r'^\s*(card|x)\(.*$', fix, src, flags=re.M)
    open(path, 'w', encoding='utf-8').write(src)
for f, d in zip(LANGS, lang):
    json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(len(changed), 'mods replaced')
for c in changed: print(*c)
