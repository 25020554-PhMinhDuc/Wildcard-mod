# Synthesised placeholder sounds (original, no samples). Replace any .ogg with your own clip of the same name.
import numpy as np, subprocess, os, json, wave
SR = 22050
OUT = '/home/claude/wildcard-mod/src/main/resources/assets/wildcard/sounds'
os.makedirs(OUT + '/impact', exist_ok=True)
rng = np.random.default_rng(7)
def t(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.01, r=0.2):
    e = np.ones(n); A = min(n, int(SR * a)); R = min(n - A, int(SR * r))
    if A: e[:A] = np.linspace(0, 1, A)
    if R: e[-R:] *= np.linspace(1, 0, R)
    return e
def tone(f, d, kind='sine', a=0.01, r=0.2, vol=0.5):
    x = t(d); ph = 2 * np.pi * np.cumsum(np.full(len(x), f) if np.isscalar(f) else f) / SR
    if kind == 'sine': w = np.sin(ph)
    elif kind == 'square': w = np.sign(np.sin(ph)) * 0.6
    elif kind == 'saw': w = 2 * ((ph / (2 * np.pi)) % 1) - 1
    else: w = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)
    return w * env(len(x), a, r) * vol
def noise(d, vol=0.5, a=0.005, r=0.2, lp=0.0):
    w = rng.uniform(-1, 1, int(SR * d))
    if lp:
        out = np.zeros_like(w); y = 0
        for i, v in enumerate(w): y += lp * (v - y); out[i] = y
        w = out / (np.abs(out).max() + 1e-9)
    return w * env(len(w), a, r) * vol
def seq(parts, gap=0.0):
    out = []
    for p in parts:
        out.append(p); out.append(np.zeros(int(SR * gap)))
    return np.concatenate(out)
def mix(*xs):
    n = max(len(x) for x in xs); o = np.zeros(n)
    for x in xs: o[:len(x)] += x
    return o
def glide(f0, f1, d): return np.linspace(f0, f1, int(SR * d))
def reverb(x, delay=0.06, fb=0.35, n=5):
    o = np.concatenate([x, np.zeros(int(SR * delay * n))])
    for k in range(1, n + 1):
        D = int(SR * delay * k); o[D:D + len(x)] += x * (fb ** k)
    return o
def save(name, x):
    x = x / (np.abs(x).max() + 1e-9) * 0.85
    pcm = (x * 32767).astype(np.int16)
    wav = f'/tmp/claude-0/{os.path.basename(name)}.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-c:a', 'libvorbis', '-q:a', '3', f'{OUT}/{name}.ogg'], check=True)
    os.remove(wav)
N = lambda m: 440 * 2 ** ((m - 69) / 12)
# v3.3: impact sound per school (original synthesis)
save('impact/fire', mix(noise(0.7, 0.9, a=0.002, r=0.6, lp=0.08), tone(glide(120, 40, 0.6), 0.6, 'sine', a=0.002, r=0.4, vol=0.8)))
save('impact/frost', mix(noise(0.25, 0.5, a=0.001, r=0.2), reverb(seq([tone(N(m), 0.06, 'sine', a=0.001, r=0.05, vol=0.4) for m in (100, 96, 103, 98)]))))
save('impact/storm', mix(noise(0.5, 1.0, a=0.0005, r=0.45), tone(glide(80, 35, 0.5), 0.5, 'square', a=0.001, r=0.4, vol=0.4)))
save('impact/blood', mix(noise(0.18, 0.6, a=0.001, r=0.15, lp=0.2), tone(glide(160, 60, 0.2), 0.2, 'sine', a=0.001, r=0.15, vol=0.8)))
save('impact/void', reverb(mix(tone(glide(90, 30, 0.7), 0.7, 'saw', a=0.005, r=0.5, vol=0.6), noise(0.4, 0.3, a=0.01, r=0.3, lp=0.05))))
save('impact/holy', reverb(mix(*[tone(N(m), 0.5, 'organ', a=0.005, r=0.45, vol=0.3) for m in (84, 88, 91, 96)], noise(0.15, 0.3, a=0.001, r=0.12))))
save('impact/earth', mix(noise(0.6, 1.0, a=0.003, r=0.5, lp=0.03), tone(glide(60, 30, 0.6), 0.6, 'sine', a=0.002, r=0.5, vol=0.9)))
save('impact/wind', noise(0.5, 0.7, a=0.05, r=0.4, lp=0.1) * (0.5 + 0.5 * np.sin(2 * np.pi * 6 * t(0.5))))
save('impact/arcane', reverb(mix(tone(glide(1400, 500, 0.3), 0.3, 'sine', a=0.001, r=0.25, vol=0.5), noise(0.12, 0.3, a=0.001, r=0.1))))
