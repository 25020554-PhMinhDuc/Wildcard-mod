# v3.3: gives some generated skills the new spells (fireball, starfall, black_hole, ice_shield, sunbeam).
import json, re, random, sys
sys.argv = ['x', '/tmp/claude-0/unused']; sys.path.insert(0, '/home/claude/gen')
import icons
R = random.Random(3303)
ROOT = '/home/claude/wildcard-mod'
GD = f'{ROOT}/src/main/java/com/hoang/wildcard/GenData.java'
TIER = {'c': 0, 'u': 1, 'r': 2, 'e': 3, 'l': 4}
def num(x): return (f"{x:.1f}".rstrip('0').rstrip('.')).replace('.', ',')
NEW = {  # kind: (element, name, desc, a[tier], b[tier], cd[tier], icon)
 'fireball': ('fire', 'Đại Hỏa Cầu', lambda a, b: f'Ném quả cầu lửa lớn, nổ bán kính {num(b)} khối: {num(a)} sát thương, đốt và hất văng', [4, 6, 9, 12, 16], [2.5, 3, 3.5, 4, 5], [20, 18, 16, 14, 12], 'explosion'),
 'starfall': ('arcane', 'Mưa Sao Băng', lambda a, b: f'12 sao băng rơi quanh chỗ bạn nhìn (bán kính {num(b)} khối), mỗi viên {num(a)} sát thương', [2, 2.5, 3.5, 4.5, 6], [4, 5, 5, 6, 7], [40, 36, 32, 28, 24], 'meteor'),
 'black_hole': ('void', 'Hố Đen', lambda a, b: f'Mở hố đen 3 giây hút kẻ địch trong {num(b)} khối rồi sụp đổ: {num(a)} sát thương', [4, 6, 8, 11, 14], [5, 6, 7, 8, 9], [45, 40, 36, 32, 28], 'blackhole'),
 'ice_shield': ('frost', 'Khiên Băng', lambda a, b: f'Mảnh băng xoay quanh bạn {int(b)} giây: giảm sát thương, thêm giáp, đóng băng kẻ lại gần', [4, 6, 8, 10, 12], [6, 8, 10, 12, 14], [35, 32, 30, 26, 22], 'snow'),
 'sunbeam': ('holy', 'Cột Sáng Thần', lambda a, b: f'Giáng cột sáng từ trời xuống mục tiêu: {num(a)} sát thương (gấp đôi với undead), hồi máu cho bạn', [4, 6, 8, 11, 14], [0]*5, [22, 20, 18, 16, 14], 'sun'),
}
# which existing kinds may be converted, and into what
FROM = {'meteor': ['fireball', 'starfall'], 'bolt': ['sunbeam', 'fireball'], 'shield': ['ice_shield'], 'pull': ['black_hole'],
        'nova': ['starfall', 'black_hole'], 'breath': ['fireball'], 'acid_orb': ['black_hole'], 'blood_slash': ['starfall']}
QUOTA = {'meteor': 15, 'bolt': 8, 'shield': 7, 'pull': 5, 'nova': 6, 'breath': 2, 'acid_orb': 2, 'blood_slash': 1}
src = open(GD).read(); lines = src.split('\n')
gen = json.load(open('/home/claude/gen/skills_gen.json'))
lang = {}; done = {}; used = {k: 0 for k in QUOTA}
cands = [(i, l) for i, l in enumerate(lines) if re.match(r'\s*skill\("(\w+)", "(\w+)"', l)]
R.shuffle(cands)
for i, l in cands:
    cid, kind = re.match(r'\s*skill\("(\w+)", "(\w+)"', l).groups()
    if kind not in QUOTA or used[kind] >= QUOTA[kind]: continue
    used[kind] += 1
    new = R.choice(FROM[kind]); t = TIER[cid[0]]
    el, name, desc, A, B, CD, ic = NEW[new]
    a, b, cd = A[t], B[t], CD[t]
    lines[i] = f'        skill("{cid}", "{new}", "{el}", {a}, {b}, "", 0, {cd});'
    lang[f'skill.wildcard.{cid}.0'] = name
    lang[f'skill.wildcard.{cid}.0.desc'] = desc(a, b)
    gen[cid] = dict(kind=new, el=el, a=a, b=b, eff='', amp=0, cd=cd, name=name, desc=desc(a, b))
    icons.icon(el, ic).save(f'{ROOT}/src/main/resources/assets/wildcard/textures/gui/skill/{cid}_0.png')
    done[cid] = new
open(GD, 'w').write('\n'.join(lines))
json.dump(gen, open('/home/claude/gen/skills_gen.json', 'w'), ensure_ascii=False)
for fn in ['vi_vn', 'en_us']:
    p = f'{ROOT}/src/main/resources/assets/wildcard/lang/{fn}.json'
    d = json.load(open(p)); d.update(lang); json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
json.dump(done, open('/home/claude/gen/spells_v33.json', 'w'), indent=1)
from collections import Counter
print(len(done), Counter(done.values()), Counter(c[0] for c in done))
