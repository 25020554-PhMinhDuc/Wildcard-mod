"""v7.1: thẻ mới chép từ ảnh của người dùng (cards.zip). Sinh V71Data.java + chữ trong lang."""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# id, rarity, buff icon, debuff icon, buff name, buff desc, debuff name, debuff desc, buff specs, debuff specs
C = [
 ("c151","COMMON","ARROW","DRAGON_EGG","Kẻ Né Cung Tên","-10% sát thương tầm xa nhận vào","Rồng Khỏe","Rồng Ender nhận thêm 10% máu tối đa",["inc:projectile:0.9"],[]),
 ("c152","COMMON","OAK_STAIRS","PLAYER_HEAD","Đi 2 Bước Cầu Thang","Bước lên được khối cao thêm 1","Một Vị Khách?","Thỉnh thoảng một người chơi lạ \"tham gia\" thế giới của bạn",[],[]),
 ("c153","COMMON","GOLDEN_SWORD","RABBIT_HIDE","Nhanh Tay","+15% tốc độ đánh","Đầu Gối Cứng","-15% sức nhảy",["attr:atkspeed:0.15"],[]),
 ("c154","COMMON","SNOWBALL","NETHERRACK","Đầu Lạnh","-25% sát thương lửa nhận vào","Phổi Lưu Huỳnh","Bị Đào Chậm khi ở Nether",["inc:fire:0.75"],["eff:fatigue:0:nether"]),
 ("c155","COMMON","BOW","INK_SAC","Con Mắt Cung Thủ","+10% sát thương tầm xa gây ra","Nỗi Sợ Nước","Bị Bóng Tối khi ở dưới nước",[],["eff:darkness:0:water"]),
 ("c156","COMMON","IRON_INGOT","WOODEN_SWORD","Da Sắt","+1 giáp","Lưỡi Kiếm Cùn","-10% sát thương gây ra",["attr:armor:1"],["out:all:0.9"]),
 ("c157","COMMON","PISTON","PUFFERFISH","Knock Knock","+0,2 đẩy lùi","Phổi Yếu","+50% sát thương chết đuối",[],["inc:drown:1.5"]),
 ("c158","COMMON","RABBIT_FOOT","WATER_BUCKET","Nhanh Nhẹn","+15% sức nhảy","Trời Âm U","Bị Chậm Chạp khi trời mưa",[],["eff:slowness:0:rain"]),
 ("c159","COMMON","SPECTRAL_ARROW","ANVIL","Bao Đựng Tên Vô Đáy","12,5% tỉ lệ không tốn mũi tên khi bắn","Bel","+50% trọng lực",[],[]),
 ("c160","COMMON","STICK","LEATHER_CHESTPLATE","Tầm Đánh Xa","+0,5 tầm đánh","Sơ Hở","+10% sát thương nhận vào",["attr:reach:0.5"],["inc:all:1.1"]),
 ("u201","UNCOMMON","IRON_SWORD","BLAZE_ROD","Đánh Đau","+20% sát thương cận chiến","Thick Blaze","Blaze nhận thêm 30% máu",[],[]),
 ("u202","UNCOMMON","SLIME_BLOCK","FEATHER","Bước Đệm Trên Không","+35% sức nhảy","Cơn Gió Bất Chợt","Cứ 20 giây một cơn gió đẩy bạn đi",[],[]),
 ("u203","UNCOMMON","LANTERN","SCULK_SENSOR","Mũ Thợ Mỏ","Nhìn Đêm khi ở dưới Y=0","Bóng Tối Lên Lỗi","Cứ 60 giây bị Bóng Tối 10 giây",["eff:night_vision:0:deep"],[]),
 ("u204","UNCOMMON","MAGMA_CREAM","COD","Dân Bản Xứ Nether","Kháng Lửa khi ở Nether","Dị Ứng Hải Sản","Không ăn được cá",["eff:fire_res:0:nether"],[]),
 ("u205","UNCOMMON","IRON_BLOCK","ZOMBIE_HEAD","Kiên Cố","+30% kháng đẩy lùi","Zombie Trâu Hơn","Zombie nhận thêm 30% máu",["attr:kbres:0.3"],[]),
 ("u206","UNCOMMON","PRISMARINE_CRYSTALS","END_CRYSTAL","Mang Cá","Thở được dưới nước (yes sir)","Pha Lê Múp","Pha lê End cần đánh thêm 2 lần mới vỡ",["eff:water_breath:0:water"],[]),
 ("u207","UNCOMMON","STONE_SWORD","PACKED_ICE","Đấu Tay Đôi","+15% sát thương gây ra","Băng Tan","Băng dưới chân tan sau 1 giây, băng nén sau 3 giây",["out:all:1.15"],[]),
 ("u208","UNCOMMON","OBSIDIAN","PIGLIN_HEAD","Chống Nổ (Mạnh Hơn)","-30% sát thương vụ nổ","Piglin Hung Dữ","Piglin gây thêm 40% sát thương lên bạn",["inc:explosion:0.7"],[]),
 ("u209","UNCOMMON","SHIELD","LEATHER_BOOTS","Kẻ Chặn Tên","-30% sát thương tầm xa nhận vào","Auto Jump","Tự động nhảy luôn luôn được bật",["inc:projectile:0.7"],[]),
 ("u210","UNCOMMON","DEEPSLATE","SLIME_BALL","Fan Mờ U","Kháng Sát Thương khi ở dưới Y=0","Cầm Nắm Yếu","2% tỉ lệ làm rơi vật phẩm đang cầm khi bạn đánh trúng thứ gì đó",["eff:resistance:0:deep"],[]),
 ("r51","RARE","BROWN_MUSHROOM","HONEY_BOTTLE","Người Lùn","-15% kích thước","Tay Trơn Trượt","6% tỉ lệ làm rơi vật phẩm đang cầm khi bạn đánh trúng thứ gì đó",[],[]),
 ("r52","RARE","REDSTONE","SUNFLOWER","Khát Máu","Mỗi lần hạ gục +3% sát thương (tối đa 30%), mất hết khi bị thương","Cháy Nắng","Bạn bị cháy dưới ánh nắng mặt trời trực tiếp",[],[]),
 ("r53","RARE","WOODEN_SHOVEL","NOTE_BLOCK","Bonk","Đòn cận chiến có 8% làm choáng mục tiêu trong 2 giây","Hell's Kitchen","Tiếng Hell's Kitchen ngẫu nhiên phát ra, phá vỡ sự im lặng",[],[]),
 ("r54","RARE","TNT","WITHER_SKELETON_SKULL","Mũi Tên Phát Nổ","Mũi tên phát nổ khi va chạm, gây sát thương mọi thứ trong 3 khối","Wither Béo","Wither nhận thêm 30% máu",[],[]),
 ("r55","RARE","STONE_BRICKS","SKELETON_SKULL","Chắc Như Tường Thành","-15% sát thương nhận vào","Buổi Tiệc Skeleton","Cứ 150 giây 2 Skeleton xuất hiện gần bạn. Mặt Đường: -15% tốc độ di chuyển, -10% tốc độ đánh",["inc:all:0.85"],["attr:speed:-0.15","attr:atkspeed:-0.1"]),
 ("r56","RARE","MILK_BUCKET","LAPIS_LAZULI","MILK","Mọi sinh vật và người chơi đều có thể vắt sữa","Đó Là La Peace","Quặng kim cương gần bạn biến thành quặng lưu ly",[],[]),
 ("r57","RARE","FEATHER","LIGHTNING_ROD","Nhảy 2 Lần","Nhảy thêm 1 lần nữa khi đang ở trên không","Kẻ Thu Hút Sét","Cứ 240 giây sét đánh thẳng vào bạn",[],[]),
 ("r58","RARE","HEART_OF_THE_SEA","GOLDEN_HELMET","Bạn Của Cá Heo","Nhận Ân Huệ Cá Heo khi ở dưới nước","Ác Mộng Của Ph1LzA","Mọi zombie gần bạn hóa thành zombie con mặc full giáp vàng",["eff:dolphin:0:water"],[]),
 ("r59","RARE","LEATHER_BOOTS","WITHER_ROSE","Nhảy Siêu Cao","+30% sức nhảy, -25% sát thương rơi","Cái Chạm Của Wither","Cứ 60 giây bị Yếu Ớt II và Chậm Chạp 6 giây",["inc:fall:0.75"],[]),
 ("r60","RARE","SLIME_BALL","FROGSPAWN","Slime Rancher","Slime và Magma Cube không còn nhắm vào hay làm hại bạn","Ếch Ở Bedrock Nhưng Tệ Hơn","Ếch muốn ăn thịt bạn",[],[]),
 ("r61","RARE","GLISTERING_MELON_SLICE","BUNDLE","Hút Máu","Hồi máu bằng 2% sát thương bạn gây ra","Túi Thủng","Cứ 120 giây một chồng đồ ngẫu nhiên rơi khỏi túi",[],[]),
 ("r62","RARE","SHIELD","SPYGLASS","Phòng Thủ Linh Hoạt","Sử dụng khiên không còn khiến bạn bị chậm lại","Có Thấy Tao Đang Share Màn Hình Không?","Máu càng thấp chất lượng màn hình càng kém",[],[]),
 ("r63","RARE","NETHERITE_AXE","DRAGON_HEAD","Berserker","Khi dưới 4 HP, nhận Sức Mạnh II trong 10 giây (hồi chiêu 60 giây)","Rồng Béo","Rồng Ender nhận thêm 25% máu",[],[]),
 ("e31","EPIC","EMERALD","CLOCK","Emerald Splash","Chuột phải khi cầm ngọc lục bảo để ném liên tục (10 viên mỗi giây, mỗi viên 3 sát thương)","Input Lag","Nút di chuyển phản hồi chậm 200ms",[],[]),
 ("e32","EPIC","TNT","ITEM_FRAME","Simon Says","Cứ 30 giây, làm theo lời Simon trong 3 giây để nhận một vật phẩm khoáng sản, nếu không bạn sẽ chịu 2 sát thương chuẩn","DVD Screensaver","Hotbar bay khắp màn hình. Tĩnh Lặng: Quái mất đi phần lớn hoạt ảnh",[],["troll:t21"]),
 ("e33","EPIC","IRON_SWORD","BLACK_BED","Đâm Sau Lưng","Tấn công từ phía sau gây thêm 100% sát thương","Màn Đêm Bất Tận","Trời luôn là ban đêm (với bạn). Chỉ Muốn Hòa Bình: -20% sát thương gây ra",[],["out:all:0.8"]),
 ("e34","EPIC","FIREWORK_ROCKET","OAK_LEAVES","Màn Trình Diễn Pháo Hoa","Creeper bay lên trời và nổ thành pháo hoa","Cây Này Biết Nói","Lá cây xung quanh bạn biến mất, mỗi lá có 25% biến thành Creeper",[],[]),
 ("e35","EPIC","DIAMOND_AXE","ROTTEN_FLESH","Kẻ Hành Quyết","+30% sát thương gây ra","Ma Dại","+50% sát thương nhận vào",["out:all:1.3"],["inc:all:1.5"]),
 ("e36","EPIC","DIAMOND_SWORD","LIGHTNING_ROD","Parry","Kiếm giờ có thể đỡ đòn. Chuột phải ngay trước khi bị đánh để parry đòn đó, làm choáng kẻ địch và tăng sức mạnh cho đòn đánh tiếp theo của bạn","Cột Thu Lôi","Cứ 120 giây sét đánh thẳng vào bạn",[],[]),
 ("e37","EPIC","CONDUIT","ENCHANTING_TABLE","Người Cá","Sở hữu Conduit Power dưới nước, và gây thêm 20% sát thương trong 10 giây sau khi ở dưới nước","Ngữ Pháp Của Bàn Phù Phép","Mọi chữ cái đều bị thay bằng chữ cái bàn phù phép, chỉ về bình thường trong 30 giây mỗi 2 phút",[],[]),
 ("e38","EPIC","SADDLE","STRUCTURE_VOID","Con Ngựa Da Đen","Con Ngựa sẽ giáng trần xuống thế giới này và sẽ dõi theo một sinh vật được gọi là Người Chơi","No F3 For You","Bạn không thể dùng menu Debug nữa",[],[]),
 ("e39","EPIC","ELYTRA","WITHER_SKELETON_SKULL","Kẻ Bay Lượn","Nhận khả năng bay như đang sử dụng Elytra (nhấn nhảy khi đang rơi)","Sức Mạnh Thật Sự Của Wither","Khi dưới 75% máu, Wither lao về phía trước phá hủy mọi thứ; dưới 50% máu Wither chỉ nhận một nửa sát thương",[],[]),
 ("e40","EPIC","NETHERITE_CHESTPLATE","BARRIER","Aegis","+3 giáp","Mặt Đường Gồ Ghề","-10% tốc độ di chuyển",["attr:armor:3"],["attr:speed:-0.1"]),
 ("l26","LEGENDARY","BAT_SPAWN_EGG","SUNFLOWER","Ma Cà Rồng","Hồi máu bằng 10% sát thương bạn gây ra","Con Của Mặt Trời","Bạn sẽ cháy dưới ánh nắng mặt trời",[],[]),
 ("l27","LEGENDARY","SAND","SANDSTONE","Lời Nguyền Pharaoh","Tích trữ cát trong cơ thể, mỗi 5 giây nhận 1 cát. Nhấn X để phun cát (tốn 20 cát)","Chỉ Ăn Cát","Bạn chỉ có thể ăn cát (chuột phải vào không khí khi cầm cát)",[],[]),
 ("l28","LEGENDARY","CREEPER_HEAD","TNT","Auuu Man","Creeper không còn xuất hiện","Mưa TNT","Cứ 10 giây một khối TNT rơi xuống đầu bạn",[],[]),
 ("l29","LEGENDARY","POTION","WOODEN_SWORD","Nhỏ Như Bỏ Túi","-50% kích thước, +10% tốc độ di chuyển","Tay Ngắn Sức Yếu","-30% sát thương gây ra, -1 tầm với",["attr:speed:0.1"],["out:all:0.7","attr:reach:-1"]),
 ("l30","LEGENDARY","IRON_BLOCK","PRISMARINE_SHARD","Terra Firma","50% quái vật xuất hiện trên mặt đất sẽ biến thành Iron Golem","Biển Dữ","Cá ở đại dương sẽ biến thành Elder Guardian",[],[]),
 ("l31","LEGENDARY","RED_DYE","SHEEP_SPAWN_EGG","Among Us","Mob thiện lành rơi ra thêm 1 vật phẩm từ quái ngẫu nhiên (và có cơ hội rơi ra quặng ngẫu nhiên)","Kẻ Giả Mạo","80% mob thiện lành trở nên hung dữ",[],[]),
 ("l32","LEGENDARY","ENDER_PEARL","CROSSBOW","Chắc Chắn Là RNG Hợp Lệ","Piglin đổi ra ngọc ender thường xuyên hơn 32 lần","Ngắm Lệch","Vật thể bạn bắn ra ít chính xác hơn 1000%",[],[]),
]
if __name__ == '__main__':
    ids = [c[0] for c in C]; assert len(ids) == len(set(ids))
    out = ['package com.hoang.wildcard;', '', 'import net.minecraft.world.item.Items;', '',
           'import static com.hoang.wildcard.Rarity.*;', '',
           '/** GENERATED by gen/v71_cards.py: v7.1 cards copied from the user\'s screenshots. Effects: effects/V71Cards, client/V71Client. */',
           'final class V71Data {', '    static void load() {']
    for (i, r, bi, di, *_rest) in C:
        out.append(f'        Cards.add("{i}", {r}, Items.{bi}, Items.{di}, "v71");')
    for c in C:
        if c[8] or c[9]:
            b = ', '.join(f'"{s}"' for s in c[8]); d = ', '.join(f'"{s}"' for s in c[9])
            out.append(f'        Cards.x("{c[0]}", new String[]{{{b}}}, new String[]{{{d}}});')
    out += ['    }', '', '    private V71Data() {}', '}', '']
    open(os.path.join(ROOT, 'src/main/java/com/hoang/wildcard/V71Data.java'), 'w', encoding='utf-8').write('\n'.join(out))
    for f in ('vi_vn.json', 'en_us.json'):
        p = os.path.join(ROOT, 'src/main/resources/assets/wildcard/lang', f)
        d = json.load(open(p, encoding='utf-8'))
        for (i, r, bi, di, bn, bd, dn, dd, *_x) in C:
            d[f'card.wildcard.{i}.buff'] = bn; d[f'card.wildcard.{i}.buff.desc'] = bd
            d[f'card.wildcard.{i}.debuff'] = dn; d[f'card.wildcard.{i}.debuff.desc'] = dd
        json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(len(C), 'cards')
