"""v7.3: lợi ích và bất lợi của một thẻ không được đụng cùng một chỉ số (vd. tốc đánh +40% / tốc đánh -30%)."""
import json, re, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = os.path.join(ROOT, 'src/main/java/com/hoang/wildcard')
LANGS = [os.path.join(ROOT, 'src/main/resources/assets/wildcard/lang', f) for f in ('vi_vn.json', 'en_us.json')]
DRY = '--dry' in sys.argv
def pct(x): return f"{round(x*100)}%"
def num1(x): return (f"{x:.1f}".rstrip('0').rstrip('.')).replace('.', ',')
def num2(x): return (f"{x:.2f}".rstrip('0').rstrip('.')).replace('.', ',')
TIER = {'c': 0, 'u': 1, 'r': 2, 'e': 3, 'l': 4, 'm': 4}
ROMAN = ['I', 'II', 'III', 'IV', 'V']
COND = {'always': '', 'night': 'Ban đêm', 'day': 'Ban ngày', 'rain': 'Khi trời mưa', 'water': 'Khi ở trong nước',
        'nether': 'Ở Nether', 'deep': 'Dưới độ cao Y=0', 'high': 'Trên độ cao Y=100', 'dark': 'Ở chỗ tối',
        'sneak': 'Khi đang cúi', 'sprint': 'Khi chạy nước rút', 'lowhp': 'Khi máu dưới 40%', 'fullhp': 'Khi máu đầy',
        'armorless': 'Khi không mặc giáp', 'unarmed': 'Khi tay không', 'dayout': 'Ban ngày ngoài trời'}
EFF = {'slowness': 'Chậm Chạp', 'fatigue': 'Đào Chậm', 'weakness': 'Yếu Ớt', 'hunger': 'Đói', 'glowing': 'Phát Sáng',
       'unluck': 'Xui Xẻo', 'blindness': 'Mù', 'nausea': 'Buồn Nôn', 'darkness': 'Bóng Tối', 'poison': 'Độc'}
TGT = {'undead': 'mob xác sống', 'arthropod': 'nhện và côn trùng', 'illager': 'dân làng ác', 'water': 'mob dưới nước',
       'animal': 'động vật', 'all': 'mọi mục tiêu', 'player': 'người chơi khác'}
SRC = {'fall': 'khi rơi', 'fire': 'từ lửa', 'explosion': 'từ vụ nổ', 'projectile': 'từ tên và đạn', 'magic': 'từ phép thuật',
       'melee': 'cận chiến', 'drown': 'do đuối nước', 'freeze': 'do đóng băng'}
EFFG = {'speed': 'speed', 'slowness': 'speed', 'strength': 'dmg', 'weakness': 'dmg', 'haste': 'mining', 'fatigue': 'mining',
        'luck': 'luck', 'unluck': 'luck', 'regen': 'heal', 'poison': 'heal', 'night_vision': 'vision', 'blindness': 'vision',
        'darkness': 'vision', 'resistance': 'incall'}
TROLLG = {'t08': 'mining', 't24': 'speed'}

def group(spec):
    a = spec.split(':')
    k = a[0]
    if k == 'attr':
        return {'toughness': 'armor', 'attack': 'dmg'}.get(a[1], a[1])
    if k == 'eff': return EFFG.get(a[1], 'eff' + a[1])
    if k == 'xp' or a[:2] in (['kill', 'xp'], ['mine', 'xp']): return 'xp'
    if k == 'out': return 'dmg'
    if k == 'inc': return 'inc' + a[1]
    if k in ('regen',) or a[:2] == ['kill', 'heal']: return 'heal'
    if k in ('food', 'exh') or a[:2] == ['kill', 'food']: return 'food'
    if a[:2] == ['mine', 'haste']: return 'mining'
    if k == 'troll': return TROLLG.get(a[1], 'troll' + a[1])
    return k

def text(spec):
    """Mô tả tiếng Việt của một bất lợi (để tìm và thay trong lang)."""
    a = spec.split(':')
    if a[0] == 'attr':
        v = -float(a[2])
        return {'speed': f"Tốc chạy -{pct(v)}", 'attack': f"Sát thương cận chiến -{num1(v)}", 'armor': f"Giáp -{num1(v)}",
                'luck': f"Xui Xẻo: May Mắn -{num1(v)}", 'atkspeed': f"Tốc đánh -{pct(v)}", 'reach': f"Tầm với -{num2(v)} khối",
                'maxhp': f"Máu tối đa -{num1(v/2)} tim"}.get(a[1])
    if a[0] == 'xp': return f"XP nhận được -{pct(1-float(a[1]))}"
    if a[0] == 'out': return f"-{pct(1-float(a[2]))} sát thương lên {TGT[a[1]]}"
    if a[0] == 'inc' and a[1] == 'all': return f"Nhận thêm {pct(float(a[2])-1)} mọi sát thương"
    if a[0] == 'inc': return f"Nhận thêm {pct(float(a[2])-1)} sát thương {SRC[a[1]]}"
    if a[0] == 'eff':
        c = COND[a[3]]; base = f"{EFF[a[1]]} {ROMAN[int(a[2])]}"
        return f"{c}: {base}" if c else f"{base} vĩnh viễn"
    if a[0] == 'troll':
        return L.get(f'troll.wildcard.{a[1]}') + ': ' + L.get(f'troll.wildcard.{a[1]}.desc')
    return None

def D(k, t):
    if k == 'xp': v = [.85, .75, .6, .5, .4][t]; return f"xp:{v}", f"XP nhận được -{pct(1-v)}"
    if k == 'atkspeed': v = [.1, .15, .2, .25, .3][t]; return f"attr:atkspeed:-{v}", f"Tốc đánh -{pct(v)}"
    if k == 'reach': v = [.5, .75, 1, 1.25, 1.5][t]; return f"attr:reach:-{v}", f"Tầm với -{num2(v)} khối"
    if k == 'luck': v = [1, 2, 3, 4, 5][t]; return f"attr:luck:-{v}", f"Xui Xẻo: May Mắn -{v}"
    if k == 'armor': v = [2, 3, 4, 5, 6][t]; return f"attr:armor:-{v}", f"Giáp -{v}"
    if k == 'speed': v = [.08, .12, .18, .22, .3][t]; return f"attr:speed:-{v}", f"Tốc chạy -{pct(v)}"
    if k == 'incfall': m = [1.25, 1.35, 1.5, 1.75, 2][t]; return f"inc:fall:{m}", f"Nhận thêm {pct(m-1)} sát thương khi rơi"
    if k == 'dmg': m = [.9, .85, .8, .75, .7][t]; return f"out:all:{m}", f"-{pct(1-m)} sát thương lên mọi mục tiêu"
    if k == 'mining': return "eff:fatigue:0:day", "Ban ngày: Đào Chậm I"
    if k == 'vision': return "eff:darkness:0:deep", "Dưới độ cao Y=0: Bóng Tối I"
ORDER = ['reach', 'luck', 'xp', 'atkspeed', 'incfall', 'armor', 'speed', 'mining', 'dmg', 'vision']
NAMES = {'xp': ['Học Chậm', 'Não Cá Vàng', 'Hay Quên', 'Lơ Đãng', 'Mất Tập Trung', 'Trí Nhớ Ngắn', 'Đầu Óc Trên Mây', 'Học Trước Quên Sau'],
         'atkspeed': ['Tay Mỏi', 'Tay Run Run', 'Cổ Tay Đau', 'Vung Chậm', 'Tay Lười', 'Khuỷu Tay Cứng', 'Vai Nhức', 'Ra Đòn Ì Ạch'],
         'reach': ['Tay Ngắn', 'Tay Khủng Long', 'Với Không Tới', 'Cánh Tay Cụt', 'Tay Ngắn Tũn', 'Ngắn Tay', 'Với Hụt', 'Tay Không Tới'],
         'dmg': ['Đánh Lệch', 'Ra Đòn Hụt', 'Run Tay', 'Thiếu Lực', 'Mất Phong Độ', 'Ngại Va Chạm', 'Hiền Khô', 'Đòn Nhẹ Hều'],
         'luck': ['Đen Đủi', 'Số Nhọ', 'Xui Tận Mạng', 'Mèo Đen Ngang Đường', 'Sao Quả Tạ', 'Gương Vỡ', 'Thứ Sáu 13', 'Vận Đen'],
         'armor': ['Giáp Rỉ', 'Áo Rách', 'Giáp Giấy', 'Áo Mỏng', 'Khóa Giáp Lỏng', 'Giáp Thủng', 'Áo Mưa Rách', 'Giáp Mục'],
         'speed': ['Chân Nặng', 'Chậm Như Sên', 'Chân Chì', 'Lết Bộ', 'Giày Chật', 'Chuột Rút', 'Bước Ì Ạch', 'Chân Đeo Tạ'],
         'incfall': ['Xương Giòn', 'Gót Chân Kính', 'Ngã Đau', 'Tiếp Đất Dở', 'Đầu Gối Thủy Tinh', 'Mắt Cá Yếu', 'Hạ Cánh Xấu', 'Rơi Là Đau'],
         'mining': ['Cuốc Cùn', 'Lười Đào', 'Tay Cuốc Mỏi', 'Mỏ Cứng'], 'vision': ['Sợ Bóng Tối', 'Mắt Mờ Dưới Sâu', 'Quáng Gà']}

lang = [json.load(open(f, encoding='utf-8')) for f in LANGS]
L = lang[0]
used = set(v.lower() for k, v in L.items() if k.startswith('card.wildcard.') and (k.endswith('.buff') or k.endswith('.debuff')))
FILES = ('GenData.java', 'GenExtra.java', 'V71Data.java')
src = {fn: open(os.path.join(J, fn), encoding='utf-8').read() for fn in FILES}
LINE = r'^\s*(?:Cards\.)?(card|x)\("(\w+)".*$'
buffs, debs = {}, {}
for fn, s in src.items():
    for m in re.finditer(LINE, s, flags=re.M):
        arrs = re.findall(r'new String\[\]\{([^}]*)\}', m.group(0))
        if len(arrs) < 2: continue
        buffs.setdefault(m.group(2), []).extend(re.findall(r'"([^"]+)"', arrs[0]))
        debs.setdefault(m.group(2), []).extend(re.findall(r'"([^"]+)"', arrs[1]))
conf = {}
for cid in buffs:
    bg = {group(x) for x in buffs[cid]}
    bad = [x for x in debs[cid] if group(x) in bg]
    if bad: conf[cid] = bad
print(len(conf), 'cards with overlapping buff/debuff')
changed = []
for fn in FILES:
    def fix(m):
        line = m.group(0)
        cid = m.group(2)
        if cid not in conf: return line
        arrs = re.findall(r'new String\[\]\{([^}]*)\}', line)
        if len(arrs) < 2: return line
        deb = re.findall(r'"([^"]+)"', arrs[1])
        taken = {group(x) for x in buffs[cid]} | {group(x) for x in debs[cid]}
        t = TIER[cid[0]]
        key = f'card.wildcard.{cid}.debuff.desc'
        new = []
        for s in deb:
            if s not in conf[cid]: new.append(s); continue
            k = next(k for k in ORDER[(sum(map(ord, cid)) % len(ORDER)):] + ORDER if k not in taken)
            taken.add(k)
            spec, txt = D(k, t)
            new.append(spec)
            ot = text(s)
            for d in lang:
                if ot and ot in d.get(key, ''): d[key] = d[key].replace(ot, txt, 1)
                else: print('WARN text', cid, s, ot, '|', d.get(key))
            nm = L.get(f'card.wildcard.{cid}.debuff', '')
            if len(debs[cid]) == 1 or group(s) in nm.lower():
                n2 = next((n for n in NAMES[k] if n.lower() not in used), None)
                if n2:
                    used.add(n2.lower())
                    for d in lang: d[f'card.wildcard.{cid}.debuff'] = n2
            changed.append((cid, s, spec, txt))
        old = 'new String[]{' + arrs[1] + '}'
        i = line.rfind(old)
        return line[:i] + 'new String[]{' + ', '.join(f'"{x}"' for x in new) + '}' + line[i + len(old):]
    s = re.sub(LINE, fix, src[fn], flags=re.M)
    if not DRY: open(os.path.join(J, fn), 'w', encoding='utf-8').write(s)
if not DRY:
    for f, d in zip(LANGS, lang):
        json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(len(changed), 'debuffs replaced')
for c in changed: print(*c)
