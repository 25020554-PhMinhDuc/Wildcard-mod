import json
L = {}
rs = {
 'r01': ('Dậm Đất', 'Sóng chấn động quanh 4 khối, 4 sát thương'),
 'r02': ('Bom Khói', 'Kẻ địch trong 6 khối bị mù 5 giây và mất dấu bạn'),
 'r03': ('Tường Đất', 'Dựng tường đất 3x3 trước mặt'),
 'r04': ('Hồi Sức', 'Hồi ngay 6 máu'),
 'r05': ('Định Vị', 'Mọi sinh vật trong 32 khối phát sáng 10 giây'),
 'r06': ('Lực Hút', 'Hút vật phẩm, XP và kẻ địch trong 10 khối về phía bạn'),
 'r07': ('Gọi Sấm', 'Sét đánh mục tiêu đang nhìn, 6 sát thương'),
 'r08': ('Bật Gió', 'Bật lên cao rồi rơi chậm'),
 'r09': ('Biến Mất', 'Tàng hình 6 giây, kẻ địch quanh bạn bị mù'),
 'r10': ('Vòng Băng', 'Kẻ địch trong 6 khối bị làm chậm và đóng băng'),
 'r11': ('Gọi Sói', 'Gọi 2 sói chiến đấu cùng bạn 30 giây'),
 'r12': ('Sửa Nhanh', 'Sửa 25% độ bền món đồ đang cầm'),
 'r13': ('Lướt Nước', 'Lướt nhanh về phía trước'),
 'r14': ('Lưỡi Ếch', 'Kéo mob nhỏ hoặc vật phẩm trong 8 khối về phía bạn'),
 'r15': ('Húc Đầu', 'Lao về trước, húc văng kẻ đầu tiên chạm phải'),
 'r16': ('Nhảy Tên Lửa', 'Nổ dưới chân hất bạn bay lên, không mất máu'),
 'r17': ('Móc Túi', 'Cướp 1 vật phẩm rơi của mob đang nhìn'),
 'r18': ('Bữa Phụ', 'Hồi 4 máu và 4 điểm đói'),
 'r19': ('Ném Độc', 'Ném lọ thuốc độc'),
 'r20': ('Lùi Nhanh', 'Nhảy lùi ra sau và được Tốc Độ II 3 giây'),
 'r21': ('Thánh Quang', 'Xác sống trong 8 khối nhận 6 sát thương và bốc cháy'),
 'r22': ('Ẩn Bóng', 'Tàng hình 8 giây, mob mất dấu'),
 'r23': ('Tia Băng', 'Bắn tia băng 4 sát thương, đóng băng mục tiêu'),
 'r24': ('Chợ Đen', 'Đổi 5 Emerald lấy 1 món đồ ngẫu nhiên'),
 'r25': ('Gầm Thét', 'Kẻ địch trong 8 khối bị Yếu, bạn được Sức Mạnh 6 giây'),
}
for k, (n, d) in rs.items():
    L[f'skill.wildcard.{k}.0'] = n; L[f'skill.wildcard.{k}.0.desc'] = d
sp = {
 'u61': ('La Peace ✌', 'Quái không chủ động tấn công bạn (trừ khi bạn đánh trước, mất 30 giây hòa bình)',
         'Hòa Bình Quá Mức', 'Sát thương của bạn chỉ còn 40%. Thỉnh thoảng bạn đứng tạo dáng "peace" giữa trận (bị chậm 3 giây)',
         'Peace Out', 'Tốc Độ III + tàng hình 4 giây, kẻ địch trong 8 khối bị chậm và mất dấu'),
 'u62': ('Tay Nhanh Hơn Não', 'Đào Nhanh I vĩnh viễn, tốc đánh +15%',
         'Hotbar Lơ Lửng', 'Thanh hotbar bay lơ lửng khắp màn hình, thỉnh thoảng ô đang cầm tự đổi',
         'Bắt Hotbar', 'Giữ hotbar đứng yên 15 giây và nhận Sức Mạnh I'),
 'u63': ('Trap Card!', 'Bị đánh có 20% kích hoạt bài bẫy: kẻ tấn công nhận lại toàn bộ sát thương',
         'Rương Có Bẫy', 'Mở rương, lò, thùng... có 15% chui ra 2 con bọ bạc',
         'Úp Bài Bẫy', 'Đặt bẫy tại chỗ (60 giây): kẻ địch đầu tiên bước vào nhận 8 sát thương và bị chậm'),
 'u64': ('Jackpot', 'Mỗi lượt nhận thẻ tự quay hũ: 8% trúng lớn (3 kim cương + 8 emerald), 30% trúng nhỏ (4 vàng)',
         'Cháy Túi', '62% còn lại thua: mất 3 cấp XP (không đủ thì bị Đói và Xui 60 giây)',
         'Quay Hũ', 'Tốn 2 cấp XP để quay hũ ngay'),
}
for k, (bn, bd, dn, dd, sn, sd) in sp.items():
    L[f'card.wildcard.{k}.buff'] = bn; L[f'card.wildcard.{k}.buff.desc'] = bd
    L[f'card.wildcard.{k}.debuff'] = dn; L[f'card.wildcard.{k}.debuff.desc'] = dd
    L[f'skill.wildcard.{k}.0'] = sn; L[f'skill.wildcard.{k}.0.desc'] = sd
tr = {
 't01': ('Hắt Xì Đồ', 'Thỉnh thoảng hắt xì làm rơi món đang cầm'),
 't02': ('Vine Boom', 'Thỉnh thoảng phát tiếng BOOM thật to, bạn giật mình đứng hình 1 giây'),
 't03': ('Bàn Phím Ngược', 'Thỉnh thoảng đảo phím di chuyển 10 giây'),
 't04': ('Lag Giả', 'Thỉnh thoảng bị kéo ngược về chỗ 2 giây trước như mạng lag'),
 't05': ('Creeper Ma', 'Thỉnh thoảng nghe tiếng creeper xì xì ngay sau lưng'),
 't06': ('Skill Issue', 'Chết thì cả server nhận tin "skill issue" và bạn mất thêm 3 cấp'),
 't07': ('NPC', 'Thỉnh thoảng tự nói câu thoại NPC vào chat'),
 't08': ('Đói Như Sói', 'Tốn đói gấp 1,5 lần'),
 't09': ('Trượt Tay', 'Đánh trúng có 4% làm rơi vũ khí'),
 't10': ('Đồ Mau Hỏng', 'Đào khối làm dụng cụ mất thêm 1 độ bền'),
 't11': ('Say Xe', 'Thỉnh thoảng bị Buồn Nôn 8 giây'),
 't12': ('Chớp Tắt', 'Thỉnh thoảng tối sầm màn hình 2 giây'),
 't13': ('Fan Cứng', 'Thỉnh thoảng một con gà fan cứng xuất hiện theo bạn'),
 't14': ('Thuế Thu Nhập', 'Mỗi lượt nhận thẻ mất 2 cấp XP'),
 't15': ('Phát Sáng', 'Luôn phát sáng, ai cũng thấy bạn xuyên tường'),
 't16': ('Trượt Vỏ Chuối', 'Đang chạy nước rút có lúc trượt ngã, bị chậm 2 giây'),
 't17': ('Rung Màn Hình', 'Thỉnh thoảng màn hình rung lắc 3 giây'),
 't18': ('Gió Lùa', 'Thỉnh thoảng bị gió thổi bay sang một bên'),
 't19': ('Nam Châm Quái', 'Quái trong 20 khối luôn để ý bạn'),
 't20': ('Chân Thủy Tinh', 'Sát thương khi rơi x1,5'),
 't21': ('Hotbar Lơ Lửng', 'Hotbar bay lơ lửng khắp màn hình'),
 't22': ('Ohio', 'Thỉnh thoảng một con mob gần bạn hóa Ohio: siêu nhanh, nhảy cao, phát sáng'),
 't23': ('Rickroll', 'Thỉnh thoảng bị rickroll giữa chừng'),
 't24': ('Bruh', 'Ngã đau thì cả xóm nghe tiếng "bruh" và bạn bị Đói 5 giây'),
 't25': ('Mất Sóng', 'Thỉnh thoảng mất sóng: 5 giây không dùng được kỹ năng'),
}
for k, (n, d) in tr.items():
    L[f'troll.wildcard.{k}'] = n; L[f'troll.wildcard.{k}.desc'] = d
L.update({
 'troll.wildcard.fan': 'Fan cứng',
 'troll.wildcard.rickroll': 'Bạn vừa bị Rickroll!',
 'troll.wildcard.skillissue': '%s chết vì... skill issue 💀',
 'msg.wildcard.duplicate': 'Trùng thẻ! %s lên ★%s (hồi chiêu -8%%, +1 máu tối đa)',
 'msg.wildcard.peace.pose': '✌ La Peace ✌',
 'msg.wildcard.trap.title': 'BÀI BẪY KÍCH HOẠT!',
 'msg.wildcard.trap.sub': 'Kẻ tấn công nhận lại toàn bộ sát thương',
 'msg.wildcard.trap.chest': 'Rương có bẫy!',
 'msg.wildcard.jackpot.win': 'JACKPOT!!!',
 'msg.wildcard.jackpot.small': 'Trúng nhỏ',
 'msg.wildcard.jackpot.lose': 'Thua sạch :(',
 'msg.wildcard.jackpot.all': '%s vừa nổ hũ JACKPOT!',
 'msg.wildcard.jackpot.nolevel': 'Cần 2 cấp XP để quay hũ',
 'gui.wildcard.hint.flip': 'Bấm vào thẻ (hoặc 1 / 2 / 3) để lật, bấm lần nữa để chọn · Space: lật hết',
 'gui.wildcard.flip': 'Lật thẻ',
 'gui.wildcard.dupe': 'Trùng thẻ: lên ★%s',
 'gui.wildcard.stars': 'Bậc sao: %s',
 'gui.wildcard.troll': 'TROLL',
})
gen = json.load(open('/home/claude/gen/lang_gen.json'))
L.update(gen)
for fn in ['vi_vn', 'en_us']:
    p = f'/home/claude/wildcard-mod/src/main/resources/assets/wildcard/lang/{fn}.json'
    d = json.load(open(p))
    d.update(L)
    json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
    print(fn, len(d))
