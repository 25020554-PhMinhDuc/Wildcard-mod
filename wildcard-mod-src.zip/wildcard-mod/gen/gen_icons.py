import json, sys, re
sys.argv = ['x', '/tmp/claude-0/unused']
import icons
from PIL import Image, ImageDraw
OUT = '/home/claude/wildcard-mod/src/main/resources/assets/wildcard/textures/gui/skill'
gen = json.load(open('skills_gen.json'))
SYM = {'bolt': {'fire': 'fireball', 'frost': 'snow', 'storm': 'bolt', 'void': 'swirl', 'arcane': 'eye', 'blood': 'drop'},
       'nova': 'shockwave', 'heal': 'heartplus', 'buff': 'fist', 'curse': 'eye', 'dash': 'dash', 'leap': 'uparrow',
       'blink': 'swirl', 'shield': 'shield', 'feast': 'drop', 'summon': 'claw', 'meteor': 'meteor', 'pull': 'blackhole',
       'taunt': 'roar', 'sigma': 'eye', 'sus': 'ghost'}
n = 0
for cid, s in gen.items():
    sym = SYM[s['kind']]
    if isinstance(sym, dict): sym = sym.get(s['el'], 'bolt')
    icons.icon(s['el'], sym).save(f'{OUT}/{cid}_0.png'); n += 1
# hand rares + specials
H = {'r01': ('earth', 'shockwave'), 'r02': ('void', 'ghost'), 'r03': ('earth', 'wall'), 'r04': ('holy', 'heartplus'),
     'r05': ('holy', 'eye'), 'r06': ('void', 'blackhole'), 'r07': ('storm', 'bolt'), 'r08': ('wind', 'uparrow'),
     'r09': ('void', 'invis'), 'r10': ('frost', 'snow'), 'r11': ('earth', 'claw'), 'r12': ('earth', 'pickaxe'),
     'r13': ('wind', 'dash'), 'r14': ('earth', 'hook'), 'r15': ('storm', 'fist'), 'r16': ('earth', 'explosion'),
     'r17': ('void', 'chest'), 'r18': ('blood', 'heart'), 'r19': ('blood', 'drop'), 'r20': ('wind', 'swap'),
     'r21': ('holy', 'sun'), 'r22': ('void', 'ghost'), 'r23': ('frost', 'snow'), 'r24': ('holy', 'gem'), 'r25': ('blood', 'roar'),
     'u61': ('wind', 'feather'), 'u62': ('storm', 'swap'), 'u63': ('void', 'web'), 'u64': ('holy', 'gem')}
for cid, (el, sym) in H.items():
    icons.icon(el, sym).save(f'{OUT}/{cid}_0.png'); n += 1
print(n, 'icons')
# card back 64x96
W, Hh = 64, 96
im = Image.new('RGBA', (W, Hh), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
d.rectangle([0, 0, W - 1, Hh - 1], fill=(22, 18, 40, 255))
d.rectangle([0, 0, W - 1, Hh - 1], outline=(12, 8, 22, 255))
d.rectangle([2, 2, W - 3, Hh - 3], outline=(150, 110, 255, 255))
d.rectangle([4, 4, W - 5, Hh - 5], outline=(70, 45, 140, 255))
for y in range(6, Hh - 6, 4):
    for x in range(6 + (y // 4 % 2) * 2, W - 6, 4):
        im.putpixel((x, y), (48, 34, 96, 255))
cx, cy = W // 2, Hh // 2
for r, col in ((18, (110, 70, 220, 255)), (13, (190, 150, 255, 255))):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=col)
# big "?" glyph
Q = [".####.", "##..##", "....##", "...##.", "..##..", "..##..", "......", "..##..", "..##.."]
for yy, row in enumerate(Q):
    for xx, ch in enumerate(row):
        if ch == '#':
            for a in range(2):
                for b in range(2):
                    im.putpixel((cx - 6 + xx * 2 + a, cy - 9 + yy * 2 + b), (255, 215, 90, 255))
for (x, y) in ((8, 8), (W - 9, 8), (8, Hh - 9), (W - 9, Hh - 9)):
    d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=(255, 215, 90, 255))
im.save('/home/claude/wildcard-mod/src/main/resources/assets/wildcard/textures/gui/card/back.png')
