# Synthesised placeholder sounds (original, no samples). Replace any .ogg with your own clip of the same name.
import numpy as np, subprocess, os, json, wave
SR = 22050
OUT = '/home/claude/wildcard-mod/src/main/resources/assets/wildcard/sounds'
os.makedirs(OUT + '/roll', exist_ok=True); os.makedirs(OUT + '/meme', exist_ok=True); os.makedirs(OUT + '/skill', exist_ok=True)
rng = np.random.default_rng(7)
def t(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.01, r=0.2):
    e = np.ones(n); A = min(n, int(SR * a)); R = min(n - A, int(SR * r))
    if A: e[:A] = np.linspace(0, 1, A)
    if R: e[-R:] *= np.linspace(1, 0, R)
    return e
def tone(f, d, kind='sine', a=0.01, r=0.2, vol=0.5):
    x = t(d); ph = 2 * np.pi * np.cumsum(np.full(len(x), f) if np.isscalar(f) else f) / SR
    if kind == 'sine': w = np.sin(ph)
    elif kind == 'square': w = np.sign(np.sin(ph)) * 0.6
    elif kind == 'saw': w = 2 * ((ph / (2 * np.pi)) % 1) - 1
    else: w = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)
    return w * env(len(x), a, r) * vol
def noise(d, vol=0.5, a=0.005, r=0.2, lp=0.0):
    w = rng.uniform(-1, 1, int(SR * d))
    if lp:
        out = np.zeros_like(w); y = 0
        for i, v in enumerate(w): y += lp * (v - y); out[i] = y
        w = out / (np.abs(out).max() + 1e-9)
    return w * env(len(w), a, r) * vol
def seq(parts, gap=0.0):
    out = []
    for p in parts:
        out.append(p); out.append(np.zeros(int(SR * gap)))
    return np.concatenate(out)
def mix(*xs):
    n = max(len(x) for x in xs); o = np.zeros(n)
    for x in xs: o[:len(x)] += x
    return o
def glide(f0, f1, d): return np.linspace(f0, f1, int(SR * d))
def reverb(x, delay=0.06, fb=0.35, n=5):
    o = np.concatenate([x, np.zeros(int(SR * delay * n))])
    for k in range(1, n + 1):
        D = int(SR * delay * k); o[D:D + len(x)] += x * (fb ** k)
    return o
def save(name, x):
    x = x / (np.abs(x).max() + 1e-9) * 0.85
    pcm = (x * 32767).astype(np.int16)
    wav = f'/tmp/claude-0/{os.path.basename(name)}.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-c:a', 'libvorbis', '-q:a', '3', f'{OUT}/{name}.ogg'], check=True)
    os.remove(wav)
N = lambda m: 440 * 2 ** ((m - 69) / 12)

# ---- roll
save('roll/spin', seq([tone(N(72 + (i % 4) * 2), 0.05, 'square', r=0.03, vol=0.3) for i in range(18)], 0.015) + 0)
save('roll/flip', mix(noise(0.18, 0.4, r=0.15, lp=0.25), tone(glide(500, 900, 0.18), 0.18, vol=0.2)))
save('roll/vip', reverb(seq([tone(N(m), 0.12, 'organ', r=0.08, vol=0.4) for m in (67, 71, 74, 79)]) ))
save('roll/legendary', reverb(mix(seq([tone(N(m), 0.1, 'organ', r=0.06, vol=0.4) for m in (72, 76, 79, 84, 88)]),
      np.concatenate([np.zeros(int(SR * 0.5)), tone(N(84), 0.9, 'organ', r=0.6, vol=0.35) + tone(N(88), 0.9, r=0.6, vol=0.25)]))))
save('roll/mythic', reverb(mix(tone(glide(80, 40, 0.8), 0.8, 'saw', r=0.5, vol=0.6),
      np.concatenate([np.zeros(int(SR * 0.3)), mix(tone(N(57), 1.4, 'organ', r=0.9, vol=0.4), tone(N(60), 1.4, 'organ', r=0.9, vol=0.35), tone(N(64), 1.4, 'organ', r=0.9, vol=0.3))])), 0.09, 0.45))
save('roll/meme', seq([tone(glide(N(67), N(64), 0.3), 0.3, 'saw', r=0.05, vol=0.4), tone(glide(N(66), N(63), 0.3), 0.3, 'saw', r=0.05, vol=0.4),
      tone(glide(N(65), N(62), 0.3), 0.3, 'saw', r=0.05, vol=0.4), tone(glide(N(64), N(60), 0.7) * (1 + 0.02 * np.sin(2 * np.pi * 6 * t(0.7))), 0.7, 'saw', r=0.3, vol=0.4)]))

# ---- memes (original synth, not the real clips)
save('meme/vineboom', reverb(mix(tone(glide(110, 45, 0.6), 0.6, 'organ', a=0.002, r=0.5, vol=0.9), noise(0.15, 0.5, a=0.001, r=0.12, lp=0.08)), 0.08, 0.5, 6))
save('meme/bruh', tone(glide(140, 95, 0.55), 0.55, 'saw', a=0.02, r=0.25, vol=0.7) * (1 + 0.3 * np.sin(2 * np.pi * 30 * t(0.55))))
save('meme/rickroll', seq([tone(N(m), d, 'square', r=0.04, vol=0.35) for m, d in
      [(60, .15), (64, .15), (67, .15), (72, .3), (71, .15), (67, .15), (69, .3), (65, .15), (69, .15), (72, .45)]], 0.02))
save('meme/trap', reverb(seq([tone(N(52), 0.18, 'saw', r=0.05, vol=0.5), tone(N(55), 0.18, 'saw', r=0.05, vol=0.5),
      mix(tone(N(58), 0.8, 'saw', r=0.6, vol=0.5), tone(N(46), 0.8, 'organ', r=0.6, vol=0.5))]), 0.07, 0.4))
coins = [tone(N(88 + (i % 3) * 3), 0.07, 'square', r=0.05, vol=0.3) for i in range(14)]
save('meme/jackpot', mix(seq(coins, 0.03), np.concatenate([np.zeros(int(SR * 0.6)), seq([tone(N(m), 0.14, 'organ', r=0.08, vol=0.45) for m in (72, 76, 79, 84, 79, 84)])])))
save('meme/lapeace', mix(noise(0.35, 0.4, a=0.05, r=0.25, lp=0.15), np.concatenate([np.zeros(int(SR * 0.25)), tone(N(84), 0.5, 'sine', r=0.4, vol=0.5), ])))
save('meme/sus', reverb(seq([tone(N(53), 0.35, 'saw', r=0.1, vol=0.5), tone(N(56), 0.35, 'saw', r=0.1, vol=0.5), tone(N(53), 0.7, 'saw', r=0.5, vol=0.5)]), 0.1, 0.4))
save('meme/fail', seq([tone(N(m) * (1 + 0.01 * np.sin(2 * np.pi * 5 * t(d))), d, 'saw', r=0.08, vol=0.45) for m, d in [(55, .3), (54, .3), (53, .3), (52, .9)]]))
save('meme/sigma', reverb(mix(tone(N(40), 1.0, 'organ', a=0.05, r=0.6, vol=0.6), tone(N(47), 1.0, 'organ', a=0.05, r=0.6, vol=0.4))))

# ---- skill sounds per element
save('skill/fire', mix(noise(0.5, 0.6, a=0.02, r=0.35, lp=0.12), tone(glide(200, 90, 0.5), 0.5, 'saw', r=0.3, vol=0.25)))
save('skill/frost', reverb(seq([tone(N(m), 0.09, 'sine', r=0.07, vol=0.4) for m in (88, 93, 96, 100)])))
save('skill/storm', mix(noise(0.35, 0.7, a=0.001, r=0.3), tone(glide(1200, 200, 0.35), 0.35, 'square', r=0.2, vol=0.2)))
save('skill/blood', seq([tone(60, 0.12, 'sine', a=0.005, r=0.1, vol=0.9), tone(55, 0.16, 'sine', a=0.005, r=0.14, vol=0.8)], 0.12))
save('skill/void', reverb(tone(glide(300, 120, 0.6) * (1 + 0.1 * np.sin(2 * np.pi * 9 * t(0.6))), 0.6, 'saw', r=0.4, vol=0.5)))
save('skill/holy', reverb(mix(*[tone(N(m), 0.8, 'organ', a=0.1, r=0.5, vol=0.3) for m in (72, 76, 79)])))
save('skill/earth', mix(noise(0.45, 0.7, a=0.01, r=0.35, lp=0.04), tone(glide(70, 40, 0.45), 0.45, 'sine', r=0.3, vol=0.6)))
save('skill/wind', noise(0.6, 0.6, a=0.15, r=0.35, lp=0.06) * (0.6 + 0.4 * np.sin(2 * np.pi * 3 * t(0.6))))
save('skill/arcane', reverb(seq([tone(N(m), 0.07, 'sine', r=0.05, vol=0.35) for m in (79, 84, 86, 91, 96)])))
print('ok')
