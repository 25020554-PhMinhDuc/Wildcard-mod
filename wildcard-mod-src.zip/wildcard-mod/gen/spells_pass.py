# Turns generated skills into spell-book style spells (all Rare+ generated cards, ~30% of Common/Uncommon).
import json, re, random, sys
sys.path.insert(0, '/home/claude/gen')
R = random.Random(5150)
ROOT = '/home/claude/wildcard-mod'
GD = f'{ROOT}/src/main/java/com/hoang/wildcard/GenData.java'
TIER = {'c': 0, 'u': 1, 'r': 2, 'e': 3, 'l': 4}
def num(x): return (f"{x:.1f}".rstrip('0').rstrip('.')).replace('.', ',')
SPELLS = {  # kind: (element(s), name, desc(t,a,b), a list, b list, cd list)
 'firebolt': (['fire'], 'Hỏa Tiễn', lambda a, b: f'Bắn quả cầu lửa bay thẳng: {num(a)} sát thương, đốt 5 giây', [4, 5, 7, 9, 12], [0]*5, [12, 10, 9, 8, 7]),
 'icicle': (['frost'], 'Mũi Băng Nhọn', lambda a, b: f'Bắn mũi băng bay nhanh: {num(a)} sát thương, làm chậm và đóng băng', [3, 4, 6, 8, 10], [0]*5, [12, 10, 9, 8, 7]),
 'magic_missile': (['arcane'], 'Phi Đạn Ma Thuật', lambda a, b: f'3 viên đạn phép tự bám mục tiêu, mỗi viên {num(a)} sát thương', [2, 2.5, 3.5, 4.5, 6], [0]*5, [18, 16, 14, 12, 10]),
 'lightning_lance': (['storm'], 'Giáo Sét', lambda a, b: f'Phóng giáo sét vào mục tiêu trong {int(b)} khối: {num(a)} sát thương kèm tia sét', [5, 6, 8, 11, 14], [16, 20, 24, 28, 32], [25, 22, 20, 18, 15]),
 'chain_lightning': (['storm'], 'Sét Chuỗi', lambda a, b: f'Sét đánh mục tiêu rồi nhảy sang 3 kẻ gần đó: {num(a)} sát thương, giảm dần', [4, 5, 6, 8, 10], [0]*5, [30, 26, 24, 20, 18]),
 'blood_slash': (['blood'], 'Huyết Trảm', lambda a, b: f'Chém vòng cung máu phía trước: {num(a)} sát thương, hút một phần thành máu', [4, 5, 7, 9, 12], [0]*5, [12, 10, 9, 8, 7]),
 'ray_of_frost': (['frost'], 'Tia Băng Giá', lambda a, b: f'Tia băng xuyên thẳng {int(b)} khối: {num(a)} sát thương mọi kẻ trên đường, đóng băng', [3, 4, 6, 8, 10], [10, 12, 14, 16, 20], [20, 18, 16, 14, 12]),
 'fang_strike': (['void'], 'Nanh Quỷ', lambda a, b: f'Hàng {int(b)} nanh quỷ trồi lên từ mặt đất phía trước (6 sát thương mỗi nanh)', [0]*5, [5, 6, 8, 10, 12], [20, 18, 16, 14, 12]),
 'wisp': (['holy'], 'Đom Đóm Thánh', lambda a, b: f'Thả đom đóm sáng bay theo kẻ địch: {num(a)} sát thương và hồi cho bạn một nửa', [4, 5, 7, 9, 12], [0]*5, [18, 16, 14, 12, 10]),
 'acid_orb': (['void'], 'Cầu Axit', lambda a, b: f'Ném cầu axit: {num(a)} sát thương, vỡ ra vũng độc bán kính {num(b)} khối', [2, 3, 4, 5, 6], [2, 2.5, 3, 3.5, 4], [25, 22, 20, 18, 15]),
 'breath': (['fire', 'frost'], None, lambda a, b: f'Phun hơi thở hình nón 6 khối trong 2 giây, tổng {num(a)} sát thương', [6, 8, 12, 16, 22], [0]*5, [30, 26, 24, 20, 18]),
 'counterspell': (['arcane'], 'Phản Phép', lambda a, b: 'Xóa mọi hiệu ứng của kẻ địch trong 10 khối và gỡ hiệu ứng xấu trên bạn', [0]*5, [0]*5, [60, 50, 45, 40, 35]),
 'root': (['earth'], 'Rễ Trói', lambda a, b: f'Rễ cây trói chân kẻ địch trong 6 khối suốt {int(b)} giây', [0]*5, [3, 4, 5, 6, 8], [30, 26, 24, 22, 20]),
 'blight': (['void'], 'Tàn Lụi', lambda a, b: f'Kẻ địch trong 8 khối bị Héo Úa II trong {int(b)} giây', [0]*5, [4, 5, 6, 8, 10], [35, 30, 28, 25, 22]),
}
SYM = {'firebolt': 'fireball', 'icicle': 'icicle', 'magic_missile': 'missile', 'lightning_lance': 'lance', 'chain_lightning': 'chain',
       'blood_slash': 'slash', 'ray_of_frost': 'ray', 'fang_strike': 'fangs', 'wisp': 'wisp', 'acid_orb': 'acid',
       'breath': 'breath', 'counterspell': 'cross', 'root': 'root', 'blight': 'skull'}
src = open(GD).read()
gen = json.load(open('/home/claude/gen/skills_gen.json'))
lang = {}
changed = {}
lines = src.split('\n')
for i, l in enumerate(lines):
    m = re.match(r'\s*skill\("(\w+)", ', l)
    if not m: continue
    cid = m.group(1); t = TIER[cid[0]]
    if t < 2 and R.random() >= 0.3: continue
    kind = R.choice(list(SPELLS))
    els, name, desc, A, B, CD = SPELLS[kind]
    el = R.choice(els)
    if kind == 'breath': name = 'Hơi Thở Rồng' if el == 'fire' else 'Hơi Thở Băng Giá'
    a, b, cd = A[t], B[t], CD[t]
    lines[i] = f'        skill("{cid}", "{kind}", "{el}", {a}, {b}, "", 0, {cd});'
    lang[f'skill.wildcard.{cid}.0'] = name
    lang[f'skill.wildcard.{cid}.0.desc'] = desc(a, b)
    gen[cid] = dict(kind=kind, el=el, a=a, b=b, eff='', amp=0, cd=cd, name=name, desc=desc(a, b))
    changed[cid] = (el, SYM[kind])
open(GD, 'w').write('\n'.join(lines))
json.dump(gen, open('/home/claude/gen/skills_gen.json', 'w'), ensure_ascii=False)
for fn in ['vi_vn', 'en_us']:
    p = f'{ROOT}/src/main/resources/assets/wildcard/lang/{fn}.json'
    d = json.load(open(p)); d.update(lang); json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
json.dump(changed, open('/home/claude/gen/spell_icons.json', 'w'))
from collections import Counter
print(len(changed), 'spells', Counter(v[1] for v in changed.values()))
