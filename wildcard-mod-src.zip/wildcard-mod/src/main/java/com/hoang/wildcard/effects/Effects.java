package com.hoang.wildcard.effects;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;
import java.util.*;

/** Shared helpers, one-time card setup, and all per-tick server effects. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class Effects {
    public static final String OWNER_TAG = "wildcard_owner";

    // ================================================================== helpers

    public static boolean has(Player p, String id) {
        return Cards.has(p, id);
    }

    /** Keeps a hidden, effectively permanent potion effect on the player. */
    public static void keep(LivingEntity p, MobEffect eff, int amp) {
        MobEffectInstance cur = p.getEffect(eff);
        if (cur == null || cur.getAmplifier() < amp || cur.getDuration() < 230) {
            p.addEffect(new MobEffectInstance(eff, 300, amp, true, false, true));
        }
    }

    public static void effect(LivingEntity e, MobEffect eff, int ticks, int amp) {
        e.addEffect(new MobEffectInstance(eff, ticks, amp, false, true, true));
    }

    private static final Map<String, UUID> UUIDS = new HashMap<>();

    public static UUID uuid(String key) {
        return UUIDS.computeIfAbsent(key, k -> UUID.nameUUIDFromBytes(("wildcard:" + k).getBytes()));
    }

    /** Adds, updates or removes a transient attribute modifier. */
    public static void attr(LivingEntity e, Attribute a, String key, double amount, AttributeModifier.Operation op, boolean active) {
        AttributeInstance inst = e.getAttribute(a);
        if (inst == null) return;
        UUID id = uuid(key);
        AttributeModifier cur = inst.getModifier(id);
        if (!active || amount == 0) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && cur.getAmount() == amount && cur.getOperation() == op) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTransientModifier(new AttributeModifier(id, "wildcard " + key, amount, op));
    }

    public static void give(Player p, ItemStack stack) {
        if (!p.getInventory().add(stack)) p.drop(stack, false);
    }

    public static ItemEntity dropAt(ServerLevel level, double x, double y, double z, ItemStack stack) {
        ItemEntity ie = new ItemEntity(level, x, y, z, stack);
        ie.setDefaultPickUpDelay();
        level.addFreshEntity(ie);
        return ie;
    }

    public static void lightning(ServerLevel level, Vec3 pos, @Nullable ServerPlayer cause, boolean visualOnly) {
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(level);
        if (b == null) return;
        b.moveTo(pos);
        if (cause != null) b.setCause(cause);
        b.setVisualOnly(visualOnly);
        level.addFreshEntity(b);
    }

    /** Visual lightning plus direct damage to one target (so the caster is never hit). */
    public static void smite(ServerPlayer caster, LivingEntity target, float damage) {
        lightning(caster.serverLevel(), target.position(), caster, true);
        target.hurt(caster.damageSources().lightningBolt(), damage);
        target.setSecondsOnFire(4);
    }

    public static boolean isWeapon(ItemStack s) {
        Item i = s.getItem();
        return i instanceof SwordItem || i instanceof AxeItem || i instanceof TridentItem || i instanceof ProjectileWeaponItem;
    }

    @Nullable
    public static BlockPos findStand(ServerLevel level, int x, int y, int z) {
        for (int dy = 0; dy <= 10; dy++) {
            for (int s : new int[]{1, -1}) {
                BlockPos pos = new BlockPos(x, y + dy * s, z);
                if (!level.isLoaded(pos)) return null;
                BlockPos below = pos.below();
                if (level.getBlockState(pos).isAir() && level.getBlockState(pos.above()).isAir()
                        && level.getBlockState(below).isSolidRender(level, below)) return pos;
            }
        }
        return null;
    }

    @Nullable
    public static <T extends Mob> T spawnNear(ServerPlayer p, EntityType<T> type, double minR, double maxR) {
        ServerLevel level = p.serverLevel();
        RandomSource r = p.getRandom();
        for (int i = 0; i < 20; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = minR + r.nextDouble() * (maxR - minR);
            int x = Mth.floor(p.getX() + Math.cos(ang) * dist);
            int z = Mth.floor(p.getZ() + Math.sin(ang) * dist);
            BlockPos pos = findStand(level, x, p.getBlockY(), z);
            if (pos == null && level.isLoaded(new BlockPos(x, 0, z))) {
                int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                if (Math.abs(top - p.getBlockY()) < 24) pos = findStand(level, x, top, z);
            }
            if (pos == null) continue;
            T m = type.create(level);
            if (m == null) return null;
            m.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, r.nextFloat() * 360f, 0f);
            m.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null, null);
            level.addFreshEntity(m);
            return m;
        }
        return null;
    }

    public static void actionBar(ServerPlayer p, Component c) {
        p.displayClientMessage(c, true);
    }

    public static CompoundTagAccess extra(Player p) {
        return new CompoundTagAccess(WData.get(p).extra);
    }

    /** Small wrapper around the saved per-card NBT. */
    public record CompoundTagAccess(net.minecraft.nbt.CompoundTag tag) {
        public int getInt(String k) { return tag.getInt(k); }
        public void putInt(String k, int v) { tag.putInt(k, v); }
        public net.minecraft.nbt.CompoundTag round() {
            if (!tag.contains("round")) tag.put("round", new net.minecraft.nbt.CompoundTag());
            return tag.getCompound("round");
        }
    }

    // ================================================================== card granted / new round

    public static void onGranted(ServerPlayer p, Card c) {
        ServerLevel level = p.serverLevel();
        switch (c.id) {
            case "u09" -> {
                Cat cat = EntityType.CAT.create(level);
                if (cat != null) {
                    cat.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), 0);
                    cat.tame(p);
                    level.addFreshEntity(cat);
                }
            }
            case "r11" -> {
                for (int i = 0; i < 2; i++) spawnWolf(p);
            }
            case "e03" -> spawnGolem(p);
            case "l15" -> p.setRespawnPosition(level.dimension(), null, 0f, false, false);
            default -> {
            }
        }
    }

    private static void spawnWolf(ServerPlayer p) {
        Wolf w = EntityType.WOLF.create(p.serverLevel());
        if (w == null) return;
        w.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), 0);
        w.tame(p);
        w.setHealth(w.getMaxHealth());
        p.serverLevel().addFreshEntity(w);
    }

    private static void spawnGolem(ServerPlayer p) {
        IronGolem g = EntityType.IRON_GOLEM.create(p.serverLevel());
        if (g == null) return;
        g.moveTo(p.getX() + 1, p.getY(), p.getZ() + 1, p.getYRot(), 0);
        g.setPlayerCreated(true);
        g.getPersistentData().putUUID(OWNER_TAG, p.getUUID());
        g.setPersistenceRequired();
        p.serverLevel().addFreshEntity(g);
    }

    public static boolean isOwnedBy(Entity e, Player p) {
        return e.getPersistentData().hasUUID(OWNER_TAG) && e.getPersistentData().getUUID(OWNER_TAG).equals(p.getUUID());
    }

    public static void onRoundStart(ServerPlayer p, WData d) {
        ServerLevel level = p.serverLevel();
        if (has(p, "u18")) give(p, new ItemStack(Items.EMERALD, 3));
        if (has(p, "e07")) {
            for (int i = 0; i < 3; i++) {
                ItemEntity ie = dropAt(level, p.getX() + p.getRandom().nextGaussian() * 2, p.getY() + 8, p.getZ() + p.getRandom().nextGaussian() * 2,
                        new ItemStack(Items.DIAMOND));
                ie.setGlowingTag(true);
            }
        }
        if (has(p, "l18")) {
            for (int i = 0; i < 4; i++) {
                Pillager pl = spawnNear(p, EntityType.PILLAGER, 26, 32);
                if (pl != null) pl.setTarget(p);
            }
        }
    }

    // ================================================================== per-tick server effects

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide) return;
        if (!(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        WData d = WData.get(p);
        if (d.cards.isEmpty()) return;
        PlayerState st = PlayerState.get(p);
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        RandomSource rng = p.getRandom();
        int tc = p.tickCount;

        // ---- movement tracking
        Vec3 pos = p.position();
        boolean moved = st.lastPos == null || pos.distanceToSqr(st.lastPos) > 0.0004;
        if (moved) {
            if (has(p, "u17") && st.stillTicks > 60) effect(p, MobEffects.MOVEMENT_SLOWDOWN, 20, 3); // Mọc Rễ
            st.stillTicks = 0;
        } else {
            st.stillTicks++;
        }
        st.lastPos = pos;
        st.crouchTicks = p.isShiftKeyDown() ? st.crouchTicks + 1 : 0;
        st.history.addLast(pos);
        while (st.history.size() > 60) st.history.removeFirst();

        exhaustion(p, st);
        durability(p, st, rng);

        // ---- attributes (every 10 ticks)
        if (tc % 10 == 0) attributes(p, d, st, now);

        // ---- frequent checks (every tick)
        if (has(p, "e12")) p.clearFire();
        if (has(p, "e01") && p.isOnFire() && p.isInWaterRainOrBubble()) {
            p.setRemainingFireTicks(Math.max(p.getRemainingFireTicks(), 60)); // Thiêu Đốt: nước không dập lửa
        }
        if (has(p, "e01") && p.isOnFire() && tc % 2 == 0) p.setRemainingFireTicks(p.getRemainingFireTicks() + 1);
        if (has(p, "u15") && p.isUnderWater() && rng.nextInt(3) != 0) {
            p.setAirSupply(Math.min(p.getMaxAirSupply(), p.getAirSupply() + 1)); // Lá Phổi Cá
        }
        if (has(p, "u12") && level.getBiome(p.blockPosition()).value().coldEnoughToSnow(p.blockPosition()) && p.canFreeze()) {
            p.setTicksFrozen(Math.min(p.getTicksRequiredToFreeze() + 20, p.getTicksFrozen() + 4)); // Cóng
        }
        if (has(p, "l07")) stomp(p);
        if (has(p, "r15")) headBreak(p, level);
        if (has(p, "r15") && !p.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) { // Đau Đầu
            ItemStack helm = p.getItemBySlot(EquipmentSlot.HEAD).copy();
            p.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            give(p, helm);
        }
        if (has(p, "r08") && p.isShiftKeyDown() && !p.onGround() && p.getDeltaMovement().y < -0.1) p.fallDistance = Math.min(p.fallDistance, 2f);
        if (has(p, "r13") && p.isSprinting()) p.fallDistance = 0;
        if (has(p, "e12") && p.onGround()) { // Quá Nhiệt
            BlockState below = level.getBlockState(p.blockPosition().below());
            if (below.is(Blocks.GRASS_BLOCK) || below.is(BlockTags.LEAVES)) p.setSecondsOnFire(3);
        }
        if (has(p, "e12")) {
            for (InteractionHandHolder h : InteractionHandHolder.BOTH) {
                if (p.getItemInHand(h.hand).is(Items.WATER_BUCKET)) {
                    p.setItemInHand(h.hand, new ItemStack(Items.BUCKET));
                    level.playSound(null, p.blockPosition(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.8f, 1.4f);
                    level.sendParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1.2, p.getZ(), 10, 0.3, 0.3, 0.3, 0.01);
                }
            }
        }

        // ---- every second
        if (tc % 20 == 0) everySecond(p, d, st, level, now, rng);
        // ---- periodic events
        periodic(p, d, st, level, now, rng, tc);
    }

    /** Small helper so the loop above reads nicely. */
    private record InteractionHandHolder(net.minecraft.world.InteractionHand hand) {
        static final InteractionHandHolder[] BOTH = {
                new InteractionHandHolder(net.minecraft.world.InteractionHand.MAIN_HAND),
                new InteractionHandHolder(net.minecraft.world.InteractionHand.OFF_HAND)};
    }

    private static void exhaustion(ServerPlayer p, PlayerState st) {
        FoodData fd = p.getFoodData();
        float ex = fd.getExhaustionLevel();
        float mult = 1f;
        if (has(p, "c02")) mult *= 0.75f;       // Bụng Không Đáy
        if (has(p, "r18")) mult *= 1.5f;        // Đói Meo
        if (has(p, "l11") && p.isSprinting()) mult = 0f; // Thần Tốc: chạy không tốn đói
        if (st.lastExhaustion >= 0 && ex > st.lastExhaustion && mult != 1f) {
            float nv = st.lastExhaustion + (ex - st.lastExhaustion) * mult;
            fd.addExhaustion(nv - ex); // negative delta lowers exhaustion (setExhaustion is client-only)
            ex = fd.getExhaustionLevel();
        }
        st.lastExhaustion = ex;
    }

    private static void durability(ServerPlayer p, PlayerState st, RandomSource rng) {
        // Thợ Rèn: 25% không mất độ bền (đồ cầm tay chính)
        int slot = p.getInventory().selected;
        ItemStack main = p.getMainHandItem();
        if (main.isDamageableItem()) {
            if (st.trackedMainItem == main.getItem() && st.trackedMainSlot == slot) {
                int diff = main.getDamageValue() - st.trackedMainDamage;
                if (diff > 0 && has(p, "r12") && rng.nextFloat() < 0.25f) main.setDamageValue(st.trackedMainDamage);
            }
            st.trackedMainItem = main.getItem();
            st.trackedMainSlot = slot;
            st.trackedMainDamage = main.getDamageValue();
        } else {
            st.trackedMainItem = null;
        }
        // Mục Rỉ: giáp mất độ bền gấp 3
        for (int i = 0; i < 4; i++) {
            ItemStack a = p.getInventory().armor.get(i);
            if (!a.isDamageableItem()) {
                st.armorItems[i] = null;
                continue;
            }
            if (st.armorItems[i] == a.getItem()) {
                int diff = a.getDamageValue() - st.armorDamage[i];
                if (diff > 0 && has(p, "e18")) {
                    EquipmentSlot es = EquipmentSlot.byTypeAndIndex(EquipmentSlot.Type.ARMOR, i);
                    a.hurtAndBreak(diff * 2, p, pl -> pl.broadcastBreakEvent(es));
                }
            }
            st.armorItems[i] = a.isEmpty() ? null : a.getItem();
            st.armorDamage[i] = a.getDamageValue();
        }
    }

    private static void attributes(ServerPlayer p, WData d, PlayerState st, long now) {
        AttributeModifier.Operation ADD = AttributeModifier.Operation.ADDITION;
        AttributeModifier.Operation MUL = AttributeModifier.Operation.MULTIPLY_TOTAL;
        attr(p, Attributes.ARMOR, "c09_armor", 2, ADD, has(p, "c09"));
        attr(p, Attributes.MOVEMENT_SPEED, "c09_speed", -0.05, MUL, has(p, "c09"));
        attr(p, Attributes.MAX_HEALTH, "u05_hp", -2, ADD, has(p, "u05"));
        attr(p, Attributes.MAX_HEALTH, "r01_hp", 4, ADD, has(p, "r01"));
        attr(p, ForgeMod.BLOCK_REACH.get(), "r01_reach", 1, ADD, has(p, "r01"));
        attr(p, ForgeMod.ENTITY_REACH.get(), "r01_ereach", 1, ADD, has(p, "r01"));
        attr(p, ForgeMod.BLOCK_REACH.get(), "l12_reach", 5.5, ADD, has(p, "l12"));
        attr(p, ForgeMod.ENTITY_REACH.get(), "l12_ereach", 7, ADD, has(p, "l12"));
        int lost = d.extra.getInt("l04_lost");
        attr(p, Attributes.MAX_HEALTH, "l04_hp", -2.0 * lost, ADD, has(p, "l04") && lost > 0);
        int souls = d.extra.getInt("e09_kills");
        attr(p, Attributes.ATTACK_DAMAGE, "e09_dmg", Math.min(5.0, souls * 0.5), ADD, has(p, "e09"));
        // Cát Lún
        BlockState below = p.level().getBlockState(p.blockPosition().below());
        boolean sand = below.is(BlockTags.SAND) || below.is(Blocks.GRAVEL);
        attr(p, Attributes.MOVEMENT_SPEED, "u08_sand", -0.3, MUL, has(p, "u08") && sand && p.onGround());
        // Pháo Đài Di Động: giữ Shift 2 giây
        st.fortress = has(p, "e18") && st.crouchTicks >= 40;
        boolean frozen = now < st.timeStopSelfFreeze;
        attr(p, Attributes.MOVEMENT_SPEED, "freeze", -1.0, MUL, st.fortress || frozen);
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    private static void everySecond(ServerPlayer p, WData d, PlayerState st, ServerLevel level, long now, RandomSource rng) {
        BlockPos bp = p.blockPosition();
        ItemStack main = p.getMainHandItem();
        boolean sunny = level.isDay() && !level.isRaining() && level.canSeeSky(bp.above());

        if (has(p, "c01")) keep(p, MobEffects.JUMP, 0);
        if (has(p, "c03") && main.getItem() instanceof PickaxeItem) keep(p, MobEffects.DIG_SPEED, 0);
        if (has(p, "c04") && p.getY() < 40) keep(p, MobEffects.NIGHT_VISION, 0);
        if (has(p, "c04") && sunny) effect(p, MobEffects.MOVEMENT_SLOWDOWN, 40, 0);
        if (has(p, "c06") && p.isInWater()) effect(p, MobEffects.MOVEMENT_SLOWDOWN, 40, 1);
        if (has(p, "c15") && p.isInWater()) keep(p, MobEffects.DOLPHINS_GRACE, 0);
        if (has(p, "c17") && level.getMaxLocalRawBrightness(bp) < 4) effect(p, MobEffects.WEAKNESS, 40, 0);
        if (has(p, "u10") && !isWeapon(main)) keep(p, MobEffects.MOVEMENT_SPEED, 0);
        if (has(p, "r05")) keep(p, MobEffects.GLOWING, 0);
        if (has(p, "l10")) keep(p, MobEffects.DIG_SPEED, 4);
        if (has(p, "l11")) keep(p, MobEffects.MOVEMENT_SPEED, 2);
        if (has(p, "l19")) keep(p, MobEffects.LUCK, 4);
        if (has(p, "r13") && p.isUnderWater()) p.hurt(p.damageSources().drown(), 1f); // Sợ Nước
        if (has(p, "l02") && p.getY() > 100) { // Sợ Độ Cao
            effect(p, MobEffects.CONFUSION, 100, 0);
            effect(p, MobEffects.MOVEMENT_SLOWDOWN, 40, 1);
        }
        if (has(p, "l06") && sunny && p.getItemBySlot(EquipmentSlot.HEAD).isEmpty() && !p.isInWaterRainOrBubble()) {
            p.setSecondsOnFire(8); // Thân Xác Undead
        }

        // Lửa Trại: đứng yên 5 giây thì hồi 1 HP mỗi 4 giây
        if (has(p, "c06") && st.stillTicks >= 100 && (st.stillTicks / 20) % 4 == 0) p.heal(1f);
        // Ôm Cây
        if (has(p, "u17") && (p.tickCount / 20) % 3 == 0 && nearLog(level, bp)) p.heal(1f);
        // Khô Mang
        if (has(p, "u15")) {
            st.dryTicks = p.isInWaterOrRain() ? 0 : st.dryTicks + 20;
            if (st.dryTicks > 6000) effect(p, MobEffects.MOVEMENT_SLOWDOWN, 40, 0);
        }
        // Mắt Thần: giữ Shift
        if (has(p, "r05") && p.isShiftKeyDown()) {
            for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(24), x -> x != p && x instanceof Enemy)) {
                m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 30, 0, false, false));
            }
        }
        // Ninja: cúi yên 2 giây
        if (has(p, "r09")) {
            if (p.isShiftKeyDown() && st.stillTicks >= 40) {
                p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 40, 0, false, false, true));
                if (!st.ninja) {
                    for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(32), x -> x.getTarget() == p)) m.setTarget(null);
                }
                st.ninja = true;
            } else {
                st.ninja = false;
            }
        }
        // Nhịp Tim
        if (has(p, "e16") && p.getHealth() < p.getMaxHealth() * 0.3f && st.ready("e16", now, 1200)) {
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        }
        // Ma Trận
        if (has(p, "l09") && p.getHealth() < 4f) {
            for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16))) {
                m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 3, false, false));
            }
            for (Projectile pr : level.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(16))) {
                if (!pr.getPersistentData().getBoolean("wc_slowed") && pr.getOwner() != p) {
                    pr.getPersistentData().putBoolean("wc_slowed", true);
                    pr.setDeltaMovement(pr.getDeltaMovement().scale(0.4));
                }
            }
        }
        // Mây Mưa Riêng
        if (has(p, "e19")) {
            level.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 3.2, p.getZ(), 12, 0.6, 0.1, 0.6, 0.0);
            level.sendParticles(ParticleTypes.FALLING_WATER, p.getX(), p.getY() + 2.9, p.getZ(), 10, 0.5, 0.0, 0.5, 0.0);
            for (BlockPos f : BlockPos.betweenClosed(bp.offset(-3, -2, -3), bp.offset(3, 3, 3))) {
                BlockState s = level.getBlockState(f);
                if (s.is(BlockTags.FIRE)) level.removeBlock(f, false);
            }
        }
        // Mèo Hộ Mệnh: Creeper sợ bạn
        if (has(p, "u09")) {
            for (Creeper c : level.getEntitiesOfClass(Creeper.class, p.getBoundingBox().inflate(6))) {
                c.setTarget(null);
                c.setSwellDir(-1);
                Vec3 away = c.position().subtract(p.position()).normalize().scale(6).add(c.position());
                c.getNavigation().moveTo(away.x, away.y, away.z, 1.3);
            }
        }
        // Golem Nghi Ngờ
        if (has(p, "c20") && p.tickCount % 40 == 0) {
            for (IronGolem g : level.getEntitiesOfClass(IronGolem.class, p.getBoundingBox().inflate(32), x -> !isOwnedBy(x, p))) {
                g.getLookControl().setLookAt(p, 30f, 30f);
                if (g.distanceToSqr(p) > 16) g.getNavigation().moveTo(p, 0.6);
            }
        }
        // Truy Nã: vào làng ban đêm thì Golem tấn công
        if (has(p, "r17") && level.isNight() && level.isVillage(bp)) {
            for (IronGolem g : level.getEntitiesOfClass(IronGolem.class, p.getBoundingBox().inflate(24), x -> !isOwnedBy(x, p))) {
                if (!p.isCreative()) g.setTarget(p);
            }
        }
        // Cà Khịa: mob trung lập thù địch
        if (has(p, "e03") && !p.isCreative()) {
            for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16))) {
                if (m instanceof NeutralMob nm && !(m instanceof Wolf w && w.isTame()) && !(m instanceof IronGolem)) {
                    nm.setPersistentAngerTarget(p.getUUID());
                    nm.setRemainingPersistentAngerTime(400);
                    m.setTarget(p);
                }
            }
        }
        // Vệ Sĩ Sắt
        if (has(p, "e03")) golemGuard(p, d, level);
        // Bầy Sói
        if (has(p, "r11")) wolfPack(p, d, level);
        // Nam Châm Túi / Hố Đen Mini / Nam Châm Ngược
        if (has(p, "c05") || has(p, "r06")) magnet(p, level, has(p, "r06") ? 10 : 4);
        if (has(p, "c05")) {
            for (ExperienceOrb orb : level.getEntitiesOfClass(ExperienceOrb.class, p.getBoundingBox().inflate(6))) {
                Vec3 away = orb.position().subtract(p.position()).normalize().scale(0.35);
                orb.setDeltaMovement(away.x, 0.15, away.z);
            }
        }
        // Mất Ngủ: Phantom xuất hiện dù ngủ đều
        if (has(p, "u09") && p.tickCount % 1200 == 0) {
            p.getStats().setValue(p, Stats.CUSTOM.get(Stats.TIME_SINCE_REST), 80000);
        }
        // Dẫn Đường
        if (has(p, "u14") && p.tickCount % 40 == 0) village(p, st, level, now);
        // Rồng Con: hết thời gian bay
        if (st.flightEnd > 0 && now >= st.flightEnd) {
            st.flightEnd = 0;
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
                p.onUpdateAbilities();
                p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 120, 0));
            }
        }
        // Kỹ năng bị cướp hết hạn
        if (!st.stolen.isEmpty() && now >= st.stolenUntil) {
            st.stolen = "";
            com.hoang.wildcard.RoundManager.sync(p);
        }
        // Nông Dân Chăm Chỉ: cây lớn nhanh gấp đôi (thêm random tick quanh bạn)
        if (has(p, "c18")) {
            for (int i = 0; i < 20; i++) {
                BlockPos c = bp.offset(rng.nextInt(17) - 8, rng.nextInt(5) - 2, rng.nextInt(17) - 8);
                BlockState s = level.getBlockState(c);
                if ((s.getBlock() instanceof CropBlock || s.getBlock() instanceof BonemealableBlock) && s.isRandomlyTicking()) {
                    s.randomTick(level, c, rng);
                }
            }
        }
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    private static boolean nearLog(ServerLevel level, BlockPos bp) {
        for (BlockPos q : BlockPos.betweenClosed(bp.offset(-1, 0, -1), bp.offset(1, 1, 1))) {
            if (level.getBlockState(q).is(BlockTags.LOGS)) return true;
        }
        return false;
    }

    private static void magnet(ServerPlayer p, ServerLevel level, double r) {
        AABB box = p.getBoundingBox().inflate(r);
        for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, box, x -> !x.hasPickUpDelay())) {
            Vec3 dir = p.position().add(0, 0.5, 0).subtract(ie.position());
            if (dir.lengthSqr() > 0.5) ie.setDeltaMovement(dir.normalize().scale(0.45));
        }
        if (r > 5) {
            for (ExperienceOrb orb : level.getEntitiesOfClass(ExperienceOrb.class, box)) {
                Vec3 dir = p.position().add(0, 0.5, 0).subtract(orb.position());
                if (dir.lengthSqr() > 0.5) orb.setDeltaMovement(dir.normalize().scale(0.5));
            }
        }
    }

    private static void golemGuard(ServerPlayer p, WData d, ServerLevel level) {
        List<IronGolem> golems = level.getEntitiesOfClass(IronGolem.class, p.getBoundingBox().inflate(64), g -> isOwnedBy(g, p));
        if (golems.isEmpty()) {
            int t = d.extra.getInt("e03_timer") + 20;
            if (t >= 3600) {
                spawnGolem(p);
                t = 0;
            }
            d.extra.putInt("e03_timer", t);
            return;
        }
        d.extra.putInt("e03_timer", 0);
        LivingEntity threat = p.getLastHurtByMob();
        for (IronGolem g : golems) {
            double dist = g.distanceToSqr(p);
            if (dist > 40 * 40) g.teleportTo(p.getX(), p.getY(), p.getZ());
            else if (dist > 64 && g.getTarget() == null) g.getNavigation().moveTo(p, 1.0);
            if (threat != null && threat.isAlive() && threat != g && !(threat instanceof Player)) g.setTarget(threat);
        }
    }

    private static void wolfPack(ServerPlayer p, WData d, ServerLevel level) {
        List<Wolf> wolves = level.getEntitiesOfClass(Wolf.class, p.getBoundingBox().inflate(64), w -> w.isTame() && p.getUUID().equals(w.getOwnerUUID()));
        if (wolves.size() < 2) {
            int t = d.extra.getInt("r11_timer") + 20;
            if (t >= 3600) {
                for (int i = wolves.size(); i < 2; i++) spawnWolf(p);
                t = 0;
            }
            d.extra.putInt("r11_timer", t);
        } else {
            d.extra.putInt("r11_timer", 0);
        }
    }

    private static void village(ServerPlayer p, PlayerState st, ServerLevel level, long now) {
        if (now - st.villageCacheTime > 600) {
            st.villageCacheTime = now;
            st.villagePos = level.findNearestMapStructure(net.minecraft.tags.StructureTags.VILLAGE, p.blockPosition(), 64, false);
        }
        if (st.villagePos == null) {
            actionBar(p, Component.translatable("msg.wildcard.novillage").withStyle(ChatFormatting.GRAY));
            return;
        }
        double dx = st.villagePos.getX() + 0.5 - p.getX();
        double dz = st.villagePos.getZ() + 0.5 - p.getZ();
        int dist = (int) Math.sqrt(dx * dx + dz * dz);
        String[] names = {"Nam", "Tây Nam", "Tây", "Tây Bắc", "Bắc", "Đông Bắc", "Đông", "Đông Nam"};
        double ang = Math.toDegrees(Math.atan2(-dx, dz)); // 0 = south
        int idx = Math.floorMod((int) Math.round(ang / 45.0), 8);
        actionBar(p, Component.translatable("msg.wildcard.village", dist, names[idx]).withStyle(ChatFormatting.GREEN));
    }

    private static void stomp(ServerPlayer p) {
        Vec3 v = p.getDeltaMovement();
        if (p.onGround() || p.fallDistance < 1.5f) return;
        AABB feet = p.getBoundingBox().move(0, -0.6, 0).deflate(0.05, 0, 0.05);
        List<LivingEntity> hits = p.level().getEntitiesOfClass(LivingEntity.class, feet, m -> m != p && m.isAlive() && !(m instanceof Player));
        if (hits.isEmpty()) return;
        LivingEntity m = hits.get(0);
        if (m.getBoundingBox().maxY > p.getY() + 0.1) return;
        m.hurt(p.damageSources().playerAttack(p), 8f);
        p.setDeltaMovement(v.x, 0.7, v.z);
        p.hurtMarked = true;
        p.fallDistance = 0;
        p.level().playSound(null, m.blockPosition(), SoundEvents.SLIME_SQUISH, SoundSource.PLAYERS, 1f, 0.8f);
    }

    private static void headBreak(ServerPlayer p, ServerLevel level) {
        if (p.getDeltaMovement().y <= 0.05 || p.onGround()) return;
        BlockPos head = BlockPos.containing(p.getX(), p.getBoundingBox().maxY + 0.2, p.getZ());
        BlockState s = level.getBlockState(head);
        if (s.is(BlockTags.LEAVES) || s.is(net.minecraftforge.common.Tags.Blocks.GLASS) || s.is(net.minecraftforge.common.Tags.Blocks.GLASS_PANES)) {
            level.destroyBlock(head, true, p);
        }
    }

    private static void periodic(ServerPlayer p, WData d, PlayerState st, ServerLevel level, long now, RandomSource rng, int tc) {
        // Gà Mái Tốt Bụng: cứ 2 phút đẻ 1 trứng
        if (has(p, "c07") && st.ready("c07", now, 2400)) {
            if (d.extra.getInt("c07_init") == 1) {
                dropAt(level, p.getX(), p.getY() + 0.3, p.getZ(), new ItemStack(Items.EGG));
                level.playSound(null, p.blockPosition(), SoundEvents.CHICKEN_EGG, SoundSource.PLAYERS, 1f, 1f);
            }
            d.extra.putInt("c07_init", 1);
        }
        // Hắt Xì: cứ 90 giây
        if (has(p, "c12") && st.ready("c12", now, 1800) && d.extra.getInt("c12_init") == 1) {
            float yaw = rng.nextFloat() * 360f;
            p.setDeltaMovement(p.getDeltaMovement().add(Math.sin(Math.toRadians(yaw)) * 0.5, 0.2, Math.cos(Math.toRadians(yaw)) * 0.5));
            p.hurtMarked = true;
            level.playSound(null, p.blockPosition(), SoundEvents.PANDA_SNEEZE, SoundSource.PLAYERS, 1f, 1.2f);
            Net.toPlayer(p, new Net.Fx("sneeze", 0));
        }
        if (has(p, "c12")) d.extra.putInt("c12_init", 1);
        // Gió Ngược: cứ 45 giây
        if (has(p, "e02") && st.ready("e02", now, 900) && d.extra.getInt("e02_init") == 1) {
            double a = rng.nextDouble() * Math.PI * 2;
            p.setDeltaMovement(Math.cos(a) * 1.4, 0.45, Math.sin(a) * 1.4);
            p.hurtMarked = true;
            level.playSound(null, p.blockPosition(), SoundEvents.ELYTRA_FLYING, SoundSource.PLAYERS, 0.6f, 1.5f);
            level.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 20, 0.5, 0.5, 0.5, 0.1);
        }
        if (has(p, "e02")) d.extra.putInt("e02_init", 1);
        // Bão Lửa: cứ 10 giây bắn cầu lửa vào mob gần nhất
        if (has(p, "e01") && tc % 200 == 0) {
            Monster target = level.getNearestEntity(Monster.class, net.minecraft.world.entity.ai.targeting.TargetingConditions.forCombat().range(16),
                    p, p.getX(), p.getY(), p.getZ(), p.getBoundingBox().inflate(16));
            if (target != null) {
                Vec3 from = p.getEyePosition();
                Vec3 dir = target.getEyePosition().subtract(from);
                SmallFireball fb = new SmallFireball(level, p, dir.x, dir.y, dir.z);
                fb.setPos(from.x, from.y, from.z);
                level.addFreshEntity(fb);
                level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.7f, 1.2f);
            }
        }
        // Mưa Đe: cứ 60 giây
        if (has(p, "e07") && tc % 1200 == 600) dropAnvil(p, level, rng);
        // Gà Báo Thù: cứ 3 phút
        if (has(p, "e08") && tc % 3600 == 1800) {
            net.minecraft.world.entity.animal.Chicken ch = spawnNear(p, EntityType.CHICKEN, 8, 14);
            if (ch != null) {
                Zombie z = EntityType.ZOMBIE.create(level);
                if (z != null) {
                    z.setBaby(true);
                    z.moveTo(ch.getX(), ch.getY(), ch.getZ(), 0, 0);
                    level.addFreshEntity(z);
                    z.startRiding(ch, true);
                    z.setTarget(p);
                }
            }
        }
        // Tối Sầm: cứ 30 giây
        if (has(p, "e10") && tc % 600 == 300) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0));
        // Cột Thu Lôi: giông thì cứ 60 giây bị sét đánh
        if (has(p, "r07") && level.isThundering() && tc % 1200 == 0 && level.canSeeSky(p.blockPosition())) {
            lightning(level, p.position(), null, false);
        }
        // Dẫn Điện: giáp kim loại + giông, cứ 20 giây
        if (has(p, "l01") && level.isThundering() && tc % 400 == 0 && wearsMetal(p)) lightning(level, p.position(), null, false);
        // Fan Creeper
        if (has(p, "u13") && tc % 1200 == 900 && (level.isNight() || level.getMaxLocalRawBrightness(p.blockPosition()) < 7)) {
            spawnNear(p, EntityType.CREEPER, 12, 22);
        }
        // Sói Ăn Vụng: cứ 2 phút
        if (has(p, "r11") && tc % 2400 == 1200) stealMeat(p);
        // Túi Đồ Hỗn Loạn: cứ 60 giây
        if (has(p, "l14") && tc % 1200 == 0) shuffleInventory(p, rng);
        // Mạng Lag: cứ 90 giây giật về 3 giây trước
        if (has(p, "l09") && tc % 1800 == 900 && st.history.size() >= 60 && p.getVehicle() == null) {
            Vec3 back = st.history.peekFirst();
            p.teleportTo(back.x, back.y, back.z);
        }
        // Thu Hút Đồng Loại
        if (has(p, "l08") && st.lastKilledType != null && tc % 1200 == 600) {
            EntityType<?> t = st.lastKilledType;
            Entity ent = t.create(level);
            if (ent instanceof Monster) {
                @SuppressWarnings("unchecked") EntityType<Monster> mt = (EntityType<Monster>) t;
                for (int i = 0; i < 2; i++) spawnNear(p, mt, 10, 20);
            }
            if (ent != null) ent.discard();
        }
        // Sao Chổi: cứ 5 phút một sự cố xui
        if (has(p, "l19") && tc % 6000 == 3000) misfortune(p, level, rng);
    }

    private static boolean wearsMetal(Player p) {
        for (ItemStack a : p.getArmorSlots()) {
            if (a.getItem() instanceof ArmorItem ai) {
                ArmorMaterial m = ai.getMaterial();
                if (m == ArmorMaterials.IRON || m == ArmorMaterials.GOLD || m == ArmorMaterials.CHAIN || m == ArmorMaterials.NETHERITE) return true;
            }
        }
        return false;
    }

    public static void dropAnvil(ServerPlayer p, ServerLevel level, RandomSource rng) {
        for (int i = 0; i < 8; i++) {
            int x = p.getBlockX() + rng.nextInt(11) - 5;
            int z = p.getBlockZ() + rng.nextInt(11) - 5;
            BlockPos pos = new BlockPos(x, p.getBlockY() + 10, z);
            if (!level.getBlockState(pos).isAir()) continue;
            FallingBlockEntity fb = FallingBlockEntity.fall(level, pos, Blocks.ANVIL.defaultBlockState());
            fb.setHurtsEntities(2.0f, 40);
            return;
        }
    }

    private static void stealMeat(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (isMeat(s.getItem())) {
                s.shrink(1);
                p.level().playSound(null, p.blockPosition(), SoundEvents.WOLF_GROWL, SoundSource.NEUTRAL, 1f, 1f);
                return;
            }
        }
    }

    private static boolean isMeat(Item i) {
        return i == Items.BEEF || i == Items.COOKED_BEEF || i == Items.PORKCHOP || i == Items.COOKED_PORKCHOP
                || i == Items.CHICKEN || i == Items.COOKED_CHICKEN || i == Items.MUTTON || i == Items.COOKED_MUTTON
                || i == Items.RABBIT || i == Items.COOKED_RABBIT || i == Items.ROTTEN_FLESH;
    }

    private static void shuffleInventory(ServerPlayer p, RandomSource rng) {
        Inventory inv = p.getInventory();
        List<ItemStack> items = new ArrayList<>();
        for (int i = 0; i < 36; i++) items.add(inv.getItem(i));
        Collections.shuffle(items, new Random(rng.nextLong()));
        for (int i = 0; i < 36; i++) inv.setItem(i, items.get(i));
        p.inventoryMenu.broadcastChanges();
        p.level().playSound(null, p.blockPosition(), SoundEvents.BUNDLE_DROP_CONTENTS, SoundSource.PLAYERS, 1f, 1f);
    }

    private static void misfortune(ServerPlayer p, ServerLevel level, RandomSource rng) {
        switch (rng.nextInt(4)) {
            case 0 -> lightning(level, p.position(), null, false);
            case 1 -> dropAnvil(p, level, rng);
            case 2 -> {
                Vec3 back = p.getLookAngle().multiply(1, 0, 1).normalize().scale(-2.5).add(p.position());
                Creeper c = EntityType.CREEPER.create(level);
                if (c != null) {
                    c.moveTo(back.x, p.getY(), back.z, p.getYRot(), 0);
                    level.addFreshEntity(c);
                    c.setTarget(p);
                }
            }
            default -> {
                List<ItemStack> damageable = new ArrayList<>();
                for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).isDamageableItem()) damageable.add(p.getInventory().getItem(i));
                if (!damageable.isEmpty()) {
                    ItemStack s = damageable.get(rng.nextInt(damageable.size()));
                    int left = s.getMaxDamage() - s.getDamageValue();
                    s.setDamageValue(Math.min(s.getMaxDamage() - 1, s.getDamageValue() + left / 2));
                    level.playSound(null, p.blockPosition(), SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 1f, 0.6f);
                }
            }
        }
    }

    private Effects() {}
}
