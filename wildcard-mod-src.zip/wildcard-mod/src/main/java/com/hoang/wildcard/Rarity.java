package com.hoang.wildcard;

import net.minecraft.network.chat.Component;

public enum Rarity {
    COMMON("common", 0xFFA8A8A8),
    UNCOMMON("uncommon", 0xFF55D86A),
    RARE("rare", 0xFF4A9BFF),
    EPIC("epic", 0xFFB45CFF),
    LEGENDARY("legendary", 0xFFFFB020);

    public final String key;
    /** ARGB colour used for border and title. */
    public final int color;

    Rarity(String key, int color) {
        this.key = key;
        this.color = color;
    }

    public Component displayName() {
        return Component.translatable("rarity.wildcard." + key);
    }

    public int rgb() {
        return color & 0xFFFFFF;
    }

    public int baseWeight() {
        return switch (this) {
            case COMMON -> Config.W_COMMON.get();
            case UNCOMMON -> Config.W_UNCOMMON.get();
            case RARE -> Config.W_RARE.get();
            case EPIC -> Config.W_EPIC.get();
            case LEGENDARY -> Config.W_LEGENDARY.get();
        };
    }

    public boolean isEpicOrBetter() {
        return this == EPIC || this == LEGENDARY;
    }
}
