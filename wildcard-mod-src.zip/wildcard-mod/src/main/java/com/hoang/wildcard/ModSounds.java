package com.hoang.wildcard;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Our sound events. Files live in assets/wildcard/sounds and are listed in sounds.json, so a resource pack
 * (or editing the mod zip) can swap any of them for your own .ogg clips.
 */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> REG = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, WildcardMod.MODID);

    public static final RegistryObject<SoundEvent> ROLL_SPIN = reg("roll.spin");
    public static final RegistryObject<SoundEvent> ROLL_FLIP = reg("roll.flip");
    public static final RegistryObject<SoundEvent> ROLL_VIP = reg("roll.vip");
    public static final RegistryObject<SoundEvent> ROLL_LEGENDARY = reg("roll.legendary");
    public static final RegistryObject<SoundEvent> ROLL_MYTHIC = reg("roll.mythic");
    public static final RegistryObject<SoundEvent> ROLL_MEME = reg("roll.meme");
    public static final RegistryObject<SoundEvent> VINE_BOOM = reg("meme.vineboom");
    public static final RegistryObject<SoundEvent> BRUH = reg("meme.bruh");
    public static final RegistryObject<SoundEvent> RICKROLL = reg("meme.rickroll");
    public static final RegistryObject<SoundEvent> TRAP = reg("meme.trap");
    public static final RegistryObject<SoundEvent> JACKPOT = reg("meme.jackpot");
    public static final RegistryObject<SoundEvent> JACKPOT_WIN = reg("meme.jackpot_win");
    public static final RegistryObject<SoundEvent> LA_PEACE = reg("meme.lapeace");
    public static final RegistryObject<SoundEvent> SUS = reg("meme.sus");
    public static final RegistryObject<SoundEvent> FAIL = reg("meme.fail");
    public static final RegistryObject<SoundEvent> SIGMA = reg("meme.sigma");
    /** "impact.<element>": v3.3 spell impact per school. */
    public static final Map<com.hoang.wildcard.fx.Element, RegistryObject<SoundEvent>> IMPACT = new java.util.EnumMap<>(com.hoang.wildcard.fx.Element.class);
    /** "card.<id>": played when that card's skill is used. */
    public static final Map<String, RegistryObject<SoundEvent>> CARD = new HashMap<>();

    static {
        for (String id : Cards.ALL.keySet()) CARD.put(id, reg("card." + id));
        for (com.hoang.wildcard.fx.Element e : com.hoang.wildcard.fx.Element.values()) IMPACT.put(e, reg("impact." + e.key()));
    }

    private static RegistryObject<SoundEvent> reg(String name) {
        return REG.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(WildcardMod.MODID, name)));
    }

    public static SoundEvent card(String id) {
        RegistryObject<SoundEvent> r = CARD.get(id);
        return r == null ? null : r.get();
    }

    public static SoundEvent impact(com.hoang.wildcard.fx.Element e) {
        RegistryObject<SoundEvent> r = IMPACT.get(e);
        return r == null ? null : r.get();
    }

    public static void register(IEventBus bus) {
        REG.register(bus);
    }

    private ModSounds() {}
}
