package com.hoang.wildcard.effects;

import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.AbstractFish;
import net.minecraft.world.entity.animal.frog.Frog;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.animal.horse.Variant;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

import static com.hoang.wildcard.effects.Effects.*;

/**
 * v7.1 cards copied from the player's screenshots (ids c151-c160, u201-u210, r51-r63, e31-e40, l26-l32, data in
 * V71Data). Server side; the client half (input lag, glide, double jump, screen effects...) is client/V71Client.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class V71Cards {
    private static final Random RNG = new Random();
    private static final Map<UUID, Integer> BLOODLUST = new HashMap<>();
    private static final Map<UUID, float[]> SIZE_SENT = new HashMap<>();
    private static final Map<UUID, Simon> SIMON = new HashMap<>();
    private static final Map<UUID, String> GUEST = new HashMap<>();
    private static final Map<BlockPos, long[]> MELT = new HashMap<>(); // pos -> {melt at, level hash}
    private static final Map<UUID, Long> BARTER = new HashMap<>();
    private static final String[] GUESTS = {"Herobrine", "Entity303", "xX_Noob_Xx", "Steve", "Alex", "NullPlayer", "Bo_Cua_Ban", "Notch2"};

    private static final class Simon {
        int order;
        boolean simonSaid, did;
        long until;
        double y, x, z;
    }

    // ================================================================== helpers

    /** Scale of a player's body: Người Lùn 0.85, Nhỏ Như Bỏ Túi 0.5. */
    public static float scaleOf(Player p) {
        float f = 1f;
        if (has(p, "r51")) f *= 0.85f;
        if (has(p, "l29")) f *= 0.5f;
        return f;
    }

    /** Jump power multiplier (height): Nhanh Nhẹn, Bước Đệm, Nhảy Siêu Cao, Đầu Gối Cứng. */
    public static float jumpMul(Player p) {
        float h = 1f;
        if (has(p, "c158")) h += 0.15f;
        if (has(p, "u202")) h += 0.35f;
        if (has(p, "r59")) h += 0.30f;
        if (has(p, "c153")) h -= 0.15f;
        return (float) Math.sqrt(Math.max(0.2f, h)); // tốc độ bật nhảy ~ căn bậc hai độ cao
    }

    private static boolean anyOwner(Level level, String id, Vec3 at, double r) {
        for (Player pl : level.players()) if (has(pl, id) && pl.position().distanceToSqr(at) < r * r) return true;
        return false;
    }

    private static boolean anyOwner(Level level, String id) {
        for (Player pl : level.players()) if (has(pl, id)) return true;
        return false;
    }

    private static void boost(LivingEntity e, String key, double pct) {
        AttributeInstance ai = e.getAttribute(Attributes.MAX_HEALTH);
        UUID id = uuid("v71_" + key);
        if (ai == null || ai.getModifier(id) != null) return;
        ai.addPermanentModifier(new AttributeModifier(id, "wildcard " + key, pct, AttributeModifier.Operation.MULTIPLY_TOTAL));
        e.setHealth(e.getMaxHealth());
    }

    private static boolean sunny(ServerPlayer p) {
        Level l = p.level();
        BlockPos bp = BlockPos.containing(p.getX(), p.getEyeY(), p.getZ());
        return l.dimension() == Level.OVERWORLD && l.isDay() && !l.isRaining() && l.canSeeSky(bp) && !p.isInWaterRainOrBubble();
    }

    private static boolean melee(DamageSource s, Player p) {
        return s.getDirectEntity() == p && !s.is(net.minecraft.tags.DamageTypeTags.IS_PROJECTILE);
    }

    private static void dropHeld(ServerPlayer p) {
        ItemStack held = p.getMainHandItem();
        if (held.isEmpty()) return;
        p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        ItemEntity ie = p.drop(held, true, false);
        if (ie != null) ie.setPickUpDelay(40);
        actionBar(p, Component.translatable("msg.wildcard.v71.slip").withStyle(ChatFormatting.RED));
    }

    private static void title(ServerPlayer p, Component t, Component sub) {
        p.connection.send(new ClientboundSetTitleTextPacket(t));
        if (sub != null) p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
    }

    // ================================================================== tick

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        PlayerState st = PlayerState.get(p);
        RandomSource rng = p.getRandom();
        int tc = p.tickCount;

        // kích thước cơ thể
        if (tc % 10 == 0) {
            float s = scaleOf(p);
            float[] last = SIZE_SENT.get(p.getUUID());
            if (last == null || last[0] != s) {
                SIZE_SENT.put(p.getUUID(), new float[]{s});
                p.refreshDimensions();
                Net.CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new Net.Size(p.getId(), s));
            }
        }
        if (tc % 10 == 0) {
            attr(p, ForgeMod.STEP_HEIGHT_ADDITION.get(), "v71_step", 1.0, AttributeModifier.Operation.ADDITION, has(p, "c152"));
            attr(p, Attributes.ATTACK_KNOCKBACK, "v71_kb", 0.2, AttributeModifier.Operation.ADDITION, has(p, "c157"));
            attr(p, ForgeMod.ENTITY_GRAVITY.get(), "v71_grav", 0.5, AttributeModifier.Operation.MULTIPLY_TOTAL, has(p, "c159"));
        }
        // Simon Says: kiểm tra mỗi tick trong 3 giây
        Simon sm = SIMON.get(p.getUUID());
        if (sm != null) simonCheck(p, sm, now);

        // Băng Tan
        if (has(p, "u207") && tc % 5 == 0) {
            BlockPos below = BlockPos.containing(p.getX(), p.getY() - 0.2, p.getZ());
            BlockState bs = level.getBlockState(below);
            if ((bs.is(Blocks.ICE) || bs.is(Blocks.PACKED_ICE) || bs.is(Blocks.FROSTED_ICE)) && !MELT.containsKey(below)) {
                MELT.put(below.immutable(), new long[]{now + (bs.is(Blocks.PACKED_ICE) ? 60 : 20), level.dimension().location().hashCode()});
            }
        }
        if (tc % 5 == 0 && !MELT.isEmpty()) {
            int dim = level.dimension().location().hashCode();
            MELT.entrySet().removeIf(en -> {
                if (en.getValue()[1] != dim || en.getValue()[0] > now) return false;
                BlockState bs = level.getBlockState(en.getKey());
                if (bs.is(Blocks.ICE) || bs.is(Blocks.PACKED_ICE) || bs.is(Blocks.FROSTED_ICE)) {
                    level.setBlockAndUpdate(en.getKey(), level.dimensionType().ultraWarm() ? Blocks.AIR.defaultBlockState() : Blocks.WATER.defaultBlockState());
                    level.playSound(null, en.getKey(), SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 0.6f, 1.4f);
                }
                return true;
            });
        }
        // Người Cá: nhớ lần cuối ở dưới nước
        if (has(p, "e37") && p.isInWater()) {
            st.time("e37_water", now);
            keep(p, MobEffects.CONDUIT_POWER, 0);
        }
        // Kẻ Bay Lượn: vẫn đang lượn thì không tính sát thương rơi
        if (now < st.time("glide")) p.fallDistance = 0;
        // Chắc Chắn Là RNG Hợp Lệ: nhớ piglin đang cầm vàng để đổi
        if (has(p, "l32") && tc % 5 == 0) {
            for (Piglin pg : level.getEntitiesOfClass(Piglin.class, p.getBoundingBox().inflate(16))) {
                if (pg.getOffhandItem().is(ItemTags.PIGLIN_LOVED) || pg.getOffhandItem().is(Items.GOLD_INGOT)) BARTER.put(pg.getUUID(), now);
            }
        }

        if (tc % 20 != 0) return;
        int sec = tc / 20;
        // ---- Phổ biến
        if (has(p, "c152") && GUEST.get(p.getUUID()) == null && rng.nextInt(600) == 0) { // Một Vị Khách?
            String name = GUESTS[rng.nextInt(GUESTS.length)];
            GUEST.put(p.getUUID(), name);
            // v7.3: cả server đều thấy vị khách vào, chat và rời đi
            var list = p.server.getPlayerList();
            list.broadcastSystemMessage(Component.translatable("multiplayer.player.joined", name).withStyle(ChatFormatting.YELLOW), false);
            Scheduler.later(60 + rng.nextInt(100), () -> list.broadcastSystemMessage(Component.literal("<" + name + "> ")
                    .append(Component.translatable("msg.wildcard.v71.guest." + RNG.nextInt(4))), false));
            Scheduler.later(900 + rng.nextInt(1200), () -> {
                list.broadcastSystemMessage(Component.translatable("multiplayer.player.left", name).withStyle(ChatFormatting.YELLOW), false);
                GUEST.remove(p.getUUID());
            });
        }
        // ---- Không phổ biến
        if (has(p, "u202") && sec % 20 == 0) { // Cơn Gió Bất Chợt
            double a = rng.nextDouble() * Math.PI * 2;
            p.push(Math.cos(a) * 0.9, 0.25, Math.sin(a) * 0.9);
            p.hurtMarked = true;
            level.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 15, 0.6, 0.4, 0.6, 0.05);
            level.playSound(null, p.blockPosition(), SoundEvents.ELYTRA_FLYING, SoundSource.PLAYERS, 0.4f, 1.6f);
        }
        if (has(p, "u203") && sec % 60 == 0) effect(p, MobEffects.DARKNESS, 200, 0); // Bóng Tối Lên Lỗi
        if (has(p, "u209") || has(p, "r62")) {
            // phần client (V71Client)
        }
        // ---- Hiếm
        if (has(p, "r52") || has(p, "l26")) { // Cháy Nắng / Ma Cà Rồng
            if (sunny(p) && !p.fireImmune() && p.getRemainingFireTicks() < 40) p.setSecondsOnFire(3);
        }
        if (has(p, "r53") && rng.nextInt(75) == 0) hellsKitchen(p); // Hell's Kitchen
        if (has(p, "r55") && sec % 150 == 0) { // Buổi Tiệc Skeleton
            for (int i = 0; i < 2; i++) spawnNear(p, EntityType.SKELETON, 4, 8);
            actionBar(p, Component.translatable("msg.wildcard.v71.skeleton").withStyle(ChatFormatting.GRAY));
        }
        if (has(p, "r56") && sec % 5 == 0) { // Đó Là La Peace
            BlockPos c = p.blockPosition();
            for (BlockPos bp : BlockPos.betweenClosed(c.offset(-6, -6, -6), c.offset(6, 6, 6))) {
                BlockState bs = level.getBlockState(bp);
                if (bs.is(Blocks.DIAMOND_ORE)) level.setBlockAndUpdate(bp, Blocks.LAPIS_ORE.defaultBlockState());
                else if (bs.is(Blocks.DEEPSLATE_DIAMOND_ORE)) level.setBlockAndUpdate(bp, Blocks.DEEPSLATE_LAPIS_ORE.defaultBlockState());
            }
        }
        if (has(p, "r57") && sec % 240 == 0) lightning(level, p.position(), null, false); // Kẻ Thu Hút Sét
        if (has(p, "r58") && sec % 3 == 0) { // Ác Mộng Của Ph1LzA
            for (Zombie z : level.getEntitiesOfClass(Zombie.class, p.getBoundingBox().inflate(16), z -> !z.getTags().contains("wc_philza"))) {
                z.addTag("wc_philza");
                z.setBaby(true);
                z.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.GOLDEN_HELMET));
                z.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.GOLDEN_CHESTPLATE));
                z.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.GOLDEN_LEGGINGS));
                z.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.GOLDEN_BOOTS));
                for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) z.setDropChance(s, 0f);
                level.sendParticles(ParticleTypes.WAX_ON, z.getX(), z.getY() + 0.5, z.getZ(), 10, 0.3, 0.3, 0.3, 0.1);
            }
        }
        if (has(p, "r59") && sec % 60 == 0) { // Cái Chạm Của Wither (không mất máu)
            effect(p, MobEffects.WEAKNESS, 120, 1);
            effect(p, MobEffects.MOVEMENT_SLOWDOWN, 120, 0);
        }
        if (has(p, "r60")) { // Ếch muốn ăn thịt bạn
            for (Frog f : level.getEntitiesOfClass(Frog.class, p.getBoundingBox().inflate(12))) {
                if (f.distanceToSqr(p) > 2.5) f.getNavigation().moveTo(p, 1.4);
                else {
                    p.hurt(p.damageSources().mobAttack(f), 1f);
                    effect(p, MobEffects.MOVEMENT_SLOWDOWN, 30, 1);
                    level.playSound(null, f.blockPosition(), SoundEvents.FROG_TONGUE, SoundSource.HOSTILE, 1f, 1f);
                }
            }
        }
        if (has(p, "r61") && sec % 120 == 0) { // Túi Thủng
            List<Integer> slots = new ArrayList<>();
            for (int i = 0; i < 36; i++) if (!p.getInventory().getItem(i).isEmpty()) slots.add(i);
            if (!slots.isEmpty()) {
                int i = slots.get(rng.nextInt(slots.size()));
                ItemStack s = p.getInventory().removeItemNoUpdate(i);
                ItemEntity ie = p.drop(s, true, false);
                if (ie != null) ie.setPickUpDelay(60);
                actionBar(p, Component.translatable("msg.wildcard.v71.hole").withStyle(ChatFormatting.RED));
            }
        }
        if (has(p, "r63") && p.getHealth() < 4f && now >= st.time("r63_cd")) { // Berserker
            st.time("r63_cd", now + 1200);
            effect(p, MobEffects.DAMAGE_BOOST, 200, 1);
            level.playSound(null, p.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 0.8f, 1.3f);
        }
        // ---- Sử thi
        if (has(p, "e32") && sec % 30 == 0 && !SIMON.containsKey(p.getUUID())) simonStart(p, now);
        if (has(p, "e34")) { // Màn Trình Diễn Pháo Hoa + Cây Này Biết Nói
            for (Creeper c : level.getEntitiesOfClass(Creeper.class, p.getBoundingBox().inflate(16), c -> c.getSwellDir() > 0 && !c.getTags().contains("wc_fw"))) {
                c.addTag("wc_fw");
                c.setDeltaMovement(0, 1.2, 0);
                c.hurtMarked = true;
                Scheduler.later(18, () -> {
                    if (!c.isAlive()) return;
                    fireworks(level, c.position());
                    c.discard();
                });
            }
            if (sec % 10 == 0) {
                BlockPos c = p.blockPosition();
                List<BlockPos> leaves = new ArrayList<>();
                for (BlockPos bp : BlockPos.betweenClosed(c.offset(-6, -3, -6), c.offset(6, 6, 6)))
                    if (level.getBlockState(bp).is(net.minecraft.tags.BlockTags.LEAVES)) leaves.add(bp.immutable());
                for (int i = 0; i < Math.min(3, leaves.size()); i++) {
                    BlockPos bp = leaves.remove(rng.nextInt(leaves.size()));
                    level.destroyBlock(bp, false);
                    if (rng.nextInt(4) == 0) {
                        Creeper cr = EntityType.CREEPER.create(level);
                        if (cr != null) {
                            cr.moveTo(bp.getX() + 0.5, bp.getY(), bp.getZ() + 0.5, rng.nextFloat() * 360, 0);
                            level.addFreshEntity(cr);
                        }
                    }
                }
            }
        }
        if (has(p, "e36") && sec % 120 == 0) lightning(level, p.position(), null, false); // Cột Thu Lôi
        if (has(p, "e38") && sec % 5 == 0) blackHorse(p, level);
        if (has(p, "e39")) witherPower(p, level, rng);
        // ---- Huyền thoại
        if (has(p, "l27") && sec % 5 == 0) { // Lời Nguyền Pharaoh: +1 cát
            WData d = WData.get(p);
            int sand = Math.min(200, d.extra.getInt("l27_sand") + 1);
            d.extra.putInt("l27_sand", sand);
            if (sand % 10 == 0) actionBar(p, Component.translatable("msg.wildcard.v71.sand", sand).withStyle(ChatFormatting.YELLOW));
        }
        if (has(p, "l28") && sec % 10 == 0) { // Mưa TNT
            PrimedTnt tnt = new PrimedTnt(level, p.getX(), p.getY() + 6, p.getZ(), null);
            tnt.setFuse(50);
            level.addFreshEntity(tnt);
            level.playSound(null, p.blockPosition(), SoundEvents.TNT_PRIMED, SoundSource.HOSTILE, 1f, 1f);
        }
        if (has(p, "l31") && sec % 3 == 0) amogus(p, level);
    }

    // ================================================================== Simon Says

    private static final int ORDERS = 6; // nhảy, ngồi, nhìn lên, nhìn xuống, vung tay, đứng yên

    private static void simonStart(ServerPlayer p, long now) {
        Simon s = new Simon();
        s.order = RNG.nextInt(ORDERS);
        s.simonSaid = RNG.nextInt(4) != 0; // 25%: "Simon không nói" - đừng làm theo
        s.until = now + 60;
        s.x = p.getX();
        s.y = p.getY();
        s.z = p.getZ();
        SIMON.put(p.getUUID(), s);
        Component order = Component.translatable("msg.wildcard.v71.simon.o" + s.order);
        title(p, Component.translatable(s.simonSaid ? "msg.wildcard.v71.simon.says" : "msg.wildcard.v71.simon.plain").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                order.copy().withStyle(ChatFormatting.YELLOW));
        p.playNotifySound(SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.MASTER, 1f, 1.2f);
    }

    private static void simonCheck(ServerPlayer p, Simon s, long now) {
        boolean doing = switch (s.order) {
            case 0 -> p.getY() > s.y + 0.4;
            case 1 -> p.isShiftKeyDown();
            case 2 -> p.getXRot() < -55;
            case 3 -> p.getXRot() > 55;
            case 4 -> p.swinging;
            default -> false;
        };
        if (s.order == 5) { // đứng yên: hỏng nếu di chuyển
            if (p.position().distanceToSqr(s.x, s.y, s.z) > 0.25) s.did = true;
        } else if (doing) s.did = true;
        if (now < s.until) return;
        SIMON.remove(p.getUUID());
        boolean obeyed = s.order == 5 ? !s.did : s.did;
        boolean win = s.simonSaid == obeyed;
        if (win) {
            Item[] loot = {Items.IRON_INGOT, Items.GOLD_INGOT, Items.EMERALD, Items.LAPIS_LAZULI, Items.REDSTONE, Items.COAL, Items.COPPER_INGOT, Items.AMETHYST_SHARD, Items.QUARTZ};
            ItemStack prize = RNG.nextInt(10) == 0 ? new ItemStack(Items.DIAMOND) : new ItemStack(loot[RNG.nextInt(loot.length)], 1 + RNG.nextInt(3));
            give(p, prize);
            actionBar(p, Component.translatable("msg.wildcard.v71.simon.win", prize.getHoverName()).withStyle(ChatFormatting.GREEN));
            p.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.MASTER, 0.6f, 1.5f);
        } else {
            var holder = p.level().registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(Skills.TRUE_DAMAGE);
            p.hurt(new DamageSource(holder), 2f);
            actionBar(p, Component.translatable("msg.wildcard.v71.simon.lose").withStyle(ChatFormatting.RED));
        }
    }

    // ================================================================== misc effects

    private static void hellsKitchen(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        var snd = switch (RNG.nextInt(4)) {
            case 0 -> SoundEvents.ANVIL_LAND;
            case 1 -> SoundEvents.VILLAGER_NO;
            case 2 -> SoundEvents.GENERIC_EXTINGUISH_FIRE;
            default -> SoundEvents.RAVAGER_ROAR;
        };
        l.playSound(null, p.blockPosition(), snd, SoundSource.PLAYERS, 1f, 0.8f + RNG.nextFloat() * 0.5f);
        p.sendSystemMessage(Component.translatable("msg.wildcard.v71.kitchen." + RNG.nextInt(6)).withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
    }

    private static void fireworks(ServerLevel level, Vec3 at) {
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
        CompoundTag fw = new CompoundTag();
        ListTag list = new ListTag();
        for (int i = 0; i < 3; i++) {
            CompoundTag ex = new CompoundTag();
            ex.putByte("Type", (byte) RNG.nextInt(5));
            ex.putIntArray("Colors", new int[]{0x55FF55, 0x22AA22, RNG.nextInt(0xFFFFFF)});
            ex.putBoolean("Flicker", true);
            ex.putBoolean("Trail", true);
            list.add(ex);
        }
        fw.put("Explosions", list);
        fw.putByte("Flight", (byte) 0);
        rocket.getOrCreateTag().put("Fireworks", fw);
        FireworkRocketEntity e = new FireworkRocketEntity(level, at.x, at.y, at.z, rocket);
        level.addFreshEntity(e);
    }

    /** Con Ngựa Da Đen: one tame black horse follows its player and comes back if lost. */
    private static void blackHorse(ServerPlayer p, ServerLevel level) {
        String tag = "wc_horse_" + p.getUUID();
        Horse found = null;
        for (Horse h : level.getEntitiesOfClass(Horse.class, p.getBoundingBox().inflate(48), h -> h.getTags().contains(tag))) found = h;
        if (found == null) {
            if (p.isPassenger() || PlayerState.get(p).time("e38_cd") > level.getGameTime()) return;
            PlayerState.get(p).time("e38_cd", level.getGameTime() + 600);
            Horse h = EntityType.HORSE.create(level);
            if (h == null) return;
            BlockPos at = findStand(level, p.getBlockX() + 3, p.getBlockY(), p.getBlockZ() + 3);
            h.moveTo(at.getX() + 0.5, at.getY(), at.getZ() + 0.5, p.getYRot(), 0);
            h.setVariant(Variant.BLACK);
            h.tameWithName(p);
            h.equipSaddle(SoundSource.NEUTRAL);
            h.addTag(tag);
            h.setCustomName(Component.translatable("entity.wildcard.black_horse").withStyle(ChatFormatting.DARK_GRAY));
            attr(h, Attributes.MOVEMENT_SPEED, "v71_horse", 0.12, AttributeModifier.Operation.ADDITION, true);
            h.setPersistenceRequired();
            level.addFreshEntity(h);
            lightning(level, h.position(), null, true);
            p.sendSystemMessage(Component.translatable("msg.wildcard.v71.horse").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
            return;
        }
        if (!found.isVehicle()) {
            double d = found.distanceToSqr(p);
            if (d > 32 * 32) found.teleportTo(p.getX() + 2, p.getY(), p.getZ() + 2);
            else if (d > 36) found.getNavigation().moveTo(p, 1.3);
        }
    }

    /** Sức Mạnh Thật Sự Của Wither: Withers near the player dash below 75% health. */
    private static void witherPower(ServerPlayer p, ServerLevel level, RandomSource rng) {
        for (WitherBoss w : level.getEntitiesOfClass(WitherBoss.class, p.getBoundingBox().inflate(96))) {
            if (w.getHealth() >= w.getMaxHealth() * 0.75f || w.getInvulnerableTicks() > 0 || rng.nextInt(5) != 0) continue;
            LivingEntity t = w.getTarget() != null ? w.getTarget() : p;
            Vec3 dir = t.position().subtract(w.position()).normalize();
            w.setDeltaMovement(dir.scale(1.8));
            w.hurtMarked = true;
            Scheduler.later(8, () -> {
                if (w.isAlive()) level.explode(w, w.getX(), w.getY() + 1, w.getZ(), 2.5f, Level.ExplosionInteraction.MOB);
            });
        }
    }

    /** Among Us debuff: 80% of animals near the player turn on players. */
    private static void amogus(ServerPlayer p, ServerLevel level) {
        for (Animal a : level.getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(20))) {
            if (!a.getTags().contains("wc_amogus")) {
                a.addTag("wc_amogus");
                if (RNG.nextInt(10) < 8) a.addTag("wc_sus");
            }
            if (!a.getTags().contains("wc_sus") || a instanceof TamableAnimal ta && ta.isTame()) continue;
            if (a.distanceToSqr(p) > 3.2) a.getNavigation().moveTo(p, 1.4);
            else {
                p.hurt(p.damageSources().mobAttack(a), 2f);
                level.playSound(null, a.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 0.7f, 0.6f);
            }
        }
    }

    // ================================================================== packets from the client

    public static void onAct(ServerPlayer p, String what) {
        long now = p.level().getGameTime();
        PlayerState st = PlayerState.get(p);
        switch (what) {
            case "djump" -> { if (has(p, "r57")) p.fallDistance = 0; }
            case "glide" -> {
                if (has(p, "e39")) {
                    st.time("glide", now + 30);
                    p.fallDistance = 0;
                }
            }
            case "sand" -> pharaohSand(p);
            case "rocket", "rocket_off" -> { // v7.3 Kẻ Bay Lượn: tốn 1 pháo hoa khi tăng tốc
                if (!has(p, "e39")) return;
                ItemStack s = p.getItemInHand(what.equals("rocket") ? net.minecraft.world.InteractionHand.MAIN_HAND : net.minecraft.world.InteractionHand.OFF_HAND);
                if (!s.is(Items.FIREWORK_ROCKET)) return;
                if (!p.getAbilities().instabuild) s.shrink(1);
                st.time("glide", now + 80);
                p.fallDistance = 0;
                p.level().playSound(null, p.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 3f, 1f);
            }
            case "reroll" -> com.hoang.wildcard.RoundManager.reroll(p);
            default -> {
            }
        }
    }

    private static void pharaohSand(ServerPlayer p) {
        if (!has(p, "l27")) return;
        WData d = WData.get(p);
        int sand = d.extra.getInt("l27_sand");
        if (sand < 20) {
            actionBar(p, Component.translatable("msg.wildcard.v71.sand.low", sand).withStyle(ChatFormatting.RED));
            return;
        }
        d.extra.putInt("l27_sand", sand - 20);
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition(), look = p.getLookAngle();
        BlockParticleOption dust = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.SAND.defaultBlockState());
        for (int i = 1; i <= 10; i++) {
            Vec3 at = eye.add(look.scale(i));
            level.sendParticles(dust, at.x, at.y, at.z, 6 + i * 2, 0.15 * i, 0.15 * i, 0.15 * i, 0.05);
        }
        level.playSound(null, p.blockPosition(), SoundEvents.SAND_BREAK, SoundSource.PLAYERS, 1.5f, 0.6f);
        level.playSound(null, p.blockPosition(), SoundEvents.HUSK_AMBIENT, SoundSource.PLAYERS, 1f, 0.7f);
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(10), le -> Skills.foe(p, le))) {
            Vec3 to = le.position().add(0, le.getBbHeight() / 2, 0).subtract(eye);
            if (to.length() > 10 || to.normalize().dot(look) < 0.8) continue;
            Skills.trueHurt(p, le, 6f);
            effect(le, MobEffects.BLINDNESS, 80, 0);
            effect(le, MobEffects.MOVEMENT_SLOWDOWN, 60, 1);
            le.knockback(0.8, -look.x, -look.z);
        }
        actionBar(p, Component.translatable("msg.wildcard.v71.sand", sand - 20).withStyle(ChatFormatting.YELLOW));
    }

    // ================================================================== combat

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(LivingAttackEvent e) {
        LivingEntity v = e.getEntity();
        if (v.level().isClientSide) return;
        Entity src = e.getSource().getEntity();
        if (v instanceof ServerPlayer p) {
            // Slime Rancher
            if (has(p, "r60") && (src instanceof Slime)) { e.setCanceled(true); return; }
            // Parry
            long now = p.level().getGameTime();
            PlayerState st = PlayerState.get(p);
            if (has(p, "e36") && now <= st.time("parry") && src instanceof LivingEntity att && e.getSource().getDirectEntity() == att) {
                e.setCanceled(true);
                st.time("parry", 0);
                st.time("parry_buff", now + 100);
                effect(att, MobEffects.MOVEMENT_SLOWDOWN, 40, 9);
                effect(att, MobEffects.WEAKNESS, 40, 4);
                att.knockback(0.6, p.getX() - att.getX(), p.getZ() - att.getZ());
                p.level().playSound(null, p.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1f, 1.4f);
                p.level().playSound(null, p.blockPosition(), SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.5f, 2f);
                p.serverLevel().sendParticles(ParticleTypes.CRIT, att.getX(), att.getY() + 1, att.getZ(), 20, 0.3, 0.4, 0.3, 0.3);
                actionBar(p, Component.translatable("msg.wildcard.v71.parry").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD));
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.NORMAL)
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity v = e.getEntity();
        if (v.level().isClientSide) return;
        DamageSource s = e.getSource();
        float amount = e.getAmount();
        long now = v.level().getGameTime();
        // người bị đánh
        if (v instanceof ServerPlayer p) {
            if (has(p, "u208") && s.getEntity() instanceof AbstractPiglin) amount *= 1.4f;
            if (has(p, "r52")) BLOODLUST.remove(p.getUUID()); // Khát Máu: mất hết khi bị thương
        }
        // Sức Mạnh Thật Sự Của Wither: dưới 50% máu chỉ nhận nửa sát thương
        if (v instanceof WitherBoss w && w.getHealth() < w.getMaxHealth() * 0.5f && anyOwner(v.level(), "e39", v.position(), 128)) amount *= 0.5f;
        // người đánh
        if (s.getEntity() instanceof ServerPlayer p && p != v) {
            PlayerState st = PlayerState.get(p);
            boolean melee = melee(s, p);
            if (melee && has(p, "u201")) amount *= 1.2f;                                         // Đánh Đau
            if (!melee && s.is(net.minecraft.tags.DamageTypeTags.IS_PROJECTILE) && has(p, "c155")) amount *= 1.1f; // Con Mắt Cung Thủ
            if (has(p, "r52")) amount *= 1f + 0.03f * BLOODLUST.getOrDefault(p.getUUID(), 0);  // Khát Máu
            if (melee && has(p, "e33")) {                                                          // Đâm Sau Lưng
                Vec3 look = Vec3.directionFromRotation(0, v.getYRot());
                Vec3 toAtt = new Vec3(p.getX() - v.getX(), 0, p.getZ() - v.getZ()).normalize();
                if (look.dot(toAtt) < -0.3) {
                    amount *= 2f;
                    p.serverLevel().sendParticles(ParticleTypes.CRIT, v.getX(), v.getY() + 1, v.getZ(), 15, 0.3, 0.3, 0.3, 0.2);
                }
            }
            if (melee && has(p, "e36") && now <= st.time("parry_buff")) {                          // Parry: đòn tiếp theo
                amount *= 1.5f;
                st.time("parry_buff", 0);
            }
            if (has(p, "e37") && now - st.time("e37_water") <= 200) amount *= 1.2f;              // Người Cá
            if (melee && has(p, "r53") && p.getRandom().nextFloat() < 0.08f) {                     // Bonk
                effect(v, MobEffects.MOVEMENT_SLOWDOWN, 40, 9);
                effect(v, MobEffects.WEAKNESS, 40, 4);
                if (v instanceof Mob m) m.getNavigation().stop();
                p.level().playSound(null, v.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.6f, 1.8f);
                actionBar(p, Component.literal("BONK!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
            }
            if (melee && has(p, "r51") && p.getRandom().nextFloat() < 0.06f) dropHeld(p);        // Tay Trơn Trượt
            else if (melee && has(p, "u210") && p.getRandom().nextFloat() < 0.02f) dropHeld(p);  // Cầm Nắm Yếu
        }
        if (amount != e.getAmount()) e.setAmount(Math.max(0f, amount));
    }

    /** Lifesteal after every other modifier. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurtLast(LivingHurtEvent e) {
        if (e.getEntity().level().isClientSide || !(e.getSource().getEntity() instanceof ServerPlayer p) || p == e.getEntity()) return;
        float heal = 0;
        if (has(p, "l26")) heal += 0.10f;
        if (has(p, "r61")) heal += 0.02f;
        if (heal > 0) p.heal(e.getAmount() * heal);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity().level().isClientSide || !(e.getSource().getEntity() instanceof ServerPlayer p) || p == e.getEntity()) return;
        if (has(p, "r52")) BLOODLUST.merge(p.getUUID(), 1, (a, b) -> Math.min(10, a + b));
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        if (!(e.getEntity() instanceof Animal a) || !(e.getSource().getEntity() instanceof ServerPlayer p) || !has(p, "l31")) return;
        Item[] mob = {Items.BONE, Items.STRING, Items.GUNPOWDER, Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.ENDER_PEARL, Items.SLIME_BALL,
                Items.BLAZE_ROD, Items.GHAST_TEAR, Items.PHANTOM_MEMBRANE, Items.PRISMARINE_SHARD, Items.MAGMA_CREAM, Items.ARROW};
        Item[] ores = {Items.RAW_IRON, Items.RAW_GOLD, Items.RAW_COPPER, Items.DIAMOND, Items.EMERALD, Items.LAPIS_LAZULI, Items.REDSTONE, Items.COAL};
        Level l = a.level();
        e.getDrops().add(new ItemEntity(l, a.getX(), a.getY() + 0.3, a.getZ(), new ItemStack(mob[RNG.nextInt(mob.length)])));
        if (RNG.nextInt(5) == 0) e.getDrops().add(new ItemEntity(l, a.getX(), a.getY() + 0.3, a.getZ(), new ItemStack(ores[RNG.nextInt(ores.length)])));
    }

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        float m = jumpMul(p);
        if (m == 1f) return;
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(v.x, v.y * m, v.z);
    }

    @SubscribeEvent
    public static void onTarget(LivingChangeTargetEvent e) {
        if (e.getEntity() instanceof Slime && e.getNewTarget() instanceof Player p && has(p, "r60")) e.setCanceled(true);
    }

    // ================================================================== items and interaction

    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickItem e) {
        Player p = e.getEntity();
        ItemStack held = e.getItemStack();
        if (p.level().isClientSide || !(p instanceof ServerPlayer sp)) return;
        ServerLevel level = sp.serverLevel();
        long now = level.getGameTime();
        // Emerald Splash: 10 viên mỗi giây (giữ chuột phải lặp 5 lần/giây, mỗi lần 2 viên)
        if (has(p, "e31") && held.is(Items.EMERALD)) {
            for (int i = 0; i < 2; i++) {
                Snowball sb = new Snowball(level, p);
                sb.setItem(new ItemStack(Items.EMERALD));
                sb.addTag("wc_emerald");
                sb.shootFromRotation(p, p.getXRot(), p.getYRot(), 0f, 1.8f, 2.5f);
                level.addFreshEntity(sb);
            }
            if (!p.getAbilities().instabuild && RNG.nextBoolean()) held.shrink(1);
            level.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.PLAYERS, 0.7f, 1.6f + RNG.nextFloat() * 0.3f);
            e.setCancellationResult(InteractionResult.SUCCESS);
            e.setCanceled(true);
            return;
        }
        // Parry: chuột phải với kiếm
        if (has(p, "e36") && held.getItem() instanceof SwordItem) {
            PlayerState st = PlayerState.get(p);
            if (now >= st.time("parry_cd")) {
                st.time("parry", now + 8);
                st.time("parry_cd", now + 20);
                p.swing(e.getHand(), true);
                level.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.6f, 1.5f);
            }
        }
        // Lời Nguyền Pharaoh: ăn cát
        if (has(p, "l27") && held.is(Items.SAND) && p.getFoodData().needsFood()) {
            p.getFoodData().eat(3, 0.3f);
            if (!p.getAbilities().instabuild) held.shrink(1);
            level.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EAT, SoundSource.PLAYERS, 1f, 0.8f);
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.SAND.defaultBlockState()), p.getX(), p.getEyeY(), p.getZ(), 12, 0.2, 0.1, 0.2, 0.05);
            e.setCancellationResult(InteractionResult.SUCCESS);
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onEatStart(LivingEntityUseItemEvent.Start e) {
        if (!(e.getEntity() instanceof Player p) || !e.getItem().isEdible()) return;
        if (has(p, "l27")) { // chỉ ăn được cát
            e.setCanceled(true);
            if (p instanceof ServerPlayer sp) actionBar(sp, Component.translatable("msg.wildcard.v71.onlysand").withStyle(ChatFormatting.YELLOW));
            return;
        }
        if (has(p, "u204") && e.getItem().is(ItemTags.FISHES)) { // Dị Ứng Hải Sản
            e.setCanceled(true);
            if (p instanceof ServerPlayer sp) actionBar(sp, Component.translatable("msg.wildcard.v71.allergy").withStyle(ChatFormatting.RED));
        }
    }

    @SubscribeEvent
    public static void onInteractEntity(PlayerInteractEvent.EntityInteract e) {
        Player p = e.getEntity();
        if (!has(p, "r56") || !e.getItemStack().is(Items.BUCKET) || !(e.getTarget() instanceof LivingEntity t)) return;
        if (t instanceof net.minecraft.world.entity.animal.Cow || t instanceof net.minecraft.world.entity.animal.goat.Goat) return; // vanilla lo
        if (!p.level().isClientSide) {
            if (!p.getAbilities().instabuild) e.getItemStack().shrink(1);
            give(p, new ItemStack(Items.MILK_BUCKET));
            p.level().playSound(null, t.blockPosition(), SoundEvents.COW_MILK, SoundSource.PLAYERS, 1f, 1f);
        }
        e.setCancellationResult(InteractionResult.sidedSuccess(p.level().isClientSide));
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent e) {
        if (e.getTarget() instanceof EndCrystal c && has(e.getEntity(), "u206") && crystalArmor(c)) e.setCanceled(true);
    }

    /** Pha Lê Múp: true while the crystal still has extra hits left (and uses one). */
    private static boolean crystalArmor(EndCrystal c) {
        CompoundTag t = c.getPersistentData();
        int hits = t.getInt("wc_hits");
        if (hits >= 2) return false;
        t.putInt("wc_hits", hits + 1);
        if (c.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.END_ROD, c.getX(), c.getY() + 1, c.getZ(), 8, 0.4, 0.4, 0.4, 0.05);
            sl.playSound(null, c.blockPosition(), SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.HOSTILE, 1f, 0.6f);
        }
        return true;
    }

    @SubscribeEvent
    public static void onImpact(ProjectileImpactEvent e) {
        Projectile pr = e.getProjectile();
        if (pr.level().isClientSide) return;
        Entity owner = pr.getOwner();
        // Emerald Splash
        if (pr.getTags().contains("wc_emerald") && e.getRayTraceResult() instanceof EntityHitResult eh && owner instanceof ServerPlayer p
                && eh.getEntity() instanceof LivingEntity t && t != p) {
            t.invulnerableTime = 0;
            t.hurt(p.damageSources().thrown(pr, p), 3f);
        }
        // Pha Lê Múp (bắn bằng cung)
        if (e.getRayTraceResult() instanceof EntityHitResult eh && eh.getEntity() instanceof EndCrystal c && owner instanceof Player op && has(op, "u206")
                && crystalArmor(c)) {
            e.setCanceled(true);
            pr.discard();
            return;
        }
        // Mũi Tên Phát Nổ
        if (pr instanceof AbstractArrow a && owner instanceof ServerPlayer p && has(p, "r54") && !a.getTags().contains("wc_boom")) {
            a.addTag("wc_boom");
            Vec3 at = e.getRayTraceResult().getLocation();
            pr.level().explode(a, at.x, at.y, at.z, 1.5f, Level.ExplosionInteraction.NONE);
            Scheduler.later(1, a::discard);
        }
    }

    // ================================================================== spawning

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        Entity en = e.getEntity();
        Level level = e.getLevel();
        if (en instanceof EnderDragon d) {
            if (anyOwner(level, "c151")) boost(d, "dragon10", 0.10);
            if (anyOwner(level, "r63")) boost(d, "dragon25", 0.25);
        } else if (en instanceof WitherBoss w && anyOwner(level, "r54")) boost(w, "wither", 0.30);
        else if (en instanceof Blaze b && anyOwner(level, "u201", b.position(), 96)) boost(b, "blaze", 0.30);
        else if (en instanceof Zombie z && !(z instanceof ZombifiedPiglin) && anyOwner(level, "u205", z.position(), 96)) boost(z, "zombie", 0.30);
        if (e.loadedFromDisk()) return;
        // Bao Đựng Tên Vô Đáy / Ngắm Lệch
        if (en instanceof Projectile pr && pr.getOwner() instanceof ServerPlayer p) {
            if (pr instanceof AbstractArrow a && has(p, "c159") && a.pickup == AbstractArrow.Pickup.ALLOWED && RNG.nextInt(8) == 0) {
                a.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
                give(p, new ItemStack(Items.ARROW));
            }
            if (has(p, "l32") && !pr.getTags().contains("wc_emerald")) {
                Vec3 v = pr.getDeltaMovement();
                double sp = v.length(), k = 0.0825 * sp;
                pr.setDeltaMovement(v.add(RNG.nextGaussian() * k, RNG.nextGaussian() * k, RNG.nextGaussian() * k));
            }
        }
        // Chắc Chắn Là RNG Hợp Lệ: đồ piglin vừa đổi -> ngọc ender (~70%)
        if (en instanceof ItemEntity ie && !ie.getItem().is(Items.GOLD_INGOT) && !BARTER.isEmpty() && level instanceof ServerLevel sl) {
            long now = sl.getGameTime();
            for (Piglin pg : sl.getEntitiesOfClass(Piglin.class, ie.getBoundingBox().inflate(3))) {
                Long seen = BARTER.get(pg.getUUID());
                if (seen != null && now - seen <= 20 && pg.getOffhandItem().isEmpty()) {
                    if (RNG.nextInt(100) < 70) ie.setItem(new ItemStack(Items.ENDER_PEARL, 2 + RNG.nextInt(3)));
                    BARTER.remove(pg.getUUID());
                    break;
                }
            }
        }
    }

    @SubscribeEvent
    public static void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn e) {
        Mob m = e.getEntity();
        if (!(e.getLevel() instanceof ServerLevel level)) return;
        MobSpawnType type = e.getSpawnType();
        if (type != MobSpawnType.NATURAL && type != MobSpawnType.CHUNK_GENERATION && type != MobSpawnType.SPAWNER && type != MobSpawnType.REINFORCEMENT) return;
        Vec3 at = m.position();
        // Auuu Man: không có creeper
        if (m instanceof Creeper && anyOwner(level, "l28", at, 128)) {
            e.setSpawnCancelled(true);
            return;
        }
        // Terra Firma: 50% quái trên mặt đất thành Iron Golem
        if (m instanceof Enemy && type == MobSpawnType.NATURAL && level.canSeeSky(m.blockPosition()) && RNG.nextBoolean() && anyOwner(level, "l30", at, 128)
                && level.getEntitiesOfClass(IronGolem.class, m.getBoundingBox().inflate(48), g -> g.getTags().contains("wc_terra")).size() < 8) {
            e.setSpawnCancelled(true);
            Scheduler.later(1, () -> {
                IronGolem g = EntityType.IRON_GOLEM.create(level);
                if (g == null) return;
                g.moveTo(at.x, at.y, at.z, RNG.nextFloat() * 360, 0);
                g.addTag("wc_terra");
                level.addFreshEntity(g);
            });
            return;
        }
        // Biển Dữ: cá ngoài đại dương thành Elder Guardian (tối đa 1 con mỗi phút mỗi người)
        if (m instanceof AbstractFish && type == MobSpawnType.NATURAL) {
            for (ServerPlayer p : level.players()) {
                if (!has(p, "l30") || p.position().distanceToSqr(at) > 64 * 64) continue;
                PlayerState st = PlayerState.get(p);
                if (st.time("l30_elder") > level.getGameTime()) continue;
                st.time("l30_elder", level.getGameTime() + 1200);
                e.setSpawnCancelled(true);
                Scheduler.later(1, () -> {
                    ElderGuardian g = EntityType.ELDER_GUARDIAN.create(level);
                    if (g == null) return;
                    g.moveTo(at.x, at.y, at.z, RNG.nextFloat() * 360, 0);
                    level.addFreshEntity(g);
                });
                return;
            }
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && PlayerState.get(p).time("glide") > p.level().getGameTime()) e.setDistance(0);
    }

    // ================================================================== body size

    @SubscribeEvent
    public static void onSize(EntityEvent.Size e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.tickCount < 1 || p.connection == null) return;
        float s;
        try {
            s = scaleOf(p);
        } catch (Exception ex) {
            return;
        }
        if (s == 1f) return;
        e.setNewSize(e.getNewSize().scale(s));
        e.setNewEyeHeight(e.getNewEyeHeight() * s);
    }

    @SubscribeEvent
    public static void onTrack(PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof ServerPlayer other && e.getEntity() instanceof ServerPlayer viewer) {
            float s = scaleOf(other);
            if (s != 1f) Net.toPlayer(viewer, new Net.Size(other.getId(), s));
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        UUID u = e.getEntity().getUUID();
        SIZE_SENT.remove(u);
        SIMON.remove(u);
        GUEST.remove(u);
        BLOODLUST.remove(u);
    }

    private V71Cards() {}
}
