package com.hoang.wildcard;

import com.hoang.wildcard.net.Net;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

@Mod(WildcardMod.MODID)
public class WildcardMod {
    public static final String MODID = "wildcard";
    public static final Logger LOG = LogUtils.getLogger();

    public WildcardMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::commonSetup);
        com.hoang.wildcard.fx.ModParticles.register(modBus);
        ModSounds.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(Net::register);
        LOG.info("Wildcard Hỗn Loạn: {} thẻ đã đăng ký", Cards.ALL.size());
    }
}
