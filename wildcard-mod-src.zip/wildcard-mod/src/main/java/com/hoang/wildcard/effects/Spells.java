package com.hoang.wildcard.effects;

import com.hoang.wildcard.GenSkill;
import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.Fx;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.EvokerFangs;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.function.Consumer;

/**
 * Spell-book style skills (projectiles that fly, chain lightning, rays, breath, fangs...). Own code and visuals,
 * drawn with our element particles; every cast still shows the rune circle from Fx.cast.
 */
public final class Spells {
    /** Flying orb. Moves {@code speed} blocks per tick, can home in on {@code target}. */
    static void missile(ServerPlayer p, Element el, Vec3 from, Vec3 dir, double speed, int life, LivingEntity target,
                        Consumer<LivingEntity> onHit, Consumer<Vec3> onImpact) {
        ServerLevel level = p.serverLevel();
        step(p, level, el, from, dir.normalize(), speed, life, target, onHit, onImpact);
    }

    private static void step(ServerPlayer p, ServerLevel level, Element el, Vec3 pos, Vec3 dir, double speed, int life,
                             LivingEntity target, Consumer<LivingEntity> onHit, Consumer<Vec3> onImpact) {
        if (life <= 0 || !p.isAlive() || p.level() != level) {
            if (onImpact != null) onImpact.accept(pos);
            return;
        }
        if (target != null && target.isAlive()) { // bám đuổi nhẹ
            Vec3 want = target.getBoundingBox().getCenter().subtract(pos).normalize();
            dir = dir.scale(0.6).add(want.scale(0.4)).normalize();
        }
        int sub = Math.max(1, (int) Math.ceil(speed / 0.5));
        for (int i = 0; i < sub; i++) {
            pos = pos.add(dir.scale(speed / sub));
            BlockPos bp = BlockPos.containing(pos);
            if (!level.getBlockState(bp).getCollisionShape(level, bp).isEmpty()) {
                Fx.burst(level, pos, el, 14, 0.2);
                if (onImpact != null) onImpact.accept(pos);
                return;
            }
            final Vec3 at = pos;
            List<LivingEntity> hit = level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(0.6), x -> Skills.foe(p, x));
            if (!hit.isEmpty()) {
                Fx.burst(level, at, el, 18, 0.25);
                onHit.accept(hit.get(0));
                if (onImpact != null) onImpact.accept(at);
                return;
            }
        }
        level.sendParticles(el.spark(), pos.x, pos.y, pos.z, 3, 0.08, 0.08, 0.08, 0.01);
        if (life % 3 == 0) level.sendParticles(el.rune(), pos.x, pos.y, pos.z, 0, 0, 0.01, 0, 1.0);
        final Vec3 np = pos, nd = dir;
        Scheduler.later(1, () -> step(p, level, el, np, nd, speed, life - 1, target, onHit, onImpact));
    }

    private static Vec3 eye(ServerPlayer p) {
        return p.getEyePosition().add(p.getLookAngle().scale(0.6)).subtract(0, 0.2, 0);
    }

    private static void dmg(ServerPlayer p, LivingEntity t, float a) {
        t.hurt(p.damageSources().indirectMagic(p, p), a);
    }

    /** Foes inside a cone in front of the player. */
    static List<LivingEntity> cone(ServerPlayer p, double range, double cosHalf) {
        Vec3 look = p.getLookAngle();
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity le : Skills.foes(p, range)) {
            Vec3 to = le.getBoundingBox().getCenter().subtract(p.getEyePosition());
            if (to.lengthSqr() < 1e-4 || to.normalize().dot(look) >= cosHalf) out.add(le);
        }
        return out;
    }

    static boolean run(ServerPlayer p, GenSkill s, Element el) {
        ServerLevel level = p.serverLevel();
        float a = (float) s.a();
        switch (s.kind()) {
            case "firebolt" -> {
                missile(p, el, eye(p), p.getLookAngle(), 1.4, 30, null, t -> {
                    dmg(p, t, a);
                    t.setSecondsOnFire(5);
                }, null);
                Skills.sound(p, SoundEvents.BLAZE_SHOOT, 1.3f);
            }
            case "icicle" -> {
                missile(p, el, eye(p), p.getLookAngle(), 1.8, 25, null, t -> {
                    dmg(p, t, a);
                    t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                    t.setTicksFrozen(Math.max(t.getTicksFrozen(), t.getTicksRequiredToFreeze() + 60));
                }, null);
                Skills.sound(p, SoundEvents.GLASS_BREAK, 1.8f);
            }
            case "magic_missile" -> {
                List<LivingEntity> targets = Skills.foes(p, 20);
                targets.sort(Comparator.comparingDouble(x -> x.distanceToSqr(p)));
                for (int i = 0; i < 3; i++) {
                    LivingEntity t = targets.isEmpty() ? null : targets.get(i % targets.size());
                    Vec3 d = p.getLookAngle().add((i - 1) * 0.35, 0.25, 0);
                    final int delay = i * 3;
                    Scheduler.later(delay + 1, () -> missile(p, el, eye(p), d, 0.9, 40, t, x -> dmg(p, x, a), null));
                }
                Skills.sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f);
            }
            case "lightning_lance" -> {
                LivingEntity t = Skills.aim(p, s.b());
                if (t == null) return Skills.noTarget(p);
                Fx.trail(level, p.getEyePosition(), t.getEyePosition(), el);
                Effects.lightning(level, t.position(), p, true);
                dmg(p, t, a);
            }
            case "chain_lightning" -> {
                LivingEntity t = Skills.aim(p, 20);
                if (t == null) return Skills.noTarget(p);
                Set<LivingEntity> done = new HashSet<>();
                Vec3 from = p.getEyePosition();
                float d = a;
                for (int i = 0; i < 4 && t != null; i++) {
                    Fx.trail(level, from, t.getBoundingBox().getCenter(), el);
                    dmg(p, t, d);
                    done.add(t);
                    from = t.getBoundingBox().getCenter();
                    d *= 0.8f;
                    final LivingEntity cur = t;
                    t = level.getEntitiesOfClass(LivingEntity.class, cur.getBoundingBox().inflate(6), x -> Skills.foe(p, x) && !done.contains(x))
                            .stream().min(Comparator.comparingDouble(x -> x.distanceToSqr(cur))).orElse(null);
                }
                Skills.sound(p, SoundEvents.FIREWORK_ROCKET_TWINKLE, 1.6f);
            }
            case "blood_slash" -> {
                float healed = 0;
                for (LivingEntity le : cone(p, 4.5, 0.4)) {
                    dmg(p, le, a);
                    healed += a * 0.25f;
                }
                if (healed > 0) p.heal(Math.min(6f, healed));
                Vec3 l = Skills.flatLook(p);
                Vec3 side = new Vec3(-l.z, 0, l.x);
                for (int i = -6; i <= 6; i++) {
                    Vec3 at = p.position().add(0, 1.1, 0).add(l.scale(2.2)).add(side.scale(i * 0.3)).add(l.scale(-Math.abs(i) * 0.12));
                    level.sendParticles(el.spark(), at.x, at.y, at.z, 2, 0.05, 0.05, 0.05, 0.01);
                }
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, p.getX() + l.x * 2, p.getY() + 1, p.getZ() + l.z * 2, 1, 0, 0, 0, 0);
                Skills.sound(p, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7f);
            }
            case "ray_of_frost" -> {
                Vec3 from = p.getEyePosition(), dir = p.getLookAngle();
                double len = s.b();
                Vec3 to = from.add(dir.scale(len));
                for (LivingEntity le : Skills.foes(p, len)) {
                    Vec3 c = le.getBoundingBox().getCenter();
                    double t = c.subtract(from).dot(dir);
                    if (t < 0 || t > len) continue;
                    if (from.add(dir.scale(t)).distanceTo(c) > 1.2) continue;
                    dmg(p, le, a);
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
                    le.setTicksFrozen(Math.max(le.getTicksFrozen(), le.getTicksRequiredToFreeze() + 80));
                }
                Fx.trail(level, from.subtract(0, 0.2, 0), to, el);
                Skills.sound(p, SoundEvents.POWDER_SNOW_STEP, 0.6f);
            }
            case "fang_strike" -> {
                Vec3 l = Skills.flatLook(p);
                float yaw = (float) Math.atan2(l.z, l.x);
                for (int i = 1; i <= (int) s.b(); i++) {
                    Vec3 at = p.position().add(l.scale(i * 1.25));
                    level.addFreshEntity(new EvokerFangs(level, at.x, Math.floor(p.getY()), at.z, yaw, i, p));
                }
                Skills.sound(p, SoundEvents.EVOKER_PREPARE_ATTACK, 1.2f);
            }
            case "wisp" -> {
                LivingEntity t = Skills.aim(p, 24);
                if (t == null) {
                    List<LivingEntity> near = Skills.foes(p, 16);
                    t = near.isEmpty() ? null : near.get(0);
                }
                missile(p, el, eye(p), p.getLookAngle().add(0, 0.4, 0), 0.6, 80, t, x -> {
                    dmg(p, x, a);
                    p.heal(a * 0.5f);
                }, null);
                Skills.sound(p, SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM, 1.3f);
            }
            case "acid_orb" -> {
                missile(p, el, eye(p), p.getLookAngle().add(0, 0.1, 0), 1.0, 30, null, t -> dmg(p, t, a), at -> {
                    AreaEffectCloud cloud = new AreaEffectCloud(level, at.x, at.y - 0.5, at.z);
                    cloud.setOwner(p);
                    cloud.setRadius((float) s.b());
                    cloud.setDuration(100);
                    cloud.setRadiusPerTick(-0.01f);
                    cloud.setFixedColor(0x7CFC00);
                    cloud.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 1));
                    level.addFreshEntity(cloud);
                });
                Skills.sound(p, SoundEvents.SLIME_SQUISH, 0.6f);
            }
            case "breath" -> {
                for (int k = 0; k < 10; k++) {
                    Scheduler.later(k * 4, () -> {
                        if (!p.isAlive()) return;
                        Vec3 look = p.getLookAngle();
                        for (int i = 0; i < 6; i++) {
                            Vec3 d = look.add(level.random.nextGaussian() * 0.15, level.random.nextGaussian() * 0.1, level.random.nextGaussian() * 0.15).scale(0.5);
                            Vec3 o = eye(p);
                            level.sendParticles(el.spark(), o.x, o.y, o.z, 0, d.x, d.y, d.z, 1.0);
                        }
                        for (LivingEntity le : cone(p, 6, 0.75)) {
                            dmg(p, le, a / 5f);
                            if (el == Element.FIRE) le.setSecondsOnFire(3);
                            else le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
                        }
                    });
                }
                Skills.sound(p, el == Element.FIRE ? SoundEvents.ENDER_DRAGON_SHOOT : SoundEvents.POWDER_SNOW_BREAK, 1f);
            }
            case "counterspell" -> {
                Skills.forFoes(p, 10, LivingEntity::removeAllEffects);
                for (MobEffectInstance e : new ArrayList<>(p.getActiveEffects())) {
                    if (e.getEffect().getCategory() == MobEffectCategory.HARMFUL) p.removeEffect(e.getEffect());
                }
                Fx.circle(level, p.position().add(0, 0.1, 0), el, 10, 48, true);
                Skills.sound(p, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1f);
            }
            case "root" -> {
                int ticks = (int) (s.b() * 20);
                Skills.forFoes(p, 6, le -> {
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 9));
                    le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 0));
                    Fx.circle(level, le.position().add(0, 0.1, 0), el, 0.7, 8, false);
                });
                Skills.sound(p, SoundEvents.ROOTED_DIRT_BREAK, 0.6f);
            }
            case "blight" -> {
                int ticks = (int) (s.b() * 20);
                Skills.forFoes(p, 8, le -> le.addEffect(new MobEffectInstance(MobEffects.WITHER, ticks, 1)));
                Fx.circle(level, p.position().add(0, 0.1, 0), el, 8, 40, true);
                Skills.sound(p, SoundEvents.WITHER_AMBIENT, 1.5f);
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    private Spells() {}
}
