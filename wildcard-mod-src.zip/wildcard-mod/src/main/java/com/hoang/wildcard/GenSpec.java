package com.hoang.wildcard;

/**
 * Data-driven buff and debuff of a generated card. Each entry is "kind:arg:value[:cond]", for example
 * "attr:speed:0.1", "eff:night_vision:0:dark", "inc:fall:0.5", "kill:heal:2", "troll:t05".
 * Applied by effects/GenEffects.
 */
public final class GenSpec {
    public final String[] buff;
    public final String[] debuff;

    public GenSpec(String[] buff, String[] debuff) {
        this.buff = buff;
        this.debuff = debuff;
    }
}
