package com.hoang.wildcard.fx;

import java.util.HashMap;
import java.util.Map;

/** Which element each skill belongs to (also the colour of its icon). */
public final class SkillFx {
    private static final Map<String, Element> MAP = new HashMap<>();

    private static void put(Element e, String... keys) {
        for (String k : keys) MAP.put(k, e);
    }

    static {
        put(Element.FIRE, "e01:0", "e01:1", "e07:0", "e12:0", "e12:1", "e20:0", "e20:1", "l02:1", "l05:2",
                "m02:0", "m02:1", "m02:2", "m02:3", "m02:4");
        put(Element.WIND, "e02:0", "e06:0", "e06:1", "e08:1", "e11:0", "e11:1", "l02:0");
        put(Element.EARTH, "e02:1", "e03:0", "e03:1", "e10:0", "e18:0", "l02:2", "l05:0", "l05:1",
                "m04:0", "m04:1", "m04:3");
        put(Element.ARCANE, "e04:0", "e05:0", "e05:1", "e08:0", "e10:1", "l20:2");
        put(Element.VOID, "e04:1", "e13:0", "e13:1", "m04:2", "m04:4", "m05:0", "m05:1", "m05:2", "m05:3", "m05:4");
        put(Element.HOLY, "e07:1", "l04:0", "l04:2", "m03:3");
        put(Element.BLOOD, "e16:0", "e16:1", "l04:1", "m01:0", "m01:1", "m01:2", "m01:3", "m01:4");
        put(Element.STORM, "e18:1", "l01:0", "l01:1", "l01:2", "m03:2");
        put(Element.FROST, "l20:0", "l20:1", "m03:0", "m03:1", "m03:4", "r10:0", "r23:0");
        put(Element.WIND, "u61:0", "r08:0", "r13:0", "r20:0");
        put(Element.STORM, "u62:0", "r07:0", "r15:0");
        put(Element.VOID, "u63:0", "r02:0", "r06:0", "r09:0", "r22:0", "r17:0");
        put(Element.HOLY, "u64:0", "r04:0", "r05:0", "r21:0", "r24:0");
        put(Element.EARTH, "r01:0", "r03:0", "r11:0", "r12:0", "r14:0", "r16:0");
        put(Element.BLOOD, "r18:0", "r19:0", "r25:0");
    }

    public static Element of(String id, int idx) {
        com.hoang.wildcard.Card c = com.hoang.wildcard.Cards.get(id);
        if (c != null && c.genSkill != null) return com.hoang.wildcard.effects.GenSkills.element(c.genSkill);
        return MAP.getOrDefault(id + ":" + idx, Element.ARCANE);
    }

    private SkillFx() {}
}
