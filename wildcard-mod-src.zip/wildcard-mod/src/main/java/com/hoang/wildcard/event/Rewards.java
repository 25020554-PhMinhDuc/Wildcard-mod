package com.hoang.wildcard.event;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.Rarity;
import com.hoang.wildcard.RoundManager;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import net.minecraft.advancements.Advancement;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.AdvancementEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.Set;

/**
 * v5 bonus cards:
 * every 3 advancements (Overworld: Common+, Nether: Rare+, End: Epic+), and the first kill of each boss
 * (Ender Dragon: Legendary; Wither, Warden, Elder Guardian: Epic+), once per player.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class Rewards {

    @SubscribeEvent
    public static void onAdvancement(AdvancementEvent.AdvancementEarnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Advancement adv = e.getAdvancement();
        if (adv.getDisplay() == null) return; // công thức chế tạo, thành tựu ẩn
        String path = adv.getId().getPath();
        if (path.startsWith("recipes/")) return;
        String cat = path.startsWith("nether/") ? "nether" : path.startsWith("end/") ? "end" : "overworld";
        Rarity min = switch (cat) {
            case "nether" -> Rarity.RARE;
            case "end" -> Rarity.EPIC;
            default -> Rarity.COMMON;
        };
        WData d = WData.get(p);
        String key = "adv_" + cat;
        int n = d.extra.getInt(key) + 1;
        d.extra.putInt(key, n);
        d.save(p);
        if (n % 3 == 0) {
            RoundManager.giveReward(p, RoundManager.rewardCard(d, min), Component.translatable("reward.wildcard.adv." + cat));
        } else {
            p.displayClientMessage(Component.translatable("msg.wildcard.adv.progress", Component.translatable("reward.wildcard.adv." + cat), n % 3), true);
        }
    }

    @SubscribeEvent
    public static void onBossDeath(LivingDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead.level().isClientSide) return;
        EntityType<?> type = dead.getType();
        String boss;
        Rarity rarity;
        boolean exact;
        double radius;
        if (type == EntityType.ENDER_DRAGON) { boss = "dragon"; rarity = Rarity.LEGENDARY; exact = true; radius = 256; }
        else if (type == EntityType.WITHER) { boss = "wither"; rarity = Rarity.EPIC; exact = false; radius = 64; }
        else if (type == EntityType.WARDEN) { boss = "warden"; rarity = Rarity.EPIC; exact = false; radius = 48; }
        else if (type == EntityType.ELDER_GUARDIAN) { boss = "elder_guardian"; rarity = Rarity.EPIC; exact = false; radius = 48; }
        else return;
        // người hạ + mọi người chơi đánh cùng ở gần
        Set<ServerPlayer> who = new HashSet<>();
        Entity src = e.getSource().getEntity();
        if (src instanceof Projectile pr) src = pr.getOwner();
        if (src instanceof TamableAnimal ta && ta.getOwner() instanceof ServerPlayer owner) src = owner;
        if (src instanceof ServerPlayer sp) who.add(sp);
        for (ServerPlayer sp : dead.getServer().getPlayerList().getPlayers()) {
            if (sp.level() == dead.level() && !sp.isSpectator() && sp.distanceToSqr(dead) <= radius * radius) who.add(sp);
        }
        for (ServerPlayer p : who) {
            WData d = WData.get(p);
            String flag = "boss_" + boss;
            if (d.extra.getBoolean(flag)) continue; // mỗi người chỉ 1 lần
            d.extra.putBoolean(flag, true);
            Card c = exact ? RoundManager.exactCard(d, rarity) : RoundManager.rewardCard(d, rarity);
            RoundManager.giveReward(p, c, Component.translatable("reward.wildcard.boss." + boss));
        }
    }

    private Rewards() {}
}
