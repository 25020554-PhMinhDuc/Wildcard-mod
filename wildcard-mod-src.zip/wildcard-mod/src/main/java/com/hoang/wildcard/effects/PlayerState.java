package com.hoang.wildcard.effects;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Runtime-only per-player state (not saved). */
public final class PlayerState {
    private static final Map<UUID, PlayerState> MAP = new HashMap<>();

    public static PlayerState get(Player p) {
        return MAP.computeIfAbsent(p.getUUID(), u -> new PlayerState());
    }

    public static void remove(Player p) {
        MAP.remove(p.getUUID());
    }

    public static void clearAll() {
        MAP.clear();
    }

    private final Map<String, Long> cooldowns = new HashMap<>();

    public Vec3 lastPos;
    public int stillTicks;
    public int crouchTicks;
    public float lastExhaustion = -1;
    public final ArrayDeque<Vec3> history = new ArrayDeque<>();
    public int dryTicks;
    public int hitCounter;
    public boolean ninja;
    public long revealedUntil;
    public String stolen = "";
    public long stolenUntil;
    public net.minecraft.world.entity.EntityType<?> lastKilledType;
    public boolean fortress;
    public Item trackedMainItem;
    public int trackedMainSlot = -1;
    public int trackedMainDamage;
    public final Item[] armorItems = new Item[4];
    public final int[] armorDamage = new int[4];
    public int foodBefore = -1;
    public float saturationBefore;
    public ItemStack placeStack = ItemStack.EMPTY;
    public int placeCount;
    public long flightEnd;
    public long timeStopSelfFreeze;
    public long selfExplosionImmuneUntil;
    public boolean wasStill;
    public long villageCacheTime = -10000;
    public net.minecraft.core.BlockPos villagePos;

    public String stolenAbility() {
        return stolen;
    }

    /** Returns true (and starts the cooldown) if {@code key} is off cooldown. */
    public boolean ready(String key, long now, int cooldownTicks) {
        Long until = cooldowns.get(key);
        if (until != null && now < until) return false;
        cooldowns.put(key, now + cooldownTicks);
        return true;
    }

    public long remaining(String key, long now) {
        Long until = cooldowns.get(key);
        return until == null ? 0 : Math.max(0, until - now);
    }

    public void setCooldown(String key, long until) {
        cooldowns.put(key, until);
    }
}
