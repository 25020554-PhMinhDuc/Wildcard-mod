package com.hoang.wildcard.effects;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/**
 * v7.3: a card at max stars loses the potion-effect part of its debuff (e.g. "Bóng Tối I dưới Y=0"). Generated
 * "eff:" debuffs are dropped in GenEffects; hand-written debuffs are caught here: card code always checks
 * {@code has(p, id)} right before it gives the player a bad effect, so the last card checked for this player in this
 * tick is the one giving it.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class MaxStars {
    private record Ctx(UUID player, String card, long time) {}

    private static final ThreadLocal<Ctx> LAST = new ThreadLocal<>();

    public static boolean maxed(Player p, String id) {
        return !p.level().isClientSide && WData.get(p).stars.getOrDefault(id, 0) >= Card.MAX_STARS;
    }

    public static void touch(Player p, String id) {
        LAST.set(new Ctx(p.getUUID(), id, p.level().getGameTime()));
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onApplicable(MobEffectEvent.Applicable e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (e.getEffectInstance().getEffect().getCategory() != MobEffectCategory.HARMFUL) return;
        Ctx c = LAST.get();
        if (c == null || !c.player().equals(p.getUUID()) || c.time() != p.level().getGameTime()) return;
        if (maxed(p, c.card())) e.setResult(Event.Result.DENY);
    }

    private MaxStars() {}
}
