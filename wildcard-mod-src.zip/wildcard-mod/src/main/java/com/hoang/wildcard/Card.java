package com.hoang.wildcard;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class Card {
    public final String id;
    public final Rarity rarity;
    public final Item buffIcon;
    public final Item debuffIcon;
    /** Cards sharing a tag never appear together with an owned card that has the same tag. */
    public final Set<String> tags;
    /** Active skills (cooldown in seconds), bound to G H J K L when this card is the active one. */
    public final List<Integer> skills = new ArrayList<>();

    public Card(String id, Rarity rarity, Item buffIcon, Item debuffIcon, Set<String> tags) {
        this.id = id;
        this.rarity = rarity;
        this.buffIcon = buffIcon;
        this.debuffIcon = debuffIcon;
        this.tags = tags;
    }

    public Component buffName() { return Component.translatable("card.wildcard." + id + ".buff"); }
    public Component buffDesc() { return Component.translatable("card.wildcard." + id + ".buff.desc"); }
    public Component debuffName() { return Component.translatable("card.wildcard." + id + ".debuff"); }
    public Component debuffDesc() { return Component.translatable("card.wildcard." + id + ".debuff.desc"); }

    public Component skillName(int i) { return Component.translatable("skill.wildcard." + id + "." + i); }
    public Component skillDesc(int i) { return Component.translatable("skill.wildcard." + id + "." + i + ".desc"); }
    public int skillCooldown(int i) { return i >= 0 && i < skills.size() ? skills.get(i) : 0; }

    public ItemStack buffStack() { return new ItemStack(buffIcon); }
    public ItemStack debuffStack() { return new ItemStack(debuffIcon); }

    public boolean conflictsWith(Card other) {
        if (other == this) return true;
        for (String t : tags) if (other.tags.contains(t)) return true;
        return false;
    }
}
