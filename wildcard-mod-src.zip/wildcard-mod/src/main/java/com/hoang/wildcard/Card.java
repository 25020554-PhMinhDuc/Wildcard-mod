package com.hoang.wildcard;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class Card {
    public final String id;
    public final Rarity rarity;
    public final Item buffIcon;
    public final Item debuffIcon;
    /** Cards sharing a tag never appear together with an owned card that has the same tag. */
    public final Set<String> tags;
    /** Active skill cooldowns in seconds (v3: at most one per card). */
    public final List<Integer> skills = new ArrayList<>();
    /** Original skill number of each entry in {@link #skills}: used for texts, icons and the skill code. */
    public final List<Integer> skillOrig = new ArrayList<>();
    /** Extra troll/meme debuffs (ids from TrollDebuffs), more on rarer cards. Filled by Cards. */
    public final List<String> trolls = new ArrayList<>();
    /** Generated cards (c41+, u61+): data-driven buff and debuff. Null for hand-made cards. */
    public GenSpec gen;
    /** Generated skill (null when the skill is hand-made in Skills/Mythic/MemeCards). */
    public GenSkill genSkill;
    /** Meme card: special roll sound. */
    public boolean meme;

    public Card(String id, Rarity rarity, Item buffIcon, Item debuffIcon, Set<String> tags) {
        this.id = id;
        this.rarity = rarity;
        this.buffIcon = buffIcon;
        this.debuffIcon = debuffIcon;
        this.tags = tags;
    }

    public Component buffName() { return Component.translatable("card.wildcard." + id + ".buff"); }
    public Component buffDesc() { return Component.translatable("card.wildcard." + id + ".buff.desc"); }
    public Component debuffName() { return Component.translatable("card.wildcard." + id + ".debuff"); }
    public Component debuffDesc() { return Component.translatable("card.wildcard." + id + ".debuff.desc"); }

    public int orig(int i) { return i >= 0 && i < skillOrig.size() ? skillOrig.get(i) : i; }
    public Component skillName(int i) { return Component.translatable("skill.wildcard." + id + "." + orig(i)); }
    public Component skillDesc(int i) { return Component.translatable("skill.wildcard." + id + "." + orig(i) + ".desc"); }
    public int skillCooldown(int i) { return i >= 0 && i < skills.size() ? skills.get(i) : 0; }

    public ItemStack buffStack() { return new ItemStack(buffIcon); }
    public ItemStack debuffStack() { return new ItemStack(debuffIcon); }

    public boolean conflictsWith(Card other) {
        if (other == this) return true;
        for (String t : tags) if (other.tags.contains(t)) return true;
        return false;
    }
}
