package com.hoang.wildcard.client;

import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * v6 Card Rain: "Bạn có muốn chọn thẻ này không?". The card's rarity and content stay hidden until it is taken.
 * Closing the screen (Esc or time out) counts as "No".
 */
public class RainConfirmScreen extends Screen {
    private final int entity;
    private int ticksLeft;
    private boolean answered;

    public RainConfirmScreen(int entity, int seconds) {
        super(Component.translatable("gui.wildcard.rain.ask"));
        this.entity = entity;
        this.ticksLeft = Math.max(1, seconds) * 20;
    }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 + 34;
        addRenderableWidget(Button.builder(Component.translatable("gui.wildcard.rain.yes").withStyle(ChatFormatting.GREEN), b -> answer(true))
                .bounds(cx - 104, y, 100, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.wildcard.rain.no").withStyle(ChatFormatting.RED), b -> answer(false))
                .bounds(cx + 4, y, 100, 20).build());
    }

    private void answer(boolean yes) {
        if (answered) return;
        answered = true;
        Net.toServer(new Net.RainAnswer(entity, yes));
        if (minecraft != null) minecraft.setScreen(null);
    }

    @Override
    public void tick() {
        if (--ticksLeft <= 0) answer(false);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        int cx = width / 2, cy = height / 2;
        g.fill(cx - 120, cy - 64, cx + 120, cy + 62, 0xE0101018);
        g.renderOutline(cx - 120, cy - 64, 240, 126, 0xFFB070FF);
        g.drawCenteredString(font, Component.translatable("title.wildcard.rain").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), cx, cy - 56, 0xFFFFFF);
        // mặt sau của thẻ bí ẩn
        g.fill(cx - 16, cy - 42, cx + 16, cy + 2, 0xFF2A1840);
        g.renderOutline(cx - 16, cy - 42, 32, 44, 0xFF8A8A9A);
        g.drawCenteredString(font, Component.literal("?").withStyle(ChatFormatting.BOLD), cx, cy - 24, 0xFFE0E0E0);
        g.drawCenteredString(font, Component.translatable("gui.wildcard.rain.ask").withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD), cx, cy + 8, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("gui.wildcard.rain.hidden").withStyle(ChatFormatting.GRAY), cx, cy + 20, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("gui.wildcard.timer", (ticksLeft + 19) / 20).withStyle(ChatFormatting.DARK_GRAY), cx, cy + 58 + 4, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_Y || key == GLFW.GLFW_KEY_ENTER) {
            answer(true);
            return true;
        }
        if (key == GLFW.GLFW_KEY_N) {
            answer(false);
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        answer(false);
    }

    @Override
    public void removed() {
        if (!answered) { // màn hình bị đóng vì lý do khác
            answered = true;
            Net.toServer(new Net.RainAnswer(entity, false));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
