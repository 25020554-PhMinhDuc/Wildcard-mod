package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.ModSounds;
import com.hoang.wildcard.Rarity;
import com.hoang.wildcard.net.Net;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Card choice screen. The three cards fly in face down and spin, then the player flips each one
 * (click or 1/2/3) and clicks a flipped card again to take it. Flip sounds depend on rarity (VIP) and meme cards.
 */
public class WildcardScreen extends Screen {
    private static final int GAP = 12;
    private static final int SPIN = 34, STAGGER = 7, FLIP = 10;

    private final List<Card> cards = new ArrayList<>();
    private final int round;
    private int ticksLeft;
    private int age;
    private boolean sent;
    private final int[] flipStart = {-1, -1, -1};
    private final boolean[] revealedSound = new boolean[3];

    private int cardW, cardH, top, left;

    public WildcardScreen(Net.OpenChoice msg) {
        super(Component.translatable("gui.wildcard.title"));
        for (String id : msg.ids()) {
            Card c = Cards.get(id);
            if (c != null) cards.add(c);
        }
        this.round = msg.round();
        this.ticksLeft = msg.seconds() * 20;
        play(ModSounds.ROLL_SPIN.get(), 1f);
    }

    private static void play(SoundEvent s, float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(s, pitch));
    }

    @Override
    protected void init() {
        cardW = Mth.clamp((width - 32 - GAP * 2) / 3, 100, 150);
        cardH = Mth.clamp(height - 76, 150, 240);
        int n = Math.max(1, cards.size());
        int total = n * cardW + (n - 1) * GAP;
        left = (width - total) / 2;
        top = Math.max(18, (height - cardH - 42) / 2 + 6);
    }

    private boolean spinning(int i) {
        return age < SPIN + i * STAGGER;
    }

    private boolean flipped(int i) {
        return flipStart[i] >= 0 && age - flipStart[i] >= FLIP / 2;
    }

    @Override
    public void tick() {
        age++;
        if (ticksLeft > 0) ticksLeft--;
        for (int i = 0; i < cards.size(); i++) {
            if (age == SPIN + i * STAGGER) play(net.minecraft.sounds.SoundEvents.BOOK_PAGE_TURN, 1.2f);
            if (flipStart[i] < 0 && ticksLeft <= 100 && !spinning(i)) flip(i); // hết giờ: tự lật hết
            if (flipped(i) && !revealedSound[i]) {
                revealedSound[i] = true;
                play(revealSound(cards.get(i)), 1f);
            }
        }
    }

    private static SoundEvent revealSound(Card c) {
        if (c.rarity == Rarity.MYTHIC) return ModSounds.ROLL_MYTHIC.get();
        if (c.rarity == Rarity.LEGENDARY) return ModSounds.ROLL_LEGENDARY.get();
        if (c.rarity == Rarity.EPIC) return ModSounds.ROLL_VIP.get();
        if (c.meme) return ModSounds.ROLL_MEME.get();
        return ModSounds.ROLL_FLIP.get();
    }

    private int cardX(int i) {
        return left + i * (cardW + GAP);
    }

    private int hovered(double mx, double my) {
        for (int i = 0; i < cards.size(); i++) {
            int x = cardX(i);
            if (mx >= x && mx < x + cardW && my >= top - 4 && my < top + cardH) return i;
        }
        return -1;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float pt) {
        renderBackground(g);
        int hover = hovered(mouseX, mouseY);
        float now = age + pt;

        g.drawCenteredString(font, Component.translatable("gui.wildcard.round", round).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                width / 2, top - 14, 0xFFFFFF);

        for (int i = 0; i < cards.size(); i++) {
            Card c = cards.get(i);
            int x = cardX(i);
            float end = SPIN + i * STAGGER;
            float sx;
            boolean front;
            int y = top;
            if (now < end) { // bay vào + xoay, chậm dần
                float t = Mth.clamp(now / end, 0f, 1f);
                float ease = 1 - (1 - t) * (1 - t) * (1 - t);
                float angle = ease * (float) Math.PI * 6;
                sx = Math.abs(Mth.cos(angle));
                front = false;
                y = top + (int) ((1 - ease) * (height - top));
            } else if (flipStart[i] < 0) {
                sx = 1;
                front = false;
            } else {
                float t = Mth.clamp((now - flipStart[i]) / FLIP, 0f, 1f);
                sx = Math.abs(Mth.cos(t * (float) Math.PI));
                front = t >= 0.5f;
            }
            int lift = i == hover && !spinning(i) ? -3 : 0;
            g.pose().pushPose();
            g.pose().translate(x + cardW / 2f, 0, 0);
            g.pose().scale(Math.max(0.02f, sx), 1, 1);
            g.pose().translate(-(x + cardW / 2f), 0, 0);
            if (front) {
                CardArt.drawCard(g, font, c, x, y + lift, cardW, cardH, i == hover);
            } else {
                drawBack(g, c, x, y + lift, i == hover && !spinning(i), now);
            }
            g.pose().popPose();
            if (front && swapsMythic(c)) {
                g.pose().pushPose();
                g.pose().translate(x + cardW / 2f, top + cardH + 4, 0);
                g.pose().scale(0.75f, 0.75f, 1);
                g.drawCenteredString(font, Component.translatable("gui.wildcard.mythicswap").withStyle(ChatFormatting.RED, ChatFormatting.BOLD), 0, 0, 0xFFFFFF);
                g.pose().popPose();
            } else if (front && ClientState.CARDS.contains(c.id) && ClientState.STARS.getOrDefault(c.id, 0) >= com.hoang.wildcard.Card.MAX_STARS) {
                g.pose().pushPose();
                g.pose().translate(x + cardW / 2f, top + cardH + 4, 0);
                g.pose().scale(0.75f, 0.75f, 1);
                g.drawCenteredString(font, Component.translatable("gui.wildcard.dupe.max").withStyle(ChatFormatting.GRAY, ChatFormatting.BOLD), 0, 0, 0xFFFFFF);
                g.pose().popPose();
            } else if (front && ClientState.CARDS.contains(c.id)) {
                g.pose().pushPose();
                g.pose().translate(x + cardW / 2f, top + cardH + 4, 0);
                g.pose().scale(0.75f, 0.75f, 1);
                g.drawCenteredString(font, Component.translatable("gui.wildcard.dupe", Card.starText(ClientState.STARS.getOrDefault(c.id, 0) + 1, false))
                        .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), 0, 0, 0xFFFFFF);
                g.pose().popPose();
            }
        }

        int secs = (ticksLeft + 19) / 20;
        g.drawCenteredString(font, Component.translatable("gui.wildcard.timer", secs).withStyle(secs <= 5 ? ChatFormatting.RED : ChatFormatting.GRAY),
                width / 2, top + cardH + 17, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("gui.wildcard.hint.flip").withStyle(ChatFormatting.DARK_GRAY),
                width / 2, top + cardH + 29, 0xFFFFFF);
        super.render(g, mouseX, mouseY, pt);

        if (hover >= 0 && flipped(hover) && !cards.get(hover).skills.isEmpty()) {
            g.renderComponentTooltip(font, CardArt.skillTooltip(cards.get(hover)), mouseX, mouseY);
        }
    }

    /** Face-down card. Epic and better cards glow in their colour so the player knows something good is coming. */
    private void drawBack(GuiGraphics g, Card c, int x, int y, boolean hover, float now) {
        RenderSystem.enableBlend();
        boolean vip = c.rarity.ordinal() >= Rarity.EPIC.ordinal();
        if (vip) {
            float pulse = 0.6f + 0.4f * Mth.sin(now * 0.3f);
            RenderSystem.setShaderColor(1, 1, 1, pulse);
            CardArt.nineSlice(g, CardArt.glow(c.rarity), x - 4, y - 4, cardW + 8, cardH + 8);
            RenderSystem.setShaderColor(1, 1, 1, 1);
        } else if (hover) {
            CardArt.nineSlice(g, CardArt.glow(Rarity.COMMON), x - 3, y - 3, cardW + 6, cardH + 6);
        }
        g.blit(CardArt.tex("card/back"), x, y, cardW, cardH, 0, 0, 64, 96, 64, 96);
        if (hover) g.drawCenteredString(font, Component.translatable("gui.wildcard.flip").withStyle(ChatFormatting.YELLOW), x + cardW / 2, y + cardH - 16, 0xFFFFFF);
    }

    /** Picking this card would replace the Mythical card the player already has. */
    private static boolean swapsMythic(Card c) {
        if (c.rarity != Rarity.MYTHIC || ClientState.CARDS.contains(c.id)) return false;
        for (String id : ClientState.CARDS) {
            Card o = Cards.get(id);
            if (o != null && o.rarity == Rarity.MYTHIC && o != c) return true;
        }
        return false;
    }

    private void flip(int i) {
        if (i < 0 || i >= cards.size() || flipStart[i] >= 0 || spinning(i)) return;
        flipStart[i] = age;
        play(net.minecraft.sounds.SoundEvents.BOOK_PAGE_TURN, 0.8f);
    }

    /** First press flips the card, second press (once it is face up) takes it. */
    private void press(int i) {
        if (sent || i < 0 || i >= cards.size()) return;
        if (!flipped(i)) {
            flip(i);
            return;
        }
        sent = true;
        Net.toServer(new Net.Choose(i));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int i = hovered(mx, my);
        if (button == 0 && i >= 0) {
            press(i);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_3) {
            press(key - GLFW.GLFW_KEY_1);
            return true;
        }
        if (key == GLFW.GLFW_KEY_SPACE) { // lật hết
            for (int i = 0; i < cards.size(); i++) flip(i);
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
