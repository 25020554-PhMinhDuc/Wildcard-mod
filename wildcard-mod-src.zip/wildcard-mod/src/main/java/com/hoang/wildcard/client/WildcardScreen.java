package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.Rarity;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Card choice screen, styled after the reference images: three dark cards side by side,
 * border and tier title in the rarity colour, LỢI ÍCH (green) on top and BẤT LỢI (red) below,
 * plus the KỸ NĂNG list on Rare+ cards. No reroll.
 */
public class WildcardScreen extends Screen {
    private static final int GAP = 12;

    private final List<Card> cards = new ArrayList<>();
    private final int round;
    private int ticksLeft;
    private int age;
    private boolean sent;

    private int cardW, cardH, top, left;

    public WildcardScreen(Net.OpenChoice msg) {
        super(Component.translatable("gui.wildcard.title"));
        for (String id : msg.ids()) {
            Card c = Cards.get(id);
            if (c != null) cards.add(c);
        }
        this.round = msg.round();
        this.ticksLeft = msg.seconds() * 20;
    }

    @Override
    protected void init() {
        cardW = Mth.clamp((width - 32 - GAP * 2) / 3, 100, 150);
        cardH = Mth.clamp(height - 76, 150, 240);
        int n = Math.max(1, cards.size());
        int total = n * cardW + (n - 1) * GAP;
        left = (width - total) / 2;
        top = Math.max(18, (height - cardH - 42) / 2 + 6);
    }

    @Override
    public void tick() {
        age++;
        if (ticksLeft > 0) ticksLeft--;
    }

    private int cardX(int i) {
        return left + i * (cardW + GAP);
    }

    private int hovered(double mx, double my) {
        for (int i = 0; i < cards.size(); i++) {
            int x = cardX(i);
            if (mx >= x && mx < x + cardW && my >= top - 4 && my < top + cardH) return i;
        }
        return -1;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        float intro = Math.min(1f, (age + partialTick) / 8f);
        int hover = hovered(mouseX, mouseY);

        g.drawCenteredString(font, Component.translatable("gui.wildcard.round", round).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                width / 2, top - 14, 0xFFFFFF);

        for (int i = 0; i < cards.size(); i++) {
            int slide = (int) ((1f - intro) * (30 + i * 12));
            int lift = i == hover ? -3 : 0;
            Card c = cards.get(i);
            CardArt.drawCard(g, font, c, cardX(i), top + slide + lift, cardW, cardH, i == hover);
            if (swapsMythic(c)) {
                g.pose().pushPose();
                g.pose().translate(cardX(i) + cardW / 2f, top + cardH + 4, 0);
                g.pose().scale(0.75f, 0.75f, 1);
                g.drawCenteredString(font, Component.translatable("gui.wildcard.mythicswap").withStyle(ChatFormatting.RED, ChatFormatting.BOLD), 0, 0, 0xFFFFFF);
                g.pose().popPose();
            }
        }

        int secs = (ticksLeft + 19) / 20;
        g.drawCenteredString(font, Component.translatable("gui.wildcard.timer", secs).withStyle(secs <= 5 ? ChatFormatting.RED : ChatFormatting.GRAY),
                width / 2, top + cardH + 17, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("gui.wildcard.hint").withStyle(ChatFormatting.DARK_GRAY),
                width / 2, top + cardH + 29, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);

        if (hover >= 0 && !cards.get(hover).skills.isEmpty() && intro >= 1f) {
            g.renderComponentTooltip(font, CardArt.skillTooltip(cards.get(hover)), mouseX, mouseY);
        }
    }

    /** Picking this card would replace the Mythical card the player already has. */
    private static boolean swapsMythic(Card c) {
        if (c.rarity != Rarity.MYTHIC) return false;
        for (String id : ClientState.CARDS) {
            Card o = Cards.get(id);
            if (o != null && o.rarity == Rarity.MYTHIC && o != c) return true;
        }
        return false;
    }

    private void choose(int i) {
        if (sent || i < 0 || i >= cards.size()) return;
        sent = true;
        Net.toServer(new Net.Choose(i));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int i = hovered(mx, my);
        if (button == 0 && i >= 0) {
            choose(i);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_3) {
            choose(key - GLFW.GLFW_KEY_1);
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
