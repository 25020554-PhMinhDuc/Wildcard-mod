package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.Rarity;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Card choice screen, styled after the reference images: three dark cards side by side,
 * border and tier title in the rarity colour, LỢI ÍCH (green) on top and BẤT LỢI (red) below.
 */
public class WildcardScreen extends Screen {
    private static final int BG = 0xF0141419;
    private static final int OUTLINE = 0xFF07070A;
    private static final int DIVIDER = 0xFF4B4B57;
    private static final int BUFF_LABEL = 0xFF7EE07E;
    private static final int BUFF_NAME = 0xFF5CFF6A;
    private static final int DEBUFF_LABEL = 0xFFFF7A7A;
    private static final int DEBUFF_NAME = 0xFFFF5A5A;
    private static final int DESC = 0xFFE6E6E6;
    private static final int GAP = 12;
    private static final ResourceLocation BUFF_ICON = tex("icon/buff");
    private static final ResourceLocation DEBUFF_ICON = tex("icon/debuff");
    private static final ResourceLocation STAR = tex("icon/star");
    private static final ResourceLocation CREST = tex("card/crest_legendary");

    private static ResourceLocation tex(String path) {
        return new ResourceLocation("wildcard", "textures/gui/" + path + ".png");
    }

    private static ResourceLocation frame(Rarity r) { return tex("card/frame_" + r.key); }
    private static ResourceLocation glow(Rarity r) { return tex("card/hover_" + r.key); }

    /** Nine-slice a 32x32 texture with 8px corners (edges and centre stretched; they are uniform). */
    private static void nineSlice(GuiGraphics g, ResourceLocation t, int x, int y, int w, int h) {
        final int T = 32, C = 8, M = T - 2 * C;
        int iw = w - 2 * C, ih = h - 2 * C;
        g.blit(t, x, y, C, C, 0, 0, C, C, T, T);
        g.blit(t, x + w - C, y, C, C, T - C, 0, C, C, T, T);
        g.blit(t, x, y + h - C, C, C, 0, T - C, C, C, T, T);
        g.blit(t, x + w - C, y + h - C, C, C, T - C, T - C, C, C, T, T);
        g.blit(t, x + C, y, iw, C, C, 0, M, C, T, T);
        g.blit(t, x + C, y + h - C, iw, C, C, T - C, M, C, T, T);
        g.blit(t, x, y + C, C, ih, 0, C, C, M, T, T);
        g.blit(t, x + w - C, y + C, C, ih, T - C, C, C, M, T, T);
        g.blit(t, x + C, y + C, iw, ih, C, C, M, M, T, T);
    }

    private final List<Card> cards = new ArrayList<>();
    private final int rerolls;
    private final int round;
    private int ticksLeft;
    private int age;
    private boolean sent;

    private int cardW, cardH, top, left;
    private Button rerollButton;

    public WildcardScreen(Net.OpenChoice msg) {
        super(Component.translatable("gui.wildcard.title"));
        for (String id : msg.ids()) {
            Card c = Cards.get(id);
            if (c != null) cards.add(c);
        }
        this.rerolls = msg.rerolls();
        this.round = msg.round();
        this.ticksLeft = msg.seconds() * 20;
    }

    @Override
    protected void init() {
        cardW = Mth.clamp((width - 32 - GAP * 2) / 3, 100, 150);
        cardH = Mth.clamp(height - 74, 150, 215);
        int n = Math.max(1, cards.size());
        int total = n * cardW + (n - 1) * GAP;
        left = (width - total) / 2;
        top = Math.max(18, (height - cardH - 44) / 2 + 6);
        int bw = 110;
        rerollButton = addRenderableWidget(Button.builder(Component.translatable("gui.wildcard.reroll", rerolls), b -> reroll())
                .bounds(width / 2 - bw / 2, top + cardH + 20, bw, 20).build());
        rerollButton.active = rerolls > 0;
    }

    @Override
    public void tick() {
        age++;
        if (ticksLeft > 0) ticksLeft--;
    }

    private int cardX(int i) {
        return left + i * (cardW + GAP);
    }

    private int hovered(double mx, double my) {
        for (int i = 0; i < cards.size(); i++) {
            int x = cardX(i);
            if (mx >= x && mx < x + cardW && my >= top - 4 && my < top + cardH) return i;
        }
        return -1;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        float intro = Math.min(1f, (age + partialTick) / 8f);
        int hover = hovered(mouseX, mouseY);

        g.drawCenteredString(font, Component.translatable("gui.wildcard.round", round).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                width / 2, top - 14, 0xFFFFFF);

        for (int i = 0; i < cards.size(); i++) {
            int slide = (int) ((1f - intro) * (30 + i * 12));
            int lift = i == hover ? -3 : 0;
            drawCard(g, cards.get(i), cardX(i), top + slide + lift, i == hover);
        }

        int secs = (ticksLeft + 19) / 20;
        g.drawCenteredString(font, Component.translatable("gui.wildcard.timer", secs).withStyle(secs <= 5 ? ChatFormatting.RED : ChatFormatting.GRAY),
                width / 2, top + cardH + 7, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(font, Component.translatable("gui.wildcard.hint").withStyle(ChatFormatting.DARK_GRAY),
                width / 2, top + cardH + 44, 0xFFFFFF);
    }

    // ------------------------------------------------------------------ card drawing

    private static void pixelRect(GuiGraphics g, int x, int y, int w, int h, int color) {
        // rectangle with 2px stepped corners, like the pixel-art frames in the reference
        g.fill(x + 2, y, x + w - 2, y + h, color);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, color);
        g.fill(x, y + 2, x + w, y + h - 2, color);
    }

    private static int brighten(int argb, float f) {
        int r = Math.min(255, (int) (((argb >> 16) & 255) * f));
        int gr = Math.min(255, (int) (((argb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((argb & 255) * f));
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    private void drawCard(GuiGraphics g, Card c, int x, int y, boolean hover) {
        int w = cardW, h = cardH;
        RenderSystem.enableBlend();
        if (hover) nineSlice(g, glow(c.rarity), x - 3, y - 3, w + 6, h + 6);
        nineSlice(g, frame(c.rarity), x, y, w, h);
        if (c.rarity == Rarity.LEGENDARY) g.blit(CREST, x + w / 2 - 9, y - 4, 0, 0, 18, 8, 18, 8);

        int pad = 8;
        int innerW = w - pad * 2;

        // tier title
        Component title = c.rarity.displayName().copy().withStyle(s -> s.withBold(true).withColor(c.rarity.rgb()));
        g.pose().pushPose();
        float ts = 1.25f;
        g.pose().translate(x + w / 2f, y + 8, 0);
        g.pose().scale(ts, ts, 1);
        g.drawCenteredString(font, title, 0, 0, 0xFFFFFF);
        g.pose().popPose();

        int contentTop = y + 24;
        if (c.rarity == Rarity.LEGENDARY) {
            g.blit(STAR, x + w / 2 - 8, y + 22, 0, 0, 16, 16, 16, 16);
            contentTop = y + 42;
        }
        int bottom = y + h - 6;
        int half = (bottom - contentTop - 6) / 2;
        int mid = contentTop + half + 2;
        g.fill(x + pad, mid, x + w - pad, mid + 1, DIVIDER);

        drawHalf(g, x + pad, contentTop, innerW, half, Component.translatable("gui.wildcard.buff"), BUFF_LABEL, BUFF_ICON,
                c.buffName(), BUFF_NAME, c.buffDesc(), c.buffStack());
        drawHalf(g, x + pad, mid + 6, innerW, bottom - mid - 6, Component.translatable("gui.wildcard.debuff"), DEBUFF_LABEL, DEBUFF_ICON,
                c.debuffName(), DEBUFF_NAME, c.debuffDesc(), c.debuffStack());
    }

    private void drawHalf(GuiGraphics g, int x, int y, int w, int h, Component label, int labelColor, ResourceLocation arrow,
                          Component name, int nameColor, Component desc, ItemStack icon) {
        Component bold = label.copy().withStyle(ChatFormatting.BOLD);
        g.drawString(font, bold, x, y + 2, labelColor, true);
        // small arrow (8x8, scaled down from 16x16) right after the label; item icon stays on the right
        g.blit(arrow, x + font.width(bold) + 3, y + 2, 8, 8, 0, 0, 16, 16, 16, 16);
        g.renderItem(icon, x + w - 16, y - 2);

        int cy = y + 14;
        // name: bold, wraps; shrink if too long
        Component boldName = name.copy().withStyle(ChatFormatting.BOLD);
        float ns = 1f;
        List<FormattedCharSequence> nameLines = font.split(boldName, w);
        if (nameLines.size() > 2) {
            ns = 0.8f;
            nameLines = font.split(boldName, (int) (w / ns));
        }
        cy = drawLines(g, nameLines, x, cy, ns, nameColor, true);
        cy += 3;

        int avail = y + h - cy;
        float[] scales = {1f, 0.85f, 0.72f, 0.62f, 0.55f};
        List<FormattedCharSequence> lines = null;
        float s = 1f;
        for (float sc : scales) {
            s = sc;
            lines = font.split(FormattedText.of(desc.getString()), (int) (w / sc));
            if (lines.size() * 10 * sc <= avail) break;
        }
        drawLines(g, lines, x, cy, s, DESC, false);
    }

    private int drawLines(GuiGraphics g, List<FormattedCharSequence> lines, int x, int y, float scale, int color, boolean shadow) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1);
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(font, lines.get(i), 0, i * 10, color, shadow);
        }
        g.pose().popPose();
        return y + (int) Math.ceil(lines.size() * 10 * scale);
    }

    // ------------------------------------------------------------------ input

    private void choose(int i) {
        if (sent || i < 0 || i >= cards.size()) return;
        sent = true;
        Net.toServer(new Net.Choose(i));
    }

    private void reroll() {
        if (sent || rerolls <= 0) return;
        sent = true;
        Net.toServer(new Net.Choose(-1));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int i = hovered(mx, my);
        if (button == 0 && i >= 0) {
            choose(i);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_3) {
            choose(key - GLFW.GLFW_KEY_1);
            return true;
        }
        if (key == GLFW.GLFW_KEY_R) {
            reroll();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
