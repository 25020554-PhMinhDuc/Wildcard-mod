package com.hoang.wildcard.net;

import com.hoang.wildcard.RoundManager;
import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.client.ClientPackets;
import com.hoang.wildcard.effects.Abilities;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class Net {
    private static final String VERSION = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(WildcardMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);
    private static boolean registered;

    public static void register() {
        if (registered) return;
        registered = true;
        int id = 0;
        CH.messageBuilder(OpenChoice.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenChoice::encode).decoder(OpenChoice::decode).consumerMainThread(OpenChoice::handle).add();
        CH.messageBuilder(Sync.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(Sync::encode).decoder(Sync::decode).consumerMainThread(Sync::handle).add();
        CH.messageBuilder(Fx.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(Fx::encode).decoder(Fx::decode).consumerMainThread(Fx::handle).add();
        CH.messageBuilder(Choose.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(Choose::encode).decoder(Choose::decode).consumerMainThread(Choose::handle).add();
        CH.messageBuilder(Ability.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(Ability::encode).decoder(Ability::decode).consumerMainThread(Ability::handle).add();
    }

    public static void toPlayer(ServerPlayer p, Object msg) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), msg);
    }

    public static void toServer(Object msg) {
        CH.sendToServer(msg);
    }

    private static void writeList(FriendlyByteBuf buf, List<String> list) {
        buf.writeVarInt(list.size());
        for (String s : list) buf.writeUtf(s);
    }

    private static List<String> readList(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<String> l = new ArrayList<>(n);
        for (int i = 0; i < n; i++) l.add(buf.readUtf());
        return l;
    }

    /** Server -> client: open the card choice screen. */
    public record OpenChoice(List<String> ids, int seconds, int rerolls, int round) {
        public void encode(FriendlyByteBuf buf) {
            writeList(buf, ids);
            buf.writeVarInt(seconds);
            buf.writeVarInt(rerolls);
            buf.writeVarInt(round);
        }

        public static OpenChoice decode(FriendlyByteBuf buf) {
            return new OpenChoice(readList(buf), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPackets.openChoice(this));
        }
    }

    /** Server -> client: the list of owned cards. */
    public record Sync(List<String> cards, String stolen) {
        public void encode(FriendlyByteBuf buf) {
            writeList(buf, cards);
            buf.writeUtf(stolen);
        }

        public static Sync decode(FriendlyByteBuf buf) {
            return new Sync(readList(buf), buf.readUtf());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPackets.sync(this));
        }
    }

    /** Server -> client: a one-shot visual effect (flash, sneeze, close screen...). */
    public record Fx(String type, int value) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeUtf(type);
            buf.writeVarInt(value);
        }

        public static Fx decode(FriendlyByteBuf buf) {
            return new Fx(buf.readUtf(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPackets.fx(this));
        }
    }

    /** Client -> server: chosen card index (0..2) or -1 to reroll. */
    public record Choose(int index) {
        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(index + 1);
        }

        public static Choose decode(FriendlyByteBuf buf) {
            return new Choose(buf.readVarInt() - 1);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) RoundManager.onChoose(p, index);
        }
    }

    /** Client -> server: an ability key was pressed. */
    public record Ability(int kind) {
        public static final int MOVE = 0, SKILL = 1, ENDER = 2, FAN = 3;

        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(kind);
        }

        public static Ability decode(FriendlyByteBuf buf) {
            return new Ability(buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) Abilities.use(p, kind);
        }
    }

    private Net() {}
}
