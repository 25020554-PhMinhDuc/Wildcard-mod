package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Skill bar in the bottom-right corner: the 5 loadout slots G H J K L with cooldowns. */
public final class SkillHud {
    private static final int BOX = 18, GAP = 3;

    /** Card of a loadout entry, or null. */
    static Card card(String entry) {
        int i = entry.lastIndexOf(':');
        return i <= 0 ? null : Cards.get(entry.substring(0, i));
    }

    static int index(String entry) {
        try {
            return Integer.parseInt(entry.substring(entry.lastIndexOf(':') + 1));
        } catch (RuntimeException e) {
            return -1;
        }
    }

    public static void render(GuiGraphics g, Minecraft mc) {
        if (mc.level == null) return;
        boolean any = false;
        for (String s : ClientState.LOADOUT) if (card(s) != null) any = true;
        if (!any) return;
        int w = g.guiWidth(), h = g.guiHeight();
        int n = ClientState.LOADOUT.length;
        int total = n * BOX + (n - 1) * GAP;
        boolean fits = w - (w / 2 + 91) >= total + 12;
        int x0 = w - total - 6;
        int y = fits ? h - BOX - 4 : h - BOX - 52;
        long now = mc.level.getGameTime();

        for (int i = 0; i < n; i++) {
            int x = x0 + i * (BOX + GAP);
            String entry = ClientState.LOADOUT[i];
            Card c = card(entry);
            String key = ClientSetup.skillKeyLabel(i);
            if (c == null) {
                g.fill(x, y, x + BOX, y + BOX, 0x60101014);
                g.renderOutline(x - 1, y - 1, BOX + 2, BOX + 2, 0x60FFFFFF);
                g.drawCenteredString(mc.font, key, x + BOX / 2 + 1, y + 5, 0xFF606068);
                continue;
            }
            int color = 0xFF000000 | c.rarity.rgb();
            g.fill(x, y, x + BOX, y + BOX, 0xC0101014);
            g.renderOutline(x - 1, y - 1, BOX + 2, BOX + 2, color);
            int k = index(entry);
            if (k >= 0 && k < c.skills.size()) CardArt.drawSkillIcon(g, c, k, x + 1, y + 1, 16);
            long[] cd = ClientState.COOLDOWNS.get(c.id + ":" + index(entry));
            long left = cd == null ? 0 : cd[0] - now;
            if (left > 0) {
                int fillH = (int) Math.ceil(BOX * Math.min(1.0, left / (double) cd[1]));
                g.fill(x, y + BOX - fillH, x + BOX, y + BOX, 0xA0000000);
                g.drawCenteredString(mc.font, String.valueOf((left + 19) / 20), x + BOX / 2 + 1, y + 5, 0xFFFF6A6A);
            } else {
                g.pose().pushPose();
                g.pose().translate(x + BOX - 1, y + BOX - 5, 0);
                g.pose().scale(0.5f, 0.5f, 1);
                g.drawString(mc.font, key, -mc.font.width(key), 0, 0xFFFFE070, true);
                g.pose().popPose();
            }
        }
    }

    private SkillHud() {}
}
