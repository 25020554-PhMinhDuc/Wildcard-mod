package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Small skill bar in the bottom-right corner: one box per skill of the active card, with key and cooldown. */
public final class SkillHud {
    private static final int BOX = 18, GAP = 3;

    public static void render(GuiGraphics g, Minecraft mc) {
        Card c = Cards.get(ClientState.active);
        if (c == null || c.skills.isEmpty() || mc.level == null || !ClientState.has(c.id)) return;
        int w = g.guiWidth(), h = g.guiHeight();
        int n = c.skills.size();
        int total = n * BOX + (n - 1) * GAP;
        boolean fits = w - (w / 2 + 91) >= total + 12;
        int x0 = w - total - 6;
        int y = fits ? h - BOX - 4 : h - BOX - 52;
        int color = 0xFF000000 | c.rarity.rgb();
        long now = mc.level.getGameTime();

        // card name above the boxes
        String name = c.buffName().getString();
        g.pose().pushPose();
        float s = 0.7f;
        int tw = (int) (mc.font.width(name) * s);
        g.pose().translate(w - 6 - tw, y - 8, 0);
        g.pose().scale(s, s, 1);
        g.drawString(mc.font, name, 0, 0, color, true);
        g.pose().popPose();

        for (int i = 0; i < n; i++) {
            int x = x0 + i * (BOX + GAP);
            g.fill(x, y, x + BOX, y + BOX, 0xC0101014);
            g.renderOutline(x - 1, y - 1, BOX + 2, BOX + 2, color);
            long[] cd = ClientState.COOLDOWNS.get(c.id + ":" + i);
            long left = cd == null ? 0 : cd[0] - now;
            String key = ClientSetup.skillKeyLabel(i);
            if (left > 0) {
                int fillH = (int) Math.ceil(BOX * Math.min(1.0, left / (double) cd[1]));
                g.fill(x, y + BOX - fillH, x + BOX, y + BOX, 0xA0000000);
                String secs = String.valueOf((left + 19) / 20);
                g.drawCenteredString(mc.font, secs, x + BOX / 2 + 1, y + 5, 0xFFFF6A6A);
            } else {
                g.drawCenteredString(mc.font, key, x + BOX / 2 + 1, y + 5, 0xFFFFE070);
            }
        }
    }

    private SkillHud() {}
}
