package com.hoang.wildcard;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * /wildcard now            - mở lượt chọn ngay
 * /wildcard give <id>      - nhận thẻ
 * /wildcard remove <id>    - bỏ thẻ
 * /wildcard clear          - xóa toàn bộ thẻ và đặt lại
 * /wildcard list           - xem thẻ đang có
 * /wildcard timer <giây>   - đặt thời gian tới lượt kế
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class WildcardCommand {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("wildcard")
                .then(Commands.literal("list").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    WData d = WData.get(p);
                    MutableComponent out = Component.literal("Thẻ (" + d.cards.size() + "), lượt " + d.round + ": ");
                    for (String id : d.cards) {
                        Card c = Cards.get(id);
                        out.append(Component.literal("[" + id + "] ").withStyle(s -> s.withColor(c.rarity.rgb())));
                        out.append(c.buffName().copy().withStyle(ChatFormatting.GREEN)).append(" / ");
                        out.append(c.debuffName().copy().withStyle(ChatFormatting.RED)).append("  ");
                    }
                    ctx.getSource().sendSuccess(() -> out, false);
                    return d.cards.size();
                }))
                .then(Commands.literal("rain").requires(s -> s.hasPermission(2))
                        .executes(ctx -> {
                            com.hoang.wildcard.event.CardRain.schedule(ctx.getSource().getServer(), false);
                            ctx.getSource().sendSuccess(() -> Component.literal("Mưa Thẻ sẽ bắt đầu sau " + Config.RAIN_WARN_SECONDS.get() + " giây"), true);
                            return 1;
                        })
                        .then(Commands.literal("now").executes(ctx -> {
                            com.hoang.wildcard.event.CardRain.schedule(ctx.getSource().getServer(), true);
                            ctx.getSource().sendSuccess(() -> Component.literal("Mưa Thẻ bắt đầu!"), true);
                            return 1;
                        })))
                .then(Commands.literal("now").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    WData d = WData.get(p);
                    if (!d.choosing) RoundManager.startChoice(p, d);
                    return 1;
                }))
                .then(Commands.literal("timer").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("seconds", IntegerArgumentType.integer(1)).executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            WData.get(p).timer = IntegerArgumentType.getInteger(ctx, "seconds") * 20;
                            return 1;
                        })))
                .then(Commands.literal("give").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Cards.ALL.keySet(), b))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    Card c = Cards.get(StringArgumentType.getString(ctx, "id"));
                                    if (c == null) {
                                        ctx.getSource().sendFailure(Component.literal("Không có thẻ này"));
                                        return 0;
                                    }
                                    WData d = WData.get(p);
                                    if (!d.cards.contains(c.id)) RoundManager.grant(p, d, c);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Đã nhận ").append(c.buffName()).append(" / ").append(c.debuffName()), false);
                                    return 1;
                                })))
                .then(Commands.literal("remove").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Cards.ALL.keySet(), b))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    WData d = WData.get(p);
                                    boolean ok = d.cards.remove(StringArgumentType.getString(ctx, "id"));
                                    RoundManager.sync(p);
                                    d.save(p);
                                    return ok ? 1 : 0;
                                })))
                .then(Commands.literal("clear").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    WData d = WData.get(p);
                    d.reset();
                    RoundManager.sync(p);
                    d.save(p);
                    ctx.getSource().sendSuccess(() -> Component.literal("Đã xóa toàn bộ wildcard"), false);
                    return 1;
                })));
    }

    private WildcardCommand() {}
}
