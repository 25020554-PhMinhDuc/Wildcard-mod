package com.hoang.wildcard;

import com.hoang.wildcard.client.ClientState;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.*;

import static com.hoang.wildcard.Rarity.*;

/** Registry of all 100 cards. Texts live in assets/wildcard/lang/*.json. */
public final class Cards {
    public static final Map<String, Card> ALL = new LinkedHashMap<>();

    private static void add(String id, Rarity r, Item buff, Item debuff, String... tags) {
        ALL.put(id, new Card(id, r, buff, debuff, Set.of(tags)));
    }

    static {
        // ---------------- Phổ biến ----------------
        add("c01", COMMON, Items.RABBIT_FOOT, Items.NOTE_BLOCK, "jump");
        add("c02", COMMON, Items.BREAD, Items.FERMENTED_SPIDER_EYE, "hunger");
        add("c03", COMMON, Items.STONE_PICKAXE, Items.STICK);
        add("c04", COMMON, Items.ENDER_EYE, Items.SUNFLOWER);
        add("c05", COMMON, Items.HOPPER, Items.EXPERIENCE_BOTTLE, "magnet");
        add("c06", COMMON, Items.CAMPFIRE, Items.ICE);
        add("c07", COMMON, Items.EGG, Items.FEATHER);
        add("c08", COMMON, Items.FISHING_ROD, Items.COD);
        add("c09", COMMON, Items.LEATHER_CHESTPLATE, Items.ANVIL);
        add("c10", COMMON, Items.COOKED_BEEF, Items.BEEF);
        add("c11", COMMON, Items.STONE_AXE, Items.OAK_LOG);
        add("c12", COMMON, Items.LEATHER_BOOTS, Items.PAPER);
        add("c13", COMMON, Items.ARROW, Items.BOW);
        add("c14", COMMON, Items.RED_BED, Items.ZOMBIE_HEAD);
        add("c15", COMMON, Items.TROPICAL_FISH, Items.IRON_INGOT, "swim");
        add("c16", COMMON, Items.EXPERIENCE_BOTTLE, Items.BOOK);
        add("c17", COMMON, Items.TORCH, Items.BLACK_CANDLE);
        add("c18", COMMON, Items.WHEAT, Items.WHEAT_SEEDS);
        add("c19", COMMON, Items.HAY_BLOCK, Items.CHAINMAIL_BOOTS);
        add("c20", COMMON, Items.EMERALD, Items.IRON_BLOCK, "trade");
        // ---------------- Không phổ biến ----------------
        add("u01", UNCOMMON, Items.DIAMOND_ORE, Items.GLOWSTONE_DUST);
        add("u02", UNCOMMON, Items.CACTUS, Items.SPECTRAL_ARROW);
        add("u03", UNCOMMON, Items.VINE, Items.LADDER, "climb");
        add("u04", UNCOMMON, Items.FEATHER, Items.POTION, "dash");
        add("u05", UNCOMMON, Items.REDSTONE, Items.BONE, "maxhp");
        add("u06", UNCOMMON, Items.FIREWORK_ROCKET, Items.ROTTEN_FLESH);
        add("u07", UNCOMMON, Items.BREWING_STAND, Items.SPLASH_POTION, "potion");
        add("u08", UNCOMMON, Items.IRON_SHOVEL, Items.SAND);
        add("u09", UNCOMMON, Items.COD, Items.PHANTOM_MEMBRANE);
        add("u10", UNCOMMON, Items.SUGAR, Items.COOKED_PORKCHOP, "speed");
        add("u11", UNCOMMON, Items.BOW, Items.STRING, "bow");
        add("u12", UNCOMMON, Items.SNOWBALL, Items.POWDER_SNOW_BUCKET);
        add("u13", UNCOMMON, Items.TNT, Items.CREEPER_HEAD);
        add("u14", UNCOMMON, Items.COMPASS, Items.MAP);
        add("u15", UNCOMMON, Items.PUFFERFISH, Items.DEAD_BUSH, "swim");
        add("u16", UNCOMMON, Items.IRON_AXE, Items.WOODEN_AXE);
        add("u17", UNCOMMON, Items.OAK_SAPLING, Items.HANGING_ROOTS);
        add("u18", UNCOMMON, Items.EMERALD, Items.GOLD_NUGGET, "trade");
        add("u19", UNCOMMON, Items.RABBIT_FOOT, Items.SLIME_BALL, "jump");
        add("u20", UNCOMMON, Items.ENDER_CHEST, Items.ENDERMITE_SPAWN_EGG);
        // ---------------- Hiếm ----------------
        add("r01", RARE, Items.IRON_GOLEM_SPAWN_EGG, Items.SCAFFOLDING, "size", "maxhp", "reach");
        add("r02", RARE, Items.TIPPED_ARROW, Items.TNT, "bow");
        add("r03", RARE, Items.DIRT, Items.SAND);
        add("r04", RARE, Items.TOTEM_OF_UNDYING, Items.WOODEN_SWORD, "death");
        add("r05", RARE, Items.SPYGLASS, Items.GLOWSTONE);
        add("r06", RARE, Items.ENDER_PEARL, Items.IRON_BOOTS, "magnet", "jump");
        add("r07", RARE, Items.LIGHTNING_ROD, Items.LIGHTNING_ROD);
        add("r08", RARE, Items.FEATHER, Items.SLIME_BLOCK, "fall");
        add("r09", RARE, Items.BLACK_DYE, Items.GLOW_INK_SAC);
        add("r10", RARE, Items.IRON_SWORD, Items.FURNACE);
        add("r11", RARE, Items.BONE, Items.MUTTON);
        add("r12", RARE, Items.ANVIL, Items.CHIPPED_ANVIL);
        add("r13", RARE, Items.LILY_PAD, Items.WATER_BUCKET, "water");
        add("r14", RARE, Items.SLIME_BALL, Items.SPIDER_EYE);
        add("r15", RARE, Items.IRON_HELMET, Items.CHAINMAIL_HELMET);
        add("r16", RARE, Items.FIREWORK_ROCKET, Items.CREEPER_HEAD);
        add("r17", RARE, Items.GOLDEN_SWORD, Items.IRON_BARS);
        add("r18", RARE, Items.GLOW_BERRIES, Items.ROTTEN_FLESH, "hunger");
        add("r19", RARE, Items.LINGERING_POTION, Items.SPLASH_POTION, "potion");
        add("r20", RARE, Items.GOLDEN_BOOTS, Items.GLASS_PANE);
        // ---------------- Sử thi ----------------
        add("e01", EPIC, Items.FIRE_CHARGE, Items.FLINT_AND_STEEL);
        add("e02", EPIC, Items.FEATHER, Items.ELYTRA, "jump");
        add("e03", EPIC, Items.IRON_BLOCK, Items.HONEYCOMB);
        add("e04", EPIC, Items.CHEST, Items.COMPASS, "death", "respawn");
        add("e05", EPIC, Items.ENDER_PEARL, Items.CHORUS_FRUIT);
        add("e06", EPIC, Items.DIAMOND_SWORD, Items.SPYGLASS, "camera");
        add("e07", EPIC, Items.DIAMOND, Items.ANVIL);
        add("e08", EPIC, Items.CHICKEN_SPAWN_EGG, Items.CHICKEN);
        add("e09", EPIC, Items.SOUL_LANTERN, Items.VEX_ARMOR_TRIM_SMITHING_TEMPLATE);
        add("e10", EPIC, Items.DIAMOND_PICKAXE, Items.SCULK_SHRIEKER);
        add("e11", EPIC, Items.PHANTOM_MEMBRANE, Items.PISTON);
        add("e12", EPIC, Items.LAVA_BUCKET, Items.GRASS_BLOCK, "fire");
        add("e13", EPIC, Items.COBWEB, Items.SPIDER_EYE, "climb");
        add("e14", EPIC, Items.OAK_BOAT, Items.KELP);
        add("e15", EPIC, Items.AMETHYST_SHARD, Items.ZOMBIE_SPAWN_EGG);
        add("e16", EPIC, Items.GOLDEN_APPLE, Items.REDSTONE_BLOCK);
        add("e17", EPIC, Items.FISHING_ROD, Items.LEATHER_BOOTS);
        add("e18", EPIC, Items.SHIELD, Items.IRON_CHESTPLATE);
        add("e19", EPIC, Items.TRIDENT, Items.WATER_BUCKET, "fire");
        add("e20", EPIC, Items.BLAST_FURNACE, Items.CHEST);
        // ---------------- Huyền thoại ----------------
        add("l01", LEGENDARY, Items.LIGHTNING_ROD, Items.IRON_CHESTPLATE);
        add("l02", LEGENDARY, Items.DRAGON_HEAD, Items.LADDER, "fly");
        add("l03", LEGENDARY, Items.GOLD_INGOT, Items.GOLDEN_CARROT);
        add("l04", LEGENDARY, Items.TOTEM_OF_UNDYING, Items.WITHER_ROSE, "death", "maxhp");
        add("l05", LEGENDARY, Items.NETHERITE_PICKAXE, Items.GRAVEL);
        add("l06", LEGENDARY, Items.ZOMBIE_HEAD, Items.SKELETON_SKULL);
        add("l07", LEGENDARY, Items.IRON_BOOTS, Items.GOLD_NUGGET);
        add("l08", LEGENDARY, Items.BLAZE_ROD, Items.SPAWNER);
        add("l09", LEGENDARY, Items.CLOCK, Items.REPEATER);
        add("l10", LEGENDARY, Items.NETHERITE_PICKAXE, Items.SILVERFISH_SPAWN_EGG);
        add("l11", LEGENDARY, Items.SUGAR, Items.BLUE_ICE, "speed");
        add("l12", LEGENDARY, Items.END_ROD, Items.GLASS, "reach");
        add("l13", LEGENDARY, Items.BLAZE_POWDER, Items.CHARCOAL, "death");
        add("l14", LEGENDARY, Items.BUNDLE, Items.CHEST, "inventory");
        add("l15", LEGENDARY, Items.SADDLE, Items.RED_BED, "respawn");
        add("l16", LEGENDARY, Items.CROSSBOW, Items.ARROW, "bow");
        add("l17", LEGENDARY, Items.TNT, Items.CREEPER_HEAD);
        add("l18", LEGENDARY, Items.EMERALD_BLOCK, Items.CROSSBOW, "trade");
        add("l19", LEGENDARY, Items.RABBIT_FOOT, Items.ANVIL);
        add("l20", LEGENDARY, Items.CLOCK, Items.PACKED_ICE);
    }

    public static Card get(String id) {
        return ALL.get(id);
    }

    /** Works on both sides: server reads saved data, client reads synced state of the local player. */
    public static boolean has(Player p, String id) {
        if (p == null) return false;
        if (p.level().isClientSide) return ClientState.has(id);
        return WData.get(p).cards.contains(id);
    }

    private Cards() {}
}
