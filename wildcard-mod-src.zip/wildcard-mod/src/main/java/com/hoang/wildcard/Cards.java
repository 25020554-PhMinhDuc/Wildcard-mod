package com.hoang.wildcard;

import com.hoang.wildcard.client.ClientState;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.*;

import static com.hoang.wildcard.Rarity.*;

/** Registry of all cards (40 / 60 / 25 / 15 / 5 / 5). Texts live in assets/wildcard/lang/*.json. */
public final class Cards {
    public static final Map<String, Card> ALL = new LinkedHashMap<>();

    private static void add(String id, Rarity r, Item buff, Item debuff, String... tags) {
        ALL.put(id, new Card(id, r, buff, debuff, Set.of(tags)));
    }

    private static void sk(String id, int... cooldowns) {
        Card c = ALL.get(id);
        for (int cd : cooldowns) c.skills.add(cd);
    }

    static {
        // ---------------- Phổ biến ----------------
        add("c01", COMMON, Items.RABBIT_FOOT, Items.NOTE_BLOCK, "jump");
        add("c02", COMMON, Items.BREAD, Items.FERMENTED_SPIDER_EYE, "hunger");
        add("c03", COMMON, Items.STONE_PICKAXE, Items.STICK);
        add("c04", COMMON, Items.ENDER_EYE, Items.SUNFLOWER);
        add("c05", COMMON, Items.HOPPER, Items.EXPERIENCE_BOTTLE, "magnet");
        add("c06", COMMON, Items.CAMPFIRE, Items.ICE, "campfire");
        add("c07", COMMON, Items.EGG, Items.FEATHER);
        add("c08", COMMON, Items.FISHING_ROD, Items.COD);
        add("c09", COMMON, Items.LEATHER_CHESTPLATE, Items.ANVIL);
        add("c10", COMMON, Items.COOKED_BEEF, Items.BEEF);
        add("c11", COMMON, Items.STONE_AXE, Items.OAK_LOG);
        add("c12", COMMON, Items.LEATHER_BOOTS, Items.PAPER);
        add("c13", COMMON, Items.ARROW, Items.BOW);
        add("c14", COMMON, Items.RED_BED, Items.ZOMBIE_HEAD, "sleep");
        add("c15", COMMON, Items.TROPICAL_FISH, Items.IRON_INGOT, "swim");
        add("c16", COMMON, Items.EXPERIENCE_BOTTLE, Items.BOOK);
        add("c17", COMMON, Items.TORCH, Items.BLACK_CANDLE);
        add("c18", COMMON, Items.WHEAT, Items.WHEAT_SEEDS);
        add("c19", COMMON, Items.HAY_BLOCK, Items.CHAINMAIL_BOOTS);
        add("c20", COMMON, Items.EMERALD, Items.IRON_BLOCK, "trade");
        add("c21", COMMON, Items.SCUTE, Items.BONE_MEAL);
        add("c22", COMMON, Items.LEATHER_BOOTS, Items.ROTTEN_FLESH);
        add("c23", COMMON, Items.BREAD, Items.COD);
        add("c24", COMMON, Items.TURTLE_HELMET, Items.WATER_BUCKET);
        add("c25", COMMON, Items.COAL, Items.COAL_ORE);
        add("c26", COMMON, Items.FEATHER, Items.LEATHER_LEGGINGS, "fall");
        add("c27", COMMON, Items.TORCH, Items.FLINT_AND_STEEL, "fire");
        add("c28", COMMON, Items.HOPPER, Items.LEATHER, "magnet");
        add("c29", COMMON, Items.APPLE, Items.SLIME_BALL, "maxhp");
        add("c30", COMMON, Items.WHITE_WOOL, Items.SAND, "cold");
        add("c31", COMMON, Items.PORKCHOP, Items.CARROT, "meat");
        add("c32", COMMON, Items.PRISMARINE_SHARD, Items.KELP, "swim");
        add("c33", COMMON, Items.IRON_NUGGET, Items.IRON_PICKAXE);
        add("c34", COMMON, Items.WHITE_BED, Items.NOTE_BLOCK, "sleep");
        add("c35", COMMON, Items.STONE_SWORD, Items.FERMENTED_SPIDER_EYE);
        add("c36", COMMON, Items.SNIFFER_EGG, Items.POPPY);
        add("c37", COMMON, Items.TORCH, Items.SOUL_TORCH);
        add("c38", COMMON, Items.MAGMA_CREAM, Items.BLAZE_POWDER, "burn");
        add("c39", COMMON, Items.ARROW, Items.BOW);
        add("c40", COMMON, Items.MAP, Items.COMPASS);
        // ---------------- Không phổ biến ----------------
        add("u01", UNCOMMON, Items.DIAMOND_ORE, Items.GLOWSTONE_DUST);
        add("u02", UNCOMMON, Items.CACTUS, Items.SPECTRAL_ARROW);
        add("u03", UNCOMMON, Items.VINE, Items.LADDER, "climb");
        add("u04", UNCOMMON, Items.FEATHER, Items.POTION, "dash");
        add("u05", UNCOMMON, Items.REDSTONE, Items.BONE, "maxhp");
        add("u06", UNCOMMON, Items.FIREWORK_ROCKET, Items.ROTTEN_FLESH);
        add("u07", UNCOMMON, Items.BREWING_STAND, Items.SPLASH_POTION, "potion");
        add("u08", UNCOMMON, Items.IRON_SHOVEL, Items.SAND);
        add("u09", UNCOMMON, Items.COD, Items.PHANTOM_MEMBRANE);
        add("u10", UNCOMMON, Items.SUGAR, Items.COOKED_PORKCHOP, "speed");
        add("u11", UNCOMMON, Items.BOW, Items.STRING, "bow");
        add("u12", UNCOMMON, Items.SNOWBALL, Items.POWDER_SNOW_BUCKET);
        add("u13", UNCOMMON, Items.TNT, Items.CREEPER_HEAD);
        add("u14", UNCOMMON, Items.COMPASS, Items.MAP);
        add("u15", UNCOMMON, Items.PUFFERFISH, Items.DEAD_BUSH, "swim");
        add("u16", UNCOMMON, Items.IRON_AXE, Items.WOODEN_AXE, "axe");
        add("u17", UNCOMMON, Items.OAK_SAPLING, Items.HANGING_ROOTS);
        add("u18", UNCOMMON, Items.EMERALD, Items.GOLD_NUGGET, "trade");
        add("u19", UNCOMMON, Items.RABBIT_FOOT, Items.SLIME_BALL, "jump", "dash");
        add("u20", UNCOMMON, Items.ENDER_CHEST, Items.ENDERMITE_SPAWN_EGG);
        add("u21", UNCOMMON, Items.IRON_SWORD, Items.ANVIL);
        add("u22", UNCOMMON, Items.IRON_CHESTPLATE, Items.CHAINMAIL_LEGGINGS);
        add("u23", UNCOMMON, Items.HEART_OF_THE_SEA, Items.DRIED_KELP, "swim");
        add("u24", UNCOMMON, Items.BLAZE_POWDER, Items.FLINT_AND_STEEL, "burn");
        add("u25", UNCOMMON, Items.PHANTOM_MEMBRANE, Items.SUNFLOWER);
        add("u26", UNCOMMON, Items.GRAY_DYE, Items.OAK_LEAVES);
        add("u27", UNCOMMON, Items.MILK_BUCKET, Items.ROTTEN_FLESH);
        add("u28", UNCOMMON, Items.SLIME_BALL, Items.NOTE_BLOCK, "jump");
        add("u29", UNCOMMON, Items.SCAFFOLDING, Items.WOODEN_SWORD, "reach");
        add("u30", UNCOMMON, Items.BREWING_STAND, Items.FERMENTED_SPIDER_EYE, "potion");
        add("u31", UNCOMMON, Items.DIAMOND, Items.DEEPSLATE, "deep");
        add("u32", UNCOMMON, Items.HONEY_BOTTLE, Items.BEE_NEST);
        add("u33", UNCOMMON, Items.IRON_BOOTS, Items.POISONOUS_POTATO);
        add("u34", UNCOMMON, Items.GOLDEN_CARROT, Items.BOWL);
        add("u35", UNCOMMON, Items.LANTERN, Items.COBBLED_DEEPSLATE, "deep");
        add("u36", UNCOMMON, Items.RABBIT_HIDE, Items.COBWEB);
        add("u37", UNCOMMON, Items.FISHING_ROD, Items.STRING);
        add("u38", UNCOMMON, Items.BONE_MEAL, Items.BROWN_DYE);
        add("u39", UNCOMMON, Items.CAMPFIRE, Items.CHARCOAL, "campfire");
        add("u40", UNCOMMON, Items.BOW, Items.TARGET);
        add("u41", UNCOMMON, Items.SADDLE, Items.LEAD);
        add("u42", UNCOMMON, Items.SALMON, Items.WET_SPONGE, "swim");
        add("u43", UNCOMMON, Items.ZOMBIE_HEAD, Items.SPIDER_EYE, "undead");
        add("u44", UNCOMMON, Items.ENDER_PEARL, Items.ENDERMAN_SPAWN_EGG);
        add("u45", UNCOMMON, Items.GLISTERING_MELON_SLICE, Items.SPIDER_EYE);
        add("u46", UNCOMMON, Items.ENDER_EYE, Items.SUNFLOWER);
        add("u47", UNCOMMON, Items.EMERALD, Items.GOLD_NUGGET, "trade");
        add("u48", UNCOMMON, Items.DIAMOND_CHESTPLATE, Items.IRON_LEGGINGS);
        add("u49", UNCOMMON, Items.IRON_AXE, Items.STONE_AXE, "axe");
        add("u50", UNCOMMON, Items.IRON_SWORD, Items.STRING);
        add("u51", UNCOMMON, Items.GOLDEN_SWORD, Items.WOODEN_SWORD);
        add("u52", UNCOMMON, Items.SPECTRAL_ARROW, Items.ARROW);
        add("u53", UNCOMMON, Items.STONE_PICKAXE, Items.OAK_LOG);
        add("u54", UNCOMMON, Items.GOLDEN_HELMET, Items.WHITE_BANNER);
        add("u55", UNCOMMON, Items.EXPERIENCE_BOTTLE, Items.ENCHANTED_BOOK);
        add("u56", UNCOMMON, Items.WOLF_SPAWN_EGG, Items.BONE);
        add("u57", UNCOMMON, Items.COOKED_BEEF, Items.ROTTEN_FLESH, "hunger");
        add("u58", UNCOMMON, Items.SHIELD, Items.ARROW);
        add("u59", UNCOMMON, Items.MAGMA_BLOCK, Items.NETHERRACK);
        add("u60", UNCOMMON, Items.JUKEBOX, Items.GUNPOWDER);
        // ---------------- Hiếm ----------------
        add("r01", RARE, Items.IRON_GOLEM_SPAWN_EGG, Items.SCAFFOLDING, "size", "maxhp", "reach");
        add("r02", RARE, Items.TIPPED_ARROW, Items.TNT, "bow");
        add("r03", RARE, Items.DIRT, Items.SAND);
        add("r04", RARE, Items.TOTEM_OF_UNDYING, Items.WOODEN_SWORD, "death");
        add("r05", RARE, Items.SPYGLASS, Items.GLOWSTONE);
        add("r06", RARE, Items.ENDER_PEARL, Items.IRON_BOOTS, "magnet", "jump");
        add("r07", RARE, Items.LIGHTNING_ROD, Items.LIGHTNING_ROD);
        add("r08", RARE, Items.FEATHER, Items.SLIME_BLOCK, "fall");
        add("r09", RARE, Items.BLACK_DYE, Items.GLOW_INK_SAC);
        add("r10", RARE, Items.IRON_SWORD, Items.FURNACE);
        add("r11", RARE, Items.BONE, Items.MUTTON);
        add("r12", RARE, Items.ANVIL, Items.CHIPPED_ANVIL);
        add("r13", RARE, Items.LILY_PAD, Items.WATER_BUCKET, "water");
        add("r14", RARE, Items.SLIME_BALL, Items.SPIDER_EYE);
        add("r15", RARE, Items.IRON_HELMET, Items.CHAINMAIL_HELMET);
        add("r16", RARE, Items.FIREWORK_ROCKET, Items.CREEPER_HEAD);
        add("r17", RARE, Items.GOLDEN_SWORD, Items.IRON_BARS);
        add("r18", RARE, Items.GLOW_BERRIES, Items.ROTTEN_FLESH, "hunger");
        add("r19", RARE, Items.LINGERING_POTION, Items.SPLASH_POTION, "potion");
        add("r20", RARE, Items.GOLDEN_BOOTS, Items.GLASS_PANE);
        add("r21", RARE, Items.BEACON, Items.GLOW_INK_SAC, "undead");
        add("r22", RARE, Items.ECHO_SHARD, Items.TORCH);
        add("r23", RARE, Items.BLUE_ICE, Items.MAGMA_BLOCK, "cold");
        add("r24", RARE, Items.EMERALD_BLOCK, Items.PAPER, "trade");
        add("r25", RARE, Items.NETHERITE_SWORD, Items.LEATHER);
        // ---------------- Sử thi ----------------
        add("e01", EPIC, Items.FIRE_CHARGE, Items.FLINT_AND_STEEL);
        add("e02", EPIC, Items.FEATHER, Items.ELYTRA, "jump");
        add("e03", EPIC, Items.IRON_BLOCK, Items.HONEYCOMB);
        add("e04", EPIC, Items.CHEST, Items.COMPASS, "death", "respawn");
        add("e05", EPIC, Items.ENDER_PEARL, Items.CHORUS_FRUIT);
        add("e06", EPIC, Items.DIAMOND_SWORD, Items.SPYGLASS, "camera");
        add("e07", EPIC, Items.DIAMOND, Items.ANVIL);
        add("e08", EPIC, Items.CHICKEN_SPAWN_EGG, Items.CHICKEN);
        add("e10", EPIC, Items.DIAMOND_PICKAXE, Items.SCULK_SHRIEKER);
        add("e11", EPIC, Items.PHANTOM_MEMBRANE, Items.PISTON);
        add("e12", EPIC, Items.LAVA_BUCKET, Items.GRASS_BLOCK, "fire");
        add("e13", EPIC, Items.COBWEB, Items.SPIDER_EYE, "climb");
        add("e16", EPIC, Items.GOLDEN_APPLE, Items.REDSTONE_BLOCK);
        add("e18", EPIC, Items.SHIELD, Items.IRON_CHESTPLATE);
        add("e20", EPIC, Items.BLAST_FURNACE, Items.CHEST);
        // ---------------- Huyền thoại ----------------
        add("l01", LEGENDARY, Items.LIGHTNING_ROD, Items.IRON_CHESTPLATE);
        add("l02", LEGENDARY, Items.DRAGON_HEAD, Items.LADDER, "fly");
        add("l04", LEGENDARY, Items.TOTEM_OF_UNDYING, Items.WITHER_ROSE, "death", "maxhp");
        add("l05", LEGENDARY, Items.NETHERITE_PICKAXE, Items.GRAVEL);
        add("l20", LEGENDARY, Items.CLOCK, Items.PACKED_ICE);
        // ---------------- Thần thoại ----------------
        // Mỗi người chỉ giữ 1 thẻ Thần thoại; đổi sang thẻ khác mất 1 tim vĩnh viễn.
        add("m01", MYTHIC, Items.BAT_SPAWN_EGG, Items.SUNFLOWER, "mythic");
        add("m02", MYTHIC, Items.DRAGON_HEAD, Items.SHIELD, "mythic");
        add("m03", MYTHIC, Items.CLOCK, Items.SKELETON_SKULL, "mythic");
        add("m04", MYTHIC, Items.BRICKS, Items.WOODEN_SWORD, "mythic");
        add("m05", MYTHIC, Items.END_CRYSTAL, Items.BLACK_STAINED_GLASS, "mythic");

        // ---------------- Kỹ năng (hồi chiêu, giây) ----------------
        sk("r01", 30);
        sk("r02", 40);
        sk("r03", 30);
        sk("r04", 90);
        sk("r05", 45);
        sk("r06", 30);
        sk("r07", 45);
        sk("r08", 25);
        sk("r09", 60);
        sk("r10", 40);
        sk("r11", 90);
        sk("r12", 120);
        sk("r13", 20);
        sk("r14", 3);
        sk("r15", 25);
        sk("r16", 20);
        sk("r17", 30);
        sk("r18", 60);
        sk("r19", 30);
        sk("r20", 20);
        sk("r21", 45);
        sk("r22", 60);
        sk("r23", 20);
        sk("r24", 60);
        sk("r25", 45);
        sk("e01", 8, 40);
        sk("e02", 15, 30);
        sk("e03", 30, 60);
        sk("e04", 300, 30);
        sk("e05", 12, 30);
        sk("e06", 10, 30);
        sk("e07", 60, 60);
        sk("e08", 60, 30);
        sk("e10", 60, 40);
        sk("e11", 10, 20);
        sk("e12", 40, 60);
        sk("e13", 5, 8);
        sk("e16", 60, 90);
        sk("e18", 45, 60);
        sk("e20", 120, 15);
        sk("l01", 15, 90, 60);
        sk("l02", 90, 20, 30);
        sk("l04", 120, 60, 180);
        sk("l05", 30, 45, 60);
        sk("l20", 180, 60, 60);
        sk("m01", 60, 30, 25, 60, 180);
        sk("m02", 12, 20, 40, 90, 150);
        sk("m03", 45, 40, 30, 300, 240);
        sk("m04", 20, 20, 90, 120, 120);
        sk("m05", 10, 60, 45, 15, 240);
    }

    public static Card get(String id) {
        return ALL.get(id);
    }

    /** Works on both sides: server reads saved data, client reads synced state of the local player. */
    public static boolean has(Player p, String id) {
        if (p == null) return false;
        if (p.level().isClientSide) return ClientState.has(id);
        return WData.get(p).cards.contains(id);
    }

    private Cards() {}
}
