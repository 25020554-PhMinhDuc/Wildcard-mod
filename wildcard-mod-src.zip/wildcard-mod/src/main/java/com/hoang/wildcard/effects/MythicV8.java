package com.hoang.wildcard.effects;

import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.Fx;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerXpEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static com.hoang.wildcard.Cards.has;
import static com.hoang.wildcard.effects.Effects.effect;
import static com.hoang.wildcard.effects.Effects.keep;
import static com.hoang.wildcard.effects.Skills.*;

/**
 * v8.0.0: reworked Mythic cards M1 Huyết Tộc Cổ Đại, M2 Hiệp Sĩ Rồng, M3 Thần Thời Gian and M5 Chúa Tể Hư Không.
 * Two skills each (see {@link #skill}); data-driven stats are in GenExtra, the rest is here.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class MythicV8 {

    private static final Set<String> IRON_EXTRA = Set.of("bucket", "water_bucket", "lava_bucket", "milk_bucket", "powder_snow_bucket",
            "cod_bucket", "salmon_bucket", "pufferfish_bucket", "tropical_fish_bucket", "axolotl_bucket", "tadpole_bucket",
            "shears", "flint_and_steel", "chain", "anvil", "chipped_anvil", "damaged_anvil", "hopper", "minecart", "chest_minecart",
            "furnace_minecart", "hopper_minecart", "tnt_minecart", "rail", "powered_rail", "detector_rail", "activator_rail",
            "cauldron", "compass", "recovery_compass", "crossbow", "shield", "heavy_weighted_pressure_plate", "tripwire_hook",
            "lantern", "soul_lantern", "blast_furnace", "stonecutter", "smithing_table", "piston", "sticky_piston");

    /** M1: item made of iron (armor, weapons, tools, buckets, bars, rails...). */
    public static boolean ironItem(ItemStack s) {
        if (s.isEmpty()) return false;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (k == null) return false;
        String path = k.getPath();
        if (path.contains("_ore") || path.startsWith("raw_iron")) return false;
        return path.contains("iron") || path.startsWith("chainmail") || IRON_EXTRA.contains(path);
    }

    private static boolean carriesIron(Player p) {
        for (ItemStack s : p.getInventory().items) if (ironItem(s)) return true;
        for (ItemStack s : p.getInventory().armor) if (ironItem(s)) return true;
        for (ItemStack s : p.getInventory().offhand) if (ironItem(s)) return true;
        return false;
    }

    private static void burn(ServerPlayer p, float extra) {
        if (p.isCreative()) return;
        if (p.getRemainingFireTicks() < 40) p.setSecondsOnFire(3);
        p.invulnerableTime = 0;
        p.hurt(p.damageSources().onFire(), extra);
    }

    // ================================================================== ticking

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        ServerLevel level = p.serverLevel();
        PlayerState st = PlayerState.get(p);
        long now = level.getGameTime();
        // M3: vị trí 10 giây trước (mỗi 5 tick một điểm)
        if (p.tickCount % 5 == 0) {
            st.history10.addLast(p.position());
            while (st.history10.size() > 40) st.history10.removeFirst();
        }
        // M2: sợ nước, không bơi được (chìm xuống)
        if (has(p, "m02") && p.isInWater() && !p.isCreative()) {
            p.setSwimming(false);
            Vec3 v = p.getDeltaMovement();
            if (v.y > -0.15) p.setDeltaMovement(v.x * 0.6, Math.min(v.y, 0) - 0.04, v.z * 0.6);
        }
        // M5: rơi xuống Void không chết, 10 giây sau về điểm hồi sinh
        if (has(p, "m05") && p.getY() < level.getMinBuildHeight() - 8) {
            if (st.time("m05_void") == 0) {
                st.time("m05_void", now + 200);
                p.displayClientMessage(Component.translatable("msg.wildcard.m05.void").withStyle(ChatFormatting.DARK_PURPLE), true);
            }
            p.setDeltaMovement(Vec3.ZERO);
            p.fallDistance = 0;
            if (now >= st.time("m05_void")) {
                st.time("m05_void", 0);
                toSpawn(p);
            }
        } else if (st.time("m05_void") != 0 && p.getY() >= level.getMinBuildHeight()) {
            st.time("m05_void", 0);
        }
        if (p.tickCount % 20 != 0) return;
        everySecond(p, st, level, now);
    }

    private static void everySecond(ServerPlayer p, PlayerState st, ServerLevel level, long now) {
        BlockPos bp = p.blockPosition();
        boolean outdoorsDay = level.dimension() == Level.OVERWORLD && level.isDay() && !level.isRaining() && level.canSeeSky(bp.above());
        // ---- M1 Huyết Tộc Cổ Đại
        if (has(p, "m01")) {
            boolean turtle = p.getItemBySlot(EquipmentSlot.HEAD).is(Items.TURTLE_HELMET);
            if (outdoorsDay && !turtle && !p.isInWaterRainOrBubble()) { // nắng: cháy 2 tim/giây + Yếu Ớt III
                burn(p, 3f);
                effect(p, MobEffects.WEAKNESS, 40, 2);
                level.sendParticles(ParticleTypes.SMOKE, p.getX(), p.getY() + 1.8, p.getZ(), 6, 0.2, 0.1, 0.2, 0.01);
            }
            if (carriesIron(p)) { // mang đồ sắt: cháy 2 máu/giây
                burn(p, 1f);
                p.displayClientMessage(Component.translatable("msg.wildcard.m01.iron").withStyle(ChatFormatting.RED), true);
            }
        }
        // ---- M2 Hiệp Sĩ Rồng
        if (has(p, "m02")) {
            if (p.isOnFire() || p.isInLava()) p.heal(4f); // bốc cháy: hồi 2 tim/giây
            if (p.isInWaterOrBubble() && !p.isCreative()) { // chạm nước: mất 5 tim/giây
                p.invulnerableTime = 0;
                p.hurt(p.damageSources().drown(), 10f);
                level.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 8, 0.3, 0.4, 0.3, 0.02);
            }
        }
        // ---- M3 Thần Thời Gian
        if (has(p, "m03")) {
            keep(p, MobEffects.DIG_SPEED, 1); // Haste II
            p.removeEffect(MobEffects.HUNGER);
            if (p.getFoodData().getFoodLevel() < 20) p.getFoodData().setFoodLevel(20); // không cảm thấy đói
        }
        // ---- M5 Chúa Tể Hư Không
        if (has(p, "m05") && outdoorsDay) {
            effect(p, MobEffects.BLINDNESS, 60, 0);
            effect(p, MobEffects.MOVEMENT_SLOWDOWN, 40, 1);
        }
    }

    private static void toSpawn(ServerPlayer p) {
        ServerLevel dim = p.server.getLevel(p.getRespawnDimension());
        BlockPos pos = p.getRespawnPosition();
        if (dim == null || pos == null) {
            dim = p.server.overworld();
            pos = dim.getSharedSpawnPos();
        }
        Vec3 to = Player.findRespawnPositionAndUseSpawnBlock(dim, pos, p.getRespawnAngle(), true, true)
                .orElse(Vec3.atBottomCenterOf(dim.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, pos)));
        p.teleportTo(dim, to.x, to.y, to.z, p.getYRot(), p.getXRot());
        p.fallDistance = 0;
        p.setDeltaMovement(Vec3.ZERO);
        dim.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 0.6f);
    }

    // ================================================================== damage

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttacked(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        var s = e.getSource();
        if (has(p, "m02") && s.is(DamageTypeTags.IS_FIRE)) e.setCanceled(true); // miễn nhiễm lửa và dung nham
        if (has(p, "m05") && s.is(DamageTypes.FELL_OUT_OF_WORLD)) e.setCanceled(true); // miễn nhiễm Void
    }

    /** M3: mining 30% faster. */
    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        if (has(e.getEntity(), "m03")) e.setNewSpeed(e.getNewSpeed() * 1.3f);
    }

    /** M3: every level up gives Slowness II and Weakness II for 60 seconds. */
    @SubscribeEvent
    public static void onLevel(PlayerXpEvent.LevelChange e) {
        if (e.getLevels() > 0 && e.getEntity() instanceof ServerPlayer p && has(p, "m03") && !p.isCreative()) {
            effect(p, MobEffects.MOVEMENT_SLOWDOWN, 1200, 1);
            effect(p, MobEffects.WEAKNESS, 1200, 1);
            p.displayClientMessage(Component.translatable("msg.wildcard.m03toll").withStyle(ChatFormatting.DARK_AQUA), true);
        }
    }

    /** M2: dizziness, Nausea and Slowness for 3 seconds after every skill. */
    static void dragonCost(ServerPlayer p) {
        if (p.isCreative()) return;
        p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
        Net.toPlayer(p, new Net.Fx("shake", 60));
    }

    // ================================================================== skills

    /** Returns null when the slot is not one of the v8 skills (fall back to {@link Mythic#skill}). */
    static Boolean skill(ServerPlayer p, String id, int slot) {
        ServerLevel level = p.serverLevel();
        PlayerState st = PlayerState.get(p);
        long now = level.getGameTime();
        switch (id + ":" + slot) {
            // ---------------------------------------------------------- Huyết Tộc Cổ Đại
            case "m01:1" -> { // Huyết Thực
                List<LivingEntity> list = foes(p, 20);
                if (list.isEmpty()) return noTarget(p);
                float healed = 0;
                for (LivingEntity le : list) {
                    if (Skills.trueHurt(p, le, 5f)) healed += 5f;
                    beam(p, le.getEyePosition(), ParticleTypes.DAMAGE_INDICATOR);
                    level.sendParticles(ParticleTypes.CRIMSON_SPORE, le.getX(), le.getY() + 1, le.getZ(), 12, 0.3, 0.5, 0.3, 0.02);
                }
                p.heal(Math.min(15f, healed));
                Fx.circle(level, p.position().add(0, 0.05, 0), Element.BLOOD, 4, 40, true);
                sound(p, SoundEvents.WITCH_DRINK, 0.6f);
                sound(p, SoundEvents.WITHER_AMBIENT, 1.6f);
                return true;
            }
            case "m01:0" -> { // Huyết Tộc: hóa dơi bay 15 giây
                if (p.isCreative()) return nothing(p);
                st.flightEnd = now + 300;
                p.getAbilities().mayfly = true;
                p.getAbilities().flying = true;
                p.onUpdateAbilities();
                p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 300, 0, false, false, true));
                Bat bat = EntityType.BAT.create(level);
                if (bat != null) { // hình dạng dơi trên đầu
                    bat.moveTo(p.getX(), p.getY() + 1.8, p.getZ(), p.getYRot(), 0);
                    bat.setNoAi(true);
                    bat.setInvulnerable(true);
                    bat.setSilent(true);
                    bat.getPersistentData().putUUID(Effects.OWNER_TAG, p.getUUID());
                    level.addFreshEntity(bat);
                    bat.startRiding(p, true);
                    Scheduler.later(300, bat::discard);
                }
                puff(p, ParticleTypes.SQUID_INK, 40, 0.6);
                sound(p, SoundEvents.BAT_TAKEOFF, 0.8f);
                return true;
            }
            // ---------------------------------------------------------- Hiệp Sĩ Rồng
            case "m02:0" -> { // Hơi Thở Rồng: nón lửa 12 khối, 8 sát thương, đốt 5 giây
                Vec3 look0 = p.getLookAngle();
                Vec3 mouth0 = p.getEyePosition().add(look0.scale(0.7)).subtract(0, 0.25, 0);
                com.hoang.wildcard.fx.Vfx.portal(level, mouth0, Element.FIRE, Math.atan2(look0.z, look0.x) + Math.PI / 2, 0.9, 12);
                com.hoang.wildcard.fx.Vfx.burst(level, mouth0, Element.FIRE, 1.2);
                java.util.Set<java.util.UUID> hit = new java.util.HashSet<>();
                double range = reach(12);
                for (int k = 0; k < 12; k++) {
                    final int tick = k;
                    Scheduler.later(k * 2, () -> {
                        if (!p.isAlive()) return;
                        Vec3 look = p.getLookAngle();
                        Vec3 mouth = p.getEyePosition().add(look.scale(0.7)).subtract(0, 0.25, 0);
                        com.hoang.wildcard.fx.Vfx.breath(level, mouth, look, Element.FIRE, 5);
                        com.hoang.wildcard.fx.Vfx.breath(level, mouth.add(look.scale(5)), look, Element.FIRE, 5);
                        if (tick % 2 == 0) com.hoang.wildcard.fx.Vfx.breath(level, mouth, look.add(0, 0.08, 0), Element.FIRE, 5);
                        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range),
                                x -> foe(p, x) && x.distanceToSqr(p) <= range * range)) {
                            Vec3 to = le.getBoundingBox().getCenter().subtract(p.getEyePosition());
                            if (to.normalize().dot(look) < 0.8 || !hit.add(le.getUUID())) continue;
                            Skills.trueHurt(p, le, 8f);
                            le.setSecondsOnFire(5);
                        }
                        if (tick % 3 == 0) {
                            Vec3 ground = p.position().add(look.scale(4 + tick * 0.6));
                            com.hoang.wildcard.fx.Vfx.area(level, ground.add(0, 0.02, 0), Element.FIRE, 1.8, 30);
                        }
                    });
                }
                sound(p, SoundEvents.ENDER_DRAGON_SHOOT, 0.9f);
                sound(p, SoundEvents.ENDER_DRAGON_GROWL, 1.3f);
                return true;
            }
            case "m02:2" -> { // Thánh Ca Rồng: hồi 8 tim + Hồi Phục II 15 giây
                p.heal(16f);
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 1));
                Fx.circle(level, p.position().add(0, 0.05, 0), Element.HOLY, 2.5, 40, true);
                Fx.burst(level, p.position().add(0, 1, 0), Element.FIRE, 30, 0.25);
                sound(p, SoundEvents.ENDER_DRAGON_AMBIENT, 1.4f);
                sound(p, SoundEvents.BEACON_POWER_SELECT, 1.2f);
                return true;
            }
            // ---------------------------------------------------------- Thần Thời Gian
            case "m03:0" -> { // Quay Ngược Thời Gian: về vị trí 10 giây trước, hồi 10 tim
                Vec3 back = st.history10.peekFirst();
                if (back == null) return nothing(p);
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.8, 0.4, 0.05);
                p.teleportTo(back.x, back.y, back.z);
                p.fallDistance = 0;
                p.heal(20f);
                st.history10.clear();
                st.history.clear();
                sound(p, SoundEvents.CHORUS_FRUIT_TELEPORT, 0.8f);
                return true;
            }
            case "m03:3" -> { // Made In Heaven
                ServerLevel ow = p.server.overworld();
                long t = ow.getDayTime();
                long day = t % 24000;
                ow.setDayTime(t - day + (day < 13000 ? 13000 : 24000));
                p.server.getPlayerList().broadcastSystemMessage(Component.translatable("msg.wildcard.madeinheaven", p.getDisplayName())
                        .withStyle(ChatFormatting.AQUA), false);
                freezeAll(p, 64, 300);
                level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 200, 8, 4, 8, 0.05);
                sound(p, SoundEvents.BELL_RESONATE, 0.8f);
                sound(p, SoundEvents.BEACON_DEACTIVATE, 0.5f);
                return true;
            }
            // ---------------------------------------------------------- Chúa Tể Hư Không
            case "m05:1" -> { // Xoáy Hư Không: hố đen 10 khối, 15 giây, 1 tim/giây
                Vec3 c = lookPoint(p, 16);
                double r = reach(10);
                vortex(p, c, 75, r);
                sound(p, SoundEvents.END_PORTAL_SPAWN, 0.6f);
                return true;
            }
            case "m05:0" -> { // Bước Nhảy Hư Không: dịch chuyển 10 khối về trước
                Vec3 l = p.getLookAngle();
                for (int d = 10; d >= 1; d--) {
                    Vec3 to = p.position().add(l.x * d, Math.max(0, l.y * d), l.z * d);
                    BlockPos q = BlockPos.containing(to);
                    if (level.getBlockState(q).getCollisionShape(level, q).isEmpty()
                            && level.getBlockState(q.above()).getCollisionShape(level, q.above()).isEmpty()) {
                        level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 25, 0.4, 0.6, 0.4, 0.05);
                        p.teleportTo(to.x, to.y, to.z);
                        p.fallDistance = 0;
                        level.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 25, 0.4, 0.6, 0.4, 0.3);
                        sound(p, SoundEvents.ENDERMAN_TELEPORT, 1.2f);
                        return true;
                    }
                }
                return nothing(p);
            }
            default -> {
                return null;
            }
        }
    }

    private static void vortex(ServerPlayer p, Vec3 c, int pulses, double r) {
        if (pulses <= 0 || !p.isAlive()) return;
        ServerLevel level = p.serverLevel();
        level.sendParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 40, r * 0.2, r * 0.2, r * 0.2, 0.6);
        level.sendParticles(ParticleTypes.SQUID_INK, c.x, c.y, c.z, 8, 0.3, 0.3, 0.3, 0.01);
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(c, c).inflate(r),
                x -> foe(p, x) && x.position().distanceToSqr(c) <= r * r)) {
            Vec3 pull = c.subtract(le.position());
            push(le, pull.normalize().scale(Math.min(0.6, pull.length() * 0.2)));
            if (pulses % 5 == 0) {
                le.invulnerableTime = 0;
                Skills.trueHurt(p, le, 2f);
            }
        }
        if (pulses % 10 == 0) level.playSound(null, BlockPos.containing(c), SoundEvents.PORTAL_AMBIENT, SoundSource.PLAYERS, 0.6f, 0.5f);
        Scheduler.later(4, () -> vortex(p, c, pulses - 1, r));
    }

    /** Made In Heaven: everything within {@code r} blocks (not the caster) is frozen with Nausea and Weakness. */
    private static void freezeAll(ServerPlayer p, double r, int ticks) {
        ServerLevel level = p.serverLevel();
        List<Mob> mobs = new ArrayList<>();
        List<ServerPlayer> players = new ArrayList<>();
        List<Vec3> spots = new ArrayList<>();
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                x -> x != p && x.isAlive() && x.distanceToSqr(p) <= r * r)) {
            if (le instanceof net.minecraft.world.entity.decoration.ArmorStand) continue;
            le.addEffect(new MobEffectInstance(MobEffects.CONFUSION, ticks, 0));
            le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 0));
            if (le instanceof Mob m && !m.isNoAi()) {
                m.setNoAi(true);
                m.setDeltaMovement(Vec3.ZERO);
                mobs.add(m);
            } else if (le instanceof ServerPlayer o && !o.isCreative() && !o.isSpectator()) {
                players.add(o);
                spots.add(o.position());
                o.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 9, false, false, true));
                o.addEffect(new MobEffectInstance(MobEffects.JUMP, ticks, 128, false, false, false));
                o.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, ticks, 4, false, false, true));
                Net.toPlayer(o, new Net.Fx("shake", ticks));
                o.displayClientMessage(Component.translatable("msg.wildcard.timestop.frozen", p.getDisplayName()).withStyle(ChatFormatting.AQUA), true);
            }
        }
        for (int t = 1; t < ticks; t += 2) {
            Scheduler.later(t, () -> {
                for (int i = 0; i < players.size(); i++) {
                    ServerPlayer o = players.get(i);
                    if (!o.isAlive() || o.isRemoved()) continue;
                    Vec3 at = spots.get(i);
                    o.setDeltaMovement(Vec3.ZERO);
                    o.fallDistance = 0;
                    if (o.position().distanceToSqr(at) > 0.0025) o.teleportTo(at.x, at.y, at.z);
                }
            });
        }
        Scheduler.later(ticks, () -> {
            for (Mob m : mobs) if (m.isAlive()) m.setNoAi(false);
        });
    }

    private MythicV8() {}
}
