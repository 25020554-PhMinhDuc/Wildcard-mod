package com.hoang.wildcard.client;

import com.hoang.wildcard.net.Net;
import net.minecraft.client.Minecraft;

/** Client-side packet handlers. Only loaded on the physical client. */
public final class ClientPackets {
    public static void openChoice(Net.OpenChoice msg) {
        Minecraft.getInstance().setScreen(new WildcardScreen(msg));
    }

    public static void sync(Net.Sync msg) {
        ClientState.CARDS.clear();
        ClientState.CARDS.addAll(msg.cards());
        ClientState.stolen = msg.stolen();
    }

    public static void fx(Net.Fx msg) {
        Minecraft mc = Minecraft.getInstance();
        switch (msg.type()) {
            case "close" -> {
                if (mc.screen instanceof WildcardScreen) mc.setScreen(null);
            }
            case "flash" -> ClientEvents.flashTicks = Math.max(ClientEvents.flashTicks, msg.value());
            case "sneeze" -> {
                if (mc.player != null) {
                    mc.player.setXRot(mc.player.getXRot() + 20f);
                    mc.player.setYRot(mc.player.getYRot() + (mc.player.getRandom().nextFloat() - 0.5f) * 40f);
                }
            }
            default -> {
            }
        }
    }

    private ClientPackets() {}
}
