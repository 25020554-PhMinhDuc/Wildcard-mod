package com.hoang.wildcard.client;

import com.hoang.wildcard.net.Net;
import net.minecraft.client.Minecraft;

/** Client-side packet handlers. Only loaded on the physical client. */
public final class ClientPackets {
    public static void openChoice(Net.OpenChoice msg) {
        Minecraft.getInstance().setScreen(new WildcardScreen(msg));
    }

    public static void sync(Net.Sync msg) {
        ClientState.CARDS.clear();
        ClientState.CARDS.addAll(msg.cards());
        ClientState.EQUIPPED.clear();
        ClientState.EQUIPPED.addAll(msg.equipped());
        ClientState.stolen = msg.stolen();
        ClientState.STARS.clear();
        for (String e : msg.stars()) {
            int i = e.indexOf('=');
            if (i > 0) {
                try {
                    ClientState.STARS.put(e.substring(0, i), Integer.parseInt(e.substring(i + 1)));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        for (int i = 0; i < ClientState.LOADOUT.length; i++) {
            ClientState.LOADOUT[i] = i < msg.loadout().size() ? msg.loadout().get(i) : "";
        }
    }

    public static void fx(Net.Fx msg) {
        Minecraft mc = Minecraft.getInstance();
        if (msg.type().startsWith("cd:")) { // skill cooldown "cd:<card>:<slot>"
            if (mc.level != null) {
                ClientState.COOLDOWNS.put(msg.type().substring(3), new long[]{mc.level.getGameTime() + msg.value(), Math.max(1, msg.value())});
            }
            return;
        }
        switch (msg.type()) {
            case "close" -> {
                if (mc.screen instanceof WildcardScreen) mc.setScreen(null);
            }
            case "invert" -> ClientEvents.invertTicks = Math.max(ClientEvents.invertTicks, msg.value());
            case "shake" -> ClientEvents.shakeTicks = Math.max(ClientEvents.shakeTicks, msg.value());
            case "hotbarstop" -> ClientEvents.hotbarHoldTicks = Math.max(ClientEvents.hotbarHoldTicks, msg.value());
            case "xray" -> ClientEvents.xrayTicks = Math.max(ClientEvents.xrayTicks, msg.value());
            case "flash" -> ClientEvents.flashTicks = Math.max(ClientEvents.flashTicks, msg.value());
            case "sneeze" -> {
                if (mc.player != null) {
                    mc.player.setXRot(mc.player.getXRot() + 20f);
                    mc.player.setYRot(mc.player.getYRot() + (mc.player.getRandom().nextFloat() - 0.5f) * 40f);
                }
            }
            default -> {
            }
        }
    }

    private ClientPackets() {}
}
