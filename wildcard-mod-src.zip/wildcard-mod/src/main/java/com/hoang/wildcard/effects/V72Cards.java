package com.hoang.wildcard.effects;

import com.hoang.wildcard.WildcardMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import static com.hoang.wildcard.effects.Effects.*;

/** v7.2: debuffs that replaced the old "lose food points" debuffs of hand-made cards and troll t08. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class V72Cards {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        int tc = p.tickCount;
        if (tc % 10 == 0) {
            AttributeModifier.Operation MUL = AttributeModifier.Operation.MULTIPLY_TOTAL;
            attr(p, Attributes.ATTACK_SPEED, "v72_c22", -0.15, MUL, has(p, "c22") && p.isSprinting());                          // Thở Dốc
            attr(p, Attributes.ATTACK_SPEED, "v72_u59", -0.15, MUL, has(p, "u59") && p.level().dimension() == Level.NETHER);  // Đổ Mồ Hôi
        }
        if (tc % 20 != 0) return;
        if (has(p, "u57") && p.getFoodData().getFoodLevel() < 6) effect(p, MobEffects.MOVEMENT_SLOWDOWN, 40, 0);              // Thèm Ăn
        if (has(p, "r18") && (tc / 20) % 90 == 0) effect(p, MobEffects.CONFUSION, 80, 0);                                    // Hoa Mắt
    }

    /** Lười Biếng (troll t08): mining 20% slower. */
    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        if (TrollDebuffs.has(e.getEntity(), "t08")) e.setNewSpeed(e.getNewSpeed() * 0.8f); // chạy cả 2 phía cho khớp
    }

    private V72Cards() {}
}
