package com.hoang.wildcard;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** A Wildcard card as an item (Card Rain). Shows the card's name in its rarity colour. */
public class CardItem extends Item {
    public CardItem(Properties props) {
        super(props);
    }

    @Nullable
    public static Card card(ItemStack stack) {
        return stack.hasTag() ? Cards.get(stack.getTag().getString("card")) : null;
    }

    public static ItemStack of(Card c) {
        ItemStack s = new ItemStack(ModItems.CARD.get());
        s.getOrCreateTag().putString("card", c.id);
        return s;
    }

    @Override
    public Component getName(ItemStack stack) {
        Card c = card(stack);
        if (c == null) return super.getName(stack);
        return Component.empty().append(c.rarity.displayName()).append(": ").append(c.buffName())
                .withStyle(s -> s.withColor(c.rarity.rgb()).withBold(c.rarity.ordinal() >= Rarity.EPIC.ordinal()));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        Card c = card(stack);
        return c != null && c.rarity.ordinal() >= Rarity.EPIC.ordinal();
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        Card c = card(stack);
        if (c == null) return;
        tip.add(Component.literal("+ ").append(c.buffDesc()).withStyle(ChatFormatting.GREEN));
        tip.add(Component.literal("- ").append(c.debuffDesc()).withStyle(ChatFormatting.RED));
    }
}
