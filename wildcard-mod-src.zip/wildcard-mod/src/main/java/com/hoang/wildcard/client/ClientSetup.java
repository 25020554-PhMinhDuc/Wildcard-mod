package com.hoang.wildcard.client;

import com.hoang.wildcard.WildcardMod;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = WildcardMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    public static final String CATEGORY = "key.categories.wildcard";
    /** Skill loadout keys: G H J K L. */
    public static final KeyMapping[] KEY_SKILLS = {
            new KeyMapping("key.wildcard.skill1", GLFW.GLFW_KEY_G, CATEGORY),
            new KeyMapping("key.wildcard.skill2", GLFW.GLFW_KEY_H, CATEGORY),
            new KeyMapping("key.wildcard.skill3", GLFW.GLFW_KEY_J, CATEGORY),
            new KeyMapping("key.wildcard.skill4", GLFW.GLFW_KEY_K, CATEGORY),
            new KeyMapping("key.wildcard.skill5", GLFW.GLFW_KEY_L, CATEGORY)};
    public static final KeyMapping KEY_CARDS = new KeyMapping("key.wildcard.cards", GLFW.GLFW_KEY_B, CATEGORY);
    public static final KeyMapping KEY_ENDER = new KeyMapping("key.wildcard.ender", GLFW.GLFW_KEY_N, CATEGORY);
    /** v7.1 Lời Nguyền Pharaoh: phun cát. */
    public static final KeyMapping KEY_SAND = new KeyMapping("key.wildcard.sand", GLFW.GLFW_KEY_X, CATEGORY);

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        for (KeyMapping k : KEY_SKILLS) e.register(k);
        e.register(KEY_CARDS);
        e.register(KEY_ENDER);
        e.register(KEY_SAND);
    }

    /** Short label of the key currently bound to skill slot {@code i}, e.g. "G". */
    public static String skillKeyLabel(int i) {
        String s = KEY_SKILLS[i].getTranslatedKeyMessage().getString();
        return s.length() > 3 ? s.substring(0, 3) : s;
    }

    private ClientSetup() {}
}
