package com.hoang.wildcard.client;

import com.hoang.wildcard.WildcardMod;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = WildcardMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    public static final KeyMapping KEY_MOVE = new KeyMapping("key.wildcard.move", GLFW.GLFW_KEY_V, "key.categories.wildcard");
    public static final KeyMapping KEY_SKILL = new KeyMapping("key.wildcard.skill", GLFW.GLFW_KEY_G, "key.categories.wildcard");
    public static final KeyMapping KEY_ENDER = new KeyMapping("key.wildcard.ender", GLFW.GLFW_KEY_B, "key.categories.wildcard");

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(KEY_MOVE);
        e.register(KEY_SKILL);
        e.register(KEY_ENDER);
    }

    private ClientSetup() {}
}
