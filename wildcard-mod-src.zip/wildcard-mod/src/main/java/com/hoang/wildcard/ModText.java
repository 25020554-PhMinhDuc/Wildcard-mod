package com.hoang.wildcard;

import java.util.Locale;
import java.util.Map;

/**
 * v7: Vietnamese text of one data-driven mod ("attr:attack:1.2", "eff:speed:0:day"...), used to show exactly what each
 * duplicate star changes (for example "Sát thương cận chiến +1 → +1,2"). Returns null for troll debuffs.
 */
public final class ModText {
    private static final String[] ROMAN = {"I", "II", "III", "IV", "V", "VI"};
    private static final Map<String, String> EFF = Map.ofEntries(
            Map.entry("speed", "Tốc Độ"), Map.entry("haste", "Đào Nhanh"), Map.entry("strength", "Sức Mạnh"), Map.entry("jump", "Nhảy Cao"),
            Map.entry("regen", "Hồi Máu"), Map.entry("resistance", "Kháng Cự"), Map.entry("fire_res", "Kháng Lửa"),
            Map.entry("water_breath", "Thở Dưới Nước"), Map.entry("night_vision", "Nhìn Đêm"), Map.entry("dolphin", "Cá Heo"),
            Map.entry("luck", "May Mắn"), Map.entry("slow_fall", "Rơi Chậm"), Map.entry("invis", "Tàng Hình"), Map.entry("slowness", "Chậm Chạp"),
            Map.entry("fatigue", "Đào Chậm"), Map.entry("weakness", "Yếu Ớt"), Map.entry("hunger", "Đói"), Map.entry("glowing", "Phát Sáng"),
            Map.entry("unluck", "Xui Xẻo"), Map.entry("blindness", "Mù"), Map.entry("nausea", "Buồn Nôn"), Map.entry("darkness", "Bóng Tối"),
            Map.entry("poison", "Độc"), Map.entry("levitation", "Bay Lơ Lửng"));
    private static final Map<String, String> COND = Map.ofEntries(
            Map.entry("always", ""), Map.entry("night", "Ban đêm"), Map.entry("day", "Ban ngày"), Map.entry("rain", "Khi trời mưa"),
            Map.entry("water", "Khi ở trong nước"), Map.entry("nether", "Ở Nether"), Map.entry("deep", "Dưới Y=0"), Map.entry("high", "Trên Y=100"),
            Map.entry("dark", "Ở chỗ tối"), Map.entry("sneak", "Khi cúi"), Map.entry("sprint", "Khi chạy nước rút"), Map.entry("lowhp", "Máu dưới 40%"),
            Map.entry("fullhp", "Máu đầy"), Map.entry("armorless", "Không mặc giáp"), Map.entry("unarmed", "Tay không"), Map.entry("dayout", "Ban ngày ngoài trời"));
    private static final Map<String, String> SRC = Map.of("fall", "khi rơi", "fire", "từ lửa", "explosion", "từ vụ nổ", "projectile", "từ tên và đạn",
            "magic", "từ phép thuật", "melee", "cận chiến", "drown", "do đuối nước", "freeze", "do đóng băng", "all", "mọi loại");
    private static final Map<String, String> TGT = Map.of("undead", "mob xác sống", "arthropod", "nhện và côn trùng", "illager", "dân làng ác",
            "water", "mob dưới nước", "animal", "động vật", "all", "mọi mục tiêu", "player", "người chơi khác");

    static double d(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** 1,25 style number, at most 2 decimals. */
    public static String num(double v) {
        String s = String.format(Locale.ROOT, "%.2f", v);
        s = s.contains(".") ? s.replaceAll("0+$", "").replaceAll("\\.$", "") : s;
        return s.replace('.', ',');
    }

    private static String signed(double v) { return (v >= 0 ? "+" : "") + num(v); }

    private static String pct(double v) { return num(Math.round(v * 1000) / 10.0) + "%"; }

    private static String spct(double v) { return (v >= 0 ? "+" : "-") + pct(Math.abs(v)); }

    /** Short label of the mod (what it changes) and its value, e.g. {"Sát thương cận chiến", "+1,2"}. Null = no number. */
    public static String[] parts(String[] a) {
        if (a.length < 2) return null;
        switch (a[0]) {
            case "attr" -> {
                if (a.length < 3) return null;
                double v = d(a[2]);
                return switch (a[1]) {
                    case "speed" -> new String[]{"Tốc chạy", spct(v)};
                    case "maxhp" -> new String[]{"Máu tối đa", signed(v / 2) + " tim"};
                    case "attack" -> new String[]{"Sát thương cận chiến", signed(v)};
                    case "armor" -> new String[]{"Giáp", signed(v)};
                    case "toughness" -> new String[]{"Độ cứng giáp", signed(v)};
                    case "luck" -> new String[]{"May Mắn", signed(v)};
                    case "kbres" -> new String[]{"Kháng đẩy lùi", pct(v)};
                    case "atkspeed" -> new String[]{"Tốc đánh", spct(v)};
                    case "reach" -> new String[]{"Tầm với", signed(v) + " khối"};
                    case "swim" -> new String[]{"Tốc bơi", spct(v)};
                    default -> new String[]{a[1], signed(v)};
                };
            }
            case "eff" -> {
                if (a.length < 4) return null;
                int amp = (int) d(a[2]);
                String c = COND.getOrDefault(a[3], a[3]);
                return new String[]{(c.isEmpty() ? "" : c + ": ") + EFF.getOrDefault(a[1], a[1]), ROMAN[Math.max(0, Math.min(5, amp))]};
            }
            case "inc" -> {
                if (a.length < 3) return null;
                double m = d(a[2]);
                return new String[]{"Sát thương nhận " + SRC.getOrDefault(a[1], a[1]), spct(m - 1)};
            }
            case "out" -> {
                if (a.length < 3) return null;
                double m = d(a[2]);
                return new String[]{"Sát thương lên " + TGT.getOrDefault(a[1], a[1]), spct(m - 1)};
            }
            case "kill" -> {
                if (a.length < 3) return null;
                double v = d(a[2]);
                return switch (a[1]) {
                    case "heal" -> new String[]{"Hạ mob: hồi máu", num(v)};
                    case "xp" -> new String[]{"Hạ mob: XP thêm", num(v)};
                    case "food" -> new String[]{"Hạ mob: hồi điểm đói", num(v)};
                    case "hurt" -> new String[]{"Hạ mob: tự mất máu", num(v)};
                    case "hunger" -> new String[]{"Hạ mob: mất điểm đói", num(v)};
                    default -> null;
                };
            }
            case "mine" -> {
                if (a.length < 3) return null;
                double v = d(a[2]);
                return switch (a[1]) {
                    case "xp" -> new String[]{"Đào khối: tỉ lệ rơi thêm XP", num(v) + "%"};
                    case "hurt" -> new String[]{"Đào khối: tỉ lệ bị đá văng", num(v) + "%"};
                    case "haste" -> new String[]{"Đào đá: Đào Nhanh", ROMAN[Math.max(0, Math.min(5, (int) v))]};
                    default -> null;
                };
            }
            case "regen" -> { return new String[]{"Hồi 1 máu mỗi", num(d(a[1])) + " giây"}; }
            case "drain" -> { return new String[]{"Mất 1 máu mỗi", num(d(a[1])) + " giây"}; }
            case "food" -> { return new String[]{"Điểm đói thêm khi ăn", signed(d(a[1]))}; }
            case "exh" -> { return new String[]{"Mức tốn đói", "×" + num(d(a[1]))}; }
            case "xp" -> { return new String[]{"XP nhận được", spct(d(a[1]) - 1)}; }
            default -> { return null; }
        }
    }

    private ModText() {}
}
