package com.hoang.wildcard;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

import java.util.*;

/** Saved per-player wildcard data. Stored in the player's persisted NBT so it survives death and relogs. */
public final class WData {
    private static final Map<UUID, WData> CACHE = new HashMap<>();

    /** Every card the player owns (collection). */
    public final LinkedHashSet<String> cards = new LinkedHashSet<>();
    /** Owned cards that are equipped; only these give their buff, debuff and skills. At most Config.MAX_EQUIPPED. */
    public final LinkedHashSet<String> equipped = new LinkedHashSet<>();
    /** Number of cards picked so far. */
    public int round;
    /** Offers in a row without an Epic or Legendary card. */
    public int pity;
    /** Skill loadout for G H J K L: "cardId:skillIndex" or "" per slot. */
    public final String[] loadout = {"", "", "", "", ""};
    /** Ticks until the next offer. */
    public int timer;
    public boolean choosing;
    public int choiceTicks;
    public final List<String> offer = new ArrayList<>();
    /** Free-form per-card storage (counters, cooldowns, flags). */
    public CompoundTag extra = new CompoundTag();

    public static WData get(Player p) {
        return CACHE.computeIfAbsent(p.getUUID(), u -> load(p));
    }

    public static void unload(Player p) {
        WData d = CACHE.remove(p.getUUID());
        if (d != null) d.save(p);
    }

    public static void clearAll() {
        CACHE.clear();
    }

    private static WData load(Player p) {
        CompoundTag root = p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        CompoundTag t = root.getCompound("wildcard");
        WData d = new WData();
        if (t.isEmpty()) {
            d.timer = Config.ROUND_SECONDS.get() * 20;
            return d;
        }
        ListTag list = t.getList("cards", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            String id = list.getString(i);
            if (Cards.get(id) != null) d.cards.add(id);
        }
        d.round = t.getInt("round");
        d.pity = t.getInt("pity");
        if (t.contains("equipped")) {
            ListTag eq = t.getList("equipped", Tag.TAG_STRING);
            for (int i = 0; i < eq.size(); i++) if (d.cards.contains(eq.getString(i))) d.equipped.add(eq.getString(i));
        } else { // older saves: equip the first cards up to the limit
            for (String id : d.cards) if (d.equipped.size() < Config.MAX_EQUIPPED.get()) d.equipped.add(id);
        }
        ListTag lo = t.getList("loadout", Tag.TAG_STRING);
        for (int i = 0; i < Math.min(5, lo.size()); i++) d.loadout[i] = lo.getString(i);
        d.cleanLoadout();
        if (java.util.Arrays.stream(d.loadout).allMatch(String::isEmpty)) { // older saves: fill with the newest skill cards
            List<String> owned = new ArrayList<>(d.cards);
            Collections.reverse(owned);
            for (String id : owned) {
                Card c = Cards.get(id);
                if (c != null && d.equipped.contains(id)) d.autoFill(c);
            }
        }
        d.timer = t.getInt("timer");
        d.choosing = t.getBoolean("choosing");
        d.choiceTicks = t.getInt("choiceTicks");
        ListTag off = t.getList("offer", Tag.TAG_STRING);
        for (int i = 0; i < off.size(); i++) d.offer.add(off.getString(i));
        d.extra = t.getCompound("extra");
        return d;
    }

    public CompoundTag write() {
        CompoundTag t = new CompoundTag();
        ListTag list = new ListTag();
        for (String c : cards) list.add(StringTag.valueOf(c));
        t.put("cards", list);
        t.putInt("round", round);
        t.putInt("pity", pity);
        ListTag eq = new ListTag();
        for (String c : equipped) eq.add(StringTag.valueOf(c));
        t.put("equipped", eq);
        ListTag lo = new ListTag();
        for (String s : loadout) lo.add(StringTag.valueOf(s));
        t.put("loadout", lo);
        t.putInt("timer", timer);
        t.putBoolean("choosing", choosing);
        t.putInt("choiceTicks", choiceTicks);
        ListTag off = new ListTag();
        for (String c : offer) off.add(StringTag.valueOf(c));
        t.put("offer", off);
        t.put("extra", extra);
        return t;
    }

    /** Card and skill index in a loadout entry, or null when the slot is empty or no longer valid. */
    public static String[] parse(String entry) {
        if (entry == null || entry.isEmpty()) return null;
        int i = entry.lastIndexOf(':');
        if (i <= 0) return null;
        return new String[]{entry.substring(0, i), entry.substring(i + 1)};
    }

    public boolean validEntry(String entry) {
        String[] e = parse(entry);
        if (e == null || !equipped.contains(e[0])) return false;
        Card c = Cards.get(e[0]);
        try {
            int idx = Integer.parseInt(e[1]);
            return c != null && idx >= 0 && idx < c.skills.size();
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    /** Empties slots that point to cards the player no longer has. */
    public void cleanLoadout() {
        equipped.retainAll(cards);
        for (int i = 0; i < loadout.length; i++) if (!validEntry(loadout[i])) loadout[i] = "";
    }

    /** Puts a new card's skills into the empty slots, in order. */
    public void autoFill(Card c) {
        cleanLoadout();
        for (int k = 0; k < c.skills.size(); k++) {
            String entry = c.id + ":" + k;
            if (java.util.Arrays.asList(loadout).contains(entry)) continue;
            for (int i = 0; i < loadout.length; i++) {
                if (loadout[i].isEmpty()) {
                    loadout[i] = entry;
                    break;
                }
            }
        }
    }

    public boolean isFull() {
        return equipped.size() >= Config.MAX_EQUIPPED.get();
    }

    public void save(Player p) {
        CompoundTag data = p.getPersistentData();
        CompoundTag root = data.getCompound(Player.PERSISTED_NBT_TAG);
        root.put("wildcard", write());
        data.put(Player.PERSISTED_NBT_TAG, root);
    }

    public void reset() {
        cards.clear();
        equipped.clear();
        round = 0;
        pity = 0;
        java.util.Arrays.fill(loadout, "");
        timer = Config.ROUND_SECONDS.get() * 20;
        choosing = false;
        choiceTicks = 0;
        offer.clear();
        extra = new CompoundTag();
    }
}
