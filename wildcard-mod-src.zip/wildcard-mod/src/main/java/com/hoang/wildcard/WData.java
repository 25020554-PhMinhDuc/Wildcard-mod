package com.hoang.wildcard;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

import java.util.*;

/** Saved per-player wildcard data. Stored in the player's persisted NBT so it survives death and relogs. */
public final class WData {
    private static final Map<UUID, WData> CACHE = new HashMap<>();

    public final LinkedHashSet<String> cards = new LinkedHashSet<>();
    /** Number of cards picked so far. */
    public int round;
    /** Offers in a row without an Epic or Legendary card. */
    public int pity;
    public int rerolls;
    /** Ticks until the next offer. */
    public int timer;
    public boolean choosing;
    public int choiceTicks;
    public final List<String> offer = new ArrayList<>();
    /** Free-form per-card storage (counters, cooldowns, flags). */
    public CompoundTag extra = new CompoundTag();

    public static WData get(Player p) {
        return CACHE.computeIfAbsent(p.getUUID(), u -> load(p));
    }

    public static void unload(Player p) {
        WData d = CACHE.remove(p.getUUID());
        if (d != null) d.save(p);
    }

    public static void clearAll() {
        CACHE.clear();
    }

    private static WData load(Player p) {
        CompoundTag root = p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        CompoundTag t = root.getCompound("wildcard");
        WData d = new WData();
        if (t.isEmpty()) {
            d.timer = Config.ROUND_SECONDS.get() * 20;
            d.rerolls = Config.REROLL_START.get();
            return d;
        }
        ListTag list = t.getList("cards", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            String id = list.getString(i);
            if (Cards.get(id) != null) d.cards.add(id);
        }
        d.round = t.getInt("round");
        d.pity = t.getInt("pity");
        d.rerolls = t.getInt("rerolls");
        d.timer = t.getInt("timer");
        d.choosing = t.getBoolean("choosing");
        d.choiceTicks = t.getInt("choiceTicks");
        ListTag off = t.getList("offer", Tag.TAG_STRING);
        for (int i = 0; i < off.size(); i++) d.offer.add(off.getString(i));
        d.extra = t.getCompound("extra");
        return d;
    }

    public CompoundTag write() {
        CompoundTag t = new CompoundTag();
        ListTag list = new ListTag();
        for (String c : cards) list.add(StringTag.valueOf(c));
        t.put("cards", list);
        t.putInt("round", round);
        t.putInt("pity", pity);
        t.putInt("rerolls", rerolls);
        t.putInt("timer", timer);
        t.putBoolean("choosing", choosing);
        t.putInt("choiceTicks", choiceTicks);
        ListTag off = new ListTag();
        for (String c : offer) off.add(StringTag.valueOf(c));
        t.put("offer", off);
        t.put("extra", extra);
        return t;
    }

    public void save(Player p) {
        CompoundTag data = p.getPersistentData();
        CompoundTag root = data.getCompound(Player.PERSISTED_NBT_TAG);
        root.put("wildcard", write());
        data.put(Player.PERSISTED_NBT_TAG, root);
    }

    public void reset() {
        cards.clear();
        round = 0;
        pity = 0;
        rerolls = Config.REROLL_START.get();
        timer = Config.ROUND_SECONDS.get() * 20;
        choosing = false;
        choiceTicks = 0;
        offer.clear();
        extra = new CompoundTag();
    }
}
