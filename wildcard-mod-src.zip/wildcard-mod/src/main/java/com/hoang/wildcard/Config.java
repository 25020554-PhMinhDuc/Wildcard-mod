package com.hoang.wildcard;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ROUND_SECONDS;
    public static final ForgeConfigSpec.IntValue CHOICE_SECONDS;
    public static final ForgeConfigSpec.IntValue WARN_SECONDS;
    public static final ForgeConfigSpec.IntValue W_COMMON, W_UNCOMMON, W_RARE, W_EPIC, W_LEGENDARY;
    public static final ForgeConfigSpec.IntValue PITY_ROUNDS;
    public static final ForgeConfigSpec.IntValue ESCALATE_FROM_ROUND;
    public static final ForgeConfigSpec.IntValue ESCALATE_STEP;
    public static final ForgeConfigSpec.IntValue COMMON_MIN;
    public static final ForgeConfigSpec.IntValue REROLL_START;
    public static final ForgeConfigSpec.IntValue REROLL_EVERY;
    public static final ForgeConfigSpec.IntValue REROLL_MAX;
    public static final ForgeConfigSpec.BooleanValue PROTECT_WHILE_CHOOSING;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DISABLED_CARDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Thời gian").push("timing");
        ROUND_SECONDS = b.comment("Số giây giữa hai lượt chọn thẻ").defineInRange("roundSeconds", 360, 10, 36000);
        CHOICE_SECONDS = b.comment("Số giây tối đa để chọn thẻ, hết giờ sẽ tự chọn ngẫu nhiên").defineInRange("choiceSeconds", 30, 5, 600);
        WARN_SECONDS = b.comment("Phát âm thanh báo hiệu khi còn bao nhiêu giây").defineInRange("warnSeconds", 10, 0, 600);
        PROTECT_WHILE_CHOOSING = b.comment("Bất tử và đóng băng mob xung quanh khi đang chọn").define("protectWhileChoosing", true);
        b.pop();
        b.comment("Tỉ lệ độ hiếm (trọng số)").push("weights");
        W_COMMON = b.defineInRange("phoBien", 40, 0, 1000);
        W_UNCOMMON = b.defineInRange("khongPhoBien", 28, 0, 1000);
        W_RARE = b.defineInRange("hiem", 18, 0, 1000);
        W_EPIC = b.defineInRange("suThi", 10, 0, 1000);
        W_LEGENDARY = b.defineInRange("huyenThoai", 4, 0, 1000);
        ESCALATE_FROM_ROUND = b.comment("Từ lượt này trở đi bắt đầu leo thang").defineInRange("escalateFromRound", 6, 1, 1000);
        ESCALATE_STEP = b.comment("Mỗi lượt chuyển bao nhiêu % từ Phổ biến sang Sử thi + Huyền thoại").defineInRange("escalateStep", 2, 0, 100);
        COMMON_MIN = b.comment("Tỉ lệ Phổ biến tối thiểu sau khi leo thang").defineInRange("commonMin", 20, 0, 100);
        b.pop();
        b.comment("Luật").push("rules");
        PITY_ROUNDS = b.comment("Số lượt liền không thấy Sử thi trở lên thì lượt sau chắc chắn có (0 = tắt)").defineInRange("pityRounds", 4, 0, 100);
        REROLL_START = b.defineInRange("rerollStart", 1, 0, 10);
        REROLL_EVERY = b.comment("Cứ bao nhiêu lượt chọn thì được thêm 1 lượt đổi bài").defineInRange("rerollEvery", 3, 1, 100);
        REROLL_MAX = b.defineInRange("rerollMax", 2, 0, 10);
        DISABLED_CARDS = b.comment("Danh sách id thẻ bị tắt, ví dụ [\"c01\", \"l14\"]")
                .defineListAllowEmpty("disabledCards", List.of(), o -> o instanceof String);
        b.pop();
        SPEC = b.build();
    }

    private Config() {}
}
