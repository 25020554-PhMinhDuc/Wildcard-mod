package com.hoang.wildcard;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ROUND_SECONDS;
    public static final ForgeConfigSpec.IntValue CHOICE_SECONDS;
    public static final ForgeConfigSpec.IntValue WARN_SECONDS;
    public static final ForgeConfigSpec.IntValue W_COMMON, W_UNCOMMON, W_RARE, W_EPIC, W_LEGENDARY, W_MYTHIC;
    public static final ForgeConfigSpec.IntValue PITY_ROUNDS;
    public static final ForgeConfigSpec.DoubleValue CHANCE_EPIC, CHANCE_LEGENDARY, CHANCE_MYTHIC, DUPLICATE_CHANCE;
    public static final ForgeConfigSpec.IntValue POOL_SIZE, PITY_LEGENDARY, PITY_MYTHIC;
    public static final ForgeConfigSpec.IntValue MAX_EQUIPPED;
    public static final ForgeConfigSpec.IntValue ESCALATE_FROM_ROUND;
    public static final ForgeConfigSpec.IntValue ESCALATE_STEP;
    public static final ForgeConfigSpec.IntValue COMMON_MIN;
    public static final ForgeConfigSpec.BooleanValue PROTECT_WHILE_CHOOSING;
    public static final ForgeConfigSpec.IntValue RAIN_DAYS, RAIN_CARDS, RAIN_WARN_SECONDS, RAIN_PICK_SECONDS;
    public static final ForgeConfigSpec.IntValue ADV_GREEN_EVERY, ADV_PURPLE_EVERY;
    public static final ForgeConfigSpec.DoubleValue MOB_DROP_CHANCE, INVASION_CHANCE;
    public static final ForgeConfigSpec.IntValue INVASION_WARN_SECONDS, INVASION_SECONDS, INVASION_GROUP_RADIUS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DISABLED_CARDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Thời gian").push("timing");
        ROUND_SECONDS = b.comment("Số giây giữa hai lượt chọn thẻ (mặc định 20 phút)").defineInRange("roundSecondsV3", 1200, 10, 36000);
        CHOICE_SECONDS = b.comment("Số giây tối đa để chọn thẻ, hết giờ sẽ tự chọn ngẫu nhiên").defineInRange("choiceSeconds", 30, 5, 600);
        WARN_SECONDS = b.comment("Phát âm thanh báo hiệu khi còn bao nhiêu giây").defineInRange("warnSeconds", 10, 0, 600);
        PROTECT_WHILE_CHOOSING = b.comment("Bất tử và đóng băng mob xung quanh khi đang chọn").define("protectWhileChoosing", true);
        b.pop();
        b.comment("Tỉ lệ độ hiếm (trọng số, đơn vị 0,1%). Mỗi ô thẻ tự quay độ hiếm theo các trọng số này.").push("weights");
        W_COMMON = b.defineInRange("phoBien", 360, 0, 100000);
        W_UNCOMMON = b.defineInRange("khongPhoBien", 670, 0, 100000);
        W_RARE = b.defineInRange("hiem", 180, 0, 100000);
        W_EPIC = b.defineInRange("suThi", 50, 0, 100000);
        W_LEGENDARY = b.defineInRange("huyenThoai", 10, 0, 100000);
        W_MYTHIC = b.defineInRange("thanThoai", 1, 0, 100000);
        ESCALATE_FROM_ROUND = b.comment("Từ lượt này trở đi bắt đầu leo thang").defineInRange("escalateFromRound", 6, 1, 1000);
        ESCALATE_STEP = b.comment("Mỗi lượt chuyển bao nhiêu % từ Không phổ biến sang Sử thi + Huyền thoại (0 = tắt)").defineInRange("escalateStep", 0, 0, 100);
        COMMON_MIN = b.comment("Tỉ lệ Phổ biến tối thiểu sau khi leo thang").defineInRange("commonMin", 20, 0, 100);
        b.pop();
        b.comment("Tỉ lệ v3: mỗi ô thẻ quay riêng. Thần thoại / Huyền thoại / Sử thi theo % cố định,",
                "phần còn lại rút từ bộ bài " + "poolSize" + " lá (thẻ Phổ biến được nhân bản cho đủ, nên Hiếm khó ra).").push("chances");
        CHANCE_EPIC = b.comment("% ra Sử thi mỗi ô").defineInRange("suThiPercent", 5.0, 0, 100);
        CHANCE_LEGENDARY = b.comment("% ra Huyền thoại mỗi ô").defineInRange("huyenThoaiPercent", 0.5, 0, 100);
        CHANCE_MYTHIC = b.comment("% ra Thần thoại mỗi ô").defineInRange("thanThoaiPercent", 0.01, 0, 100);
        POOL_SIZE = b.comment("Số lá trong bộ bài ảo").defineInRange("poolSize", 2000, 100, 100000);
        PITY_LEGENDARY = b.comment("Bảo hiểm: sau bấy nhiêu lượt không thấy Huyền thoại thì lượt sau chắc chắn có (0 = tắt)").defineInRange("pityHuyenThoai", 50, 0, 10000);
        PITY_MYTHIC = b.comment("Bảo hiểm: sau bấy nhiêu lượt không thấy Thần thoại thì lượt sau chắc chắn có (0 = tắt)").defineInRange("pityThanThoai", 150, 0, 10000);
        DUPLICATE_CHANCE = b.comment("% một ô ra lại thẻ bạn đã có (trùng thẻ, lên sao)").defineInRange("trungThePercent", 60.0, 0, 100);
        b.pop();
        b.comment("Sự kiện Mưa Thẻ (v5)").push("cardRain");
        RAIN_DAYS = b.comment("Mỗi bao nhiêu ngày Minecraft có một lần Mưa Thẻ (0 = tắt)").defineInRange("rainDays", 7, 0, 1000);
        RAIN_CARDS = b.comment("Tổng số thẻ rơi mỗi lần (chia đều cho người chơi đang online)").defineInRange("rainCards", 100, 1, 1000);
        RAIN_WARN_SECONDS = b.comment("Thông báo trước bao nhiêu giây").defineInRange("rainWarnSeconds", 60, 0, 600);
        RAIN_PICK_SECONDS = b.comment("Thời gian nhặt thẻ (giây)").defineInRange("rainPickSeconds", 30, 5, 600);
        b.pop();
        b.comment("Thẻ thưởng thành tựu (v6)").push("advancements");
        ADV_GREEN_EVERY = b.comment("Cứ bao nhiêu thành tựu xanh (thường và mục tiêu) thì được 1 thẻ Rare trở lên (0 = tắt)").defineInRange("greenEvery", 3, 0, 100);
        ADV_PURPLE_EVERY = b.comment("Cứ bao nhiêu thành tựu tím (thử thách) thì được 1 thẻ Epic trở lên (0 = tắt)").defineInRange("purpleEvery", 1, 0, 100);
        b.pop();
        b.comment("Rơi thẻ khi hạ quái vật (v7)").push("mobDrops");
        MOB_DROP_CHANCE = b.comment("Tỉ lệ một quái vật (zombie, skeleton, creeper, enderman, stray, phantom, guardian...) rơi 1 thẻ khi bị người chơi hạ. 0.001 = 0,1%").defineInRange("dropChance", 0.001, 0.0, 1.0);
        b.pop();
        b.comment("Sự kiện Quái Vật Xâm Lăng (v7)").push("invasion");
        INVASION_CHANCE = b.comment("Tỉ lệ xảy ra mỗi khi trời tối (0.04 = 4%, 0 = tắt)").defineInRange("chance", 0.04, 0.0, 1.0);
        INVASION_WARN_SECONDS = b.comment("Thông báo trước bao nhiêu giây").defineInRange("warnSeconds", 60, 0, 600);
        INVASION_SECONDS = b.comment("Sự kiện kéo dài bao nhiêu giây").defineInRange("durationSeconds", 90, 10, 1200);
        INVASION_GROUP_RADIUS = b.comment("Người chơi cách nhau trong bán kính này (khối) tính là cùng một nơi").defineInRange("groupRadius", 48, 8, 512);
        b.pop();
        b.comment("Luật").push("rules");
        MAX_EQUIPPED = b.comment("Số thẻ tối đa được trang bị cùng lúc (chỉ thẻ trang bị mới có hiệu ứng và kỹ năng)").defineInRange("maxEquipped", 20, 1, 1000);
        PITY_ROUNDS = b.comment("Số lượt liền không thấy Sử thi trở lên thì lượt sau chắc chắn có (0 = tắt)").defineInRange("pityRounds", 0, 0, 100);
        DISABLED_CARDS = b.comment("Danh sách id thẻ bị tắt, ví dụ [\"c01\", \"l14\"]")
                .defineListAllowEmpty("disabledCards", List.of(), o -> o instanceof String);
        b.pop();
        SPEC = b.build();
    }

    private Config() {}
}
