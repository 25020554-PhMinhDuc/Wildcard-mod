package com.hoang.wildcard;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ROUND_SECONDS;
    public static final ForgeConfigSpec.IntValue CHOICE_SECONDS;
    public static final ForgeConfigSpec.IntValue WARN_SECONDS;
    public static final ForgeConfigSpec.IntValue W_COMMON, W_UNCOMMON, W_RARE, W_EPIC, W_LEGENDARY, W_MYTHIC;
    public static final ForgeConfigSpec.IntValue PITY_ROUNDS;
    public static final ForgeConfigSpec.IntValue MAX_EQUIPPED;
    public static final ForgeConfigSpec.IntValue ESCALATE_FROM_ROUND;
    public static final ForgeConfigSpec.IntValue ESCALATE_STEP;
    public static final ForgeConfigSpec.IntValue COMMON_MIN;
    public static final ForgeConfigSpec.BooleanValue PROTECT_WHILE_CHOOSING;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DISABLED_CARDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Thời gian").push("timing");
        ROUND_SECONDS = b.comment("Số giây giữa hai lượt chọn thẻ").defineInRange("roundSeconds", 360, 10, 36000);
        CHOICE_SECONDS = b.comment("Số giây tối đa để chọn thẻ, hết giờ sẽ tự chọn ngẫu nhiên").defineInRange("choiceSeconds", 30, 5, 600);
        WARN_SECONDS = b.comment("Phát âm thanh báo hiệu khi còn bao nhiêu giây").defineInRange("warnSeconds", 10, 0, 600);
        PROTECT_WHILE_CHOOSING = b.comment("Bất tử và đóng băng mob xung quanh khi đang chọn").define("protectWhileChoosing", true);
        b.pop();
        b.comment("Tỉ lệ độ hiếm (trọng số, đơn vị 0,1%). Mỗi ô thẻ tự quay độ hiếm theo các trọng số này.").push("weights");
        W_COMMON = b.defineInRange("phoBien", 360, 0, 100000);
        W_UNCOMMON = b.defineInRange("khongPhoBien", 670, 0, 100000);
        W_RARE = b.defineInRange("hiem", 180, 0, 100000);
        W_EPIC = b.defineInRange("suThi", 50, 0, 100000);
        W_LEGENDARY = b.defineInRange("huyenThoai", 10, 0, 100000);
        W_MYTHIC = b.defineInRange("thanThoai", 1, 0, 100000);
        ESCALATE_FROM_ROUND = b.comment("Từ lượt này trở đi bắt đầu leo thang").defineInRange("escalateFromRound", 6, 1, 1000);
        ESCALATE_STEP = b.comment("Mỗi lượt chuyển bao nhiêu % từ Không phổ biến sang Sử thi + Huyền thoại (0 = tắt)").defineInRange("escalateStep", 0, 0, 100);
        COMMON_MIN = b.comment("Tỉ lệ Phổ biến tối thiểu sau khi leo thang").defineInRange("commonMin", 20, 0, 100);
        b.pop();
        b.comment("Luật").push("rules");
        MAX_EQUIPPED = b.comment("Số thẻ tối đa được trang bị cùng lúc (chỉ thẻ trang bị mới có hiệu ứng và kỹ năng)").defineInRange("maxEquipped", 20, 1, 1000);
        PITY_ROUNDS = b.comment("Số lượt liền không thấy Sử thi trở lên thì lượt sau chắc chắn có (0 = tắt)").defineInRange("pityRounds", 0, 0, 100);
        DISABLED_CARDS = b.comment("Danh sách id thẻ bị tắt, ví dụ [\"c01\", \"l14\"]")
                .defineListAllowEmpty("disabledCards", List.of(), o -> o instanceof String);
        b.pop();
        SPEC = b.build();
    }

    private Config() {}
}
