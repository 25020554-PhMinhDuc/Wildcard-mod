package com.hoang.wildcard.fx;

import com.hoang.wildcard.net.Net;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.concurrent.atomic.AtomicInteger;

/** Server side senders for the v4 spell visuals drawn by client.VfxClient. Kind numbers match VfxClient. */
public final class Vfx {
    private static final AtomicInteger IDS = new AtomicInteger(1);

    public static int newId() {
        return IDS.getAndIncrement();
    }

    private static void send(ServerLevel l, int kind, Element e, int id, Vec3 p, double a, double b, double c, double d, int life) {
        Net.near(l, p.x, p.y, p.z, new Net.Vfx(kind, e.ordinal(), id, (float) p.x, (float) p.y, (float) p.z,
                (float) a, (float) b, (float) c, (float) d, life));
    }

    /** Voxel ball. {@code id} != 0: a flying one, send every tick with its velocity; id 0: a still one. */
    public static void ball(ServerLevel l, int id, Vec3 p, Vec3 vel, Element e, double size, int life) {
        send(l, 0, e, id, p, vel.x, vel.y, vel.z, size, life);
    }

    public static void lightning(ServerLevel l, Vec3 a, Vec3 b, Element e, double width, int life) {
        send(l, 1, e, 0, a, b.x, b.y, b.z, width, life);
    }

    public static void beam(ServerLevel l, Vec3 a, Vec3 b, Element e, double width, int life) {
        send(l, 2, e, 0, a, b.x, b.y, b.z, width, life);
    }

    public static void ring(ServerLevel l, Vec3 c, Element e, double radius, int life) {
        send(l, 3, e, 0, c, radius, 0, 0, 0, life);
    }

    public static void blackHole(ServerLevel l, Vec3 c, Element e, double size, int life) {
        send(l, 4, e, 0, c, 0, 0, 0, size, life);
    }

    /** Voxel shards flying out plus a flash; {@code power} ~ 0.5 small .. 4 huge. */
    public static void burst(ServerLevel l, Vec3 c, Element e, double power) {
        send(l, 5, e, 0, c, power, 0, 0, 0, 10);
    }

    public static void slash(ServerLevel l, Vec3 c, Element e, double yaw, double size) {
        send(l, 6, e, 0, c, yaw, size, 0, 0, 10);
    }

    /** Stream of voxels from {@code from} along {@code dir} for {@code life} ticks. */
    public static void breath(ServerLevel l, Vec3 from, Vec3 dir, Element e, int life) {
        send(l, 7, e, 0, from, dir.x, dir.y, dir.z, 0, life);
    }

    /** Row of ice pillars rising one after another along {@code dir}. */
    public static void iceSpikes(ServerLevel l, Vec3 from, Vec3 dir, Element e, int count, int life) {
        send(l, 8, e, 0, from, dir.x, 0, dir.z, count, life);
    }

    /** Upright swirling oval (teleport, summon, curse). */
    public static void portal(ServerLevel l, Vec3 c, Element e, double yaw, double size, int life) {
        send(l, 9, e, 0, c, yaw, 0, 0, size, life);
    }

    /** Rays of light shooting out with pixel sparks (holy smite, lightning hit). */
    public static void starburst(ServerLevel l, Vec3 c, Element e, double size) {
        send(l, 10, e, 0, c, 0, 0, 0, size, 12);
    }

    /** Ring of spikes (ice / earth / void depending on element) bursting up around a point. */
    public static void spikesAround(ServerLevel l, Vec3 c, Element e, double radius, int count, int life) {
        send(l, 8, e, 0, c, 0, radius, 0, count, life);
    }

    /** Rising column of light with floating cubes (heals, buffs). */
    public static void pillar(ServerLevel l, Vec3 c, Element e, double height, double radius, int life) {
        send(l, 11, e, 0, c, height, 0, 0, radius, life);
    }

    /** Glowing half-sphere shield. */
    public static void dome(ServerLevel l, Vec3 c, Element e, double radius, int life) {
        send(l, 12, e, 0, c, 0, 0, 0, radius, life);
    }

    /** Spiral of cubes rising (wind, pulls, leaps). */
    public static void vortex(ServerLevel l, Vec3 c, Element e, double radius, double height, int life) {
        send(l, 13, e, 0, c, height, 0, 0, radius, life);
    }

    /** Bubbling ground zone (poison, curses, blight). */
    public static void area(ServerLevel l, Vec3 c, Element e, double radius, int life) {
        send(l, 14, e, 0, c, 0, 0, 0, radius, life);
    }

    private Vfx() {}
}
