package com.hoang.wildcard.effects;

import com.hoang.wildcard.Cards;
import com.hoang.wildcard.ModSounds;
import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.Fx;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetCarriedItemPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.*;

/** Hand-made meme cards: u61 La Peace, u62 Hotbar Lơ Lửng, u63 Trap Card, u64 Jackpot. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class MemeCards {
    private record Trap(ServerLevel level, Vec3 pos, UUID owner, long until) {}

    private static final List<Trap> TRAPS = new ArrayList<>();

    private static boolean has(net.minecraft.world.entity.player.Player p, String id) {
        return Cards.has(p, id);
    }

    // ------------------------------------------------------------------ passives

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide) return;
        if (!(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        if (p.tickCount % 20 != 0) return;
        RandomSource r = p.getRandom();
        // La Peace: thỉnh thoảng tạo dáng "peace" giữa trận
        if (has(p, "u61") && r.nextInt(240) == 0) {
            TrollDebuffs.soundAll(p, ModSounds.LA_PEACE.get(), 1.5f);
            Effects.effect(p, MobEffects.MOVEMENT_SLOWDOWN, 60, 1);
            Effects.actionBar(p, Component.translatable("msg.wildcard.peace.pose").withStyle(ChatFormatting.AQUA));
        }
        // Hotbar Lơ Lửng: Đào Nhanh + tốc đánh, nhưng ô đang cầm tự nhảy lung tung
        boolean hb = has(p, "u62");
        if (hb) Effects.keep(p, MobEffects.DIG_SPEED, 0);
        Effects.attr(p, Attributes.ATTACK_SPEED, "u62_as", 0.15, AttributeModifier.Operation.MULTIPLY_TOTAL, hb);
        if (hb && r.nextInt(60) == 0 && p.level().getGameTime() > PlayerState.get(p).time("hotbar_hold")) {
            int slot = r.nextInt(9);
            p.getInventory().selected = slot;
            p.connection.send(new ClientboundSetCarriedItemPacket(slot));
        }
    }

    @SubscribeEvent
    public static void onTarget(LivingChangeTargetEvent e) {
        if (!(e.getNewTarget() instanceof ServerPlayer p) || !(e.getEntity() instanceof Enemy)) return;
        if (!has(p, "u61")) return;
        if (p.level().getGameTime() < PlayerState.get(p).time("peace_angry")) return;
        e.setCanceled(true); // La Peace: quái không gây sự trước
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity().level().isClientSide) return;
        // La Peace: đánh ai thì mất hòa bình 30 giây, và đánh rất yếu
        if (e.getSource().getEntity() instanceof ServerPlayer att && att != e.getEntity() && has(att, "u61")) {
            PlayerState.get(att).time("peace_angry", att.level().getGameTime() + 600);
            e.setAmount(e.getAmount() * 0.4f);
        }
        // Trap Card: 20% phản lại toàn bộ sát thương
        if (e.getEntity() instanceof ServerPlayer p && has(p, "u63") && e.getSource().getEntity() instanceof LivingEntity att
                && att != p && p.getRandom().nextInt(5) == 0) {
            float dmg = e.getAmount();
            att.hurt(p.damageSources().thorns(p), dmg);
            TrollDebuffs.title(p, Component.translatable("msg.wildcard.trap.title").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD),
                    Component.translatable("msg.wildcard.trap.sub").withStyle(ChatFormatting.LIGHT_PURPLE));
            TrollDebuffs.soundAll(p, ModSounds.TRAP.get(), 1.2f);
            Fx.burst(p.serverLevel(), att.position().add(0, 1, 0), Element.VOID, 20, 0.3);
        }
    }

    @SubscribeEvent
    public static void onOpen(PlayerInteractEvent.RightClickBlock e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "u63")) return;
        BlockEntity be = p.level().getBlockEntity(e.getPos());
        if (!(be instanceof Container)) return;
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        if (now < st.time("trap_chest") || p.getRandom().nextInt(100) >= 15) return;
        st.time("trap_chest", now + 200);
        ServerLevel level = p.serverLevel();
        for (int i = 0; i < 2; i++) {
            Silverfish s = EntityType.SILVERFISH.create(level);
            if (s == null) continue;
            s.moveTo(e.getPos().getX() + 0.5, e.getPos().getY() + 1, e.getPos().getZ() + 0.5, 0, 0);
            level.addFreshEntity(s);
            s.setTarget(p);
        }
        TrollDebuffs.soundAll(p, ModSounds.TRAP.get(), 1f);
        Effects.actionBar(p, Component.translatable("msg.wildcard.trap.chest").withStyle(ChatFormatting.RED));
    }

    // ------------------------------------------------------------------ Jackpot

    /** Spins the slot machine. {@code manual} = from the skill (smaller cost already paid). */
    public static void spin(ServerPlayer p) {
        RandomSource r = p.getRandom();
        int roll = r.nextInt(100);
        if (roll < 8) {
            Effects.give(p, new ItemStack(Items.DIAMOND, 3));
            Effects.give(p, new ItemStack(Items.EMERALD, 8));
            TrollDebuffs.title(p, Component.translatable("msg.wildcard.jackpot.win").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                    Component.literal("7  7  7").withStyle(ChatFormatting.YELLOW));
            TrollDebuffs.soundAll(p, ModSounds.JACKPOT_WIN.get(), 2f);
            // Hakari: bất tử 15 giây sau khi nổ hũ
            PlayerState.get(p).time("jackpot_god", p.level().getGameTime() + 300);
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 2, false, true, true));
            Fx.circle(p.serverLevel(), p.position().add(0, 0.05, 0), Element.HOLY, 2, 32, true);
            Fx.burst(p.serverLevel(), p.position().add(0, 1.2, 0), Element.HOLY, 60, 0.4);
            p.server.getPlayerList().broadcastSystemMessage(Component.translatable("msg.wildcard.jackpot.all", p.getDisplayName())
                    .withStyle(ChatFormatting.GOLD), false);
        } else if (roll < 38) {
            Effects.give(p, new ItemStack(Items.GOLD_INGOT, 4));
            TrollDebuffs.title(p, Component.translatable("msg.wildcard.jackpot.small").withStyle(ChatFormatting.YELLOW),
                    Component.literal("7  7  " + (1 + r.nextInt(6))).withStyle(ChatFormatting.GRAY));
            p.level().playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 1.4f);
        } else {
            if (p.experienceLevel >= 3) p.giveExperienceLevels(-3);
            else {
                Effects.effect(p, MobEffects.HUNGER, 1200, 0);
                Effects.effect(p, MobEffects.UNLUCK, 1200, 0);
            }
            TrollDebuffs.title(p, Component.translatable("msg.wildcard.jackpot.lose").withStyle(ChatFormatting.RED),
                    Component.literal(r.nextInt(9) + "  " + r.nextInt(9) + "  " + r.nextInt(9)).withStyle(ChatFormatting.DARK_GRAY));
            TrollDebuffs.soundAll(p, ModSounds.FAIL.get(), 1f);
        }
    }

    /** Jackpot: bất tử trong 15 giây sau khi trúng lớn. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttack(net.minecraftforge.event.entity.living.LivingAttackEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && p.level().getGameTime() < PlayerState.get(p).time("jackpot_god")
                && !e.getSource().is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onDeathGod(net.minecraftforge.event.entity.living.LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && p.level().getGameTime() < PlayerState.get(p).time("jackpot_god")
                && !e.getSource().is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            e.setCanceled(true);
            p.setHealth(1f);
        }
    }

    /** La Peace: đào quặng kim cương có 35% chỉ ra lapis. */
    @SubscribeEvent
    public static void onMine(net.minecraftforge.event.level.BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || !has(p, "u61") || p.isCreative()) return;
        if (!e.getState().is(net.minecraft.tags.BlockTags.DIAMOND_ORES) || p.getRandom().nextInt(100) >= 35) return;
        e.setCanceled(true);
        ServerLevel level = p.serverLevel();
        level.removeBlock(e.getPos(), false);
        net.minecraft.world.level.block.Block.popResource(level, e.getPos(), new ItemStack(Items.LAPIS_LAZULI, 4 + p.getRandom().nextInt(5)));
        level.playSound(null, e.getPos(), ModSounds.LA_PEACE.get(), SoundSource.PLAYERS, 1f, 1f);
        Effects.actionBar(p, Component.translatable("msg.wildcard.peace.lapis").withStyle(ChatFormatting.BLUE));
        ItemStack tool = p.getMainHandItem();
        if (tool.isDamageableItem()) tool.hurtAndBreak(1, p, x -> x.broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot.MAINHAND));
    }

    /** Hạt sáng quanh người đang bất tử nhờ Jackpot. */
    @SubscribeEvent
    public static void onGodTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || p.tickCount % 5 != 0) return;
        if (p.level().getGameTime() < PlayerState.get(p).time("jackpot_god")) {
            Fx.burst(p.serverLevel(), p.position().add(0, 1, 0), Element.HOLY, 4, 0.15);
        }
    }

    /** Called when a new card is granted. */
    public static void onRoundStart(ServerPlayer p) {
        if (has(p, "u64")) spin(p);
    }

    // ------------------------------------------------------------------ skills

    static boolean skill(ServerPlayer p, String id) {
        ServerLevel level = p.serverLevel();
        switch (id) {
            case "u61" -> { // Peace Out
                Skills.self(p, MobEffects.MOVEMENT_SPEED, 80, 2);
                p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 80, 0, false, false, true));
                Skills.forFoes(p, 8, le -> {
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                    if (le instanceof Mob m) m.setTarget(null);
                });
                Skills.clearAggro(p, 16);
                Fx.burst(level, p.position().add(0, 1, 0), Element.WIND, 30, 0.3);
            }
            case "u62" -> { // Bắt Hotbar
                PlayerState.get(p).time("hotbar_hold", level.getGameTime() + 300);
                Net.toPlayer(p, new Net.Fx("hotbarstop", 300));
                Skills.self(p, MobEffects.DAMAGE_BOOST, 300, 0);
            }
            case "u63" -> { // Úp Bài Bẫy
                TRAPS.add(new Trap(level, p.position(), p.getUUID(), level.getGameTime() + 1200));
                Fx.circle(level, p.position().add(0, 0.05, 0), Element.VOID, 1.2, 16, false);
            }
            case "u64" -> { // Quay Hũ
                if (p.experienceLevel < 2) {
                    Effects.actionBar(p, Component.translatable("msg.wildcard.jackpot.nolevel").withStyle(ChatFormatting.RED));
                    return false;
                }
                p.giveExperienceLevels(-2);
                spin(p);
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || TRAPS.isEmpty()) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 5 != 0) return;
        Iterator<Trap> it = TRAPS.iterator();
        while (it.hasNext()) {
            Trap t = it.next();
            ServerPlayer owner = server.getPlayerList().getPlayer(t.owner());
            if (owner == null || t.level().getGameTime() > t.until()) {
                it.remove();
                continue;
            }
            if (server.getTickCount() % 20 == 0) Fx.circle(t.level(), t.pos().add(0, 0.05, 0), Element.VOID, 0.8, 8, false);
            List<LivingEntity> hit = t.level().getEntitiesOfClass(LivingEntity.class,
                    new net.minecraft.world.phys.AABB(t.pos(), t.pos()).inflate(2), x -> Skills.foe(owner, x));
            if (hit.isEmpty()) continue;
            for (LivingEntity le : hit) {
                Skills.trueHurt(owner, le, 8f);
                le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
            }
            Fx.burst(t.level(), t.pos().add(0, 0.5, 0), Element.VOID, 40, 0.4);
            t.level().playSound(null, net.minecraft.core.BlockPos.containing(t.pos()), ModSounds.TRAP.get(), SoundSource.PLAYERS, 1.2f, 1f);
            if (owner.level() == t.level()) TrollDebuffs.title(owner, Component.translatable("msg.wildcard.trap.title")
                    .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD), null);
            it.remove();
        }
    }

    private MemeCards() {}
}
