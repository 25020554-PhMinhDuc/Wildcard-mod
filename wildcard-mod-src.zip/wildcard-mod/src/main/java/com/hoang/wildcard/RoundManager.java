package com.hoang.wildcard;

import com.hoang.wildcard.effects.Effects;
import com.hoang.wildcard.effects.PlayerState;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.*;

/** Round timer, card rolling (rarity weights, pity, escalation, conflicts) and applying the pick. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class RoundManager {
    private static final Map<UUID, ServerBossEvent> BARS = new HashMap<>();
    private static final RandomSource RNG = RandomSource.create();

    // ------------------------------------------------------------------ ticking

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide) return;
        if (!(e.player instanceof ServerPlayer p) || p.isSpectator()) return;
        WData d = WData.get(p);

        if (d.choosing) {
            d.choiceTicks--;
            if (Config.PROTECT_WHILE_CHOOSING.get() && p.tickCount % 10 == 0) freezeMobs(p);
            if (d.choiceTicks % 20 == 0) updateBar(p, d);
            if (d.choiceTicks <= 0 && !d.offer.isEmpty()) {
                p.sendSystemMessage(Component.translatable("msg.wildcard.auto").withStyle(ChatFormatting.GRAY));
                pick(p, d, d.offer.get(RNG.nextInt(d.offer.size())));
            }
            return;
        }
        if (!p.isAlive()) return;

        d.timer--;
        int warn = Config.WARN_SECONDS.get() * 20;
        if (warn > 0 && d.timer == warn) {
            p.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1f, 1.2f);
        }
        if (d.timer % 20 == 0) updateBar(p, d);
        if (d.timer <= 0) startChoice(p, d);
        if (p.tickCount % 200 == 0) d.save(p);
    }

    private static void freezeMobs(ServerPlayer p) {
        for (Mob m : p.level().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16))) {
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 10, false, false));
            if (m.getTarget() == p) m.setTarget(null);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttack(LivingAttackEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && Config.PROTECT_WHILE_CHOOSING.get() && WData.get(p).choosing) {
            e.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ boss bar

    private static void updateBar(ServerPlayer p, WData d) {
        ServerBossEvent bar = BARS.computeIfAbsent(p.getUUID(), u -> new ServerBossEvent(
                Component.empty(), BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.NOTCHED_10));
        if (!bar.getPlayers().contains(p)) {
            bar.removeAllPlayers();
            bar.addPlayer(p);
        }
        if (d.choosing) {
            bar.setName(Component.translatable("bossbar.wildcard.choosing").withStyle(ChatFormatting.GOLD));
            bar.setColor(BossEvent.BossBarColor.PURPLE);
            bar.setProgress(Math.max(0f, d.choiceTicks / (Config.CHOICE_SECONDS.get() * 20f)));
        } else {
            int s = Math.max(0, d.timer / 20);
            String time = String.format("%d:%02d", s / 60, s % 60);
            bar.setName(Component.translatable("bossbar.wildcard.next", time).withStyle(ChatFormatting.YELLOW));
            bar.setColor(s <= Config.WARN_SECONDS.get() ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.YELLOW);
            bar.setProgress(Math.max(0f, Math.min(1f, d.timer / (Config.ROUND_SECONDS.get() * 20f))));
        }
    }

    // ------------------------------------------------------------------ rolling

    public static void startChoice(ServerPlayer p, WData d) {
        List<String> offer = roll(p, d, true);
        if (offer.isEmpty()) { // every card owned or disabled
            d.timer = Config.ROUND_SECONDS.get() * 20;
            return;
        }
        d.offer.clear();
        d.offer.addAll(offer);
        d.choosing = true;
        d.choiceTicks = Config.CHOICE_SECONDS.get() * 20;
        p.playNotifySound(SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.MASTER, 1f, 1f);
        sendOffer(p, d);
        updateBar(p, d);
    }

    private static void sendOffer(ServerPlayer p, WData d) {
        Net.toPlayer(p, new Net.OpenChoice(new ArrayList<>(d.offer), Math.max(1, d.choiceTicks / 20), d.round + 1));
    }

    /** Current rarity weights for the given round number (1-based), after escalation. */
    public static int[] weights(int roundNumber) {
        Rarity[] rs = Rarity.values();
        int[] w = new int[rs.length];
        for (int i = 0; i < rs.length; i++) w[i] = rs[i].baseWeight();
        int from = Config.ESCALATE_FROM_ROUND.get();
        int u = Rarity.UNCOMMON.ordinal(), ep = Rarity.EPIC.ordinal(), lg = Rarity.LEGENDARY.ordinal();
        if (roundNumber >= from && Config.ESCALATE_STEP.get() > 0) {
            int total = Arrays.stream(w).sum();
            int min = Math.round(total * Config.COMMON_MIN.get() / 100f);
            int shift = Config.ESCALATE_STEP.get() * (roundNumber - from + 1) * total / 100;
            shift = Math.max(0, Math.min(shift, w[u] - min));
            w[u] -= shift;
            w[ep] += shift - shift / 2;
            w[lg] += shift / 2;
        }
        return w;
    }

    private static Rarity rollRarity(int[] w, boolean epicOrBetter) {
        Rarity[] rs = Rarity.values();
        int start = epicOrBetter ? Rarity.EPIC.ordinal() : 0;
        int total = 0;
        for (int i = start; i < w.length; i++) total += w[i];
        if (total <= 0) return epicOrBetter ? Rarity.EPIC : Rarity.COMMON;
        int r = RNG.nextInt(total);
        for (int i = start; i < w.length; i++) {
            r -= w[i];
            if (r < 0) return rs[i];
        }
        return rs[w.length - 1];
    }

    private static boolean eligible(Card c, WData d, List<Card> picked, Set<String> disabled) {
        if (d.cards.contains(c.id) || disabled.contains(c.id) || picked.contains(c)) return false;
        for (String owned : d.cards) {
            Card o = Cards.get(owned);
            // Thần thoại: thẻ khác vẫn được ra để đổi (mất 1 tim vĩnh viễn)
            if (o != null && c.conflictsWith(o) && !(c.rarity == Rarity.MYTHIC && o.rarity == Rarity.MYTHIC)) return false;
        }
        for (Card o : picked) if (c.conflictsWith(o)) return false;
        return true;
    }

    private static Card pickOfRarity(Rarity r, WData d, List<Card> picked, Set<String> disabled) {
        List<Card> pool = new ArrayList<>();
        for (Card c : Cards.ALL.values()) if (c.rarity == r && eligible(c, d, picked, disabled)) pool.add(c);
        return pool.isEmpty() ? null : pool.get(RNG.nextInt(pool.size()));
    }

    private static Card pickNear(Rarity r, WData d, List<Card> picked, Set<String> disabled) {
        Card c = pickOfRarity(r, d, picked, disabled);
        if (c != null) return c;
        Rarity[] rs = Rarity.values();
        for (int dist = 1; dist < rs.length; dist++) {
            for (int sign : new int[]{1, -1}) {
                int i = r.ordinal() + dist * sign;
                if (i < 0 || i >= rs.length) continue;
                c = pickOfRarity(rs[i], d, picked, disabled);
                if (c != null) return c;
            }
        }
        return null;
    }

    /** Rolls 3 different cards. {@code countPity} updates the pity counter. */
    public static List<String> roll(ServerPlayer p, WData d, boolean countPity) {
        Set<String> disabled = new HashSet<>(Config.DISABLED_CARDS.get());
        int[] w = weights(d.round + 1);
        int pityLimit = Config.PITY_ROUNDS.get();
        boolean forceEpic = pityLimit > 0 && d.pity >= pityLimit;
        List<Card> picked = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            Rarity r = rollRarity(w, forceEpic && i == 0);
            Card c = pickNear(r, d, picked, disabled);
            if (c != null) picked.add(c);
        }
        Collections.shuffle(picked, new Random(RNG.nextLong()));
        if (countPity) {
            boolean hasEpic = picked.stream().anyMatch(c -> c.rarity.isEpicOrBetter());
            d.pity = hasEpic ? 0 : d.pity + 1;
        }
        List<String> ids = new ArrayList<>();
        for (Card c : picked) ids.add(c.id);
        return ids;
    }

    // ------------------------------------------------------------------ choosing

    public static void onChoose(ServerPlayer p, int index) {
        WData d = WData.get(p);
        if (!d.choosing) return;
        if (index < 0 || index >= d.offer.size()) return;
        pick(p, d, d.offer.get(index));
    }

    /** Gives the card to the player, announces it and restarts the timer. */
    public static void pick(ServerPlayer p, WData d, String id) {
        Card card = Cards.get(id);
        d.choosing = false;
        d.choiceTicks = 0;
        d.offer.clear();
        d.timer = Config.ROUND_SECONDS.get() * 20;
        Net.toPlayer(p, new Net.Fx("close", 0));
        if (card == null) return;
        grant(p, d, card);

        Component rarity = card.rarity.displayName().copy().withStyle(s -> s.withColor(card.rarity.rgb()).withBold(true));
        Component msg = Component.translatable("msg.wildcard.got", p.getDisplayName(), rarity,
                card.buffName().copy().withStyle(ChatFormatting.GREEN),
                card.debuffName().copy().withStyle(ChatFormatting.RED));
        p.server.getPlayerList().broadcastSystemMessage(msg, false);

        ServerLevel level = p.serverLevel();
        int c = card.rarity.rgb();
        Vector3f col = new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f);
        level.sendParticles(new DustParticleOptions(col, 1.6f), p.getX(), p.getY() + 1, p.getZ(), 80, 0.7, 1.0, 0.7, 0.05);
        level.playSound(null, p.blockPosition(),
                card.rarity.ordinal() >= Rarity.LEGENDARY.ordinal() ? SoundEvents.UI_TOAST_CHALLENGE_COMPLETE : SoundEvents.PLAYER_LEVELUP,
                SoundSource.PLAYERS, 1f, 1f);
        updateBar(p, d);
    }

    /** Adds a card without the choice screen (also used by /wildcard give). */
    public static void grant(ServerPlayer p, WData d, Card card) {
        if (card.rarity == Rarity.MYTHIC) swapMythic(p, d, card);
        d.cards.add(card.id);
        d.round++;
        d.cleanLoadout();
        if (!d.isFull()) {
            d.equipped.add(card.id);
            d.autoFill(card); // new skills go into empty G H J K L slots
        } else {
            p.sendSystemMessage(Component.translatable("msg.wildcard.equipfull", Config.MAX_EQUIPPED.get()).withStyle(ChatFormatting.YELLOW));
        }
        d.extra.put("round", new net.minecraft.nbt.CompoundTag()); // per-round flags reset
        Effects.onGranted(p, card);
        Effects.onRoundStart(p, d);
        sync(p);
        d.save(p);
    }

    /** Only one Mythical card per player: the old one is removed and one heart of max health is lost for good. */
    private static void swapMythic(ServerPlayer p, WData d, Card card) {
        List<String> old = new ArrayList<>();
        for (String id : d.cards) {
            Card c = Cards.get(id);
            if (c != null && c.rarity == Rarity.MYTHIC && !id.equals(card.id)) old.add(id);
        }
        if (old.isEmpty()) return;
        d.cards.removeAll(old);
        d.extra.putInt("mythic_lost", d.extra.getInt("mythic_lost") + 1);
        Card was = Cards.get(old.get(0));
        p.sendSystemMessage(Component.translatable("msg.wildcard.mythicswap", was.buffName(), card.buffName()).withStyle(ChatFormatting.DARK_RED));
        p.level().playSound(null, p.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.6f, 1.4f);
    }

    public static void sync(ServerPlayer p) {
        WData d = WData.get(p);
        d.cleanLoadout();
        Net.toPlayer(p, new Net.Sync(new ArrayList<>(d.cards), new ArrayList<>(d.equipped), PlayerState.get(p).stolenAbility(),
                java.util.Arrays.asList(d.loadout)));
    }

    /**
     * Client put a skill ("cardId:index", or "" to clear) into loadout slot 0..4. If that skill already sits in another
     * slot the two slots swap. A skill that is moved gets a 10 second cooldown so swapping is not free.
     */
    public static void setSlot(ServerPlayer p, int slot, String entry) {
        WData d = WData.get(p);
        if (slot < 0 || slot >= d.loadout.length) return;
        if (!entry.isEmpty() && !d.validEntry(entry)) return;
        String old = d.loadout[slot];
        if (old.equals(entry)) return;
        for (int i = 0; i < d.loadout.length; i++) {
            if (i != slot && !entry.isEmpty() && d.loadout[i].equals(entry)) d.loadout[i] = old;
        }
        d.loadout[slot] = entry;
        if (!entry.isEmpty()) com.hoang.wildcard.effects.Skills.swapCooldown(p, entry, 200);
        sync(p);
        d.save(p);
    }

    /** Equip or unequip an owned card. Each card can change state once per 30 seconds. */
    public static void toggleEquip(ServerPlayer p, String id) {
        WData d = WData.get(p);
        if (!d.cards.contains(id)) return;
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        long left = st.remaining("equip_" + id, now);
        if (left > 0) {
            p.displayClientMessage(Component.translatable("msg.wildcard.equipwait", (left + 19) / 20).withStyle(ChatFormatting.RED), true);
            sync(p);
            return;
        }
        if (d.equipped.contains(id)) {
            d.equipped.remove(id);
        } else {
            if (d.isFull()) {
                p.displayClientMessage(Component.translatable("msg.wildcard.equipmax", Config.MAX_EQUIPPED.get()).withStyle(ChatFormatting.RED), true);
                sync(p);
                return;
            }
            d.equipped.add(id);
            Card c = Cards.get(id);
            if (c != null) d.autoFill(c);
        }
        st.setCooldown("equip_" + id, now + 600);
        sync(p);
        d.save(p);
    }

    // ------------------------------------------------------------------ lifecycle

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            WData d = WData.get(p);
            sync(p);
            if (d.choosing && !d.offer.isEmpty()) sendOffer(p, d);
            updateBar(p, d);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        Player p = e.getEntity();
        ServerBossEvent bar = BARS.remove(p.getUUID());
        if (bar != null) bar.removeAllPlayers();
        if (!p.level().isClientSide) {
            WData.unload(p);
            PlayerState.remove(p);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            WData.get(p).save(p); // same UUID -> cached data, write it into the new player's NBT
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            sync(p);
            WData d = WData.get(p);
            if (d.choosing && !d.offer.isEmpty()) sendOffer(p, d);
            updateBar(p, d);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) sync(p);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        WData.clearAll();
        PlayerState.clearAll();
        BARS.clear();
    }

    private RoundManager() {}
}
