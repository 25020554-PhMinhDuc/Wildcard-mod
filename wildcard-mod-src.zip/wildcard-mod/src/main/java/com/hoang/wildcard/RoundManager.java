package com.hoang.wildcard;

import com.hoang.wildcard.effects.Effects;
import com.hoang.wildcard.effects.PlayerState;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.*;

/** Round timer, card rolling (rarity weights, pity, escalation, conflicts) and applying the pick. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class RoundManager {
    private static final Map<UUID, ServerBossEvent> BARS = new HashMap<>();
    private static final RandomSource RNG = RandomSource.create();

    // ------------------------------------------------------------------ ticking

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide) return;
        if (!(e.player instanceof ServerPlayer p) || p.isSpectator()) return;
        WData d = WData.get(p);

        if (d.choosing) {
            d.choiceTicks--;
            if (Config.PROTECT_WHILE_CHOOSING.get() && p.tickCount % 10 == 0) freezeMobs(p);
            if (d.choiceTicks % 20 == 0) updateBar(p, d);
            if (d.choiceTicks <= 0 && !d.offer.isEmpty()) {
                p.sendSystemMessage(Component.translatable("msg.wildcard.auto").withStyle(ChatFormatting.GRAY));
                pick(p, d, d.offer.get(RNG.nextInt(d.offer.size())));
            }
            return;
        }
        if (!p.isAlive()) return;

        d.timer--;
        int warn = Config.WARN_SECONDS.get() * 20;
        if (warn > 0 && d.timer == warn) {
            p.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.MASTER, 1f, 1.2f);
        }
        if (d.timer % 20 == 0) updateBar(p, d);
        if (d.timer <= 0) startChoice(p, d);
        if (p.tickCount % 200 == 0) d.save(p);
    }

    private static void freezeMobs(ServerPlayer p) {
        for (Mob m : p.level().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16))) {
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 10, false, false));
            if (m.getTarget() == p) m.setTarget(null);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttack(LivingAttackEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && Config.PROTECT_WHILE_CHOOSING.get() && WData.get(p).choosing) {
            e.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ boss bar

    private static void updateBar(ServerPlayer p, WData d) {
        ServerBossEvent bar = BARS.computeIfAbsent(p.getUUID(), u -> new ServerBossEvent(
                Component.empty(), BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.NOTCHED_10));
        if (!bar.getPlayers().contains(p)) {
            bar.removeAllPlayers();
            bar.addPlayer(p);
        }
        if (d.choosing) {
            bar.setName(Component.translatable("bossbar.wildcard.choosing").withStyle(ChatFormatting.GOLD));
            bar.setColor(BossEvent.BossBarColor.PURPLE);
            bar.setProgress(Math.max(0f, d.choiceTicks / (Config.CHOICE_SECONDS.get() * 20f)));
        } else {
            int s = Math.max(0, d.timer / 20);
            String time = String.format("%d:%02d", s / 60, s % 60);
            bar.setName(Component.translatable("bossbar.wildcard.next", time).withStyle(ChatFormatting.YELLOW));
            bar.setColor(s <= Config.WARN_SECONDS.get() ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.YELLOW);
            bar.setProgress(Math.max(0f, Math.min(1f, d.timer / (Config.ROUND_SECONDS.get() * 20f))));
        }
    }

    // ------------------------------------------------------------------ rolling

    public static void startChoice(ServerPlayer p, WData d) {
        List<String> offer = roll(p, d, true);
        if (offer.isEmpty()) { // every card owned or disabled
            d.timer = Config.ROUND_SECONDS.get() * 20;
            return;
        }
        setOffer(d, offer);
        d.extra.putInt("rerolls", Config.FREE_REROLLS.get());
        d.choosing = true;
        d.choiceTicks = Config.CHOICE_SECONDS.get() * 20;
        p.playNotifySound(SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.MASTER, 1f, 1f);
        sendOffer(p, d);
        updateBar(p, d);
    }

    private static void sendOffer(ServerPlayer p, WData d) {
        Net.toPlayer(p, new Net.OpenChoice(new ArrayList<>(d.offer), Math.max(1, d.choiceTicks / 20), d.round + 1, d.extra.getInt("rerolls")));
    }

    /** v7.1: bất lợi ẩn - một số thẻ chưa sở hữu giấu bất lợi tới khi được chọn (đánh dấu "?" trước id). */
    private static void setOffer(WData d, List<String> offer) {
        d.offer.clear();
        for (String id : offer) {
            boolean hide = !d.cards.contains(id) && RNG.nextDouble() < Config.HIDDEN_DEBUFF_CHANCE.get();
            d.offer.add(hide ? "?" + id : id);
        }
    }

    /** v7.2: reroll miễn phí - đổi cả lượt thẻ đang chọn (thời gian chọn giữ nguyên). */
    public static void reroll(ServerPlayer p) {
        WData d = WData.get(p);
        int left = d.extra.getInt("rerolls");
        if (!d.choosing || left <= 0) return;
        List<String> offer = roll(p, d, false);
        if (offer.isEmpty()) return;
        d.extra.putInt("rerolls", left - 1);
        setOffer(d, offer);
        p.playNotifySound(SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.MASTER, 1f, 1.3f);
        sendOffer(p, d);
    }

    /**
     * Rarity of one slot. Mythic / Legendary / Epic use fixed percentages; everything else is drawn from a virtual
     * deck of {@code poolSize} cards in which every Rare and Uncommon card appears once and Common cards are copied
     * until the deck is full, so Rare cards are hard to get.
     */
    public static Rarity rollRarity() {
        double r = RNG.nextDouble() * 100;
        double m = Config.CHANCE_MYTHIC.get(), l = Config.CHANCE_LEGENDARY.get(), e = Config.CHANCE_EPIC.get();
        if (r < m) return Rarity.MYTHIC;
        if (r < m + l) return Rarity.LEGENDARY;
        if (r < m + l + e) return Rarity.EPIC;
        int[] count = new int[Rarity.values().length];
        for (Card c : Cards.ALL.values()) count[c.rarity.ordinal()]++;
        int vip = count[Rarity.EPIC.ordinal()] + count[Rarity.LEGENDARY.ordinal()] + count[Rarity.MYTHIC.ordinal()];
        int rare = count[Rarity.RARE.ordinal()], unc = count[Rarity.UNCOMMON.ordinal()];
        int common = Math.max(count[Rarity.COMMON.ordinal()], Config.POOL_SIZE.get() - vip - rare - unc);
        int pick = RNG.nextInt(rare + unc + common);
        if (pick < rare) return Rarity.RARE;
        if (pick < rare + unc) return Rarity.UNCOMMON;
        return Rarity.COMMON;
    }

    /** Odds of each rarity per slot in percent (for /wildcard info and the README). */
    public static double[] odds() {
        double[] out = new double[Rarity.values().length];
        double m = Config.CHANCE_MYTHIC.get(), l = Config.CHANCE_LEGENDARY.get(), e = Config.CHANCE_EPIC.get();
        int[] count = new int[Rarity.values().length];
        for (Card c : Cards.ALL.values()) count[c.rarity.ordinal()]++;
        int vip = count[Rarity.EPIC.ordinal()] + count[Rarity.LEGENDARY.ordinal()] + count[Rarity.MYTHIC.ordinal()];
        int rare = count[Rarity.RARE.ordinal()], unc = count[Rarity.UNCOMMON.ordinal()];
        int common = Math.max(count[Rarity.COMMON.ordinal()], Config.POOL_SIZE.get() - vip - rare - unc);
        double rest = Math.max(0, 100 - m - l - e), total = rare + unc + common;
        out[Rarity.MYTHIC.ordinal()] = m;
        out[Rarity.LEGENDARY.ordinal()] = l;
        out[Rarity.EPIC.ordinal()] = e;
        out[Rarity.RARE.ordinal()] = rest * rare / total;
        out[Rarity.UNCOMMON.ordinal()] = rest * unc / total;
        out[Rarity.COMMON.ordinal()] = rest * common / total;
        return out;
    }

    /** A card the player could get as a new card (owned cards excluded, conflicts respected). */
    private static boolean eligibleNew(Card c, WData d, List<Card> picked, Set<String> disabled) {
        if (d.cards.contains(c.id) || disabled.contains(c.id) || picked.contains(c)) return false;
        for (String owned : d.cards) {
            Card o = Cards.get(owned);
            // Thần thoại: thẻ khác vẫn được ra để đổi (mất 1 tim vĩnh viễn)
            if (o != null && c.conflictsWith(o) && !(c.rarity == Rarity.MYTHIC && o.rarity == Rarity.MYTHIC)) return false;
        }
        for (Card o : picked) if (c.conflictsWith(o)) return false;
        return true;
    }

    /**
     * One card of rarity {@code r}. With {@code trungThePercent} chance (or when nothing new is left) it is a card
     * the player already owns: picking it again adds a star. {@code anyCard} (pity) draws from every card of that
     * rarity, owned or not ("lệch bảo hiểm").
     */
    private static Card pickOfRarity(Rarity r, WData d, List<Card> picked, Set<String> disabled, boolean anyCard) {
        List<Card> fresh = new ArrayList<>(), owned = new ArrayList<>(), all = new ArrayList<>();
        for (Card c : Cards.ALL.values()) {
            if (c.rarity != r || disabled.contains(c.id) || picked.contains(c)) continue;
            boolean maxed = d.stars.getOrDefault(c.id, 0) >= Card.MAX_STARS;
            if (maxed) continue; // v5: thẻ đủ 5 sao không ra lại nữa
            all.add(c);
            if (d.cards.contains(c.id)) owned.add(c);
            else if (eligibleNew(c, d, picked, disabled)) fresh.add(c);
        }
        if (anyCard && !all.isEmpty()) return all.get(RNG.nextInt(all.size()));
        boolean dupe = !owned.isEmpty() && (fresh.isEmpty() || RNG.nextDouble() * 100 < Config.DUPLICATE_CHANCE.get());
        List<Card> pool = dupe ? owned : fresh;
        return pool.isEmpty() ? null : pool.get(RNG.nextInt(pool.size()));
    }

    private static Card pickNear(Rarity r, WData d, List<Card> picked, Set<String> disabled) {
        Card c = pickOfRarity(r, d, picked, disabled, false);
        if (c != null) return c;
        for (int i = r.ordinal() - 1; i >= 0; i--) { // fall back to lower rarities only
            c = pickOfRarity(Rarity.values()[i], d, picked, disabled, false);
            if (c != null) return c;
        }
        return null;
    }

    /**
     * v5 rewards (achievements, bosses, card rain): one card of rarity {@code min} or better, rolled with the normal
     * odds but never below {@code min}. Falls back to other rarities when one has nothing left.
     */
    public static Card rewardCard(WData d, Rarity min) {
        Rarity r = min;
        for (int i = 0; i < 2000; i++) {
            Rarity x = rollRarity();
            if (x.ordinal() >= min.ordinal()) {
                r = x;
                break;
            }
        }
        Set<String> disabled = new HashSet<>(Config.DISABLED_CARDS.get());
        List<Card> none = new ArrayList<>();
        for (int k = r.ordinal(); k < Rarity.values().length; k++) {
            Card c = pickOfRarity(Rarity.values()[k], d, none, disabled, false);
            if (c != null) return c;
        }
        for (int k = r.ordinal() - 1; k >= min.ordinal(); k--) {
            Card c = pickOfRarity(Rarity.values()[k], d, none, disabled, false);
            if (c != null) return c;
        }
        return null;
    }

    /** A card of exactly rarity {@code r} (e.g. the dragon's Legendary); if none is left, {@link #rewardCard}. */
    public static Card exactCard(WData d, Rarity r) {
        Card c = pickOfRarity(r, d, new ArrayList<>(), new HashSet<>(Config.DISABLED_CARDS.get()), false);
        return c != null ? c : rewardCard(d, r);
    }

    /** Gives a reward card right away and tells everyone why ({@code reason} is a translated text). */
    public static void giveReward(ServerPlayer p, Card card, Component reason) {
        if (card == null) {
            p.sendSystemMessage(Component.translatable("msg.wildcard.reward.none", reason).withStyle(ChatFormatting.GRAY));
            return;
        }
        WData d = WData.get(p);
        grant(p, d, card);
        Component rarity = card.rarity.displayName().copy().withStyle(s -> s.withColor(card.rarity.rgb()).withBold(true));
        p.server.getPlayerList().broadcastSystemMessage(Component.translatable("msg.wildcard.reward", p.getDisplayName(), reason, rarity,
                card.buffName().copy().withStyle(ChatFormatting.GREEN)), false);
        p.level().playSound(null, p.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1.2f);
    }

    /** Rolls {@link Config#OFFER_CARDS} different cards (5 from v7.2). {@code countPity} updates the pity counters. */
    public static List<String> roll(ServerPlayer p, WData d, boolean countPity) {
        Set<String> disabled = new HashSet<>(Config.DISABLED_CARDS.get());
        int pl = Config.PITY_LEGENDARY.get(), pm = Config.PITY_MYTHIC.get();
        boolean forceMythic = pm > 0 && d.pityMythic >= pm;
        boolean forceLegendary = !forceMythic && pl > 0 && d.pityLegendary >= pl;
        List<Card> picked = new ArrayList<>();
        for (int i = 0; i < Config.OFFER_CARDS.get(); i++) {
            Card c;
            if (i == 0 && forceMythic) c = pickOfRarity(Rarity.MYTHIC, d, picked, disabled, true);
            else if (i == 0 && forceLegendary) c = pickOfRarity(Rarity.LEGENDARY, d, picked, disabled, true);
            else c = pickNear(rollRarity(), d, picked, disabled);
            if (c != null) picked.add(c);
        }
        Collections.shuffle(picked, new Random(RNG.nextLong()));
        if (countPity) {
            boolean myth = picked.stream().anyMatch(c -> c.rarity == Rarity.MYTHIC);
            boolean leg = myth || picked.stream().anyMatch(c -> c.rarity == Rarity.LEGENDARY);
            d.pityMythic = myth ? 0 : d.pityMythic + 1;
            d.pityLegendary = leg ? 0 : d.pityLegendary + 1;
        }
        List<String> ids = new ArrayList<>();
        for (Card c : picked) ids.add(c.id);
        return ids;
    }

    // ------------------------------------------------------------------ choosing

    public static void onChoose(ServerPlayer p, int index) {
        WData d = WData.get(p);
        if (!d.choosing) return;
        if (index < 0 || index >= d.offer.size()) return;
        pick(p, d, d.offer.get(index));
    }

    /** Gives the card to the player, announces it and restarts the timer. */
    public static void pick(ServerPlayer p, WData d, String id) {
        boolean hidden = id.startsWith("?");
        if (hidden) id = id.substring(1);
        Card card = Cards.get(id);
        d.choosing = false;
        d.choiceTicks = 0;
        d.offer.clear();
        d.timer = Config.ROUND_SECONDS.get() * 20;
        Net.toPlayer(p, new Net.Fx("close", 0));
        if (card == null) return;
        grant(p, d, card);

        Component rarity = card.rarity.displayName().copy().withStyle(s -> s.withColor(card.rarity.rgb()).withBold(true));
        Component msg = Component.translatable("msg.wildcard.got", p.getDisplayName(), rarity,
                card.buffName().copy().withStyle(ChatFormatting.GREEN),
                card.debuffName().copy().withStyle(ChatFormatting.RED));
        p.server.getPlayerList().broadcastSystemMessage(msg, false);
        if (hidden) { // lộ diện bất lợi ẩn
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(
                    Component.translatable("gui.wildcard.hidden.reveal").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)));
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(card.debuffName().copy().withStyle(ChatFormatting.RED)));
            p.sendSystemMessage(Component.translatable("msg.wildcard.hidden.reveal", card.debuffName().copy().withStyle(ChatFormatting.RED, ChatFormatting.BOLD),
                    card.debuffDesc().copy().withStyle(ChatFormatting.GRAY)).withStyle(ChatFormatting.DARK_RED));
            p.playNotifySound(SoundEvents.ELDER_GUARDIAN_CURSE, SoundSource.MASTER, 0.6f, 1.2f);
        }

        ServerLevel level = p.serverLevel();
        int c = card.rarity.rgb();
        Vector3f col = new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f);
        level.sendParticles(new DustParticleOptions(col, 1.6f), p.getX(), p.getY() + 1, p.getZ(), 80, 0.7, 1.0, 0.7, 0.05);
        level.playSound(null, p.blockPosition(),
                card.rarity.ordinal() >= Rarity.LEGENDARY.ordinal() ? SoundEvents.UI_TOAST_CHALLENGE_COMPLETE : SoundEvents.PLAYER_LEVELUP,
                SoundSource.PLAYERS, 1f, 1f);
        updateBar(p, d);
    }

    /** Adds a card without the choice screen (also used by /wildcard give). */
    public static void grant(ServerPlayer p, WData d, Card card) {
        boolean dupe = d.cards.contains(card.id);
        // v7: được sở hữu nhiều thẻ Mythic, nhưng chỉ trang bị 1 thẻ Mythic một lúc
        boolean otherMythic = !dupe && card.rarity == Rarity.MYTHIC && equippedMythic(d, card.id) != null;
        d.round++;
        d.cleanLoadout();
        if (dupe) { // trùng thẻ: lên sao (mạnh hơn, bất lợi nhẹ hơn, hồi chiêu ngắn hơn), tối đa 5 sao
            int had = d.stars.getOrDefault(card.id, 0);
            if (had >= Card.MAX_STARS) {
                p.sendSystemMessage(Component.translatable("msg.wildcard.duplicate.max", card.buffName()).withStyle(ChatFormatting.GRAY));
            } else {
                d.stars.put(card.id, had + 1);
                p.sendSystemMessage(Component.translatable(card.skills.isEmpty() ? "msg.wildcard.duplicate.plain" : "msg.wildcard.duplicate",
                        card.buffName(), Card.starText(had + 1, false)).withStyle(ChatFormatting.AQUA));
            }
        }
        d.cards.add(card.id);
        if (dupe) {
            // already owned: nothing to equip
        } else if (otherMythic) {
            Card on = Cards.get(equippedMythic(d, card.id));
            p.sendSystemMessage(Component.translatable("msg.wildcard.mythic.stored", card.buffName(), on != null ? on.buffName() : Component.literal("?"))
                    .withStyle(ChatFormatting.LIGHT_PURPLE));
        } else if (!d.isFull()) {
            d.equipped.add(card.id);
            d.autoFill(card); // new skills go into empty G H J K L slots
        } else {
            p.sendSystemMessage(Component.translatable("msg.wildcard.equipfull", Config.MAX_EQUIPPED.get()).withStyle(ChatFormatting.YELLOW));
        }
        d.extra.put("round", new net.minecraft.nbt.CompoundTag()); // per-round flags reset
        if (!dupe) Effects.onGranted(p, card);
        com.hoang.wildcard.fx.Element fxEl = switch (card.rarity) {
            case COMMON -> com.hoang.wildcard.fx.Element.WIND;
            case UNCOMMON -> com.hoang.wildcard.fx.Element.EARTH;
            case RARE -> com.hoang.wildcard.fx.Element.FROST;
            case EPIC -> com.hoang.wildcard.fx.Element.ARCANE;
            case LEGENDARY -> com.hoang.wildcard.fx.Element.HOLY;
            case MYTHIC -> com.hoang.wildcard.fx.Element.BLOOD;
        };
        com.hoang.wildcard.fx.Fx.circle(p.serverLevel(), p.position().add(0, 0.05, 0), fxEl, 1.6, 28, true);
        com.hoang.wildcard.fx.Fx.burst(p.serverLevel(), p.position().add(0, 1, 0), fxEl, 40, 0.3);
        Effects.onRoundStart(p, d);
        com.hoang.wildcard.effects.TrollDebuffs.onRoundStart(p);
        com.hoang.wildcard.effects.MemeCards.onRoundStart(p);
        sync(p);
        d.save(p);
    }

    /** v7: id of an equipped Mythic card other than {@code except}, or null. */
    static String equippedMythic(WData d, String except) {
        for (String id : d.equipped) {
            Card c = Cards.get(id);
            if (c != null && c.rarity == Rarity.MYTHIC && !id.equals(except)) return id;
        }
        return null;
    }

    public static void sync(ServerPlayer p) {
        WData d = WData.get(p);
        d.cleanLoadout();
        List<String> stars = new ArrayList<>();
        for (Map.Entry<String, Integer> e : d.stars.entrySet()) stars.add(e.getKey() + "=" + e.getValue());
        Net.toPlayer(p, new Net.Sync(new ArrayList<>(d.cards), new ArrayList<>(d.equipped), PlayerState.get(p).stolenAbility(),
                java.util.Arrays.asList(d.loadout), stars));
    }

    /**
     * Client put a skill ("cardId:index", or "" to clear) into loadout slot 0..4. If that skill already sits in another
     * slot the two slots swap. A skill that is moved gets a 10 second cooldown so swapping is not free.
     */
    public static void setSlot(ServerPlayer p, int slot, String entry) {
        WData d = WData.get(p);
        if (slot < 0 || slot >= d.loadout.length) return;
        if (!entry.isEmpty() && !d.validEntry(entry)) return;
        String old = d.loadout[slot];
        if (old.equals(entry)) return;
        for (int i = 0; i < d.loadout.length; i++) {
            if (i != slot && !entry.isEmpty() && d.loadout[i].equals(entry)) d.loadout[i] = old;
        }
        d.loadout[slot] = entry;
        if (!entry.isEmpty()) com.hoang.wildcard.effects.Skills.swapCooldown(p, entry, 200);
        sync(p);
        d.save(p);
    }

    /** Equip or unequip an owned card. Each card can change state once per 30 seconds. */
    public static void toggleEquip(ServerPlayer p, String id) {
        WData d = WData.get(p);
        if (!d.cards.contains(id)) return;
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        long left = st.remaining("equip_" + id, now);
        if (left > 0) {
            p.displayClientMessage(Component.translatable("msg.wildcard.equipwait", (left + 19) / 20).withStyle(ChatFormatting.RED), true);
            sync(p);
            return;
        }
        if (d.equipped.contains(id)) {
            d.equipped.remove(id);
        } else {
            if (d.isFull()) {
                p.displayClientMessage(Component.translatable("msg.wildcard.equipmax", Config.MAX_EQUIPPED.get()).withStyle(ChatFormatting.RED), true);
                sync(p);
                return;
            }
            Card c = Cards.get(id);
            String old = c != null && c.rarity == Rarity.MYTHIC ? equippedMythic(d, id) : null;
            if (old != null) { // v7: chỉ 1 Mythic được trang bị: thẻ Mythic cũ tự tháo ra (vẫn còn trong bộ sưu tập)
                d.equipped.remove(old);
                Card oc = Cards.get(old);
                p.displayClientMessage(Component.translatable("msg.wildcard.mythic.swapequip", oc != null ? oc.buffName() : Component.literal(old), c.buffName())
                        .withStyle(ChatFormatting.LIGHT_PURPLE), true);
            }
            d.equipped.add(id);
            if (c != null) d.autoFill(c);
        }
        st.setCooldown("equip_" + id, now + 600);
        sync(p);
        d.save(p);
    }

    // ------------------------------------------------------------------ lifecycle

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            WData d = WData.get(p);
            sync(p);
            if (d.choosing && !d.offer.isEmpty()) sendOffer(p, d);
            updateBar(p, d);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        Player p = e.getEntity();
        ServerBossEvent bar = BARS.remove(p.getUUID());
        if (bar != null) bar.removeAllPlayers();
        if (!p.level().isClientSide) {
            WData.unload(p);
            PlayerState.remove(p);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            WData.get(p).save(p); // same UUID -> cached data, write it into the new player's NBT
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            sync(p);
            WData d = WData.get(p);
            if (d.choosing && !d.offer.isEmpty()) sendOffer(p, d);
            updateBar(p, d);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) sync(p);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        WData.clearAll();
        PlayerState.clearAll();
        BARS.clear();
    }

    private RoundManager() {}
}
