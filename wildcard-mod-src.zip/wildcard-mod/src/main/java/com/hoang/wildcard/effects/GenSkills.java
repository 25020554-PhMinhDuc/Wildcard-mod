package com.hoang.wildcard.effects;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.GenSkill;
import com.hoang.wildcard.ModSounds;
import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.Fx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

/** Runs the data-driven skills (GenSkill). Hits hostile mobs and, when PvP is on, other players. */
public final class GenSkills {
    public static Element element(GenSkill s) {
        try {
            return Element.valueOf(s.element().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return Element.ARCANE;
        }
    }

    static boolean run(ServerPlayer p, Card c) {
        GenSkill s = c.genSkill;
        ServerLevel level = p.serverLevel();
        Element el = element(s);
        float a = (float) s.a();
        switch (s.kind()) {
            case "bolt" -> {
                LivingEntity t = Skills.aim(p, s.b());
                if (t == null) return Skills.noTarget(p);
                if (el == Element.STORM) Fx.zap(level, p.getEyePosition(), t.getEyePosition(), el);
                else Fx.beam(level, p.getEyePosition().subtract(0, 0.2, 0), t.getEyePosition(), el);
                Fx.burst(level, t.getEyePosition(), el, 16, 0.25);
                Skills.trueHurt(p, t, a);
                switch (s.eff()) {
                    case "fire" -> t.setSecondsOnFire(4);
                    case "slowness" -> t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                    case "glowing" -> t.addEffect(new MobEffectInstance(MobEffects.GLOWING, 120, 0));
                    case "weakness" -> t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
                    case "lifesteal" -> p.heal(a * 0.3f);
                    default -> {
                    }
                }
            }
            case "nova" -> Skills.shockwave(p, s.b(), a);
            case "heal" -> {
                p.heal(a * Skills.starMul(p)); // v7.3: sao tăng lượng hồi
                Fx.burst(level, p.position().add(0, 1, 0), el, 20, 0.2);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, 3, 14);
                com.hoang.wildcard.fx.Vfx.pillar(level, p.position(), el, 4, 0.8, 30);
            }
            case "buff" -> {
                MobEffect e = GenEffects.effect(s.eff());
                if (e != null) Skills.self(p, e, (int) (s.b() * 20 * Skills.starMul(p)), s.amp()); // v7.3: sao kéo dài
                com.hoang.wildcard.fx.Vfx.pillar(level, p.position(), el, 2.5, 0.6, 20);
                com.hoang.wildcard.fx.Vfx.vortex(level, p.position(), el, 1.0, 2.2, 16);
            }
            case "curse" -> {
                MobEffect e = GenEffects.effect(s.eff());
                if (e == null) return false;
                int ticks = (int) (s.b() * 20 * Skills.starMul(p));
                Skills.forFoes(p, s.a(), le -> le.addEffect(new MobEffectInstance(e, ticks, s.amp())));
                Fx.circle(level, p.position().add(0, 0.1, 0), el, s.a(), 32, true);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, s.a(), 14);
                com.hoang.wildcard.fx.Vfx.area(level, p.position().add(0, 0.02, 0), el, s.a(), 50);
            }
            case "dash" -> {
                Vec3 l = Skills.flatLook(p);
                Skills.push(p, new Vec3(l.x * a, 0.25, l.z * a));
                Skills.noFall(p, 60);
                Fx.trail(level, p.position().add(0, 0.5, 0), p.position().add(l.scale(a * 3)).add(0, 0.5, 0), el);
                Fx.burst(level, p.position().add(0, 0.6, 0), el, 10, 0.2);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, 1.8, 8);
            }
            case "leap" -> {
                Skills.push(p, p.getDeltaMovement().add(0, a, 0));
                Fx.ring(level, p.position().add(0, 0.1, 0), el, 2.5, 10);
                com.hoang.wildcard.fx.Vfx.vortex(level, p.position(), el, 1.2, 3, 12);
                Skills.noFall(p, 160);
            }
            case "blink" -> {
                Vec3 to = Skills.lookPoint(p, a);
                BlockHitResult hit = Skills.blockLook(p, a);
                if (hit != null) to = Vec3.atBottomCenterOf(hit.getBlockPos().relative(hit.getDirection()));
                double yaw = Math.atan2(p.getLookAngle().z, p.getLookAngle().x) + Math.PI / 2;
                com.hoang.wildcard.fx.Vfx.portal(level, p.position().add(0, 1, 0), el, yaw, 1.2, 20);
                com.hoang.wildcard.fx.Vfx.portal(level, to.add(0, 1, 0), el, yaw, 1.2, 20);
                p.teleportTo(to.x, to.y, to.z);
                p.fallDistance = 0;
                Skills.sound(p, SoundEvents.ENDERMAN_TELEPORT, 1.2f);
            }
            case "shield" -> {
                Skills.self(p, MobEffects.ABSORPTION, 200, s.amp());
                com.hoang.wildcard.fx.Vfx.dome(level, p.position(), el, 1.8, 40);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, 2.2, 14);
            }
            case "feast" -> {
                p.getFoodData().eat((int) a, 0.6f);
                com.hoang.wildcard.fx.Vfx.pillar(level, p.position(), el, 2, 0.5, 16);
                Skills.sound(p, SoundEvents.GENERIC_EAT, 1f);
            }
            case "summon" -> {
                for (int i = 0; i < (int) a; i++) {
                    Wolf w = EntityType.WOLF.create(level);
                    if (w == null) continue;
                    w.moveTo(p.getX() + p.getRandom().nextGaussian(), p.getY(), p.getZ() + p.getRandom().nextGaussian(), p.getYRot(), 0);
                    w.tame(p);
                    w.getPersistentData().putUUID(Effects.OWNER_TAG, p.getUUID());
                    level.addFreshEntity(w);
                    com.hoang.wildcard.fx.Vfx.portal(level, w.position().add(0, 0.8, 0), el, Math.toRadians(p.getYRot()), 1.0, 20);
                    AllyTracker.track(w, 400);
                }
                Skills.sound(p, SoundEvents.WOLF_HOWL, 1.1f);
            }
            case "meteor" -> {
                int n = Math.max(1, (int) a);
                for (int i = 0; i < n; i++) Skills.fireball(p, (i - (n - 1) / 2f) * 8f);
                Skills.sound(p, SoundEvents.BLAZE_SHOOT, 1f);
            }
            case "pull" -> {
                for (Entity e : level.getEntities(p, p.getBoundingBox().inflate(s.b()), x -> x instanceof LivingEntity le && Skills.foe(p, le))) {
                    Vec3 pull = p.position().subtract(e.position());
                    Skills.push(e, pull.normalize().scale(Math.min(1.6, pull.length() * 0.3)).add(0, 0.3, 0));
                }
                Fx.circle(level, p.position().add(0, 0.1, 0), el, s.b(), 32, true);
                Fx.ring(level, p.position().add(0, 0.1, 0), el, s.b(), 14);
                com.hoang.wildcard.fx.Vfx.vortex(level, p.position(), el, s.b() * 0.6, 1.5, 20);
            }
            case "taunt" -> {
                for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(10), x -> x instanceof Enemy)) m.setTarget(p);
                Skills.self(p, MobEffects.DAMAGE_RESISTANCE, 100, s.amp());
                com.hoang.wildcard.fx.Vfx.pillar(level, p.position(), Element.BLOOD, 5, 0.9, 30);
                Fx.ring(level, p.position().add(0, 0.1, 0), Element.BLOOD, 10, 16);
                TrollDebuffs.soundAll(p, ModSounds.VINE_BOOM.get(), 2f);
            }
            case "sigma" -> {
                LivingEntity t = Skills.aim(p, 16);
                if (t == null) return Skills.noTarget(p);
                t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, s.amp()));
                t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 0));
                t.addEffect(new MobEffectInstance(MobEffects.GLOWING, 160, 0));
                Fx.trail(level, p.getEyePosition(), t.getEyePosition(), el);
                com.hoang.wildcard.fx.Vfx.pillar(level, t.position(), el, 3, 0.7, 30);
                TrollDebuffs.soundAll(p, ModSounds.SIGMA.get(), 1.5f);
            }
            case "sus" -> {
                p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 120, 0, false, false, true));
                com.hoang.wildcard.fx.Vfx.burst(level, p.position().add(0, 1, 0), el, 1.5);
                Skills.clearAggro(p, 24);
                TrollDebuffs.soundAll(p, ModSounds.SUS.get(), 1.2f);
            }
            default -> {
                return Spells.run(p, s, el);
            }
        }
        return true;
    }

    private GenSkills() {}
}
