package com.hoang.wildcard.fx;

import com.hoang.wildcard.WildcardMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

/** Our own particle types: a spark and a floating rune for each {@link Element}. */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> REG = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, WildcardMod.MODID);
    public static final Map<Element, RegistryObject<SimpleParticleType>> SPARK = new EnumMap<>(Element.class);
    public static final Map<Element, RegistryObject<SimpleParticleType>> RUNE = new EnumMap<>(Element.class);

    static {
        for (Element e : Element.values()) {
            SPARK.put(e, REG.register(e.key() + "_spark", () -> new SimpleParticleType(true)));
            RUNE.put(e, REG.register(e.key() + "_rune", () -> new SimpleParticleType(true)));
        }
    }

    public static void register(IEventBus modBus) {
        REG.register(modBus);
    }

    private ModParticles() {}
}
