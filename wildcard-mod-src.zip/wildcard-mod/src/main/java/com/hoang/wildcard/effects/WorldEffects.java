package com.hoang.wildcard.effects;

import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.net.Net;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.MerchantMenu;
import net.minecraft.world.item.*;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

import static com.hoang.wildcard.effects.Effects.*;

/** Mining, placing, eating, sleeping, fishing, trading, projectiles, items, jumping and falling. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class WorldEffects {
    private static boolean breakingArea;

    // ================================================================== mining

    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        Player p = e.getEntity();
        BlockState s = e.getState();
        float speed = e.getNewSpeed();
        if (s.is(BlockTags.LOGS)) {
            if (has(p, "c11")) speed *= 1.5f;                                              // Tiều Phu
            if (has(p, "u16") && p.getMainHandItem().getItem() instanceof AxeItem) speed *= 0.7f; // Rìu Cùn
        }
        if (has(p, "l10") && (s.is(Blocks.OBSIDIAN) || s.is(Blocks.CRYING_OBSIDIAN))) speed *= 50f; // Thánh Đào Mỏ
        e.setNewSpeed(speed);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || !(e.getLevel() instanceof ServerLevel level)) return;
        if (p.isCreative()) return;
        BlockState s = e.getState();
        BlockPos pos = e.getPos();
        RandomSource rng = p.getRandom();
        ItemStack tool = p.getMainHandItem();
        boolean stone = s.is(Tags.Blocks.STONE) || s.is(BlockTags.BASE_STONE_OVERWORLD);
        boolean ore = s.is(Tags.Blocks.ORES);
        boolean dirt = s.is(BlockTags.DIRT) || s.is(BlockTags.SAND) || s.is(Blocks.GRAVEL);

        if (has(p, "c03") && tool.getItem() instanceof PickaxeItem && rng.nextFloat() < 0.03f) { // Tay Trơn
            ItemStack copy = tool.copy();
            p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
            ItemEntity ie = p.drop(copy, true, false);
            if (ie != null) ie.setPickUpDelay(40);
        }
        if (has(p, "c11") && s.is(BlockTags.LOGS) && tool.isEmpty()) p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.DIG_SLOWDOWN, 60, 0)); // Dằm Gỗ
        if (has(p, "c17") && stone) { // Đuốc Miễn Phí
            int n = com.hoang.wildcard.WData.get(p).extra.getInt("c17_count") + 1;
            if (n >= 64) {
                give(p, new ItemStack(Items.TORCH));
                n = 0;
            }
            com.hoang.wildcard.WData.get(p).extra.putInt("c17_count", n);
        }
        if (has(p, "c18") && s.getBlock() instanceof CropBlock crop && crop.isMaxAge(s) && rng.nextFloat() < 0.10f) { // Quạ Đen
            level.removeBlock(pos, false);
            level.playSound(null, pos, SoundEvents.PARROT_IMITATE_PHANTOM, SoundSource.BLOCKS, 0.6f, 1.4f);
            e.setCanceled(true);
            return;
        }
        if (ore && p.hasCorrectToolForDrops(s)) {
            if (has(p, "u01") && rng.nextFloat() < 0.10f) { // Bàn Tay May Mắn
                BlockEntity be = level.getBlockEntity(pos);
                for (ItemStack drop : Block.getDrops(s, level, pos, be, p, tool)) Block.popResource(level, pos, drop);
            }
            if (has(p, "u01")) Net.toPlayer(p, new Net.Fx("flash", 10)); // Lóa Mắt
        }
        if (has(p, "u08") && dirt && rng.nextFloat() < 0.02f) { // Kho Báu Dưới Chân
            Item[] loot = {Items.EMERALD, Items.IRON_INGOT, Items.BONE};
            Block.popResource(level, pos, new ItemStack(loot[rng.nextInt(loot.length)]));
        }
        if (has(p, "r03") && dirt) p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0)); // Bụi Bặm
        if (has(p, "l03") && stone && rng.nextFloat() < 0.05f) Block.popResource(level, pos, new ItemStack(Items.RAW_GOLD)); // Vua Midas
        if (has(p, "l10") && stone && rng.nextFloat() < 0.02f) { // Hang Động Ám Ảnh
            Silverfish sf = EntityType.SILVERFISH.create(level);
            if (sf != null) {
                sf.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0, 0);
                level.addFreshEntity(sf);
                sf.setTarget(p);
            }
        }
        // Bàn Tay Nung Chảy
        if (has(p, "e20") && p.hasCorrectToolForDrops(s) && EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, tool) == 0) {
            Item ingot = smelt(s);
            if (ingot != null) {
                int fortune = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, tool);
                int count = 1 + (fortune > 0 ? rng.nextInt(fortune + 1) : 0);
                level.removeBlock(pos, false);
                Block.popResource(level, pos, new ItemStack(ingot, count));
                ExperienceOrb.award(level, Vec3.atCenterOf(pos), 1 + rng.nextInt(2));
                tool.hurtAndBreak(1, p, pl -> pl.broadcastBreakEvent(EquipmentSlot.MAINHAND));
                level.playSound(null, pos, SoundEvents.FURNACE_FIRE_CRACKLE, SoundSource.BLOCKS, 1f, 1f);
                e.setCanceled(true);
            }
        }
        // Kẻ Hủy Diệt: cúp đào 3x3
        if (has(p, "l05") && !breakingArea && tool.getItem() instanceof PickaxeItem && !p.isShiftKeyDown()) {
            HitResult hit = p.pick(p.getBlockReach(), 1f, false);
            Direction face = hit instanceof BlockHitResult bhr ? bhr.getDirection() : Direction.UP;
            breakingArea = true;
            try {
                for (int a = -1; a <= 1; a++) {
                    for (int b = -1; b <= 1; b++) {
                        if (a == 0 && b == 0) continue;
                        BlockPos q = switch (face.getAxis()) {
                            case X -> pos.offset(0, a, b);
                            case Y -> pos.offset(a, 0, b);
                            case Z -> pos.offset(a, b, 0);
                        };
                        BlockState qs = level.getBlockState(q);
                        if (qs.isAir() || qs.getDestroySpeed(level, q) < 0 || qs.getDestroySpeed(level, q) > 50) continue;
                        if (!p.hasCorrectToolForDrops(qs)) continue;
                        p.gameMode.destroyBlock(q);
                    }
                }
            } finally {
                breakingArea = false;
            }
        }
    }

    private static Item smelt(BlockState s) {
        if (s.is(Blocks.IRON_ORE) || s.is(Blocks.DEEPSLATE_IRON_ORE)) return Items.IRON_INGOT;
        if (s.is(Blocks.GOLD_ORE) || s.is(Blocks.DEEPSLATE_GOLD_ORE) || s.is(Blocks.NETHER_GOLD_ORE)) return Items.GOLD_INGOT;
        if (s.is(Blocks.COPPER_ORE) || s.is(Blocks.DEEPSLATE_COPPER_ORE)) return Items.COPPER_INGOT;
        return null;
    }

    // Nền Móng Yếu: khối đặt có 10% tự vỡ sau 10 giây
    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !(e.getLevel() instanceof ServerLevel level)) return;
        if (has(p, "l05") && p.getRandom().nextFloat() < 0.10f) {
            BlockPos pos = e.getPos().immutable();
            Block block = e.getPlacedBlock().getBlock();
            Scheduler.later(200, () -> {
                if (level.getBlockState(pos).is(block)) level.destroyBlock(pos, true);
            });
        }
    }

    // Bước Nhẹ: không giẫm hỏng đất trồng
    @SubscribeEvent
    public static void onTrample(BlockEvent.FarmlandTrampleEvent e) {
        if (e.getEntity() instanceof Player p && has(p, "c12")) e.setCanceled(true);
    }

    // ================================================================== using items

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack held = e.getItemStack();
        // Kho Vô Tận: đặt khối không bị trừ
        if ((has(p, "l14") || has(p, "m04")) && held.getItem() instanceof BlockItem && !p.isCreative()) {
            final ItemStack ref = held;
            final int count = held.getCount();
            Scheduler.later(1, () -> {
                if (ref.getCount() < count) ref.setCount(count);
                p.inventoryMenu.broadcastChanges();
            });
        }
        // Tường Đất: chuột phải bằng xẻng
        if (has(p, "r03") && held.getItem() instanceof ShovelItem && e.getHand() == InteractionHand.MAIN_HAND) {
            if (dirtWall(p)) {
                e.setCanceled(true);
                e.setCancellationResult(InteractionResult.SUCCESS);
            }
        }
    }

    private static boolean dirtWall(ServerPlayer p) {
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        if (!st.ready("r03", now, 600)) {
            actionCooldown(p, st.remaining("r03", now));
            return false;
        }
        Direction f = p.getDirection();
        BlockPos base = p.blockPosition().relative(f, 2);
        Direction side = f.getClockWise();
        for (int a = -1; a <= 1; a++) {
            for (int y = 0; y < 3; y++) {
                BlockPos q = base.relative(side, a).above(y);
                if (p.level().getBlockState(q).canBeReplaced()) p.level().setBlockAndUpdate(q, Blocks.DIRT.defaultBlockState());
            }
        }
        p.level().playSound(null, base, SoundEvents.GRAVEL_PLACE, SoundSource.BLOCKS, 1f, 0.8f);
        return true;
    }

    static void actionCooldown(ServerPlayer p, long ticks) {
        actionBar(p, Component.translatable("msg.wildcard.cooldown", (ticks + 19) / 20));
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack held = e.getItemStack();
        ServerLevel level = p.serverLevel();
        // Ném Rìu
        if (has(p, "u16") && held.getItem() instanceof AxeItem && e.getHand() == InteractionHand.MAIN_HAND) {
            throwAxe(p, held);
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
            return;
        }
        // Bom Tự Chế
        if (has(p, "l17") && held.is(Items.TNT)) {
            PrimedTnt tnt = new PrimedTnt(level, p.getX(), p.getEyeY() - 0.2, p.getZ(), p);
            tnt.setDeltaMovement(p.getLookAngle().scale(1.2).add(0, 0.2, 0));
            tnt.setFuse(100);
            level.addFreshEntity(tnt);
            AllyTracker.trackTnt(tnt);
            level.playSound(null, p.blockPosition(), SoundEvents.TNT_PRIMED, SoundSource.PLAYERS, 1f, 1f);
            if (!p.isCreative()) held.shrink(1);
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
            return;
        }
        // Móc Câu: thu dây khi phao đã móc vào khối
        if (has(p, "e17") && held.getItem() instanceof FishingRodItem && p.fishing != null) {
            FishingHook hook = p.fishing;
            boolean stuck = !hook.isInWater() && (hook.onGround() || hook.getDeltaMovement().lengthSqr() < 0.01
                    || !level.getBlockState(hook.blockPosition()).isAir());
            if (stuck && hook.getHookedIn() == null) {
                Vec3 pull = hook.position().subtract(p.position());
                double dist = pull.length();
                Vec3 v = pull.normalize().scale(Math.min(3.0, 0.6 + dist * 0.12)).add(0, 0.35, 0);
                p.setDeltaMovement(v);
                p.hurtMarked = true;
                p.fallDistance = 0;
                level.playSound(null, p.blockPosition(), SoundEvents.FISHING_BOBBER_RETRIEVE, SoundSource.PLAYERS, 1f, 0.7f);
            }
        }
    }

    private static void throwAxe(ServerPlayer p, ItemStack axe) {
        ServerLevel level = p.serverLevel();
        Vec3 from = p.getEyePosition();
        Vec3 to = from.add(p.getLookAngle().scale(16));
        BlockHitResult block = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 end = block.getType() == HitResult.Type.MISS ? to : block.getLocation();
        EntityHitResult ehr = ProjectileUtil.getEntityHitResult(level, p, from, end, p.getBoundingBox().expandTowards(end.subtract(from)).inflate(1),
                x -> x instanceof LivingEntity && x != p && x.isAlive());
        Vec3 land = end;
        if (ehr != null) {
            ehr.getEntity().hurt(p.damageSources().playerAttack(p), 6f);
            land = ehr.getEntity().position().add(0, 0.5, 0);
        }
        ItemStack thrown = axe.copy();
        p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        thrown.hurtAndBreak(1, p, pl -> {});
        if (!thrown.isEmpty()) {
            ItemEntity ie = dropAt(level, land.x, land.y, land.z, thrown);
            ie.setPickUpDelay(10);
            ie.setGlowingTag(true);
        }
        Vec3 dir = land.subtract(from);
        for (int i = 0; i < 12; i++) {
            Vec3 at = from.add(dir.scale(i / 12.0));
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT, at.x, at.y, at.z, 1, 0, 0, 0, 0);
        }
        level.playSound(null, p.blockPosition(), SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 1f, 1.2f);
    }

    // Thuần Hóa Tất Cả: Shift + chuột phải để cưỡi mọi mob
    @SubscribeEvent
    public static void onInteractEntity(PlayerInteractEvent.EntityInteract e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "l15") || !p.isShiftKeyDown()) return;
        if (!(e.getTarget() instanceof Mob mob) || !e.getItemStack().isEmpty() || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (p.startRiding(mob, true)) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    // ================================================================== eating / drinking

    @SubscribeEvent
    public static void onUseStart(LivingEntityUseItemEvent.Start e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getItem();
        RandomSource rng = p.getRandom();
        if (s.isEdible()) {
            if (has(p, "l03") && !s.is(Items.GOLD_INGOT) && rng.nextFloat() < 0.25f) { // Lời Nguyền Midas
                s.shrink(1);
                give(p, new ItemStack(Items.GOLD_INGOT));
                p.level().playSound(null, p.blockPosition(), SoundEvents.ARMOR_EQUIP_GOLD, SoundSource.PLAYERS, 1f, 1.2f);
                e.setCanceled(true);
                return;
            }
            PlayerState st = PlayerState.get(p);
            st.foodBefore = p.getFoodData().getFoodLevel();
            st.saturationBefore = p.getFoodData().getSaturationLevel();
        }
        // Tuột Tay: 20% bình rơi vỡ dưới chân
        if (has(p, "u07") && s.getItem() instanceof PotionItem && !(s.getItem() instanceof ThrowablePotionItem) && rng.nextFloat() < 0.20f) {
            ThrownPotion tp = new ThrownPotion(p.level(), p);
            ItemStack splash = new ItemStack(Items.SPLASH_POTION);
            if (s.getTag() != null) splash.setTag(s.getTag().copy());
            tp.setItem(splash);
            tp.setPos(p.getX(), p.getY() + 0.3, p.getZ());
            tp.setDeltaMovement(0, -0.3, 0);
            p.level().addFreshEntity(tp);
            s.shrink(1);
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onUseFinish(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getItem();
        Item item = s.getItem();
        RandomSource rng = p.getRandom();
        PlayerState st = PlayerState.get(p);
        if (s.isEdible()) {
            // Khẩu Vị Nhện: đồ ăn thường chỉ hồi một nửa, chỉ Mắt Nhện hồi đầy
            if (has(p, "e13") && st.foodBefore >= 0) {
                if (item == Items.SPIDER_EYE) {
                    p.getFoodData().eat(6, 0.8f);
                    p.removeEffect(MobEffects.POISON);
                } else {
                    p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0)); // v7.2: không còn hồi một nửa
                }
            }
            // Khát Máu (Huyết Tộc Cổ Đại): đồ ăn thường chỉ hồi 1/4
            if (has(p, "m01") && st.foodBefore >= 0) {
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 0)); // v7.2: không còn chỉ hồi 1/4
            }
            st.foodBefore = -1;
            if (has(p, "c02")) p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 60, 0)); // Ợ Hơi
            if (has(p, "c10") && isCooked(item)) p.getFoodData().eat(2, 0.2f);                 // Đầu Bếp
            if (has(p, "c10") && isRaw(item)) p.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 0)); // Kén Ăn
            if (has(p, "r14") && rng.nextFloat() < 0.15f) p.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0)); // Vị Giác Lạ
            if (has(p, "r18")) p.heal(2f); // Bụi Tiên
        }
        if (item instanceof PotionItem) {
            List<MobEffectInstance> effects = PotionUtils.getMobEffects(s);
            if (has(p, "u07")) { // Thuốc Bền
                for (MobEffectInstance mei : effects) {
                    if (mei.getEffect().isInstantenous()) continue;
                    p.addEffect(new MobEffectInstance(mei.getEffect(), (int) (mei.getDuration() * 1.5f), mei.getAmplifier(),
                            mei.isAmbient(), mei.isVisible(), mei.showIcon()));
                }
            }
            if (has(p, "l06")) { // Thân Xác Undead: thuốc hồi máu gây sát thương
                for (MobEffectInstance mei : effects) {
                    if (mei.getEffect() == MobEffects.HEAL) {
                        float healed = 4 << mei.getAmplifier();
                        p.hurt(p.damageSources().magic(), healed + (6 << mei.getAmplifier()));
                    }
                }
            }
        }
    }

    private static boolean isCooked(Item i) {
        return i == Items.COOKED_BEEF || i == Items.COOKED_PORKCHOP || i == Items.COOKED_CHICKEN || i == Items.COOKED_MUTTON
                || i == Items.COOKED_RABBIT || i == Items.COOKED_COD || i == Items.COOKED_SALMON || i == Items.BAKED_POTATO
                || i == Items.BREAD || i == Items.PUMPKIN_PIE || i == Items.RABBIT_STEW || i == Items.MUSHROOM_STEW;
    }

    private static boolean isRaw(Item i) {
        return i == Items.BEEF || i == Items.PORKCHOP || i == Items.CHICKEN || i == Items.MUTTON || i == Items.RABBIT
                || i == Items.COD || i == Items.SALMON || i == Items.POTATO || i == Items.ROTTEN_FLESH;
    }

    // ================================================================== sleeping

    @SubscribeEvent
    public static void onSleep(PlayerSleepInBedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (has(p, "l15")) { // Vô Gia Cư
            e.setResult(Player.BedSleepingProblem.OTHER_PROBLEM);
            p.displayClientMessage(Component.translatable("msg.wildcard.homeless"), true);
            return;
        }
        if (has(p, "c14") && p.getRandom().nextFloat() < 0.15f) { // Ác Mộng
            e.setResult(Player.BedSleepingProblem.NOT_SAFE);
            net.minecraft.world.entity.monster.Zombie z = spawnNear(p, EntityType.ZOMBIE, 1.5, 3);
            if (z != null) z.setTarget(p);
        }
    }

    @SubscribeEvent
    public static void onWake(PlayerWakeUpEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && has(p, "c14") && !e.wakeImmediately()) { // Ngủ Ngon
            p.setHealth(p.getMaxHealth());
            p.getFoodData().eat(20, 0.5f);
        }
    }

    @SubscribeEvent
    public static void onSpawnSet(PlayerSetSpawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && has(p, "l15") && e.getNewSpawn() != null) e.setCanceled(true);
    }

    // ================================================================== fishing

    @SubscribeEvent
    public static void onFished(ItemFishedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "e17")) return;
        if (p.getRandom().nextFloat() < 0.70f) { // Câu Phải Rác
            Item[] junk = {Items.LEATHER_BOOTS, Items.BOWL, Items.STICK, Items.STRING, Items.ROTTEN_FLESH, Items.BONE,
                    Items.LILY_PAD, Items.LEATHER, Items.INK_SAC, Items.TRIPWIRE_HOOK, Items.GLASS_BOTTLE};
            e.setCanceled(true);
            give(p, new ItemStack(junk[p.getRandom().nextInt(junk.length)]));
            p.level().playSound(null, p.blockPosition(), SoundEvents.FISHING_BOBBER_RETRIEVE, SoundSource.PLAYERS, 1f, 0.6f);
        }
    }

    // ================================================================== trading / anvil

    @SubscribeEvent
    public static void onContainerOpen(PlayerContainerEvent.Open e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !(e.getContainer() instanceof MerchantMenu menu)) return;
        boolean emperor = has(p, "l18"), friendly = has(p, "c20"), tax = has(p, "u18");
        boolean stingy = has(p, "u47"), trader = has(p, "r24");
        if (!emperor && !friendly && !tax && !stingy && !trader) return;
        for (MerchantOffer o : menu.getOffers()) {
            int cost = o.getCostA().getCount();
            int diff = 0;
            if (emperor && o.getCostA().is(Items.EMERALD)) {
                diff = 1 - cost;
            } else {
                if (friendly) diff -= Math.max(1, Math.round(cost * 0.1f));
                if (tax && o.getCostA().is(Items.EMERALD)) diff += 1;
                if (trader) diff -= Math.max(1, Math.round(cost * 0.15f));          // Thương Nhân
                if (stingy && o.getCostA().is(Items.EMERALD)) diff += 1;          // Keo Kiệt
            }
            if (diff != 0) o.addToSpecialPriceDiff(diff);
        }
    }

    // Đe Hỏng: sửa đồ trên đe tốn gấp đôi XP
    @SubscribeEvent
    public static void onAnvil(AnvilRepairEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && has(p, "r12") && !p.isCreative() && p.containerMenu instanceof AnvilMenu am) {
            p.giveExperienceLevels(-am.getCost());
        }
    }

    // ================================================================== items

    // Phép Nhân Bản: 10% vật phẩm nhặt được nhân đôi
    @SubscribeEvent
    public static void onPickup(net.minecraftforge.event.entity.player.EntityItemPickupEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "e15")) return;
        ItemEntity ie = e.getItem();
        if (ie.getPersistentData().getBoolean("wc_dup")) return;
        ie.getPersistentData().putBoolean("wc_dup", true);
        if (p.getRandom().nextFloat() < 0.10f) {
            ItemStack s = ie.getItem();
            s.setCount(Math.min(s.getMaxStackSize(), s.getCount() * 2));
            p.level().playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1f, 1.5f);
        }
    }

    // Tham Lam: không vứt được vật phẩm bằng phím Q
    @SubscribeEvent
    public static void onToss(ItemTossEvent e) {
        Player p = e.getPlayer();
        if (p.level().isClientSide || !has(p, "e20") || !p.isAlive()) return;
        ItemStack s = e.getEntity().getItem().copy();
        e.setCanceled(true);
        give(p, s);
    }

    // ================================================================== projectiles

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || e.loadedFromDisk()) return;
        Entity ent = e.getEntity();
        if (ent instanceof AbstractArrow arrow && arrow.getOwner() instanceof ServerPlayer p) {
            if (arrow.getPersistentData().getBoolean("wc_extra")) return;
            RandomSource rng = p.getRandom();
            if (has(p, "u11")) { // Cung Thủ
                arrow.setDeltaMovement(arrow.getDeltaMovement().scale(1.3));
                arrow.setBaseDamage(arrow.getBaseDamage() + 1.0);
            }
            if (has(p, "c13")) { // Tay Run
                Vec3 v = arrow.getDeltaMovement();
                double sp = v.length() * 0.06;
                arrow.setDeltaMovement(v.add(rng.nextGaussian() * sp, rng.nextGaussian() * sp, rng.nextGaussian() * sp));
            }
            if (has(p, "c13") && arrow.pickup == AbstractArrow.Pickup.ALLOWED && rng.nextFloat() < 0.30f && !p.isCreative()) { // Mũi Tên Tái Chế
                give(p, new ItemStack(Items.ARROW));
                arrow.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
            }
            if (has(p, "r02") && rng.nextFloat() < 0.10f) { // Lóng Ngóng
                Vec3 at = arrow.position();
                arrow.getPersistentData().putBoolean("wc_fizzled", true);
                Scheduler.later(1, () -> {
                    arrow.discard();
                    p.level().explode(arrow, at.x, at.y, at.z, 1.5f, net.minecraft.world.level.Level.ExplosionInteraction.NONE);
                });
            }
            if (has(p, "l16") && arrow instanceof Arrow && !(arrow.getPersistentData().getBoolean("wc_fizzled"))) { // Mưa Mũi Tên
                Vec3 v = arrow.getDeltaMovement();
                for (int k : new int[]{-2, -1, 1, 2}) {
                    Vec3 rv = v.yRot((float) Math.toRadians(k * 8));
                    Arrow extra = new Arrow(e.getLevel(), p);
                    extra.setPos(arrow.getX(), arrow.getY(), arrow.getZ());
                    extra.setDeltaMovement(rv);
                    extra.setBaseDamage(arrow.getBaseDamage());
                    extra.setCritArrow(arrow.isCritArrow());
                    extra.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
                    extra.getPersistentData().putBoolean("wc_extra", true);
                    e.getLevel().addFreshEntity(extra);
                }
            }
        }
        if (ent instanceof ThrownEnderpearl pearl && pearl.getOwner() instanceof ServerPlayer p && has(p, "e05")) { // Ender Blink
            if (!p.isCreative()) give(p, new ItemStack(Items.ENDER_PEARL));
            p.getCooldowns().addCooldown(Items.ENDER_PEARL, 160);
        }
        if (ent instanceof ThrownPotion tp && tp.getOwner() instanceof ServerPlayer p && has(p, "r19")
                && !tp.getPersistentData().getBoolean("wc_back") && p.getRandom().nextFloat() < 0.15f) { // Phản Tác Dụng
            tp.getPersistentData().putBoolean("wc_back", true);
            tp.setPos(p.getX(), p.getEyeY() + 1.2, p.getZ());
            tp.setDeltaMovement(0, -0.5, 0);
        }
    }

    @SubscribeEvent
    public static void onImpact(ProjectileImpactEvent e) {
        Projectile pr = e.getProjectile();
        if (pr.level().isClientSide || !(pr.getOwner() instanceof ServerPlayer p)) return;
        ServerLevel level = p.serverLevel();
        HitResult hit = e.getRayTraceResult();
        if (pr instanceof AbstractArrow && has(p, "r02") && !pr.getPersistentData().getBoolean("wc_boom")) { // Mũi Tên Nổ
            pr.getPersistentData().putBoolean("wc_boom", true);
            Vec3 at = hit.getLocation();
            level.explode(p, at.x, at.y, at.z, 1.6f, net.minecraft.world.level.Level.ExplosionInteraction.NONE);
            pr.discard();
            return;
        }
        if (pr instanceof Snowball && has(p, "u12") && hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le) { // Người Tuyết
            le.hurt(p.damageSources().thrown(pr, p), 2f);
            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
        }
        if (pr instanceof ThrownPotion tp && has(p, "r19")) { // Phù Thủy Tập Sự: bán kính gấp đôi
            List<MobEffectInstance> effects = PotionUtils.getMobEffects(tp.getItem());
            if (!effects.isEmpty()) {
                Vec3 at = hit.getLocation();
                for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(8, 4, 8))) {
                    double d = le.distanceToSqr(at);
                    if (d <= 16 || d > 64 || !le.isAffectedByPotions()) continue;
                    for (MobEffectInstance mei : effects) {
                        if (mei.getEffect().isInstantenous()) {
                            mei.getEffect().applyInstantenousEffect(tp, p, le, mei.getAmplifier(), 0.5);
                        } else {
                            le.addEffect(new MobEffectInstance(mei.getEffect(), mei.getDuration() / 2, mei.getAmplifier()), p);
                        }
                    }
                }
            }
        }
        if (pr instanceof ThrownTrident && has(p, "e19") && hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le) { // Gọi Sét
            if (((ThrownTrident) pr).isChanneling() && !level.isThundering()) {
                lightning(level, le.position(), p, false);
            }
        }
    }

    @SubscribeEvent
    public static void onLoose(ArrowLooseEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.isCreative() || !e.hasAmmo()) return;
        if (has(p, "u11")) e.getBow().hurtAndBreak(1, p, pl -> pl.broadcastBreakEvent(p.getUsedItemHand())); // Dây Cung Mỏng
        if (has(p, "l16") && EnchantmentHelper.getItemEnchantmentLevel(Enchantments.INFINITY_ARROWS, e.getBow()) == 0) { // Hao Tên
            int arrows = 0;
            for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
                if (p.getInventory().getItem(i).is(Items.ARROW)) arrows += p.getInventory().getItem(i).getCount();
            }
            if (arrows < 3) {
                e.setCanceled(true);
                p.displayClientMessage(Component.literal("Hao Tên: cần 3 mũi tên cho mỗi phát!"), true);
                return;
            }
            int toRemove = 2;
            for (int i = 0; i < p.getInventory().getContainerSize() && toRemove > 0; i++) {
                ItemStack s = p.getInventory().getItem(i);
                if (s.is(Items.ARROW)) {
                    int take = Math.min(toRemove, s.getCount());
                    s.shrink(take);
                    toRemove -= take;
                }
            }
        }
    }

    // ================================================================== jumping / falling

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (p.level().isClientSide) {
            Vec3 v = p.getDeltaMovement();
            if (has(p, "r06")) p.setDeltaMovement(v.x, v.y * 0.7, v.z);                       // Trọng Lực Nặng
            v = p.getDeltaMovement();
            if (has(p, "u19") && p.isSprinting()) p.setDeltaMovement(v.x * 2.0, v.y, v.z * 2.0); // Nhảy Xa
            return;
        }
        if (p instanceof ServerPlayer sp && has(sp, "c01")) { // Lò Xo Kêu
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.SLIME_JUMP, SoundSource.PLAYERS, 0.8f, 1.6f);
            if (sp.tickCount % 3 == 0 && !sp.isCreative()) {
                for (Monster m : sp.level().getEntitiesOfClass(Monster.class, sp.getBoundingBox().inflate(16), x -> x.getTarget() == null)) {
                    m.setTarget(sp);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (has(p, "c19")) e.setDamageMultiplier(e.getDamageMultiplier() * 0.5f); // Lăn Tròn
        if (has(p, "c19") && e.getDistance() >= 3f) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1)); // Mắt Cá Lỏng
    }

    // ================================================================== spawning

    // Nhân Bản Lỗi: mob thù địch xuất hiện gần bạn luôn đi theo cặp
    @SubscribeEvent
    public static void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn e) {
        if (e.getSpawnType() != MobSpawnType.NATURAL || !(e.getEntity() instanceof Monster m)) return;
        if (!(e.getLevel() instanceof ServerLevel level)) return;
        Player near = level.getNearestPlayer(m, 32);
        if (!(near instanceof ServerPlayer p) || !has(p, "e15")) return;
        Entity twin = m.getType().create(level);
        if (twin instanceof Mob tm) {
            tm.moveTo(m.getX() + 0.5, m.getY(), m.getZ() + 0.5, m.getYRot(), 0);
            Scheduler.later(1, () -> level.addFreshEntity(tm));
        }
    }

    private WorldEffects() {}
}
