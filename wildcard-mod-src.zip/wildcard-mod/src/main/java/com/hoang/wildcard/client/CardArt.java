package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Rarity;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Shared card drawing used by the choice screen, the collection screen (B) and the skill HUD. */
public final class CardArt {
    static final int DIVIDER = 0xFF4B4B57;
    static final int BUFF_LABEL = 0xFF7EE07E;
    static final int BUFF_NAME = 0xFF5CFF6A;
    static final int DEBUFF_LABEL = 0xFFFF7A7A;
    static final int DEBUFF_NAME = 0xFFFF5A5A;
    static final int DESC = 0xFFE6E6E6;
    static final ResourceLocation BUFF_ICON = tex("icon/buff");
    static final ResourceLocation DEBUFF_ICON = tex("icon/debuff");
    static final ResourceLocation STAR = tex("icon/star");

    static ResourceLocation tex(String path) {
        return new ResourceLocation("wildcard", "textures/gui/" + path + ".png");
    }

    static ResourceLocation frame(Rarity r) { return tex("card/frame_" + r.key); }
    static ResourceLocation glow(Rarity r) { return tex("card/hover_" + r.key); }
    static ResourceLocation gem(Rarity r) { return tex("icon/gem_" + r.key); }

    /** 16x16 icon of skill {@code idx} of card {@code id}. */
    public static ResourceLocation skillIcon(String id, int idx) { return tex("skill/" + id + "_" + idx); }

    /** Draws a skill icon at any size. */
    public static void drawSkillIcon(GuiGraphics g, String id, int idx, int x, int y, int size) {
        RenderSystem.enableBlend();
        g.blit(skillIcon(id, idx), x, y, size, size, 0, 0, 16, 16, 16, 16);
    }

    /** Icon of skill entry {@code k} of a card (uses the skill's original number). */
    public static void drawSkillIcon(GuiGraphics g, Card c, int k, int x, int y, int size) {
        drawSkillIcon(g, c.id, c.orig(k), x, y, size);
    }

    static final int TROLL = 0xFFD58CFF;

    static boolean crowned(Rarity r) {
        return r == Rarity.LEGENDARY || r == Rarity.MYTHIC;
    }

    /** Nine-slice a 32x32 texture with 8px corners (edges and centre stretched; they are uniform). */
    static void nineSlice(GuiGraphics g, ResourceLocation t, int x, int y, int w, int h) {
        final int T = 32, C = 8, M = T - 2 * C;
        int iw = w - 2 * C, ih = h - 2 * C;
        g.blit(t, x, y, C, C, 0, 0, C, C, T, T);
        g.blit(t, x + w - C, y, C, C, T - C, 0, C, C, T, T);
        g.blit(t, x, y + h - C, C, C, 0, T - C, C, C, T, T);
        g.blit(t, x + w - C, y + h - C, C, C, T - C, T - C, C, C, T, T);
        g.blit(t, x + C, y, iw, C, C, 0, M, C, T, T);
        g.blit(t, x + C, y + h - C, iw, C, C, T - C, M, C, T, T);
        g.blit(t, x, y + C, C, ih, 0, C, C, M, T, T);
        g.blit(t, x + w - C, y + C, C, ih, T - C, C, C, M, T, T);
        g.blit(t, x + C, y + C, iw, ih, C, C, M, M, T, T);
    }

    /** Full card: tier title, LỢI ÍCH / BẤT LỢI halves and, for Rare+, the KỸ NĂNG list with their keys. */
    public static void drawCard(GuiGraphics g, Font font, Card c, int x, int y, int w, int h, boolean hover) {
        RenderSystem.enableBlend();
        if (hover) nineSlice(g, glow(c.rarity), x - 3, y - 3, w + 6, h + 6);
        nineSlice(g, frame(c.rarity), x, y, w, h);
        if (crowned(c.rarity)) g.blit(tex("card/crest_" + c.rarity.key), x + w / 2 - 9, y - 4, 0, 0, 18, 8, 18, 8);

        int pad = 8;
        int innerW = w - pad * 2;

        Component title = c.rarity.displayName().copy().withStyle(s -> s.withBold(true).withColor(c.rarity.rgb()));
        g.pose().pushPose();
        float ts = w >= 120 ? 1.25f : 1f;
        g.pose().translate(x + w / 2f, y + 8, 0);
        g.pose().scale(ts, ts, 1);
        g.drawCenteredString(font, title, 0, 0, 0xFFFFFF);
        g.pose().popPose();

        int contentTop = y + 24;
        if (crowned(c.rarity)) {
            g.blit(STAR, x + w / 2 - 8, y + 22, 0, 0, 16, 16, 16, 16);
            contentTop = y + 40;
        }
        int bottom = y + h - 6;
        int n = c.skills.size();
        if (n > 0) {
            int skillH = 14 + n * 9;
            int sy = bottom - skillH;
            g.fill(x + pad, sy, x + w - pad, sy + 1, DIVIDER);
            drawSkills(g, font, c, x + pad, sy + 4, innerW);
            bottom = sy - 2;
        }
        int nt = c.trolls.size();
        if (nt > 0) { // bất lợi troll thêm (thẻ càng hiếm càng nhiều)
            int lineH = 8;
            int th = 3 + nt * lineH;
            int ty = bottom - th;
            float ts2 = 0.7f;
            g.pose().pushPose();
            g.pose().translate(x + pad, ty + 2, 0);
            g.pose().scale(ts2, ts2, 1);
            int lw = (int) (innerW / ts2);
            for (int i = 0; i < nt; i++) {
                String line = "☠ " + Component.translatable("troll.wildcard." + c.trolls.get(i)).getString();
                g.drawString(font, font.plainSubstrByWidth(line, lw), 0, (int) (i * lineH / ts2), TROLL, false);
            }
            g.pose().popPose();
            bottom = ty - 1;
        }
        int half = (bottom - contentTop - 6) / 2;
        int mid = contentTop + half + 2;
        g.fill(x + pad, mid, x + w - pad, mid + 1, DIVIDER);

        drawHalf(g, font, x + pad, contentTop, innerW, half, Component.translatable("gui.wildcard.buff"), BUFF_LABEL, BUFF_ICON,
                c.buffName(), BUFF_NAME, c.buffDesc(), c.buffStack());
        drawHalf(g, font, x + pad, mid + 6, innerW, bottom - mid - 6, Component.translatable("gui.wildcard.debuff"), DEBUFF_LABEL, DEBUFF_ICON,
                c.debuffName(), DEBUFF_NAME, c.debuffDesc(), c.debuffStack());
    }

    private static void drawSkills(GuiGraphics g, Font font, Card c, int x, int y, int w) {
        Component label = Component.translatable("gui.wildcard.skills").withStyle(ChatFormatting.BOLD);
        g.drawString(font, label, x, y, 0xFF000000 | c.rarity.rgb(), true);
        float s = 0.75f;
        g.pose().pushPose();
        g.pose().translate(x, y + 11, 0);
        g.pose().scale(s, s, 1);
        int lw = (int) (w / s);
        for (int i = 0; i < c.skills.size(); i++) {
            drawSkillIcon(g, c, i, 0, i * 12 - 1, 10);
            String key = "   ";
            String cd = " " + c.cooldownSeconds(i, ClientState.STARS.getOrDefault(c.id, 0)) + "s";
            int kw = font.width(key), cw = font.width(cd);
            g.drawString(font, key, 0, i * 12, 0xFFFFD866, false);
            String name = font.plainSubstrByWidth(c.skillName(i).getString(), lw - kw - cw);
            g.drawString(font, name, kw, i * 12, 0xFFFFFFFF, false);
            g.drawString(font, cd, lw - cw, i * 12, 0xFF9A9AA8, false);
        }
        g.pose().popPose();
    }

    private static void drawHalf(GuiGraphics g, Font font, int x, int y, int w, int h, Component label, int labelColor, ResourceLocation arrow,
                                 Component name, int nameColor, Component desc, ItemStack icon) {
        Component bold = label.copy().withStyle(ChatFormatting.BOLD);
        g.drawString(font, bold, x, y + 2, labelColor, true);
        g.blit(arrow, x + font.width(bold) + 3, y + 2, 8, 8, 0, 0, 16, 16, 16, 16);
        g.renderItem(icon, x + w - 16, y - 2);

        int cy = y + 14;
        Component boldName = name.copy().withStyle(ChatFormatting.BOLD);
        float ns = 1f;
        List<FormattedCharSequence> nameLines = font.split(boldName, w);
        if (nameLines.size() > 2 || (h < 40 && nameLines.size() > 1)) {
            ns = 0.8f;
            nameLines = font.split(boldName, (int) (w / ns));
        }
        cy = drawLines(g, font, nameLines, x, cy, ns, nameColor, true);
        cy += 2;

        int avail = y + h - cy;
        float[] scales = {1f, 0.85f, 0.72f, 0.62f, 0.55f, 0.5f};
        List<FormattedCharSequence> lines = null;
        float s = 1f;
        for (float sc : scales) {
            s = sc;
            lines = font.split(FormattedText.of(desc.getString()), (int) (w / sc));
            if (lines.size() * 10 * sc <= avail) break;
        }
        drawLines(g, font, lines, x, cy, s, DESC, false);
    }

    static int drawLines(GuiGraphics g, Font font, List<FormattedCharSequence> lines, int x, int y, float scale, int color, boolean shadow) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1);
        for (int i = 0; i < lines.size(); i++) g.drawString(font, lines.get(i), 0, i * 10, color, shadow);
        g.pose().popPose();
        return y + (int) Math.ceil(lines.size() * 10 * scale);
    }

    /** Tooltip lines with each skill's key, name, cooldown and description. */
    public static List<Component> skillTooltip(Card c) {
        List<Component> out = new ArrayList<>();
        int stars = ClientState.STARS.getOrDefault(c.id, 0);
        if (stars > 0) out.add(Component.translatable("gui.wildcard.stars", "★".repeat(Math.min(com.hoang.wildcard.Card.MAX_STARS, stars)) + "☆".repeat(Math.max(0, com.hoang.wildcard.Card.MAX_STARS - stars))).withStyle(ChatFormatting.AQUA));
        for (String t : c.trolls) {
            out.add(Component.literal("☠ ").append(Component.translatable("troll.wildcard." + t)).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
            out.add(Component.literal("   ").append(Component.translatable("troll.wildcard." + t + ".desc")).withStyle(ChatFormatting.GRAY));
        }
        if (c.gen != null) for (String m : c.gen.debuff) if (m.startsWith("troll:")) {
            String t = m.substring(6);
            out.add(Component.literal("☠ ").append(Component.translatable("troll.wildcard." + t)).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
            out.add(Component.literal("   ").append(Component.translatable("troll.wildcard." + t + ".desc")).withStyle(ChatFormatting.GRAY));
        }
        if (c.skills.isEmpty()) return out;
        out.add(Component.translatable("gui.wildcard.skills").withStyle(s -> s.withBold(true).withColor(c.rarity.rgb())));
        for (int i = 0; i < c.skills.size(); i++) {
            out.add(Component.literal("• ").withStyle(ChatFormatting.YELLOW)
                    .append(c.skillName(i).copy().withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD))
                    .append(Component.literal("  ").append(Component.translatable("gui.wildcard.cooldown", c.cooldownSeconds(i, ClientState.STARS.getOrDefault(c.id, 0)))).withStyle(ChatFormatting.DARK_GRAY)));
            out.add(Component.literal("   ").append(c.skillDesc(i)).withStyle(ChatFormatting.GRAY));
        }
        return out;
    }

    private CardArt() {}
}
