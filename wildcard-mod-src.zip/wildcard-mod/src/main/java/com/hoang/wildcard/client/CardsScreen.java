package com.hoang.wildcard.client;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.Rarity;
import com.hoang.wildcard.net.Net;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Card collection (default key B): every owned card, newest first per rarity; click a Rare+ card to put its skills on G H J K L. */
public class CardsScreen extends Screen {
    private static final int TILE_W = 118, TILE_H = 36, GAP = 4, TOP = 38;

    private final List<Card> owned = new ArrayList<>();
    private Card selected;
    private double scroll;
    private int cols, gridX0, gridX1, gridY1, previewW, previewH;
    private boolean showPreview;

    public CardsScreen() {
        super(Component.translatable("gui.wildcard.collection"));
    }

    @Override
    protected void init() {
        owned.clear();
        List<String> order = new ArrayList<>(ClientState.CARDS);
        for (String id : order) {
            Card c = Cards.get(id);
            if (c != null) owned.add(c);
        }
        // highest rarity first, newest first inside a rarity
        owned.sort(Comparator.<Card>comparingInt(c -> -c.rarity.ordinal()).thenComparingInt(c -> -order.indexOf(c.id)));
        selected = Cards.get(ClientState.active);
        if (selected == null && !owned.isEmpty()) selected = owned.get(0);

        showPreview = width >= 360;
        previewW = showPreview ? Mth.clamp(width / 3, 120, 160) : 0;
        previewH = Mth.clamp(height - TOP - 22, 150, 250);
        gridX0 = 10;
        gridX1 = width - (showPreview ? previewW + 22 : 10);
        gridY1 = height - 18;
        cols = Math.max(1, (gridX1 - gridX0 + GAP) / (TILE_W + GAP));
        clampScroll();
    }

    private int rows() {
        return (owned.size() + cols - 1) / cols;
    }

    private void clampScroll() {
        int content = rows() * (TILE_H + GAP);
        int view = gridY1 - TOP;
        scroll = Mth.clamp(scroll, 0, Math.max(0, content - view));
    }

    private int gridLeft() {
        int used = cols * (TILE_W + GAP) - GAP;
        return gridX0 + Math.max(0, (gridX1 - gridX0 - used) / 2);
    }

    private int tileAt(double mx, double my) {
        if (mx < gridX0 || mx >= gridX1 || my < TOP || my >= gridY1) return -1;
        int lx = (int) mx - gridLeft();
        int ly = (int) (my - TOP + scroll);
        if (lx < 0) return -1;
        int col = lx / (TILE_W + GAP), row = ly / (TILE_H + GAP);
        if (col >= cols || lx % (TILE_W + GAP) >= TILE_W || ly % (TILE_H + GAP) >= TILE_H) return -1;
        int i = row * cols + col;
        return i < owned.size() ? i : -1;
    }

    private int previewX() {
        return width - previewW - 12;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        // ---- header
        g.drawString(font, title.copy().withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), 10, 8, 0xFFFFFF, true);
        g.drawString(font, Component.translatable("gui.wildcard.collection.count", owned.size(), Cards.ALL.size()).withStyle(ChatFormatting.GRAY),
                10 + font.width(title) + 10, 8, 0xFFFFFF, false);
        MutableComponent counts = Component.empty();
        for (Rarity r : Rarity.values()) {
            long n = owned.stream().filter(c -> c.rarity == r).count();
            if (counts.getSiblings().size() > 0) counts.append(Component.literal("  ").withStyle(ChatFormatting.DARK_GRAY));
            counts.append(r.displayName().copy().append(" " + n).withStyle(s -> s.withColor(r.rgb())));
        }
        g.pose().pushPose();
        g.pose().translate(10, 21, 0);
        g.pose().scale(0.75f, 0.75f, 1);
        g.drawString(font, counts, 0, 0, 0xFFFFFF, false);
        g.pose().popPose();

        int hover = tileAt(mouseX, mouseY);
        if (owned.isEmpty()) {
            g.drawCenteredString(font, Component.translatable("gui.wildcard.collection.empty").withStyle(ChatFormatting.GRAY),
                    (gridX0 + gridX1) / 2, height / 2, 0xFFFFFF);
        }

        // ---- grid
        g.enableScissor(gridX0 - 4, TOP - 4, gridX1 + 4, gridY1);
        int left = gridLeft();
        for (int i = 0; i < owned.size(); i++) {
            int x = left + (i % cols) * (TILE_W + GAP);
            int y = TOP + (i / cols) * (TILE_H + GAP) - (int) scroll;
            if (y + TILE_H < TOP - 4 || y > gridY1) continue;
            drawTile(g, owned.get(i), x, y, i == hover);
        }
        g.disableScissor();

        // scroll bar
        int content = rows() * (TILE_H + GAP);
        int view = gridY1 - TOP;
        if (content > view) {
            int barH = Math.max(12, view * view / content);
            int barY = TOP + (int) ((view - barH) * (scroll / (content - view)));
            g.fill(gridX1 + 2, TOP, gridX1 + 4, gridY1, 0x40FFFFFF);
            g.fill(gridX1 + 2, barY, gridX1 + 4, barY + barH, 0xC0FFFFFF);
        }

        // ---- preview of the hovered (or selected) card
        Card shown = hover >= 0 ? owned.get(hover) : selected;
        boolean overPreview = false;
        if (showPreview && shown != null) {
            int px = previewX();
            CardArt.drawCard(g, font, shown, px, TOP, previewW, previewH, false);
            overPreview = mouseX >= px && mouseX < px + previewW && mouseY >= TOP && mouseY < TOP + previewH;
        }
        g.pose().pushPose();
        g.pose().translate(10, height - 12, 0);
        g.pose().scale(0.75f, 0.75f, 1);
        g.drawString(font, Component.translatable("gui.wildcard.collection.hint").withStyle(ChatFormatting.DARK_GRAY), 0, 0, 0xFFFFFF, false);
        g.pose().popPose();

        super.render(g, mouseX, mouseY, partialTick);

        // ---- tooltips
        if (hover >= 0) {
            Card c = owned.get(hover);
            List<Component> tip = new ArrayList<>();
            if (!showPreview) {
                tip.add(c.buffName().copy().withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
                tip.add(c.buffDesc().copy().withStyle(ChatFormatting.GRAY));
                tip.add(c.debuffName().copy().withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
                tip.add(c.debuffDesc().copy().withStyle(ChatFormatting.GRAY));
            }
            tip.addAll(CardArt.skillTooltip(c));
            if (!c.skills.isEmpty() && !c.id.equals(ClientState.active)) {
                tip.add(Component.translatable("gui.wildcard.collection.setactive").withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC));
            }
            if (!tip.isEmpty()) g.renderComponentTooltip(font, tip, mouseX, mouseY);
        } else if (overPreview && shown != null && !shown.skills.isEmpty()) {
            g.renderComponentTooltip(font, CardArt.skillTooltip(shown), mouseX, mouseY);
        }
    }

    private void drawTile(GuiGraphics g, Card c, int x, int y, boolean hover) {
        RenderSystem.enableBlend();
        if (hover) CardArt.nineSlice(g, CardArt.glow(c.rarity), x - 2, y - 2, TILE_W + 4, TILE_H + 4);
        CardArt.nineSlice(g, CardArt.frame(c.rarity), x, y, TILE_W, TILE_H);
        boolean active = c.id.equals(ClientState.active);
        if (active) g.renderOutline(x - 1, y - 1, TILE_W + 2, TILE_H + 2, 0xFFFFD700);
        g.renderItem(c.buffStack(), x + 6, y + 10);
        g.blit(CardArt.gem(c.rarity), x + 3, y + 3, 0, 0, 9, 9, 9, 9);

        float s = 0.8f;
        int tx = x + 26;
        int maxW = (int) ((TILE_W - 26 - 6) / s);
        g.pose().pushPose();
        g.pose().translate(tx, y + 7, 0);
        g.pose().scale(s, s, 1);
        g.drawString(font, font.plainSubstrByWidth(c.buffName().getString(), maxW), 0, 0, CardArt.BUFF_NAME, true);
        g.drawString(font, font.plainSubstrByWidth(c.debuffName().getString(), maxW), 0, 11, CardArt.DEBUFF_NAME, true);
        if (!c.skills.isEmpty()) {
            String sk = active ? Component.translatable("gui.wildcard.collection.active").getString()
                    : Component.translatable("gui.wildcard.skills").getString() + " x" + c.skills.size();
            g.drawString(font, font.plainSubstrByWidth(sk, maxW), 0, 22, active ? 0xFFFFD700 : 0xFF9A9AA8, false);
        }
        g.pose().popPose();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int i = tileAt(mx, my);
        if (button == 0 && i >= 0) {
            Card c = owned.get(i);
            selected = c;
            if (!c.skills.isEmpty() && !c.id.equals(ClientState.active)) {
                ClientState.active = c.id;
                Net.toServer(new Net.SelectActive(c.id));
                if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.2f));
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll -= delta * (TILE_H + GAP);
        clampScroll();
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (ClientSetup.KEY_CARDS.matches(key, scan)) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
