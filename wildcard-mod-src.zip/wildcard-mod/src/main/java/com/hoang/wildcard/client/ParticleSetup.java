package com.hoang.wildcard.client;

import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.ModParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WildcardMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ParticleSetup {
    @SubscribeEvent
    public static void providers(RegisterParticleProvidersEvent ev) {
        for (Element e : Element.values()) {
            ev.registerSpriteSet(ModParticles.RUNE.get(e).get(), sprites ->
                    (type, level, x, y, z, vx, vy, vz) -> new MagicParticle(level, x, y, z, vx, vy, vz, sprites, e, true));
        }
    }

    private ParticleSetup() {}
}
