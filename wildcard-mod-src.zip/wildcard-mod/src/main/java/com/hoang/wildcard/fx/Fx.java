package com.hoang.wildcard.fx;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Server-side spell visuals. v4: everything except the rune cast circle is drawn by client.VfxClient
 * (voxel balls, glowing lightning, beams, rings, black holes, ice spikes, portals) instead of particles.
 */
public final class Fx {
    /** Element of the skill being cast right now (server thread only), or null. */
    public static Element cur;

    /** Rune circle under the caster (kept from the original), a shockwave ring and the cast sounds. */
    public static void cast(ServerPlayer p, Element e) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position().add(0, 0.05, 0);
        circle(l, c, e, 1.3, 20, true);
        circle(l, c, e, 0.7, 10, true);
        Vfx.ring(l, c.add(0, 0.05, 0), e, 2.2, 12);
        l.playSound(null, p.blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.PLAYERS, 0.7f, e.pitch);
        l.playSound(null, p.blockPosition(), e.accent(), SoundSource.PLAYERS, 0.5f, 1.2f);
    }

    /** Flat ring of runes; with {@code spin} they drift sideways so the circle seems to turn. */
    public static void circle(ServerLevel l, Vec3 c, Element e, double r, int n, boolean spin) {
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            double x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
            double vx = spin ? -Math.sin(a) * 0.04 : 0, vz = spin ? Math.cos(a) * 0.04 : 0;
            l.sendParticles(e.rune(), x, c.y, z, 0, vx, 0.004, vz, 1.0);
        }
    }

    /** Hit / impact: voxel shards and a flash. {@code n} is the old spark count, used as strength. */
    public static void burst(ServerLevel l, Vec3 at, Element e, int n, double speed) {
        Vfx.burst(l, at, e, Math.max(0.5, n / 12.0));
        if (n >= 14) {
            Vfx.ring(l, at, e, 1.2 + n * 0.04, 8);
            impact(l, at, e, 0.6f);
        }
    }

    /** Thin glowing line (dashes, teleports, aim lines). */
    public static void trail(ServerLevel l, Vec3 a, Vec3 b, Element e) {
        if (e == Element.STORM) Vfx.lightning(l, a, b, e, 0.12, 6);
        else Vfx.beam(l, a, b, e, 0.12, 6);
    }

    /** Small cloud of voxel bits (buffs, roots, decorations). */
    public static void motes(ServerLevel l, Vec3 at, Element e, int n, double spread, double speed) {
        Vfx.burst(l, at, e, Math.max(0.4, n / 16.0));
    }

    public static void ring(ServerLevel l, Vec3 at, Element e, double radius, int life) {
        Vfx.ring(l, at, e, radius, life);
    }

    public static void orb(ServerLevel l, Vec3 at, Element e, double size, int life) {
        Vfx.ball(l, 0, at, Vec3.ZERO, e, size, life);
    }

    /** Crescent sweep in front of the attacker. */
    public static void slash(ServerLevel l, LivingEntity p, Element e, double size) {
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        double yaw = Math.atan2(flat.z, flat.x);
        Vec3 at = p.position().add(0, 1.1, 0);
        Vfx.slash(l, at, e, yaw, size);
        Vfx.slash(l, at.add(0, 0.3, 0), e, yaw + 0.15, size * 0.85);
    }

    /** Thick glowing jagged lightning from a to b. */
    public static void zap(ServerLevel l, Vec3 a, Vec3 b, Element e) {
        Vfx.lightning(l, a, b, e, 0.22, 10);
        Vfx.starburst(l, b, e, 0.8);
    }

    /** Straight glowing beam. */
    public static void beam(ServerLevel l, Vec3 a, Vec3 b, Element e) {
        Vfx.beam(l, a, b, e, 0.3, 12);
        Vfx.burst(l, b, e, 1);
    }

    /** School impact sound at a point. */
    public static void impact(ServerLevel l, Vec3 at, Element e, float vol) {
        net.minecraft.sounds.SoundEvent s = com.hoang.wildcard.ModSounds.impact(e);
        if (s != null) l.playSound(null, at.x, at.y, at.z, s, SoundSource.PLAYERS, vol, 0.9f + l.random.nextFloat() * 0.2f);
    }

    /** Big explosion (fireball, meteors, black hole collapse). Visual and sound only. */
    public static void explode(ServerLevel l, Vec3 at, Element e, double radius) {
        Vfx.burst(l, at, e, radius * 1.4);
        Vfx.ring(l, at.add(0, 0.1, 0), e, radius * 1.6, 14);
        Vfx.starburst(l, at, e, radius * 0.6);
        impact(l, at, e, 1.4f);
    }

    private Fx() {}
}
