package com.hoang.wildcard.fx;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** Server-side spell visuals built from our particles. Every call is sent to nearby players. */
public final class Fx {
    /** Element of the skill being cast right now (server thread only), or null. */
    public static Element cur;

    /** Magic circle under the caster, a column of sparks and the cast sounds. */
    public static void cast(ServerPlayer p, Element e) {
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position().add(0, 0.05, 0);
        circle(l, c, e, 1.3, 20, true);
        circle(l, c, e, 0.7, 10, true);
        for (int i = 0; i < 14; i++) {
            double a = l.random.nextDouble() * Math.PI * 2, r = l.random.nextDouble() * 1.1;
            l.sendParticles(e.spark(), c.x + Math.cos(a) * r, c.y + 0.1, c.z + Math.sin(a) * r, 0,
                    0, 0.08 + l.random.nextDouble() * 0.12, 0, 1.0);
        }
        l.playSound(null, p.blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.PLAYERS, 0.7f, e.pitch);
        l.playSound(null, p.blockPosition(), e.accent(), SoundSource.PLAYERS, 0.5f, 1.2f);
    }

    /** Flat ring of runes; with {@code spin} they drift sideways so the circle seems to turn. */
    public static void circle(ServerLevel l, Vec3 c, Element e, double r, int n, boolean spin) {
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            double x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
            double vx = spin ? -Math.sin(a) * 0.04 : 0, vz = spin ? Math.cos(a) * 0.04 : 0;
            l.sendParticles(e.rune(), x, c.y, z, 0, vx, 0.004, vz, 1.0);
        }
    }

    /** Sparks flying out from a point (impacts, explosions). */
    public static void burst(ServerLevel l, Vec3 at, Element e, int n, double speed) {
        for (int i = 0; i < n; i++) {
            Vec3 v = new Vec3(l.random.nextGaussian(), l.random.nextGaussian() * 0.6 + 0.3, l.random.nextGaussian()).normalize().scale(speed);
            l.sendParticles(e.spark(), at.x, at.y, at.z, 0, v.x, v.y, v.z, 1.0);
        }
    }

    /** Line of sparks with a few runes along it (beams, dashes, teleports). */
    public static void trail(ServerLevel l, Vec3 a, Vec3 b, Element e) {
        Vec3 d = b.subtract(a);
        int n = (int) Math.max(2, d.length() * 3);
        for (int i = 0; i <= n; i++) {
            Vec3 at = a.add(d.scale(i / (double) n));
            l.sendParticles(e.spark(), at.x, at.y, at.z, 1, 0.05, 0.05, 0.05, 0.01);
            if (i % 4 == 0) l.sendParticles(e.rune(), at.x, at.y, at.z, 0, 0, 0.01, 0, 1.0);
        }
    }

    private Fx() {}
}
