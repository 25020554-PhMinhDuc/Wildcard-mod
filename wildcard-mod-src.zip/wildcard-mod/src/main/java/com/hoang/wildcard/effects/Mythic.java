package com.hoang.wildcard.effects;

import com.hoang.wildcard.WData;
import com.hoang.wildcard.fx.Element;
import com.hoang.wildcard.fx.Fx;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

import static com.hoang.wildcard.effects.Effects.*;
import static com.hoang.wildcard.effects.Skills.*;

/**
 * The five Mythical cards (m01-m05). A player can hold only one; taking another swaps it and costs
 * one heart of max health for good (see RoundManager.grant).
 */
public final class Mythic {

    /** Max health lost forever: Mythic swaps plus Thần Thời Gian's toll. Never leaves less than 1 heart. */
    public static double lostHealth(WData d) {
        // v4.2: đổi thẻ Thần thoại không còn mất tim (bỏ "mythic_lost", kể cả số đã mất trước đây)
        return 0; // v7.1: không còn mất tim vĩnh viễn (trả lại tim đã mất)
    }

    /** Cost paid after any skill succeeds. */
    static void afterSkill(ServerPlayer p, String id) {
        if ("m02".equals(id) && !p.isCreative()) { // Hiệp Sĩ Rồng (v7.2): mỗi kỹ năng bị Chậm Chạp II 2 giây
            p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
        }
    }

    /** Hiệp Sĩ Rồng cannot wear iron, diamond or netherite armor. */
    static void dragonArmor(ServerPlayer p) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack s = p.getItemBySlot(slot);
            if (s.getItem() instanceof ArmorItem a && (a.getMaterial() == ArmorMaterials.IRON
                    || a.getMaterial() == ArmorMaterials.DIAMOND || a.getMaterial() == ArmorMaterials.NETHERITE)) {
                p.setItemSlot(slot, ItemStack.EMPTY);
                give(p, s);
            }
        }
    }

    static boolean skill(ServerPlayer p, String id, int slot) {
        ServerLevel level = p.serverLevel();
        PlayerState st = PlayerState.get(p);
        long now = level.getGameTime();
        switch (id + ":" + slot) {
            // ---------------------------------------------------------- Huyết Tộc Cổ Đại
            case "m01:0" -> { // Hóa Dơi
                if (p.isCreative()) return nothing(p);
                st.flightEnd = now + 160;
                p.getAbilities().mayfly = true;
                p.getAbilities().flying = true;
                p.onUpdateAbilities();
                p.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.INVISIBILITY, 160, 0, false, false, true));
                puff(p, ParticleTypes.SQUID_INK, 40, 0.6);
                sound(p, SoundEvents.BAT_TAKEOFF, 0.8f);
            }
            case "m01:1" -> { // Hút Máu
                List<LivingEntity> list = foes(p, 6);
                if (list.isEmpty()) return noTarget(p);
                for (LivingEntity le : list) {
                    Skills.trueHurt(p, le, 3f);
                    beam(p, le.getEyePosition(), ParticleTypes.DAMAGE_INDICATOR);
                }
                p.heal(Math.min(8f, 3f * list.size()));
                sound(p, SoundEvents.WITCH_DRINK, 0.6f);
            }
            case "m01:2" -> { // Bầy Dơi
                LivingEntity t = aim(p, 24);
                if (t == null) return noTarget(p);
                for (int i = 0; i < 3; i++) {
                    Scheduler.later(5 + i * 15, () -> {
                        if (!t.isAlive() || !p.isAlive()) return;
                        Skills.trueHurt(p, t, 3f);
                        p.heal(1f);
                        level.sendParticles(ParticleTypes.SQUID_INK, t.getX(), t.getY() + 1, t.getZ(), 15, 0.4, 0.4, 0.4, 0.02);
                        level.playSound(null, t.blockPosition(), SoundEvents.BAT_HURT, SoundSource.PLAYERS, 1f, 1.2f);
                    });
                }
            }
            case "m01:3" -> { // Mắt Đêm
                self(p, MobEffects.NIGHT_VISION, 300, 0);
                glowAll(p, 24, 300, false);
                sound(p, SoundEvents.BAT_AMBIENT, 0.6f);
            }
            case "m01:4" -> { // Huyết Nguyệt
                st.time("m01_moon", now + 400);
                puff(p, ParticleTypes.CRIMSON_SPORE, 80, 1.5);
                sound(p, SoundEvents.WITHER_SPAWN, 1.6f);
            }
            // ---------------------------------------------------------- Hiệp Sĩ Rồng
            case "m02:0" -> { // Phun Lửa (v6.1: hơi thở rồng mới)
                Vec3 look0 = p.getLookAngle();
                Vec3 mouth0 = p.getEyePosition().add(look0.scale(0.7)).subtract(0, 0.25, 0);
                com.hoang.wildcard.fx.Vfx.portal(level, mouth0, Element.FIRE, Math.atan2(look0.z, look0.x) + Math.PI / 2, 0.9, 12); // vòng rune trước miệng
                com.hoang.wildcard.fx.Vfx.burst(level, mouth0, Element.FIRE, 1.2);
                for (int k = 0; k < 12; k++) { // phun 2,4 giây, đổi hướng theo nơi bạn nhìn
                    final int tick = k;
                    Scheduler.later(k * 2, () -> {
                        if (!p.isAlive()) return;
                        Vec3 look = p.getLookAngle();
                        Vec3 mouth = p.getEyePosition().add(look.scale(0.7)).subtract(0, 0.25, 0);
                        com.hoang.wildcard.fx.Vfx.breath(level, mouth, look, Element.FIRE, 5);
                        if (tick % 2 == 0) com.hoang.wildcard.fx.Vfx.breath(level, mouth, look.add(0, 0.08, 0), Element.FIRE, 5);
                        for (LivingEntity le : foes(p, 8)) {
                            Vec3 to = le.getBoundingBox().getCenter().subtract(p.getEyePosition());
                            if (to.normalize().dot(look) < 0.75) continue;
                            Skills.trueHurt(p, le, 1.5f);
                            le.invulnerableTime = 0;
                            le.setSecondsOnFire(6);
                        }
                        if (tick % 3 == 0) { // lửa cháy lan trên mặt đất nơi hơi thở chạm tới
                            BlockHitResult hit = blockLook(p, 8);
                            Vec3 ground = hit != null ? hit.getLocation() : p.position().add(look.scale(6));
                            com.hoang.wildcard.fx.Vfx.area(level, ground.add(0, 0.02, 0), Element.FIRE, 1.8, 30);
                            Fx.burst(level, ground.add(0, 0.3, 0), Element.FIRE, 10, 0.15);
                        }
                        if (tick == 11) { // cuối hơi thở: nổ bùng ở đầu luồng lửa
                            Vec3 end = p.getEyePosition().add(look.scale(7));
                            Fx.explode(level, end, Element.FIRE, 2.5);
                            for (LivingEntity le : Spells.around(p, end, 2.5)) Skills.trueHurt(p, le, 4f);
                        }
                    });
                }
                sound(p, SoundEvents.ENDER_DRAGON_SHOOT, 0.9f);
                sound(p, SoundEvents.ENDER_DRAGON_GROWL, 1.3f);
            }
            case "m02:1" -> { // Vỗ Cánh
                push(p, p.getDeltaMovement().add(0, 1.6, 0));
                noFall(p, 200);
                puff(p, ParticleTypes.CLOUD, 30, 1);
                sound(p, SoundEvents.ENDER_DRAGON_FLAP, 1f);
            }
            case "m02:2" -> { // Tiếng Gầm Rồng
                List<LivingEntity> list = foes(p, 10);
                if (list.isEmpty()) return noTarget(p);
                for (LivingEntity le : list) {
                    le.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                    if (le instanceof PathfinderMob m) {
                        m.setTarget(null);
                        Vec3 away = m.position().subtract(p.position()).normalize().scale(12).add(m.position());
                        m.getNavigation().moveTo(away.x, away.y, away.z, 1.4);
                    }
                }
                sound(p, SoundEvents.ENDER_DRAGON_GROWL, 1f);
            }
            case "m02:3" -> { // Rồng Con
                Vex v = EntityType.VEX.create(level);
                if (v == null) return nothing(p);
                v.moveTo(p.getX(), p.getY() + 1.5, p.getZ(), p.getYRot(), 0);
                v.getPersistentData().putUUID(OWNER_TAG, p.getUUID());
                v.setCustomName(Component.literal("Rồng Con").withStyle(ChatFormatting.RED));
                v.setLimitedLife(620);
                level.addFreshEntity(v);
                AllyTracker.track(v, 600);
                sound(p, SoundEvents.ENDER_DRAGON_AMBIENT, 1.8f);
            }
            case "m02:4" -> { // Mưa Lửa
                Vec3 at = lookPoint(p, 32);
                Spells.fireRain(p, at, 8, 9f, 4.5); // v6.1: mưa lửa riêng, không còn cầu lửa ghast
                sound(p, SoundEvents.ENDER_DRAGON_SHOOT, 0.6f);
            }
            // ---------------------------------------------------------- Thần Thời Gian
            case "m03:0" -> { // Tua Lại
                Vec3 back = st.history.peekFirst();
                if (back == null) return nothing(p);
                p.teleportTo(back.x, back.y, back.z);
                p.fallDistance = 0;
                p.heal(4f);
                st.history.clear();
                sound(p, SoundEvents.CHORUS_FRUIT_TELEPORT, 0.8f);
            }
            case "m03:1" -> { // Chậm Thời Gian
                forFoes(p, 8, le -> le.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 3)));
                ring(p, 8, ParticleTypes.REVERSE_PORTAL);
                sound(p, SoundEvents.BEACON_DEACTIVATE, 1.4f);
            }
            case "m03:2" -> { // Gia Tốc
                self(p, MobEffects.MOVEMENT_SPEED, 100, 2);
                self(p, MobEffects.DIG_SPEED, 100, 1);
                sound(p, SoundEvents.BEACON_POWER_SELECT, 1.8f);
            }
            case "m03:3" -> { // Đảo Ngày Đêm
                ServerLevel ow = p.server.overworld();
                long t = ow.getDayTime();
                long day = t % 24000;
                ow.setDayTime(t - day + (day < 13000 ? 13000 : 24000));
                p.server.getPlayerList().broadcastSystemMessage(Component.translatable("msg.wildcard.daynight", p.getDisplayName())
                        .withStyle(ChatFormatting.AQUA), false);
                sound(p, SoundEvents.BELL_RESONATE, 0.8f);
            }
            case "m03:4" -> Abilities.timeStop(p, false); // Ngưng Đọng
            // ---------------------------------------------------------- Đấng Tạo Hóa
            case "m04:0" -> { // Tường Đá
                if (!build(p, 2, 3, Blocks.COBBLESTONE.defaultBlockState())) return nothing(p);
            }
            case "m04:1" -> { // Bắc Cầu
                Direction f = p.getDirection();
                BlockPos start = p.blockPosition().below();
                boolean any = false;
                for (int i = 1; i <= 12; i++) {
                    BlockPos q = start.relative(f, i);
                    if (level.getBlockState(q).canBeReplaced()) {
                        level.setBlockAndUpdate(q, Blocks.COBBLESTONE.defaultBlockState());
                        any = true;
                    }
                }
                if (!any) return nothing(p);
                sound(p, SoundEvents.STONE_PLACE, 0.8f);
            }
            case "m04:2" -> { // Hầm Trú Ẩn: vỏ obsidian 20 giây
                BlockPos c = p.blockPosition();
                List<BlockPos> placed = new ArrayList<>();
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        for (int dy = -1; dy <= 2; dy++) {
                            boolean shell = dy == -1 || dy == 2 || Math.abs(dx) == 1 || Math.abs(dz) == 1;
                            if (!shell) continue;
                            BlockPos q = c.offset(dx, dy, dz);
                            if (level.getBlockState(q).canBeReplaced()) {
                                level.setBlockAndUpdate(q, Blocks.OBSIDIAN.defaultBlockState());
                                placed.add(q.immutable());
                            }
                        }
                    }
                }
                Scheduler.later(400, () -> {
                    for (BlockPos q : placed) if (level.getBlockState(q).is(Blocks.OBSIDIAN)) level.removeBlock(q, false);
                });
                sound(p, SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.8f);
            }
            case "m04:3" -> { // Hóa Quặng
                BlockHitResult hit = blockLook(p, 8);
                if (hit == null) return noTarget(p);
                BlockPos q = hit.getBlockPos();
                BlockState s = level.getBlockState(q);
                if (!s.is(BlockTags.BASE_STONE_OVERWORLD)) return noTarget(p);
                boolean deep = s.is(Blocks.DEEPSLATE) || s.is(Blocks.TUFF);
                level.setBlockAndUpdate(q, (deep ? Blocks.DEEPSLATE_IRON_ORE : Blocks.IRON_ORE).defaultBlockState());
                level.sendParticles(ParticleTypes.WAX_OFF, q.getX() + 0.5, q.getY() + 0.5, q.getZ() + 0.5, 20, 0.4, 0.4, 0.4, 0.05);
                sound(p, SoundEvents.AMETHYST_BLOCK_CHIME, 0.8f);
            }
            case "m04:4" -> { // Xóa Vùng
                BlockHitResult hit = blockLook(p, 24);
                if (hit == null) return noTarget(p);
                BlockPos c = hit.getBlockPos();
                for (BlockPos q : BlockPos.betweenClosed(c.offset(-2, -2, -2), c.offset(2, 2, 2))) {
                    BlockState s = level.getBlockState(q);
                    float hard = s.getDestroySpeed(level, q);
                    if (s.isAir() || hard < 0 || hard > 50 || s.hasBlockEntity() || !s.getFluidState().isEmpty()) continue;
                    level.removeBlock(q, false);
                }
                level.sendParticles(ParticleTypes.POOF, c.getX() + 0.5, c.getY() + 0.5, c.getZ() + 0.5, 80, 2, 2, 2, 0.02);
                sound(p, SoundEvents.ILLUSIONER_MIRROR_MOVE, 0.6f);
            }
            // ---------------------------------------------------------- Chúa Tể Hư Không
            case "m05:0" -> { // Dịch Chuyển
                BlockHitResult hit = blockLook(p, 20);
                Vec3 to = hit != null ? Vec3.atBottomCenterOf(hit.getBlockPos().relative(hit.getDirection()))
                        : p.getEyePosition().add(p.getLookAngle().scale(20));
                p.teleportTo(to.x, to.y, to.z);
                p.fallDistance = 0;
                sound(p, SoundEvents.ENDERMAN_TELEPORT, 0.8f);
            }
            case "m05:1" -> blackHole(p, lookPoint(p, 16), 30); // Hố Đen
            case "m05:2" -> { // Tàng Hình
                p.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.INVISIBILITY, 200, 0, false, false, true));
                clearAggro(p, 32);
                puff(p, ParticleTypes.REVERSE_PORTAL, 40, 0.6);
                sound(p, SoundEvents.ILLUSIONER_PREPARE_MIRROR, 1f);
            }
            case "m05:3" -> { // Xuyên Tường
                if (!phase(p)) return noTarget(p);
            }
            case "m05:4" -> { // Về Nhà
                if (!home(p)) return nothing(p);
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    /** Wall {@code half*2+1} wide and {@code high} tall, two blocks in front. */
    private static boolean build(ServerPlayer p, int half, int high, BlockState state) {
        ServerLevel level = p.serverLevel();
        Direction f = p.getDirection();
        BlockPos base = p.blockPosition().relative(f, 2);
        Direction side = f.getClockWise();
        boolean any = false;
        for (int a = -half; a <= half; a++) {
            for (int y = 0; y < high; y++) {
                BlockPos q = base.relative(side, a).above(y);
                if (level.getBlockState(q).canBeReplaced()) {
                    level.setBlockAndUpdate(q, state);
                    any = true;
                }
            }
        }
        if (any) level.playSound(null, base, SoundEvents.STONE_PLACE, SoundSource.PLAYERS, 1f, 0.7f);
        return any;
    }

    private static void blackHole(ServerPlayer p, Vec3 c, int pulses) {
        if (pulses <= 0 || !p.isAlive()) return;
        ServerLevel level = p.serverLevel();
        level.sendParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 30, 1.5, 1.5, 1.5, 0.5);
        level.sendParticles(ParticleTypes.SQUID_INK, c.x, c.y, c.z, 6, 0.2, 0.2, 0.2, 0.01);
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(c, c).inflate(8), x -> foe(p, x))) {
            Vec3 pull = c.subtract(le.position());
            push(le, pull.normalize().scale(Math.min(0.6, pull.length() * 0.2)));
            if (pulses % 5 == 0) Skills.trueHurt(p, le, 1f);
        }
        if (pulses % 10 == 0) level.playSound(null, BlockPos.containing(c), SoundEvents.PORTAL_AMBIENT, SoundSource.PLAYERS, 0.6f, 0.5f);
        Scheduler.later(4, () -> blackHole(p, c, pulses - 1));
    }

    /** Walk through up to 3 blocks of wall in the horizontal look direction. */
    private static boolean phase(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 l = flatLook(p);
        boolean blocked = false;
        for (int d = 1; d <= 4; d++) {
            BlockPos q = BlockPos.containing(p.getX() + l.x * d, p.getY() + 0.1, p.getZ() + l.z * d);
            boolean free = level.getBlockState(q).getCollisionShape(level, q).isEmpty()
                    && level.getBlockState(q.above()).getCollisionShape(level, q.above()).isEmpty();
            if (!free) {
                blocked = true;
            } else if (blocked) {
                p.teleportTo(q.getX() + 0.5, q.getY(), q.getZ() + 0.5);
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 30, 0.4, 0.6, 0.4, 0.05);
                level.playSound(null, q, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 1.5f);
                return true;
            }
        }
        return false;
    }

    private Mythic() {}
}
