package com.hoang.wildcard.client;

import java.util.HashSet;
import java.util.Set;

/** Client copy of the local player's cards. Plain Java so it is safe to reference from common code. */
public final class ClientState {
    public static final Set<String> CARDS = new HashSet<>();
    /** Mob ability stolen with "Đánh Cắp Kỹ Năng", e.g. "spider". Empty when none. */
    public static String stolen = "";

    public static boolean has(String id) {
        return CARDS.contains(id);
    }

    private ClientState() {}
}
