package com.hoang.wildcard.client;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** Client copy of the local player's cards. Plain Java so it is safe to reference from common code. */
public final class ClientState {
    /** Owned cards in the order they were picked. */
    public static final Set<String> CARDS = new LinkedHashSet<>();
    /** Equipped cards: only these are active. */
    public static final Set<String> EQUIPPED = new LinkedHashSet<>();
    /** Mob ability stolen with "Đánh Cắp Kỹ Năng", e.g. "spider". Empty when none. */
    public static String stolen = "";
    /** Skill loadout for G H J K L: "cardId:skillIndex" or "". */
    public static final String[] LOADOUT = {"", "", "", "", ""};
    /** "cardId:slot" -> {end game time, total ticks}. */
    public static final Map<String, long[]> COOLDOWNS = new HashMap<>();

    /** Duplicate copies (stars) per card. */
    public static final Map<String, Integer> STARS = new HashMap<>();

    public static boolean has(String id) {
        return EQUIPPED.contains(id);
    }

    private ClientState() {}
}
