package com.hoang.wildcard.effects;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.ModSounds;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import com.hoang.wildcard.client.ClientState;
import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

/**
 * Troll / meme debuffs. v6: they are ordinary debuffs of a card ("troll:tXX" in its debuff list, collected in Card.trolls)
 * and their text is part of the card's debuff text. Texts: troll.wildcard.tXX and troll.wildcard.tXX.desc.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class TrollDebuffs {
    public static final List<String> IDS = List.of(
            "t01", "t02", "t03", "t04", "t05", "t06", "t07", "t08", "t09", "t10", "t11", "t12", "t13",
            "t14", "t15", "t16", "t17", "t18", "t19", "t20", "t21", "t22", "t23", "t24", "t25");

    private static final String[] NPC_LINES = {
            "Chào lữ khách! Bạn có muốn mua gì không?", "Hôm nay trời đẹp nhỉ.", "Tôi từng là một nhà thám hiểm như bạn...",
            "Đừng đi về phía bắc, ở đó nguy hiểm lắm.", "Bạn đã ghé qua cửa hàng của tôi chưa?", "Hmm...",
            "Nhiệm vụ mới: nhặt 10 cái cây.", "Tôi chỉ là một NPC thôi mà.", "Bấm F để tôn trọng.", "Làng này đẹp quá đi."};

    /** Card has this troll (extra list or generated debuff). */
    public static boolean cardHas(Card c, String tid) {
        return c.trolls.contains(tid);
    }

    /** All troll ids active on a player (works on both sides). */
    public static Set<String> active(Player p) {
        Set<String> out = new HashSet<>();
        Collection<String> eq = p.level().isClientSide ? ClientState.EQUIPPED : WData.get(p).equipped;
        for (String id : eq) {
            Card c = Cards.get(id);
            if (c == null) continue;
            int st = p.level().isClientSide ? ClientState.STARS.getOrDefault(id, 0) : WData.get(p).stars.getOrDefault(id, 0);
            if (c.debuffGone(st)) continue; // v8: C/U 5 sao hết bất lợi
            out.addAll(c.trolls);
        }
        return out;
    }

    public static boolean has(Player p, String tid) {
        if (p.level().isClientSide) return active(p).contains(tid);
        for (String id : WData.get(p).equipped) { // v7.3: nhớ thẻ nào mang troll này (thẻ max sao không còn bất lợi hiệu ứng)
            Card c = Cards.get(id);
            if (c != null && c.trolls.contains(tid) && !c.debuffGone(WData.get(p).stars.getOrDefault(id, 0))) {
                MaxStars.touch(p, id);
                return true;
            }
        }
        return false;
    }

    /** Chance per second of a troll that triggers on average every {@code avgSeconds}. */
    private static boolean roll(RandomSource r, int avgSeconds) {
        return r.nextInt(avgSeconds) == 0;
    }

    static void title(ServerPlayer p, Component title, Component sub) {
        p.connection.send(new ClientboundSetTitleTextPacket(title));
        if (sub != null) p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
    }

    static void soundAll(ServerPlayer p, SoundEvent s, float vol) {
        p.level().playSound(null, p.blockPosition(), s, SoundSource.PLAYERS, vol, 1f);
    }

    private static Component name(String tid) {
        return Component.translatable("troll.wildcard." + tid).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide) return;
        if (!(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator() || p.isCreative()) return;
        if (p.tickCount % 20 != 0) return;
        WData d = WData.get(p);
        if (d.choosing) return;
        Set<String> act = active(p);
        if (act.isEmpty()) return;
        RandomSource r = p.getRandom();
        ServerLevel level = p.serverLevel();
        PlayerState st = PlayerState.get(p);
        long now = level.getGameTime();

        if (act.contains("t01") && roll(r, 180) && !p.getMainHandItem().isEmpty()) { // Hắt Xì
            p.drop(p.getInventory().removeFromSelected(true), false, true);
            Net.toPlayer(p, new Net.Fx("sneeze", 0));
            soundAll(p, SoundEvents.PANDA_SNEEZE, 1f);
            Effects.actionBar(p, name("t01"));
        }
        if (act.contains("t02") && roll(r, 150)) { // Vine Boom
            soundAll(p, ModSounds.VINE_BOOM.get(), 1.5f);
            Effects.effect(p, MobEffects.MOVEMENT_SLOWDOWN, 20, 4);
        }
        if (act.contains("t03") && roll(r, 300)) { // Bàn Phím Ngược
            Net.toPlayer(p, new Net.Fx("invert", 200));
            Effects.actionBar(p, name("t03"));
        }
        if (act.contains("t04") && roll(r, 120) && st.history.size() > 40) { // Lag Giả
            Vec3 back = new ArrayList<>(st.history).get(st.history.size() - 40);
            p.teleportTo(back.x, back.y, back.z);
            p.fallDistance = 0;
            Effects.actionBar(p, name("t04"));
        }
        if (act.contains("t05") && roll(r, 200)) p.playNotifySound(SoundEvents.CREEPER_PRIMED, SoundSource.HOSTILE, 1f, 1f); // Creeper Ma
        if (act.contains("t07") && roll(r, 400)) { // NPC
            p.server.getPlayerList().broadcastSystemMessage(Component.literal("<").append(p.getDisplayName()).append("> ")
                    .append(NPC_LINES[r.nextInt(NPC_LINES.length)]), false);
        }
        if (act.contains("t11") && roll(r, 240)) Effects.effect(p, MobEffects.CONFUSION, 160, 0); // Say Xe
        if (act.contains("t12") && roll(r, 180)) Effects.effect(p, MobEffects.BLINDNESS, 40, 0); // Chớp Tắt
        if (act.contains("t13") && roll(r, 300)) { // Fan Cứng
            Chicken c = EntityType.CHICKEN.create(level);
            if (c != null) {
                c.moveTo(p.getX() + r.nextGaussian(), p.getY(), p.getZ() + r.nextGaussian(), r.nextFloat() * 360f, 0);
                c.setCustomName(Component.translatable("troll.wildcard.fan").withStyle(ChatFormatting.YELLOW));
                c.setCustomNameVisible(true);
                level.addFreshEntity(c);
                AllyTracker.track(c, 1200);
            }
        }
        if (act.contains("t15")) Effects.keep(p, MobEffects.GLOWING, 0); // Phát Sáng
        if (act.contains("t16") && p.isSprinting() && roll(r, 40)) { // Trượt Chuối
            Vec3 l = Skills.flatLook(p);
            Skills.push(p, new Vec3(l.x * 0.8, 0.3, l.z * 0.8));
            Effects.effect(p, MobEffects.MOVEMENT_SLOWDOWN, 40, 2);
            soundAll(p, SoundEvents.SLIME_SQUISH, 1f);
            Effects.actionBar(p, name("t16"));
        }
        if (act.contains("t17") && roll(r, 150)) Net.toPlayer(p, new Net.Fx("shake", 60)); // Rung Màn Hình
        if (act.contains("t18") && roll(r, 150)) { // Gió Lùa
            double a = r.nextDouble() * Math.PI * 2;
            Skills.push(p, p.getDeltaMovement().add(Math.cos(a) * 1.0, 0.25, Math.sin(a) * 1.0));
            soundAll(p, SoundEvents.PHANTOM_FLAP, 1f);
        }
        if (act.contains("t19") && p.tickCount % 200 == 0) { // Nam Châm Quái
            for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(20), x -> x instanceof Enemy && x.getTarget() == null)) {
                m.setTarget(p);
            }
        }
        if (act.contains("t22") && roll(r, 240)) { // Ohio
            List<Mob> near = level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(16));
            if (!near.isEmpty()) {
                Mob m = near.get(r.nextInt(near.size()));
                m.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 2));
                m.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.GLOWING, 200, 0));
                m.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.JUMP, 200, 3));
                level.playSound(null, m.blockPosition(), ModSounds.VINE_BOOM.get(), SoundSource.HOSTILE, 1f, 0.6f);
                Effects.actionBar(p, name("t22"));
            }
        }
        if (act.contains("t23") && roll(r, 600)) { // Rickroll
            soundAll(p, ModSounds.RICKROLL.get(), 1f);
            title(p, Component.translatable("troll.wildcard.rickroll").withStyle(ChatFormatting.LIGHT_PURPLE), null);
        }
        if (act.contains("t25") && roll(r, 300)) { // Mất Sóng
            st.time("silence", now + 100);
            Effects.actionBar(p, name("t25"));
        }
    }

    /** Thuế Thu Nhập: called when a new card is granted. */
    public static void onRoundStart(ServerPlayer p) {
        if (has(p, "t14") && p.experienceLevel > 0) {
            p.giveExperienceLevels(-2);
            Effects.actionBar(p, name("t14"));
        }
    }

    /** Skills are blocked for a moment by Mất Sóng. */
    public static boolean silenced(ServerPlayer p) {
        return p.level().getGameTime() < PlayerState.get(p).time("silence");
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity().level().isClientSide) return;
        if (e.getEntity() instanceof ServerPlayer p && e.getSource().is(DamageTypeTags.IS_FALL)) {
            Set<String> act = active(p);
            if (act.contains("t20")) e.setAmount(e.getAmount() * 1.5f); // Chân Thủy Tinh
            if (act.contains("t24")) { // Bruh
                soundAll(p, ModSounds.BRUH.get(), 1.2f);
                Effects.effect(p, MobEffects.MOVEMENT_SLOWDOWN, 100, 0);
            }
        }
        if (e.getSource().getEntity() instanceof ServerPlayer att && att != e.getEntity() && has(att, "t09")
                && att.getRandom().nextInt(25) == 0 && !att.getMainHandItem().isEmpty()) { // Tay Trơn
            att.drop(att.getInventory().removeFromSelected(true), false, true);
            Effects.actionBar(att, name("t09"));
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !has(p, "t06")) return; // Skill Issue
        p.server.getPlayerList().broadcastSystemMessage(Component.translatable("troll.wildcard.skillissue", p.getDisplayName())
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), false);
        soundAll(p, ModSounds.BRUH.get(), 1.5f);
        p.giveExperienceLevels(-3);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || !has(p, "t10")) return; // Đồ Mau Hỏng
        ItemStack s = p.getMainHandItem();
        if (s.isDamageableItem()) s.hurtAndBreak(1, p, x -> x.broadcastBreakEvent(EquipmentSlot.MAINHAND));
    }

    /** Bụng Không Đáy x1.5 hunger, used by NewCards.exhaustMult. */
    public static float exhaustMult(Player p) {
        return 1f; // v7.2: t08 không còn tốn đói (giờ là Lười Biếng: đào chậm, xem V72Cards)
    }

    private TrollDebuffs() {}
}
