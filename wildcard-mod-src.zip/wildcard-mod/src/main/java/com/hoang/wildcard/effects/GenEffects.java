package com.hoang.wildcard.effects;

import com.hoang.wildcard.Card;
import com.hoang.wildcard.Cards;
import com.hoang.wildcard.WData;
import com.hoang.wildcard.WildcardMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerXpEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

/** Buffs and debuffs of the generated cards (see GenSpec), plus the duplicate-star HP bonus. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class GenEffects {
    private static final Map<UUID, List<String[]>> MODS = new HashMap<>();
    private static final Map<UUID, Set<String>> APPLIED = new HashMap<>();

    /** Active mods of a player (each split on ':'). Server side. */
    static List<String[]> mods(Player p) {
        return MODS.getOrDefault(p.getUUID(), List.of());
    }

    private static void refresh(ServerPlayer p, WData d) {
        List<String[]> list = new ArrayList<>();
        Map<String, double[]> attrs = new HashMap<>(); // key -> {attrIndex, amount}
        for (String id : d.equipped) {
            Card c = Cards.get(id);
            if (c == null || (c.gen == null && c.xBuff.isEmpty() && c.xDebuff.isEmpty())) continue;
            int i = 0;
            int stars = d.stars.getOrDefault(id, 0);
            boolean buffSide = true;
            for (String[] side : new String[][]{sideOf(c, true), sideOf(c, false)}) {
                double f = buffSide ? c.buffMul(stars) : c.debuffMul(stars);
                boolean debuffSide = !buffSide;
                buffSide = false;
                for (String m : side) {
                    if (debuffSide && stars >= Card.MAX_STARS && m.startsWith("eff:")) continue; // v7.3: max sao hết bất lợi hiệu ứng
                    String[] a = scale(m.split(":"), f);
                    list.add(a);
                    if (a[0].equals("attr") && a.length >= 3) attrs.put("g_" + id + "_" + (i++), new double[]{attrIndex(a[1]), parse(a[2])});
                }
            }
        }
        MODS.put(p.getUUID(), list);
        // attribute modifiers: add the wanted ones, drop the stale ones ("key|attrIndex")
        Set<String> applied = APPLIED.computeIfAbsent(p.getUUID(), u -> new HashSet<>());
        Set<String> nowApplied = new HashSet<>();
        for (Map.Entry<String, double[]> e : attrs.entrySet()) {
            int ai = (int) e.getValue()[0];
            Attribute at = attribute(ai);
            if (at == null) continue;
            double v = e.getValue()[1];
            AttributeModifier.Operation op = ai == 0 || ai == 7 || ai == 9 ? AttributeModifier.Operation.MULTIPLY_TOTAL : AttributeModifier.Operation.ADDITION;
            Effects.attr(p, at, e.getKey(), v, op, true);
            if (ai == 8) Effects.attr(p, ForgeMod.ENTITY_REACH.get(), e.getKey() + "e", v, AttributeModifier.Operation.ADDITION, true);
            nowApplied.add(e.getKey() + "|" + ai);
        }
        for (String k : applied) {
            if (nowApplied.contains(k)) continue;
            String[] parts = k.split("\\|");
            int ai = Integer.parseInt(parts[1]);
            Attribute at = attribute(ai);
            if (at != null) Effects.attr(p, at, parts[0], 0, AttributeModifier.Operation.ADDITION, false);
            if (ai == 8) Effects.attr(p, ForgeMod.ENTITY_REACH.get(), parts[0] + "e", 0, AttributeModifier.Operation.ADDITION, false);
        }
        applied.clear();
        applied.addAll(nowApplied);
        // v4.2: bỏ +1 máu mỗi sao (gỡ modifier cũ nếu còn)
        Effects.attr(p, Attributes.MAX_HEALTH, "stars_hp", 0, AttributeModifier.Operation.ADDITION, false);
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    /** Generated mods plus the v6 extras of one side of a card. */
    public static String[] sideOf(Card c, boolean buff) {
        List<String> out = new ArrayList<>();
        if (c.gen != null) out.addAll(Arrays.asList(buff ? c.gen.buff : c.gen.debuff));
        out.addAll(buff ? c.xBuff : c.xDebuff);
        return out.toArray(new String[0]);
    }

    /**
     * Duplicate stars: scales one mod by {@code f} (buff side f > 1 = stronger, debuff side f < 1 = milder).
     * Multipliers scale their distance from 1, intervals shrink for regen and grow for drain.
     */
    public static String[] scale(String[] a, double f) {
        if (f == 1 || a.length < 2) return a;
        String[] o = a.clone();
        switch (a[0]) {
            case "attr", "kill", "mine" -> { if (a.length >= 3) o[2] = fmt(parse(a[2]) * f); }
            case "inc", "out" -> { if (a.length >= 3) o[2] = fmt(1 + (parse(a[2]) - 1) * f); }
            case "exh", "xp" -> o[1] = fmt(1 + (parse(a[1]) - 1) * f);
            case "food" -> o[1] = fmt(Math.round(parse(a[1]) * f));
            case "regen" -> o[1] = fmt(Math.max(1, Math.round(parse(a[1]) / f)));
            case "drain" -> o[1] = fmt(Math.max(1, Math.round(parse(a[1]) / f)));
            case "eff" -> { // cấp hiệu ứng: buff +1 ở 5 sao, debuff -1 từ 3 sao
                if (a.length >= 3) {
                    int amp = (int) parse(a[2]);
                    if (f > 1) amp += f >= 1.8 - 1e-6 ? 2 : f >= 1.4 - 1e-6 ? 1 : 0; // 5 sao (thẻ có kỹ năng) hoặc 2/4 sao (thẻ không kỹ năng)
                    if (f < 1 && f <= Card.debuffFactor(3) + 1e-6 && amp > 0) amp--;
                    o[2] = Integer.toString(amp);
                }
            }
            default -> {
            }
        }
        return o;
    }

    private static String fmt(double v) {
        return Double.toString(v);
    }

    private static double parse(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static int attrIndex(String name) {
        return switch (name) {
            case "speed" -> 0;
            case "maxhp" -> 1;
            case "attack" -> 2;
            case "armor" -> 3;
            case "toughness" -> 4;
            case "luck" -> 5;
            case "kbres" -> 6;
            case "atkspeed" -> 7;
            case "reach" -> 8;
            case "swim" -> 9;
            default -> -1;
        };
    }

    private static Attribute attribute(int i) {
        return switch (i) {
            case 0 -> Attributes.MOVEMENT_SPEED;
            case 1 -> Attributes.MAX_HEALTH;
            case 2 -> Attributes.ATTACK_DAMAGE;
            case 3 -> Attributes.ARMOR;
            case 4 -> Attributes.ARMOR_TOUGHNESS;
            case 5 -> Attributes.LUCK;
            case 6 -> Attributes.KNOCKBACK_RESISTANCE;
            case 7 -> Attributes.ATTACK_SPEED;
            case 8 -> ForgeMod.BLOCK_REACH.get();
            case 9 -> ForgeMod.SWIM_SPEED.get();
            default -> null;
        };
    }

    static MobEffect effect(String name) {
        return switch (name) {
            case "speed" -> MobEffects.MOVEMENT_SPEED;
            case "haste" -> MobEffects.DIG_SPEED;
            case "strength" -> MobEffects.DAMAGE_BOOST;
            case "jump" -> MobEffects.JUMP;
            case "regen" -> MobEffects.REGENERATION;
            case "resistance" -> MobEffects.DAMAGE_RESISTANCE;
            case "fire_res" -> MobEffects.FIRE_RESISTANCE;
            case "water_breath" -> MobEffects.WATER_BREATHING;
            case "night_vision" -> MobEffects.NIGHT_VISION;
            case "dolphin" -> MobEffects.DOLPHINS_GRACE;
            case "luck" -> MobEffects.LUCK;
            case "slow_fall" -> MobEffects.SLOW_FALLING;
            case "invis" -> MobEffects.INVISIBILITY;
            case "slowness" -> MobEffects.MOVEMENT_SLOWDOWN;
            case "fatigue" -> MobEffects.DIG_SLOWDOWN;
            case "weakness" -> MobEffects.WEAKNESS;
            case "hunger" -> MobEffects.HUNGER;
            case "glowing" -> MobEffects.GLOWING;
            case "unluck" -> MobEffects.UNLUCK;
            case "blindness" -> MobEffects.BLINDNESS;
            case "nausea" -> MobEffects.CONFUSION;
            case "darkness" -> MobEffects.DARKNESS;
            case "poison" -> MobEffects.POISON;
            case "levitation" -> MobEffects.LEVITATION;
            case "absorption" -> MobEffects.ABSORPTION;
            default -> null;
        };
    }

    static boolean cond(ServerPlayer p, String c) {
        Level l = p.level();
        BlockPos bp = p.blockPosition();
        return switch (c) {
            case "always", "" -> true;
            case "night" -> !l.isDay();
            case "day" -> l.isDay();
            case "rain" -> l.isRainingAt(bp) || l.isRainingAt(bp.above());
            case "water" -> p.isInWater();
            case "nether" -> l.dimension() == Level.NETHER;
            case "deep" -> p.getY() < 0;
            case "high" -> p.getY() > 100;
            case "dark" -> l.getBrightness(LightLayer.BLOCK, bp) < 7 && (l.getBrightness(LightLayer.SKY, bp) < 7 || !l.isDay());
            case "sneak" -> p.isShiftKeyDown();
            case "sprint" -> p.isSprinting();
            case "lowhp" -> p.getHealth() < p.getMaxHealth() * 0.4f;
            case "fullhp" -> p.getHealth() >= p.getMaxHealth();
            case "armorless" -> {
                boolean none = true;
                for (ItemStack s : p.getInventory().armor) if (!s.isEmpty()) none = false;
                yield none;
            }
            case "unarmed" -> p.getMainHandItem().isEmpty();
            case "dayout" -> l.isDay() && l.canSeeSky(bp.above());
            default -> false;
        };
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide) return;
        if (!(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        int tc = p.tickCount;
        WData d = WData.get(p);
        if (tc % 10 == 0) refresh(p, d);
        if (tc % 20 != 0) return;
        int sec = tc / 20;
        for (String[] m : mods(p)) {
            switch (m[0]) {
                case "eff" -> {
                    MobEffect eff = effect(m[1]);
                    if (eff != null && cond(p, m.length > 3 ? m[3] : "always")) Effects.keep(p, eff, (int) parse(m[2]));
                }
                case "regen" -> {
                    int s = Math.max(1, (int) parse(m[1]));
                    if (sec % s == 0 && p.getHealth() < p.getMaxHealth()) p.heal(1f);
                }
                case "drain" -> {
                    int s = Math.max(1, (int) parse(m[1]));
                    if (sec % s == 0 && p.getHealth() > 2f) p.setHealth(p.getHealth() - 1f);
                }
                default -> {
                }
            }
        }
    }

    /** Hunger multiplier from "exh:x" mods (used by Effects.exhaustion via NewCards.exhaustMult). */
    public static float exhaustMult(Player p) {
        if (p.level().isClientSide) return 1f;
        float m = 1f;
        for (String[] a : mods(p)) if (a[0].equals("exh")) m *= (float) parse(a[1]);
        return m;
    }

    static boolean source(DamageSource s, String kind) {
        return switch (kind) {
            case "all" -> true;
            case "fall" -> s.is(DamageTypeTags.IS_FALL);
            case "fire" -> s.is(DamageTypeTags.IS_FIRE);
            case "explosion" -> s.is(DamageTypeTags.IS_EXPLOSION);
            case "projectile" -> s.is(DamageTypeTags.IS_PROJECTILE);
            case "magic" -> s.is(DamageTypes.MAGIC) || s.is(DamageTypes.INDIRECT_MAGIC);
            case "drown" -> s.is(DamageTypeTags.IS_DROWNING);
            case "freeze" -> s.is(DamageTypeTags.IS_FREEZING);
            case "melee" -> s.getDirectEntity() instanceof LivingEntity le && !(le instanceof Player) && !s.is(DamageTypeTags.IS_PROJECTILE);
            default -> false;
        };
    }

    static boolean target(LivingEntity t, String kind) {
        return switch (kind) {
            case "all" -> true;
            case "undead" -> t.getMobType() == MobType.UNDEAD;
            case "arthropod" -> t.getMobType() == MobType.ARTHROPOD;
            case "illager" -> t.getMobType() == MobType.ILLAGER;
            case "water" -> t.getMobType() == MobType.WATER;
            case "animal" -> t instanceof Animal;
            case "player" -> t instanceof Player;
            default -> false;
        };
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity().level().isClientSide) return;
        float amount = e.getAmount();
        if (e.getEntity() instanceof ServerPlayer p) {
            for (String[] m : mods(p)) if (m[0].equals("inc") && source(e.getSource(), m[1])) amount *= (float) parse(m[2]);
        }
        if (e.getSource().getEntity() instanceof ServerPlayer att && att != e.getEntity()) {
            for (String[] m : mods(att)) if (m[0].equals("out") && target(e.getEntity(), m[1])) amount *= (float) parse(m[2]);
        }
        if (amount != e.getAmount()) e.setAmount(Math.max(0f, amount));
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity().level().isClientSide || e.getEntity() instanceof Player) return;
        if (!(e.getSource().getEntity() instanceof ServerPlayer p)) return;
        for (String[] m : mods(p)) {
            if (!m[0].equals("kill")) continue;
            double v = parse(m[2]);
            switch (m[1]) {
                case "heal" -> p.heal((float) v);
                case "xp" -> p.giveExperiencePoints((int) v);
                case "food" -> p.getFoodData().eat((int) v, 0.2f);
                case "hurt" -> p.hurt(p.damageSources().magic(), (float) v);
                case "hunger" -> p.getFoodData().setFoodLevel(Math.max(0, p.getFoodData().getFoodLevel() - (int) v));
                default -> {
                }
            }
        }
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p)) return;
        var rng = p.getRandom();
        for (String[] m : mods(p)) {
            if (!m[0].equals("mine")) continue;
            double v = parse(m[2]);
            switch (m[1]) {
                case "xp" -> {
                    if (rng.nextInt(100) < v) e.setExpToDrop(e.getExpToDrop() + 1 + rng.nextInt(3));
                }
                case "haste" -> {
                    if (e.getState().is(BlockTags.BASE_STONE_OVERWORLD) || e.getState().is(BlockTags.BASE_STONE_NETHER)) {
                        Effects.effect(p, MobEffects.DIG_SPEED, 60, (int) v);
                    }
                }
                case "hurt" -> {
                    if (rng.nextInt(100) < v) p.hurt(p.damageSources().generic(), 1f);
                }
                default -> {
                }
            }
        }
    }

    @SubscribeEvent
    public static void onEat(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !e.getItem().isEdible()) return;
        for (String[] m : mods(p)) {
            if (!m[0].equals("food")) continue;
            int v = (int) parse(m[1]);
            if (v > 0) p.getFoodData().eat(v, 0.2f);
            else p.getFoodData().setFoodLevel(Math.max(0, p.getFoodData().getFoodLevel() + v));
        }
    }

    @SubscribeEvent
    public static void onXp(PlayerXpEvent.XpChange e) {
        if (e.getEntity().level().isClientSide || e.getAmount() <= 0) return;
        double m = 1;
        for (String[] a : mods(e.getEntity())) if (a[0].equals("xp")) m *= parse(a[1]);
        if (m != 1) e.setAmount(Math.max(0, (int) Math.round(e.getAmount() * m)));
    }

    public static void forget(Player p) {
        MODS.remove(p.getUUID());
        APPLIED.remove(p.getUUID());
    }

    private GenEffects() {}
}
