package com.hoang.wildcard.effects;

import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Endermite;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

import static com.hoang.wildcard.effects.Effects.*;

/** Key-triggered actions: G H J K L = skill loadout, N = Ender Chest, right click with empty hand = fan. */
public final class Abilities {

    public static void use(ServerPlayer p, int kind) {
        if (!p.isAlive() || p.isSpectator()) return;
        if (kind >= Net.Ability.SLOT_BASE) {
            Skills.use(p, kind - Net.Ability.SLOT_BASE);
            return;
        }
        switch (kind) {
            case Net.Ability.ENDER -> {
                if (has(p, "u20")) ender(p);
            }
            case Net.Ability.TONGUE -> { // Lưỡi Ếch: cúi + chuột phải tay không
                if (has(p, "r14") && p.getMainHandItem().isEmpty() && ready(p, "r14", 60) && !Skills.tongue(p)) {
                    PlayerState.get(p).setCooldown("r14", 0);
                }
            }
            case Net.Ability.FAN -> {
                if (has(p, "e11") && p.getMainHandItem().isEmpty() && ready(p, "e11", 200)) fan(p);
            }
            default -> {
            }
        }
    }

    static boolean ready(ServerPlayer p, String key, int cooldown) {
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        if (st.ready(key, now, cooldown)) return true;
        WorldEffects.actionCooldown(p, st.remaining(key, now));
        return false;
    }

    public static LivingEntity lookTarget(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestDot = 0.95;
        for (LivingEntity le : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range), x -> x != p && x.isAlive())) {
            Vec3 to = le.getEyePosition().subtract(eye);
            double dist = to.length();
            if (dist > range) continue;
            double dot = to.normalize().dot(look);
            if (dot > bestDot && p.hasLineOfSight(le)) {
                bestDot = dot;
                best = le;
            }
        }
        return best;
    }

    public static void timeStop(ServerPlayer p) {
        timeStop(p, true);
    }

    public static void timeStop(ServerPlayer p, boolean selfFreeze) {
        ServerLevel level = p.serverLevel();
        AABB box = p.getBoundingBox().inflate(20);
        List<Mob> mobs = new ArrayList<>();
        for (Mob m : level.getEntitiesOfClass(Mob.class, box, x -> !x.isNoAi())) {
            m.setNoAi(true);
            m.setDeltaMovement(Vec3.ZERO);
            mobs.add(m);
        }
        List<Projectile> projs = new ArrayList<>();
        List<Vec3> speeds = new ArrayList<>();
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> !x.isNoGravity())) {
            speeds.add(pr.getDeltaMovement());
            pr.setDeltaMovement(Vec3.ZERO);
            pr.setNoGravity(true);
            projs.add(pr);
        }
        // v6.1: người chơi khác trong vùng cũng bị đứng hình (không đi, không nhảy, không đánh)
        List<ServerPlayer> players = new ArrayList<>();
        List<Vec3> spots = new ArrayList<>();
        for (ServerPlayer o : level.getEntitiesOfClass(ServerPlayer.class, box, x -> Skills.foe(p, x))) {
            players.add(o);
            spots.add(o.position());
            PlayerState.get(o).timeStopSelfFreeze = level.getGameTime() + 120;
            o.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 9, false, false, true));
            o.addEffect(new MobEffectInstance(MobEffects.JUMP, 120, 128, false, false, false)); // nhảy âm = không nhảy được
            o.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 120, 4, false, false, true));
            o.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 9, false, false, true));
            com.hoang.wildcard.fx.Vfx.dome(level, o.position(), com.hoang.wildcard.fx.Element.ARCANE, 1.2, 120);
            o.displayClientMessage(Component.translatable("msg.wildcard.timestop.frozen", p.getDisplayName()).withStyle(ChatFormatting.AQUA), true);
        }
        for (int t = 1; t < 120; t++) { // giữ nguyên chỗ, kể cả đang rơi hay bị đẩy
            Scheduler.later(t, () -> {
                for (int i = 0; i < players.size(); i++) {
                    ServerPlayer o = players.get(i);
                    if (!o.isAlive() || o.isRemoved()) continue;
                    Vec3 at = spots.get(i);
                    o.setDeltaMovement(Vec3.ZERO);
                    o.fallDistance = 0;
                    if (o.position().distanceToSqr(at) > 0.0025) o.teleportTo(at.x, at.y, at.z);
                }
            });
        }
        level.playSound(null, p.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.5f, 0.5f);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 200, 6, 3, 6, 0.05);
        p.server.getPlayerList().broadcastSystemMessage(
                Component.translatable("msg.wildcard.timestop", p.getDisplayName()).withStyle(ChatFormatting.AQUA), false);
        // keep projectiles still while frozen
        for (int t = 1; t < 120; t += 5) {
            Scheduler.later(t, () -> projs.forEach(pr -> pr.setDeltaMovement(Vec3.ZERO)));
        }
        Scheduler.later(120, () -> {
            for (Mob m : mobs) if (m.isAlive()) m.setNoAi(false);
            for (int i = 0; i < projs.size(); i++) {
                Projectile pr = projs.get(i);
                if (pr.isAlive()) {
                    pr.setNoGravity(false);
                    pr.setDeltaMovement(speeds.get(i));
                }
            }
            level.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.6f);
            // Cái Giá Thời Gian: chính bạn bị đóng băng 3 giây
            if (p.isAlive() && selfFreeze) {
                PlayerState.get(p).timeStopSelfFreeze = level.getGameTime() + 60;
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 6));
                p.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 60, 4));
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 4));
            }
        });
    }

    // ------------------------------------------------------------------ B: pocket ender chest

    /** Opens the player's ender chest; with Ender Chest Bỏ Túi an Endermite also appears. */
    public static void ender(ServerPlayer p) {
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> ChestMenu.threeRows(id, inv, pl.getEnderChestInventory()),
                Component.translatable("container.enderchest")));
        p.level().playSound(null, p.blockPosition(), SoundEvents.ENDER_CHEST_OPEN, SoundSource.PLAYERS, 0.8f, 1f);
        // Khách Không Mời
        if (!has(p, "u20")) return;
        Endermite mite = EntityType.ENDERMITE.create(p.serverLevel());
        if (mite != null) {
            mite.moveTo(p.getX() + 1, p.getY(), p.getZ() + 1, 0, 0);
            p.serverLevel().addFreshEntity(mite);
        }
    }

    // ------------------------------------------------------------------ right click: fan

    public static void fan(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(6), x -> x != p)) {
            Vec3 to = le.position().add(0, le.getBbHeight() / 2, 0).subtract(eye);
            if (to.length() > 6 || to.normalize().dot(look) < 0.5) continue;
            Vec3 push = to.normalize().scale(2.0).add(0, 0.4, 0);
            le.setDeltaMovement(push);
            le.hurtMarked = true;
        }
        for (int i = 1; i <= 6; i++) {
            Vec3 at = eye.add(look.scale(i));
            level.sendParticles(ParticleTypes.CLOUD, at.x, at.y, at.z, 4, 0.3, 0.3, 0.3, 0.05);
        }
        level.playSound(null, p.blockPosition(), SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 1f, 1.5f);
        // Phản Lực: bạn bị đẩy lùi 3 khối
        p.setDeltaMovement(p.getDeltaMovement().add(look.scale(-0.9)));
        p.hurtMarked = true;
    }

    private Abilities() {}
}
