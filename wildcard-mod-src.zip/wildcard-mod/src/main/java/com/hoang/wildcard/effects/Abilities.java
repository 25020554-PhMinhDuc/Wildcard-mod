package com.hoang.wildcard.effects;

import com.hoang.wildcard.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Endermite;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

import static com.hoang.wildcard.effects.Effects.*;

/** Active abilities triggered by key presses (V = di chuyển, G = kỹ năng, B = Ender Chest, chuột phải tay không = quạt). */
public final class Abilities {

    public static void use(ServerPlayer p, int kind) {
        if (!p.isAlive() || p.isSpectator()) return;
        switch (kind) {
            case Net.Ability.MOVE -> move(p);
            case Net.Ability.SKILL -> skill(p);
            case Net.Ability.ENDER -> ender(p);
            case Net.Ability.FAN -> fan(p);
            default -> {
            }
        }
    }

    private static boolean ready(ServerPlayer p, String key, int cooldown) {
        PlayerState st = PlayerState.get(p);
        long now = p.level().getGameTime();
        if (st.ready(key, now, cooldown)) return true;
        WorldEffects.actionCooldown(p, st.remaining(key, now));
        return false;
    }

    // ------------------------------------------------------------------ V: movement

    private static void move(ServerPlayer p) {
        // Rồng Con: bay tự do 15 giây, hồi chiêu 90 giây
        if (has(p, "l02") && !p.isCreative() && ready(p, "l02", 1800)) {
            PlayerState st = PlayerState.get(p);
            st.flightEnd = p.level().getGameTime() + 300;
            p.getAbilities().mayfly = true;
            p.getAbilities().flying = true;
            p.onUpdateAbilities();
            p.serverLevel().sendParticles(ParticleTypes.DRAGON_BREATH, p.getX(), p.getY() + 0.5, p.getZ(), 40, 0.5, 0.3, 0.5, 0.02);
            p.level().playSound(null, p.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 1f, 1.2f);
            return;
        }
        // Lướt: 4 khối về phía trước, hồi chiêu 20 giây
        if (has(p, "u04") && ready(p, "u04", 400)) {
            Vec3 look = p.getLookAngle().multiply(1, 0, 1).normalize();
            p.setDeltaMovement(look.x * 1.6, 0.15, look.z * 1.6);
            p.hurtMarked = true;
            p.serverLevel().sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 15, 0.3, 0.1, 0.3, 0.02);
            p.level().playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.8f, 1.6f);
            p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 40 + 60, 0)); // Say Xe
        }
    }

    // ------------------------------------------------------------------ G: skills

    private static void skill(ServerPlayer p) {
        PlayerState st = PlayerState.get(p);
        ServerLevel level = p.serverLevel();
        // Ngưng Đọng Thời Gian
        if (has(p, "l20") && ready(p, "l20", 3600)) {
            timeStop(p);
            return;
        }
        // Kỹ năng bị cướp
        if (!st.stolen.isEmpty() && level.getGameTime() < st.stolenUntil) {
            switch (st.stolen) {
                case "blaze" -> {
                    if (ready(p, "steal_blaze", 20)) {
                        Vec3 look = p.getLookAngle();
                        SmallFireball fb = new SmallFireball(level, p, look.x, look.y, look.z);
                        fb.setPos(p.getX() + look.x, p.getEyeY() + look.y * 0.5, p.getZ() + look.z);
                        level.addFreshEntity(fb);
                        level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1f, 1f);
                    }
                }
                case "enderman" -> {
                    if (ready(p, "steal_ender", 40)) {
                        BlockHitResult hit = level.clip(new ClipContext(p.getEyePosition(), p.getEyePosition().add(p.getLookAngle().scale(24)),
                                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                        Vec3 to = hit.getType() == HitResult.Type.MISS ? hit.getLocation()
                                : Vec3.atBottomCenterOf(hit.getBlockPos().relative(hit.getDirection()));
                        p.teleportTo(to.x, to.y, to.z);
                        p.fallDistance = 0;
                        level.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 1f);
                    }
                }
                case "creeper" -> {
                    if (ready(p, "steal_creeper", 100)) {
                        st.selfExplosionImmuneUntil = level.getGameTime() + 5;
                        level.explode(p, p.getX(), p.getY(), p.getZ(), 3f, Level.ExplosionInteraction.MOB);
                    }
                }
                default -> {
                }
            }
            return;
        }
        // Người Nhện: bắn tơ
        if (has(p, "e13") && ready(p, "e13", 100)) {
            BlockHitResult hit = level.clip(new ClipContext(p.getEyePosition(), p.getEyePosition().add(p.getLookAngle().scale(16)),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            LivingEntity target = lookTarget(p, 16);
            BlockPos at = target != null ? target.blockPosition()
                    : hit.getType() == HitResult.Type.MISS ? null : hit.getBlockPos().relative(hit.getDirection());
            if (at != null && level.getBlockState(at).canBeReplaced()) {
                level.setBlockAndUpdate(at, Blocks.COBWEB.defaultBlockState());
                BlockPos web = at.immutable();
                Scheduler.later(200, () -> {
                    if (level.getBlockState(web).is(Blocks.COBWEB)) level.removeBlock(web, false);
                });
                level.playSound(null, p.blockPosition(), SoundEvents.SPIDER_AMBIENT, SoundSource.PLAYERS, 1f, 1.4f);
            }
            if (!has(p, "r14")) return;
        }
        // Lưỡi Ếch: kéo mob nhỏ hoặc vật phẩm trong 8 khối
        if (has(p, "r14") && ready(p, "r14", 60)) {
            Entity target = lookTarget(p, 8);
            if (target == null || target.getBbWidth() > 1.0f) {
                ItemEntity best = null;
                double bd = 64;
                for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(8))) {
                    double d = ie.distanceToSqr(p);
                    if (d < bd) {
                        bd = d;
                        best = ie;
                    }
                }
                target = best;
            }
            if (target != null) {
                Vec3 pull = p.position().subtract(target.position()).normalize().scale(1.2).add(0, 0.3, 0);
                target.setDeltaMovement(pull);
                target.hurtMarked = true;
                level.playSound(null, p.blockPosition(), SoundEvents.FROG_TONGUE, SoundSource.PLAYERS, 1f, 1f);
            }
        }
    }

    private static LivingEntity lookTarget(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestDot = 0.95;
        for (LivingEntity le : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range), x -> x != p && x.isAlive())) {
            Vec3 to = le.getEyePosition().subtract(eye);
            double dist = to.length();
            if (dist > range) continue;
            double dot = to.normalize().dot(look);
            if (dot > bestDot && p.hasLineOfSight(le)) {
                bestDot = dot;
                best = le;
            }
        }
        return best;
    }

    private static void timeStop(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        AABB box = p.getBoundingBox().inflate(20);
        List<Mob> mobs = new ArrayList<>();
        for (Mob m : level.getEntitiesOfClass(Mob.class, box, x -> !x.isNoAi())) {
            m.setNoAi(true);
            m.setDeltaMovement(Vec3.ZERO);
            mobs.add(m);
        }
        List<Projectile> projs = new ArrayList<>();
        List<Vec3> speeds = new ArrayList<>();
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> !x.isNoGravity())) {
            speeds.add(pr.getDeltaMovement());
            pr.setDeltaMovement(Vec3.ZERO);
            pr.setNoGravity(true);
            projs.add(pr);
        }
        level.playSound(null, p.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.5f, 0.5f);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 200, 6, 3, 6, 0.05);
        p.server.getPlayerList().broadcastSystemMessage(
                Component.translatable("msg.wildcard.timestop", p.getDisplayName()).withStyle(ChatFormatting.AQUA), false);
        // keep projectiles still while frozen
        for (int t = 1; t < 120; t += 5) {
            Scheduler.later(t, () -> projs.forEach(pr -> pr.setDeltaMovement(Vec3.ZERO)));
        }
        Scheduler.later(120, () -> {
            for (Mob m : mobs) if (m.isAlive()) m.setNoAi(false);
            for (int i = 0; i < projs.size(); i++) {
                Projectile pr = projs.get(i);
                if (pr.isAlive()) {
                    pr.setNoGravity(false);
                    pr.setDeltaMovement(speeds.get(i));
                }
            }
            level.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.6f);
            // Cái Giá Thời Gian: chính bạn bị đóng băng 3 giây
            if (p.isAlive()) {
                PlayerState.get(p).timeStopSelfFreeze = level.getGameTime() + 60;
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 6));
                p.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 60, 4));
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 4));
            }
        });
    }

    // ------------------------------------------------------------------ B: pocket ender chest

    private static void ender(ServerPlayer p) {
        if (!has(p, "u20")) return;
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> ChestMenu.threeRows(id, inv, pl.getEnderChestInventory()),
                Component.translatable("container.enderchest")));
        p.level().playSound(null, p.blockPosition(), SoundEvents.ENDER_CHEST_OPEN, SoundSource.PLAYERS, 0.8f, 1f);
        // Khách Không Mời
        Endermite mite = EntityType.ENDERMITE.create(p.serverLevel());
        if (mite != null) {
            mite.moveTo(p.getX() + 1, p.getY(), p.getZ() + 1, 0, 0);
            p.serverLevel().addFreshEntity(mite);
        }
    }

    // ------------------------------------------------------------------ right click: fan

    private static void fan(ServerPlayer p) {
        if (!has(p, "e11") || !p.getMainHandItem().isEmpty() || !ready(p, "e11", 200)) return;
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(6), x -> x != p)) {
            Vec3 to = le.position().add(0, le.getBbHeight() / 2, 0).subtract(eye);
            if (to.length() > 6 || to.normalize().dot(look) < 0.5) continue;
            Vec3 push = to.normalize().scale(2.0).add(0, 0.4, 0);
            le.setDeltaMovement(push);
            le.hurtMarked = true;
        }
        for (int i = 1; i <= 6; i++) {
            Vec3 at = eye.add(look.scale(i));
            level.sendParticles(ParticleTypes.CLOUD, at.x, at.y, at.z, 4, 0.3, 0.3, 0.3, 0.05);
        }
        level.playSound(null, p.blockPosition(), SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 1f, 1.5f);
        // Phản Lực: bạn bị đẩy lùi 3 khối
        p.setDeltaMovement(p.getDeltaMovement().add(look.scale(-0.9)));
        p.hurtMarked = true;
    }

    private Abilities() {}
}
