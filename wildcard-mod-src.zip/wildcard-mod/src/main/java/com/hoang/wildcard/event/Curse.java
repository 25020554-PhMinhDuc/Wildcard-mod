package com.hoang.wildcard.event;

import com.hoang.wildcard.Config;
import com.hoang.wildcard.WildcardMod;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/**
 * v7.1 "Lời Nguyền Wildcard": every 3rd night (config) and the night after it, monsters get +25% max health and
 * +15% damage. Ends when the second night is over. Nights are counted from the start of the world (night 1 is the
 * first night), so nights 3-4, 6-7, 9-10... are cursed with the default settings.
 */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class Curse {
    private static final String TAG = "wildcard_cursed";
    private static final UUID HP_ID = UUID.fromString("6f1c2a0e-7b1d-4c55-9a3e-1d2b7c4e5a01");
    private static final UUID DMG_ID = UUID.fromString("6f1c2a0e-7b1d-4c55-9a3e-1d2b7c4e5a02");
    private static long announced = -1;
    private static boolean wasActive;
    private static long forcedNight = -1;

    /** Night number (1 = first night) of the overworld right now, or -1 during the day. */
    static long nightNumber(ServerLevel ow) {
        long dt = ow.getDayTime() % 24000;
        if (dt < 13000 || dt >= 23000) return -1;
        return ow.getDayTime() / 24000 + 1;
    }

    /** Which night of the curse this is (1 or 2 with defaults), or 0 when the night is not cursed. */
    static int cursedIndex(long night) {
        if (night < 0) return 0;
        if (night == forcedNight) return 1;
        int every = Config.CURSE_EVERY.get(), len = Config.CURSE_NIGHTS.get();
        if (every <= 0 || night < every) return 0;
        long k = night % every;
        return k < len ? (int) k + 1 : 0;
    }

    public static boolean active(ServerLevel ow) {
        return cursedIndex(nightNumber(ow)) > 0;
    }

    /** /wildcard curse: curse the current (or coming) night right away. */
    public static void force(MinecraftServer server) {
        ServerLevel ow = server.overworld();
        long n = nightNumber(ow);
        forcedNight = n > 0 ? n : ow.getDayTime() / 24000 + 1;
        announced = -1;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer() == null) return;
        ServerLevel ow = e.getServer().overworld();
        if (ow.getGameTime() % 20 != 0) return;
        long night = nightNumber(ow);
        int idx = cursedIndex(night);
        if (idx > 0 && announced != night) {
            announced = night;
            wasActive = true;
            int len = night == forcedNight ? 1 : Math.max(1, Config.CURSE_NIGHTS.get());
            Component title = Component.translatable("event.wildcard.curse.title").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD);
            Component sub = Component.translatable("event.wildcard.curse.sub", hpPct(), dmgPct()).withStyle(ChatFormatting.RED);
            for (ServerPlayer p : e.getServer().getPlayerList().getPlayers()) {
                p.connection.send(new ClientboundSetTitleTextPacket(title));
                p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
                p.sendSystemMessage(Component.translatable("event.wildcard.curse.chat", hpPct(), dmgPct(), idx, len).withStyle(ChatFormatting.RED));
                p.playNotifySound(SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 0.5f, 0.6f);
            }
            for (ServerLevel l : e.getServer().getAllLevels())
                for (Entity en : l.getAllEntities()) if (en instanceof Mob m && m instanceof Enemy) curse(m);
        } else if (idx == 0 && wasActive) {
            wasActive = false;
            if (night < 0 || night != forcedNight) forcedNight = -1;
            for (ServerPlayer p : e.getServer().getPlayerList().getPlayers())
                p.sendSystemMessage(Component.translatable("event.wildcard.curse.end").withStyle(ChatFormatting.GREEN));
            for (ServerLevel l : e.getServer().getAllLevels())
                for (Entity en : l.getAllEntities()) if (en instanceof Mob m && m.getTags().contains(TAG)) lift(m);
        }
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof Mob m)) return;
        ServerLevel ow = ((ServerLevel) e.getLevel()).getServer().overworld();
        if (m instanceof Enemy && active(ow)) curse(m);
        else if (m.getTags().contains(TAG) && !active(ow)) lift(m); // loaded back after the curse ended
    }

    private static int hpPct() { return (int) Math.round(Config.CURSE_HP.get() * 100); }
    private static int dmgPct() { return (int) Math.round(Config.CURSE_DAMAGE.get() * 100); }

    private static void curse(Mob m) {
        if (m.getTags().contains(TAG)) return;
        m.addTag(TAG);
        boolean full = m.getHealth() >= m.getMaxHealth();
        mod(m, Attributes.MAX_HEALTH, HP_ID, "wildcard curse hp", Config.CURSE_HP.get());
        mod(m, Attributes.ATTACK_DAMAGE, DMG_ID, "wildcard curse dmg", Config.CURSE_DAMAGE.get());
        if (full) m.setHealth(m.getMaxHealth());
    }

    private static void lift(Mob m) {
        m.removeTag(TAG);
        for (Attribute a : new Attribute[]{Attributes.MAX_HEALTH, Attributes.ATTACK_DAMAGE}) {
            AttributeInstance ai = m.getAttribute(a);
            if (ai == null) continue;
            ai.removeModifier(a == Attributes.MAX_HEALTH ? HP_ID : DMG_ID);
        }
        if (m.getHealth() > m.getMaxHealth()) m.setHealth(m.getMaxHealth());
    }

    private static void mod(Mob m, Attribute a, UUID id, String name, double v) {
        AttributeInstance ai = m.getAttribute(a);
        if (ai == null || v == 0 || ai.getModifier(id) != null) return;
        ai.addPermanentModifier(new AttributeModifier(id, name, v, AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    private Curse() {}
}
