package com.hoang.wildcard;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> REG = DeferredRegister.create(ForgeRegistries.ITEMS, WildcardMod.MODID);
    /** Card that falls during the Card Rain event (NBT "card" = card id). */
    public static final RegistryObject<Item> CARD = REG.register("card", () -> new CardItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static void register(IEventBus bus) {
        REG.register(bus);
    }

    private ModItems() {}
}
