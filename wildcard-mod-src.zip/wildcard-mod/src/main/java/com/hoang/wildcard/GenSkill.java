package com.hoang.wildcard;

/**
 * Generated skill: {@code kind} (bolt, nova, heal, buff, curse, dash, leap, blink, shield, feast, summon, meteor,
 * pull, taunt, sigma, sus), element for the visuals, and two numbers whose meaning depends on the kind.
 * Run by effects/GenSkills.
 */
public record GenSkill(String kind, String element, double a, double b, String eff, int amp) {}
