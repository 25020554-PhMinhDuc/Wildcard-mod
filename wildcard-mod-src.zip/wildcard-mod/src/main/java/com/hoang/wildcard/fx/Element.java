package com.hoang.wildcard.fx;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/** Magic school of a skill: decides its particles, rune colour and cast sound. */
public enum Element {
    ARCANE(0xB98CFF, 1.2f),
    FIRE(0xFFA52E, 0.9f),
    FROST(0x8FD8FF, 1.5f),
    STORM(0xFFF36A, 1.7f),
    BLOOD(0xE5303C, 0.7f),
    VOID(0x9A5AE0, 0.6f),
    HOLY(0xFFE680, 1.9f),
    EARTH(0xB08A5A, 0.6f),
    WIND(0xBFF5E8, 1.4f);

    public final int rgb;
    public final float pitch;

    Element(int rgb, float pitch) {
        this.rgb = rgb;
        this.pitch = pitch;
    }

    public String key() { return name().toLowerCase(java.util.Locale.ROOT); }

    public SimpleParticleType rune() { return ModParticles.RUNE.get(this).get(); }

    public static Element of(double ordinal) {
        Element[] v = values();
        int i = (int) Math.round(ordinal);
        return i >= 0 && i < v.length ? v[i] : ARCANE;
    }

    /** Sound layered on top of the generic cast sound. */
    public SoundEvent accent() {
        return switch (this) {
            case FIRE -> SoundEvents.BLAZE_SHOOT;
            case FROST -> SoundEvents.AMETHYST_BLOCK_CHIME;
            case STORM -> SoundEvents.FIREWORK_ROCKET_TWINKLE;
            case BLOOD -> SoundEvents.WARDEN_HEARTBEAT;
            case VOID -> SoundEvents.ENDERMAN_TELEPORT;
            case HOLY -> SoundEvents.BEACON_ACTIVATE;
            case EARTH -> SoundEvents.ROOTED_DIRT_BREAK;
            case WIND -> SoundEvents.PHANTOM_FLAP;
            default -> SoundEvents.ENCHANTMENT_TABLE_USE;
        };
    }
}
