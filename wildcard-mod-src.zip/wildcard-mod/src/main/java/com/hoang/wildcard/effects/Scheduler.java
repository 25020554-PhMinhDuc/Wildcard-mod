package com.hoang.wildcard.effects;

import com.hoang.wildcard.WildcardMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny server-side delayed task runner. */
@Mod.EventBusSubscriber(modid = WildcardMod.MODID)
public final class Scheduler {
    private record Task(long due, Runnable run) {}

    private static final List<Task> TASKS = new ArrayList<>();
    private static long tick;

    public static void later(int ticks, Runnable r) {
        TASKS.add(new Task(tick + Math.max(1, ticks), r));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        tick++;
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (t.due <= tick) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) {
            try {
                t.run.run();
            } catch (Exception ex) {
                WildcardMod.LOG.error("Wildcard scheduled task failed", ex);
            }
        }
    }

    @SubscribeEvent
    public static void onStop(ServerStoppedEvent e) {
        TASKS.clear();
    }

    private Scheduler() {}
}
